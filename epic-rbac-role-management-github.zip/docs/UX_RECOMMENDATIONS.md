# User Experience Recommendations

Suggestions to make the Epic RBAC Role Management app more user-friendly. Some have been implemented; others are optional follow-ups.

## Implemented in this pass

- **Loading state on Roles** – "Loading roles…" shows on first load instead of an empty table.
- **Export feedback** – After "Export to CSV", an inline message shows "Exported N role(s)" for a few seconds.
- **Admin section descriptions** – Short helper text under each Admin section (Roles, Saved presets, Backup & Restore, Data tools) so users know what each action does.

---

## Further recommendations

### Feedback and clarity

- **Destructive confirmations** – For Delete, Restore, and Cleanup, keep confirmations but use clear wording: e.g. "This will replace all data. Type RESTORE to continue" for extra safety.
- **Empty states** – When a table is empty (no roles, no job codes, etc.), show a single line: "No roles yet. Use **Import from CSV** or **Add New Role** to get started" with the actions as buttons or links where possible.

### Navigation and context

- **Page/section titles** – Ensure each main view (Roles Management, Job Categories, Admin, etc.) has a visible `<h2>` or title so users always know where they are.
- **Tooltips** – Add `title` (or a proper tooltip component) on abbreviations and icon-only actions: e.g. "SER = Service Request", "EMP = …", "Export for SP = Export for SailPoint".

### Forms and validation

- **Inline validation** – For Job Code (4 chars), RBAC Code, etc., show a short error under the field on blur or submit instead of only on submit (e.g. "Job code must be 4 characters").
- **Unsaved changes** – When the user has edited a role (or form) and tries to leave or close without saving, show: "You have unsaved changes. Leave anyway?" (e.g. `beforeunload` or when closing the form).

### Performance and loading

- **Loading on Reload** – When the user clicks Reload (e.g. from Admin) and then opens Roles, show "Loading roles…" again if a fresh fetch is in progress (you already have `rolesLoading`; ensure it’s set when reload is triggered from Admin if you add a global reload).
- **Import/Export progress** – For very large imports/exports, consider a progress bar or step text (e.g. "Exported 500 / 2000 roles") if the operation can be chunked.

### Accessibility

- **Focus management** – Role form and Job Code form move focus to the first input when opened. Returning focus to the trigger button on close is optional.
- **Labels and ARIA** – Ensure every form field has a visible `<label>` or `aria-label` and that buttons that only show an icon have `aria-label` or `title`.

### Small polish

- **Consistent primary action** – Use the same position (e.g. primary action on the right) for "Save", "OK", "Export" across the app.
- **Current user in header** – When an audit user is selected, show "Signed in as: [username]" or similar in the header so it’s obvious who is used for audit.

---

## Priority overview

| Priority | Suggestion |
|----------|------------|
| High     | ~~Success toasts~~; ~~sticky table header~~; ~~unsaved-changes warning~~ (done) |
| Medium   | Inline validation; clearer empty states; tooltips on abbreviations |
| Lower    | ~~Escape + focus~~ (done); progress for huge exports |

You can tackle these incrementally; the items in the "Implemented" section are already in place.
