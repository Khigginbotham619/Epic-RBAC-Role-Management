-- Epic RBAC Role Management - MSSQL table creation script (NORMALIZED)
-- Run this in your target database when using datastore=MSSQL.
-- All tables use explicit columns instead of JSON blob storage.

-- Users (audit user dropdown): fixed columns (unchanged)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'users')
BEGIN
  CREATE TABLE users (
    id NVARCHAR(36) NOT NULL PRIMARY KEY,
    username NVARCHAR(255) NOT NULL,
    passwordHash NVARCHAR(255) NOT NULL DEFAULT '',
    createdAt DATETIME2 NOT NULL DEFAULT GETUTCDATE()
  );
  CREATE INDEX IX_users_username ON users(username);
END
GO

-- Roles: one row per role with explicit columns
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'roles')
BEGIN
  CREATE TABLE roles (
    id NVARCHAR(36) NOT NULL PRIMARY KEY,
    rbacCode NVARCHAR(255) NOT NULL DEFAULT '',
    deptCodeId NVARCHAR(255) NOT NULL DEFAULT '',
    department NVARCHAR(255) NOT NULL DEFAULT '',
    jobCodeId NVARCHAR(50) NOT NULL DEFAULT '',
    jobTitle NVARCHAR(500) NOT NULL DEFAULT '',
    jobCategory NVARCHAR(255) NOT NULL DEFAULT '',
    linkedRoleTemplateId NVARCHAR(MAX) NOT NULL DEFAULT '',
    linkedRoleTemplateName NVARCHAR(MAX) NOT NULL DEFAULT '',
    templateDisplayTitle NVARCHAR(MAX) NOT NULL DEFAULT '',
    subtemplateId NVARCHAR(MAX) NOT NULL DEFAULT '',
    subtemplateDescription NVARCHAR(MAX) NOT NULL DEFAULT '',
    empNeeded NVARCHAR(10) NOT NULL DEFAULT '',
    slaNeeded NVARCHAR(10) NOT NULL DEFAULT '',
    slaBlueprintId NVARCHAR(255) NOT NULL DEFAULT '',
    blueprintName NVARCHAR(500) NOT NULL DEFAULT '',
    trainingTrack NVARCHAR(500) NOT NULL DEFAULT '',
    trainingTrack2 NVARCHAR(500) NOT NULL DEFAULT '',
    trainingTrack3 NVARCHAR(500) NOT NULL DEFAULT '',
    trainingTrack4 NVARCHAR(500) NOT NULL DEFAULT '',
    trainingTrack5 NVARCHAR(500) NOT NULL DEFAULT '',
    trainingTrack6 NVARCHAR(500) NOT NULL DEFAULT '',
    sailpointRole NVARCHAR(500) NOT NULL DEFAULT '',
    affiliate NVARCHAR(10) NOT NULL DEFAULT '',
    publishToSailpoint NVARCHAR(10) NOT NULL DEFAULT 'Yes',
    status NVARCHAR(50) NOT NULL DEFAULT 'Active',
    lastEditChangeControlDateReason NVARCHAR(MAX) NOT NULL DEFAULT ''
  );
END
GO

-- Roles: template display title (aligned with Template Links)
IF OBJECT_ID(N'roles', N'U') IS NOT NULL
  AND COL_LENGTH('roles', 'templateDisplayTitle') IS NULL
BEGIN
  ALTER TABLE roles ADD templateDisplayTitle NVARCHAR(MAX) NOT NULL DEFAULT '';
END
GO

-- Roles: publish to SailPoint flag (default Yes for all existing rows)
IF OBJECT_ID(N'roles', N'U') IS NOT NULL
  AND COL_LENGTH('roles', 'publishToSailpoint') IS NULL
BEGIN
  ALTER TABLE roles ADD publishToSailpoint NVARCHAR(10) NOT NULL DEFAULT 'Yes';
END
GO

-- Roles: Affiliate flag
IF OBJECT_ID(N'roles', N'U') IS NOT NULL
  AND COL_LENGTH('roles', 'affiliate') IS NULL
BEGIN
  ALTER TABLE roles ADD affiliate NVARCHAR(10) NOT NULL DEFAULT '';
END
GO

IF OBJECT_ID(N'roles', N'U') IS NOT NULL
BEGIN
  UPDATE roles
  SET publishToSailpoint = 'Yes'
  WHERE ISNULL(LTRIM(RTRIM(publishToSailpoint)), '') = '';
END
GO

-- Audit log: normalized columns; oldData/newData remain JSON (entity snapshots)
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'audit_log')
BEGIN
  CREATE TABLE audit_log (
    id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
    action NVARCHAR(50) NOT NULL DEFAULT '',
    log_timestamp NVARCHAR(50) NOT NULL DEFAULT '',
    audit_user NVARCHAR(255) NOT NULL DEFAULT '',
    roleId NVARCHAR(36) NOT NULL DEFAULT '',
    entityType NVARCHAR(50) NOT NULL DEFAULT '',
    entityId NVARCHAR(36) NOT NULL DEFAULT '',
    oldData NVARCHAR(MAX) NULL,
    newData NVARCHAR(MAX) NULL,
    import_count INT NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETUTCDATE()
  );
END
GO

-- Job categories: one row per category with explicit columns
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'job_categories')
BEGIN
  CREATE TABLE job_categories (
    id NVARCHAR(36) NOT NULL PRIMARY KEY,
    jobCategoryId NVARCHAR(255) NOT NULL DEFAULT '',
    jobCategoryName NVARCHAR(500) NOT NULL DEFAULT '',
    organizationJobCategoryScope NVARCHAR(500) NOT NULL DEFAULT '',
    description NVARCHAR(MAX) NOT NULL DEFAULT '',
    owningApplication NVARCHAR(500) NOT NULL DEFAULT '',
    impactedApplications NVARCHAR(MAX) NOT NULL DEFAULT '',
    owningWorkgroup NVARCHAR(500) NOT NULL DEFAULT '',
    otherInterestedWorkgroups NVARCHAR(MAX) NOT NULL DEFAULT '',
    needEMP NVARCHAR(10) NOT NULL DEFAULT '',
    needSER NVARCHAR(10) NOT NULL DEFAULT '',
    linkableTemplateId NVARCHAR(MAX) NOT NULL DEFAULT '',
    linkableTemplateName NVARCHAR(MAX) NOT NULL DEFAULT '',
    subtemplatesId NVARCHAR(MAX) NOT NULL DEFAULT '',
    subtemplatesName NVARCHAR(MAX) NOT NULL DEFAULT '',
    blueprintId NVARCHAR(255) NOT NULL DEFAULT '',
    blueprintName NVARCHAR(500) NOT NULL DEFAULT '',
    trainingTrack1 NVARCHAR(500) NOT NULL DEFAULT '',
    trainingTrack2 NVARCHAR(500) NOT NULL DEFAULT '',
    trainingTrack3 NVARCHAR(500) NOT NULL DEFAULT '',
    trainingTrack4 NVARCHAR(500) NOT NULL DEFAULT '',
    trainingTrack5 NVARCHAR(500) NOT NULL DEFAULT '',
    trainingTrack6 NVARCHAR(500) NOT NULL DEFAULT '',
    sailpointRole NVARCHAR(500) NOT NULL DEFAULT '',
    sailpointRoleReview NVARCHAR(50) NOT NULL DEFAULT '',
    preLiveDayInTheLifeActivity NVARCHAR(MAX) NOT NULL DEFAULT '',
    postLiveDayInTheLifeActivity NVARCHAR(MAX) NOT NULL DEFAULT '',
    userSettingsLab NVARCHAR(MAX) NOT NULL DEFAULT '',
    status NVARCHAR(50) NOT NULL DEFAULT 'Active',
    lastEditDateReasonInitials NVARCHAR(MAX) NOT NULL DEFAULT ''
  );
END
GO

-- Job codes: one row per job code with explicit columns
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'job_codes')
BEGIN
  CREATE TABLE job_codes (
    id NVARCHAR(36) NOT NULL PRIMARY KEY,
    jobCode NVARCHAR(10) NOT NULL DEFAULT '',
    jobTitle NVARCHAR(500) NOT NULL DEFAULT '',
    currentStatus NVARCHAR(50) NOT NULL DEFAULT 'Active'
  );
  CREATE INDEX IX_job_codes_jobCode ON job_codes(jobCode);
END
GO

-- Departments: one row per department with explicit columns
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'departments')
BEGIN
  CREATE TABLE departments (
    id NVARCHAR(36) NOT NULL PRIMARY KEY,
    deptId NVARCHAR(255) NOT NULL DEFAULT '',
    deptDescription NVARCHAR(500) NOT NULL DEFAULT ''
  );
  CREATE INDEX IX_departments_deptId ON departments(deptId);
END
GO

-- Template Links: one row per template-subtemplate mapping
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'template_links')
BEGIN
  CREATE TABLE template_links (
    id NVARCHAR(36) NOT NULL PRIMARY KEY,
    userRecordType NVARCHAR(100) NOT NULL DEFAULT 'Linkable Template',
    templateId NVARCHAR(255) NOT NULL DEFAULT '',
    templateName NVARCHAR(500) NOT NULL DEFAULT '',
    primaryTemplateOwner NVARCHAR(MAX) NOT NULL DEFAULT '',
    templateDisplayTitle NVARCHAR(MAX) NOT NULL DEFAULT '',
    subtemplateId NVARCHAR(255) NOT NULL DEFAULT '',
    subtemplateName NVARCHAR(500) NOT NULL DEFAULT '',
    currentStatus NVARCHAR(50) NOT NULL DEFAULT 'Active'
  );
  CREATE INDEX IX_template_links_templateId ON template_links(templateId);
END
GO

-- Sailpoint Roles: one row per role template with explicit columns
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'sailpoint_roles')
BEGIN
  CREATE TABLE sailpoint_roles (
    id NVARCHAR(36) NOT NULL PRIMARY KEY,
    sailpointRole NVARCHAR(500) NOT NULL DEFAULT '',
    status NVARCHAR(50) NOT NULL DEFAULT 'Active',
    templates NVARCHAR(MAX) NOT NULL DEFAULT '',
    subtemplates NVARCHAR(MAX) NOT NULL DEFAULT '',
    requestable NVARCHAR(100) NOT NULL DEFAULT '',
    matchedAccessProfile NVARCHAR(MAX) NOT NULL DEFAULT '',
    entitlementType NVARCHAR(255) NOT NULL DEFAULT '',
    instructions NVARCHAR(MAX) NOT NULL DEFAULT '',
    description NVARCHAR(MAX) NOT NULL DEFAULT '',
    entitlements NVARCHAR(MAX) NOT NULL DEFAULT ''
  );
  CREATE INDEX IX_sailpoint_roles_sailpointRole ON sailpoint_roles(sailpointRole);
END
GO

IF OBJECT_ID(N'sailpoint_roles', N'U') IS NOT NULL
  AND COL_LENGTH('sailpoint_roles', 'status') IS NULL
BEGIN
  ALTER TABLE sailpoint_roles ADD status NVARCHAR(50) NOT NULL DEFAULT 'Active';
END
GO

IF OBJECT_ID(N'sailpoint_roles', N'U') IS NOT NULL
  AND COL_LENGTH('sailpoint_roles', 'templates') IS NULL
BEGIN
  ALTER TABLE sailpoint_roles ADD templates NVARCHAR(MAX) NOT NULL DEFAULT '';
END
GO

IF OBJECT_ID(N'sailpoint_roles', N'U') IS NOT NULL
  AND COL_LENGTH('sailpoint_roles', 'subtemplates') IS NULL
BEGIN
  ALTER TABLE sailpoint_roles ADD subtemplates NVARCHAR(MAX) NOT NULL DEFAULT '';
END
GO

IF OBJECT_ID(N'sailpoint_roles', N'U') IS NOT NULL
  AND COL_LENGTH('sailpoint_roles', 'requestable') IS NULL
BEGIN
  ALTER TABLE sailpoint_roles ADD requestable NVARCHAR(100) NOT NULL DEFAULT '';
END
GO

IF OBJECT_ID(N'sailpoint_roles', N'U') IS NOT NULL
  AND COL_LENGTH('sailpoint_roles', 'matchedAccessProfile') IS NULL
BEGIN
  ALTER TABLE sailpoint_roles ADD matchedAccessProfile NVARCHAR(MAX) NOT NULL DEFAULT '';
END
GO

IF OBJECT_ID(N'sailpoint_roles', N'U') IS NOT NULL
  AND COL_LENGTH('sailpoint_roles', 'entitlementType') IS NULL
BEGIN
  ALTER TABLE sailpoint_roles ADD entitlementType NVARCHAR(255) NOT NULL DEFAULT '';
END
GO

IF OBJECT_ID(N'sailpoint_roles', N'U') IS NOT NULL
  AND COL_LENGTH('sailpoint_roles', 'instructions') IS NULL
BEGIN
  ALTER TABLE sailpoint_roles ADD instructions NVARCHAR(MAX) NOT NULL DEFAULT '';
END
GO

IF OBJECT_ID(N'sailpoint_roles', N'U') IS NOT NULL
BEGIN
  UPDATE sailpoint_roles
  SET templates = description
  WHERE ISNULL(LTRIM(RTRIM(templates)), '') = '' AND ISNULL(LTRIM(RTRIM(description)), '') <> '';
  UPDATE sailpoint_roles
  SET instructions = entitlements
  WHERE ISNULL(LTRIM(RTRIM(instructions)), '') = '' AND ISNULL(LTRIM(RTRIM(entitlements)), '') <> '';
END
GO

-- Blueprints: one row per blueprint with explicit columns
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'blueprints')
BEGIN
  CREATE TABLE blueprints (
    id NVARCHAR(36) NOT NULL PRIMARY KEY,
    blueprintId NVARCHAR(255) NOT NULL DEFAULT '',
    blueprintName NVARCHAR(500) NOT NULL DEFAULT ''
  );
  CREATE INDEX IX_blueprints_blueprintId ON blueprints(blueprintId);
END
GO

-- Training tracks: reference table for role dropdown with explicit columns
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'training_tracks')
BEGIN
  CREATE TABLE training_tracks (
    id NVARCHAR(36) NOT NULL PRIMARY KEY,
    trackName NVARCHAR(500) NOT NULL DEFAULT ''
  );
END
GO

-- SP Export Table: persisted export snapshot for SailPoint handoff
IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'sp_export_table')
BEGIN
  CREATE TABLE sp_export_table (
    id NVARCHAR(36) NOT NULL PRIMARY KEY,
    rbacCode NVARCHAR(255) NOT NULL DEFAULT '',
    template NVARCHAR(MAX) NOT NULL DEFAULT '',
    serNeeded NVARCHAR(50) NOT NULL DEFAULT '',
    serBlueprintId NVARCHAR(255) NOT NULL DEFAULT '',
    affiliate NVARCHAR(10) NOT NULL DEFAULT ''
  );
  CREATE INDEX IX_sp_export_table_rbacCode ON sp_export_table(rbacCode);
END
GO
