/**
 * Migrate MSSQL tables from JSON blob storage to normalized columns.
 *
 * This script:
 *   1. Reads all data from the old JSON-blob tables (id + data NVARCHAR(MAX))
 *   2. Drops the old tables
 *   3. Creates new tables with explicit columns
 *   4. Inserts the data into the normalized columns (via bulk copy)
 *
 * Prerequisites:
 *   - datastore=MSSQL and MSSQL_connectionstring set in .env
 *   - Existing JSON-blob tables in the database
 *
 * Usage: node scripts/migrate-to-normalized.js
 *
 * The script is idempotent: if tables already have normalized columns (no 'data'
 * column), it will skip migration for those tables.
 */
require('dotenv').config();
const sql = require('mssql');

function getConnectionConfig() {
  let connStr = process.env.MSSQL_connectionstring || process.env.MSSQL_connectionString || '';
  connStr = connStr.trim();
  if (connStr.startsWith('"') && connStr.endsWith('"')) {
    connStr = connStr.slice(1, -1).trim();
  }
  if (!connStr) {
    throw new Error('MSSQL_connectionstring is required when datastore=MSSQL');
  }
  connStr = connStr.replace(/(^|;)User=/gi, '$1User Id=');
  return connStr;
}

function parseConnectionString(connStr) {
  const config = { options: {} };
  const pairs = connStr.split(';').filter(s => s.trim());
  for (const pair of pairs) {
    const idx = pair.indexOf('=');
    if (idx === -1) continue;
    const key = pair.slice(0, idx).trim().toLowerCase();
    const value = pair.slice(idx + 1).trim();
    switch (key) {
      case 'server': {
        const parts = value.split(',');
        config.server = parts[0];
        if (parts[1]) config.port = parseInt(parts[1], 10);
        break;
      }
      case 'database': config.database = value; break;
      case 'user':
      case 'user id': config.user = value; break;
      case 'password': config.password = value; break;
      case 'trustservercertificate':
        config.options.trustServerCertificate = value.toLowerCase() === 'true';
        break;
      case 'encrypt':
        config.options.encrypt = value.toLowerCase() === 'true';
        break;
    }
  }
  return config;
}

async function hasDataColumn(pool, tableName) {
  const result = await pool.request()
    .input('table', sql.NVarChar(255), tableName)
    .input('column', sql.NVarChar(255), 'data')
    .query(`SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @table AND COLUMN_NAME = @column`);
  return (result.recordset || []).length > 0;
}

function parseJson(str) {
  if (!str) return {};
  try {
    return typeof str === 'string' ? JSON.parse(str) : str;
  } catch (_) {
    return {};
  }
}

async function readJsonTable(pool, tableName) {
  const result = await pool.request().query(`SELECT id, data FROM ${tableName} ORDER BY id`);
  return (result.recordset || []).map(r => {
    const obj = parseJson(r.data);
    return { ...obj, id: obj.id || r.id };
  });
}

async function readAuditJsonTable(pool) {
  const result = await pool.request().query('SELECT id, data, created_at FROM audit_log ORDER BY id');
  return (result.recordset || []).map(r => {
    const obj = parseJson(r.data);
    return { ...obj, _created_at: r.created_at };
  });
}

// ----- DDL for normalized tables -----

const CREATE_ROLES = `
CREATE TABLE roles (
  id NVARCHAR(36) NOT NULL PRIMARY KEY,
  rbacCode NVARCHAR(255) NOT NULL DEFAULT '',
  deptCodeId NVARCHAR(255) NOT NULL DEFAULT '',
  department NVARCHAR(255) NOT NULL DEFAULT '',
  jobCodeId NVARCHAR(50) NOT NULL DEFAULT '',
  jobTitle NVARCHAR(500) NOT NULL DEFAULT '',
  jobCategory NVARCHAR(255) NOT NULL DEFAULT '',
  linkedRoleTemplateId NVARCHAR(MAX) NOT NULL DEFAULT '',
  linkedRoleTemplateName NVARCHAR(MAX) NOT NULL DEFAULT '',
  templateDisplayTitle NVARCHAR(MAX) NOT NULL DEFAULT '',
  subtemplateId NVARCHAR(MAX) NOT NULL DEFAULT '',
  subtemplateDescription NVARCHAR(MAX) NOT NULL DEFAULT '',
  empNeeded NVARCHAR(10) NOT NULL DEFAULT '',
  slaNeeded NVARCHAR(10) NOT NULL DEFAULT '',
  slaBlueprintId NVARCHAR(255) NOT NULL DEFAULT '',
  blueprintName NVARCHAR(500) NOT NULL DEFAULT '',
  trainingTrack NVARCHAR(500) NOT NULL DEFAULT '',
  trainingTrack2 NVARCHAR(500) NOT NULL DEFAULT '',
  trainingTrack3 NVARCHAR(500) NOT NULL DEFAULT '',
  trainingTrack4 NVARCHAR(500) NOT NULL DEFAULT '',
  trainingTrack5 NVARCHAR(500) NOT NULL DEFAULT '',
  trainingTrack6 NVARCHAR(500) NOT NULL DEFAULT '',
  sailpointRole NVARCHAR(500) NOT NULL DEFAULT '',
  status NVARCHAR(50) NOT NULL DEFAULT 'Active',
  lastEditChangeControlDateReason NVARCHAR(MAX) NOT NULL DEFAULT ''
)`;

const CREATE_AUDIT_LOG = `
CREATE TABLE audit_log (
  id INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
  action NVARCHAR(50) NOT NULL DEFAULT '',
  log_timestamp NVARCHAR(50) NOT NULL DEFAULT '',
  audit_user NVARCHAR(255) NOT NULL DEFAULT '',
  roleId NVARCHAR(36) NOT NULL DEFAULT '',
  entityType NVARCHAR(50) NOT NULL DEFAULT '',
  entityId NVARCHAR(36) NOT NULL DEFAULT '',
  oldData NVARCHAR(MAX) NULL,
  newData NVARCHAR(MAX) NULL,
  import_count INT NULL,
  created_at DATETIME2 NOT NULL DEFAULT GETUTCDATE()
)`;

const CREATE_JOB_CATEGORIES = `
CREATE TABLE job_categories (
  id NVARCHAR(36) NOT NULL PRIMARY KEY,
  jobCategoryId NVARCHAR(255) NOT NULL DEFAULT '',
  jobCategoryName NVARCHAR(500) NOT NULL DEFAULT '',
  organizationJobCategoryScope NVARCHAR(500) NOT NULL DEFAULT '',
  description NVARCHAR(MAX) NOT NULL DEFAULT '',
  owningApplication NVARCHAR(500) NOT NULL DEFAULT '',
  impactedApplications NVARCHAR(MAX) NOT NULL DEFAULT '',
  owningWorkgroup NVARCHAR(500) NOT NULL DEFAULT '',
  otherInterestedWorkgroups NVARCHAR(MAX) NOT NULL DEFAULT '',
  needEMP NVARCHAR(10) NOT NULL DEFAULT '',
  needSER NVARCHAR(10) NOT NULL DEFAULT '',
  linkableTemplateId NVARCHAR(MAX) NOT NULL DEFAULT '',
  linkableTemplateName NVARCHAR(MAX) NOT NULL DEFAULT '',
  subtemplatesId NVARCHAR(MAX) NOT NULL DEFAULT '',
  subtemplatesName NVARCHAR(MAX) NOT NULL DEFAULT '',
  blueprintId NVARCHAR(255) NOT NULL DEFAULT '',
  blueprintName NVARCHAR(500) NOT NULL DEFAULT '',
  trainingTrack1 NVARCHAR(500) NOT NULL DEFAULT '',
  trainingTrack2 NVARCHAR(500) NOT NULL DEFAULT '',
  trainingTrack3 NVARCHAR(500) NOT NULL DEFAULT '',
  trainingTrack4 NVARCHAR(500) NOT NULL DEFAULT '',
  trainingTrack5 NVARCHAR(500) NOT NULL DEFAULT '',
  trainingTrack6 NVARCHAR(500) NOT NULL DEFAULT '',
  sailpointRole NVARCHAR(500) NOT NULL DEFAULT '',
  sailpointRoleReview NVARCHAR(50) NOT NULL DEFAULT '',
  preLiveDayInTheLifeActivity NVARCHAR(MAX) NOT NULL DEFAULT '',
  postLiveDayInTheLifeActivity NVARCHAR(MAX) NOT NULL DEFAULT '',
  userSettingsLab NVARCHAR(MAX) NOT NULL DEFAULT '',
  status NVARCHAR(50) NOT NULL DEFAULT 'Active',
  lastEditDateReasonInitials NVARCHAR(MAX) NOT NULL DEFAULT ''
)`;

const CREATE_JOB_CODES = `
CREATE TABLE job_codes (
  id NVARCHAR(36) NOT NULL PRIMARY KEY,
  jobCode NVARCHAR(10) NOT NULL DEFAULT '',
  jobTitle NVARCHAR(500) NOT NULL DEFAULT '',
  currentStatus NVARCHAR(50) NOT NULL DEFAULT 'Active'
)`;

const CREATE_DEPARTMENTS = `
CREATE TABLE departments (
  id NVARCHAR(36) NOT NULL PRIMARY KEY,
  deptId NVARCHAR(255) NOT NULL DEFAULT '',
  deptDescription NVARCHAR(500) NOT NULL DEFAULT ''
)`;

const CREATE_SAILPOINT_ROLES = `
CREATE TABLE sailpoint_roles (
  id NVARCHAR(36) NOT NULL PRIMARY KEY,
  sailpointRole NVARCHAR(500) NOT NULL DEFAULT '',
  description NVARCHAR(MAX) NOT NULL DEFAULT '',
  entitlements NVARCHAR(MAX) NOT NULL DEFAULT ''
)`;

const CREATE_BLUEPRINTS = `
CREATE TABLE blueprints (
  id NVARCHAR(36) NOT NULL PRIMARY KEY,
  blueprintId NVARCHAR(255) NOT NULL DEFAULT '',
  blueprintName NVARCHAR(500) NOT NULL DEFAULT ''
)`;

const CREATE_TRAINING_TRACKS = `
CREATE TABLE training_tracks (
  id NVARCHAR(36) NOT NULL PRIMARY KEY,
  trackName NVARCHAR(500) NOT NULL DEFAULT ''
)`;

// ----- Column lists (must match db-mssql.js) -----

const ROLE_COLS = [
  'rbacCode', 'deptCodeId', 'department', 'jobCodeId', 'jobTitle', 'jobCategory',
  'linkedRoleTemplateId', 'linkedRoleTemplateName', 'templateDisplayTitle', 'subtemplateId', 'subtemplateDescription',
  'empNeeded', 'slaNeeded', 'slaBlueprintId', 'blueprintName',
  'trainingTrack', 'trainingTrack2', 'trainingTrack3', 'trainingTrack4', 'trainingTrack5', 'trainingTrack6', 'sailpointRole',
  'status', 'lastEditChangeControlDateReason'
];

const JOB_CAT_COLS = [
  'jobCategoryId', 'jobCategoryName', 'organizationJobCategoryScope', 'description',
  'owningApplication', 'impactedApplications', 'owningWorkgroup', 'otherInterestedWorkgroups',
  'needEMP', 'needSER',
  'linkableTemplateId', 'linkableTemplateName', 'subtemplatesId', 'subtemplatesName',
  'blueprintId', 'blueprintName',
  'trainingTrack1', 'trainingTrack2', 'trainingTrack3', 'trainingTrack4', 'trainingTrack5', 'trainingTrack6', 'sailpointRole',
  'sailpointRoleReview',
  'preLiveDayInTheLifeActivity', 'postLiveDayInTheLifeActivity', 'userSettingsLab',
  'status', 'lastEditDateReasonInitials'
];

const JOB_CODE_COLS = ['jobCode', 'jobTitle', 'currentStatus'];
const DEPT_COLS = ['deptId', 'deptDescription'];
const SAILPOINT_ROLE_COLS = ['sailpointRole', 'description', 'entitlements'];
const BLUEPRINT_COLS = ['blueprintId', 'blueprintName'];
const TRACK_COLS = ['trackName'];

function str(val) {
  return val != null ? String(val) : '';
}

function buildBulkTable(table, cols, rows) {
  const bulkTable = new sql.Table(table);
  bulkTable.create = false;
  bulkTable.columns.add('id', sql.NVarChar(36), { nullable: false });
  for (const col of cols) {
    bulkTable.columns.add(col, sql.NVarChar(sql.MAX), { nullable: false });
  }
  for (const row of rows) {
    const id = row.id || require('crypto').randomUUID();
    bulkTable.rows.add(id, ...cols.map(col => str(row[col])));
  }
  return bulkTable;
}

function buildAuditBulkTable(entries) {
  const bulkTable = new sql.Table('audit_log');
  bulkTable.create = false;
  bulkTable.columns.add('action', sql.NVarChar(50), { nullable: false });
  bulkTable.columns.add('log_timestamp', sql.NVarChar(50), { nullable: false });
  bulkTable.columns.add('audit_user', sql.NVarChar(255), { nullable: false });
  bulkTable.columns.add('roleId', sql.NVarChar(36), { nullable: false });
  bulkTable.columns.add('entityType', sql.NVarChar(50), { nullable: false });
  bulkTable.columns.add('entityId', sql.NVarChar(36), { nullable: false });
  bulkTable.columns.add('oldData', sql.NVarChar(sql.MAX), { nullable: true });
  bulkTable.columns.add('newData', sql.NVarChar(sql.MAX), { nullable: true });
  bulkTable.columns.add('import_count', sql.Int, { nullable: true });
  for (const entry of entries) {
    bulkTable.rows.add(
      str(entry.action),
      str(entry.timestamp),
      str(entry.user),
      str(entry.roleId),
      str(entry.entityType),
      str(entry.entityId),
      entry.oldData ? JSON.stringify(entry.oldData) : null,
      entry.newData ? JSON.stringify(entry.newData) : null,
      entry.count != null ? entry.count : null
    );
  }
  return bulkTable;
}

async function main() {
  if ((process.env.datastore || '').toUpperCase() !== 'MSSQL') {
    console.error('Set datastore=MSSQL and MSSQL_connectionstring in .env, then run again.');
    process.exit(1);
  }

  const connStr = getConnectionConfig();
  const config = parseConnectionString(connStr);
  config.requestTimeout = 300000;
  const pool = await sql.connect(config);

  console.log('Connected to MSSQL. Checking tables for JSON blob columns...\n');

  const tablesToMigrate = [];
  for (const t of ['roles', 'audit_log', 'job_categories', 'job_codes', 'departments', 'sailpoint_roles', 'blueprints', 'training_tracks']) {
    const hasData = await hasDataColumn(pool, t);
    if (hasData) {
      tablesToMigrate.push(t);
      console.log(`  ${t}: has 'data' column -> NEEDS MIGRATION`);
    } else {
      console.log(`  ${t}: already normalized -> skip`);
    }
  }

  if (tablesToMigrate.length === 0) {
    console.log('\nAll tables are already normalized. Nothing to do.');
    await pool.close();
    return;
  }

  console.log(`\n--- Reading existing data from ${tablesToMigrate.length} table(s) ---\n`);

  const data = {};
  for (const t of tablesToMigrate) {
    if (t === 'audit_log') {
      data[t] = await readAuditJsonTable(pool);
    } else {
      data[t] = await readJsonTable(pool, t);
    }
    console.log(`  ${t}: ${data[t].length} rows read`);
  }

  console.log('\n--- Migrating tables (drop -> create -> bulk insert) ---\n');

  const ddlMap = {
    roles: CREATE_ROLES,
    audit_log: CREATE_AUDIT_LOG,
    job_categories: CREATE_JOB_CATEGORIES,
    job_codes: CREATE_JOB_CODES,
    departments: CREATE_DEPARTMENTS,
    sailpoint_roles: CREATE_SAILPOINT_ROLES,
    blueprints: CREATE_BLUEPRINTS,
    training_tracks: CREATE_TRAINING_TRACKS
  };

  const colMap = {
    roles: ROLE_COLS,
    job_categories: JOB_CAT_COLS,
    job_codes: JOB_CODE_COLS,
    departments: DEPT_COLS,
    sailpoint_roles: SAILPOINT_ROLE_COLS,
    blueprints: BLUEPRINT_COLS,
    training_tracks: TRACK_COLS
  };

  for (const t of tablesToMigrate) {
    console.log(`  Migrating ${t}...`);

    const tx = pool.transaction();
    await tx.begin();
    try {
      await tx.request().query(`DROP TABLE ${t}`);
      await tx.request().query(ddlMap[t]);

      if (data[t].length > 0) {
        if (t === 'audit_log') {
          await tx.request().bulk(buildAuditBulkTable(data[t]));
        } else {
          await tx.request().bulk(buildBulkTable(t, colMap[t], data[t]));
        }
      }

      await tx.commit();
      console.log(`  ${t}: migrated ${data[t].length} rows OK`);
    } catch (e) {
      await tx.rollback();
      console.error(`  ${t}: MIGRATION FAILED - rolled back`, e.message);
      throw e;
    }
  }

  try {
    if (tablesToMigrate.includes('job_codes')) {
      await pool.request().query('CREATE INDEX IX_job_codes_jobCode ON job_codes(jobCode)');
    }
    if (tablesToMigrate.includes('departments')) {
      await pool.request().query('CREATE INDEX IX_departments_deptId ON departments(deptId)');
    }
    if (tablesToMigrate.includes('sailpoint_roles')) {
      await pool.request().query('CREATE INDEX IX_sailpoint_roles_sailpointRole ON sailpoint_roles(sailpointRole)');
    }
    if (tablesToMigrate.includes('blueprints')) {
      await pool.request().query('CREATE INDEX IX_blueprints_blueprintId ON blueprints(blueprintId)');
    }
  } catch (_) {
    // indexes are optional; don't fail migration
  }

  await pool.close();
  console.log('\nMigration complete. All tables are now using normalized columns.');
}

main().catch((err) => {
  console.error('\nMigration failed:', err);
  process.exit(1);
});
