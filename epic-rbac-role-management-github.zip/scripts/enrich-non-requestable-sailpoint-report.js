/* eslint-disable no-console */
/**
 * Adds a `suggestedActiveSailpointRole` column to
 *   reports/job-categories-linked-to-non-requestable-sailpoint-with-templates.csv
 *
 * For each row whose linked SailPoint role has `requestable=FALSE`, this picks
 * the most plausible active (`requestable=TRUE`, `status=Active`) SailPoint
 * role that could replace it. Candidates MUST share the exact same template-id
 * and subtemplate-id sets as the job category - this guarantees the suggested
 * role is configured for the same template context. Among template-matched
 * candidates, scoring favors shared rare specialty tokens by IDF, which means
 * rare markers ("Allergy", "Burn", "Endocrinology") dominate over common
 * role-type words.
 *
 * A candidate must additionally (a) share at least one distinctive token with
 * the inactive role and (b) when the inactive role has a clear specialty
 * marker, share a token comparably rare to it. If no candidate qualifies, the
 * cell is left blank so reviewers know manual mapping is needed.
 *
 * Run:
 *   node scripts/enrich-non-requestable-sailpoint-report.js
 *
 * Options:
 *   --backup=<path>   Backup JSON to read sailpointRoles from. Defaults to the
 *                     newest file in data/backups/.
 *   --in=<path>       Input CSV (defaults to the canonical report path).
 *   --out=<path>      Output CSV (defaults to overwriting the input).
 */
const fs = require('fs');
const path = require('path');

const DEFAULT_REPORT = path.join(
  __dirname,
  '..',
  'reports',
  'job-categories-linked-to-non-requestable-sailpoint-with-templates.csv'
);
const DEFAULT_BACKUP_DIR = path.join(__dirname, '..', 'data', 'backups');
const NEW_COLUMN = 'suggestedActiveSailpointRole';

function parseArgs(argv) {
  const out = {};
  for (const arg of argv.slice(2)) {
    const m = arg.match(/^--([^=]+)=(.*)$/);
    if (m) out[m[1]] = m[2];
  }
  return out;
}

function pickLatestBackup(dir) {
  const files = fs
    .readdirSync(dir)
    .filter((f) => /^rbac_backup_.+\.json$/i.test(f))
    .sort();
  if (!files.length) throw new Error(`No backups found in ${dir}`);
  return path.join(dir, files[files.length - 1]);
}

/** Minimal RFC4180-style CSV parser sufficient for the existing reports. */
function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = '';
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          cell += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        cell += ch;
      }
      continue;
    }
    if (ch === '"') {
      inQuotes = true;
    } else if (ch === ',') {
      row.push(cell);
      cell = '';
    } else if (ch === '\r') {
      // ignore; \n handles row end
    } else if (ch === '\n') {
      row.push(cell);
      rows.push(row);
      row = [];
      cell = '';
    } else {
      cell += ch;
    }
  }
  if (cell.length || row.length) {
    row.push(cell);
    rows.push(row);
  }
  return rows.filter((r) => r.length > 1 || (r.length === 1 && r[0] !== ''));
}

function escapeCsvCell(val) {
  const s = String(val ?? '');
  if (/[",\r\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

function writeCsv(rows) {
  return rows.map((r) => r.map(escapeCsvCell).join(',')).join('\r\n') + '\r\n';
}

/** Split a templates/subtemplates string into normalized tokens. */
function splitTokens(value) {
  const s = String(value || '').trim();
  if (!s || s.toLowerCase() === 'no subtemplate') return [];
  return s
    .split(/[\s,;/|]+/)
    .map((t) => t.trim())
    .filter(
      (t) =>
        t &&
        t.toLowerCase() !== 'no subtemplate' &&
        t.toLowerCase() !== 'no' &&
        t.toLowerCase() !== 'subtemplate'
    );
}

function normalizeName(value) {
  return String(value || '')
    .normalize('NFKC')
    .replace(/[\u2010-\u2015\u2212]/g, '-')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

function nameTokens(value) {
  return new Set(
    normalizeName(value)
      .split(/[^a-z0-9]+/)
      .filter(Boolean)
  );
}

/** True when token sets are equal (case-insensitive, order-independent). */
function tokenSetsEqual(a, b) {
  if (a.length !== b.length) return false;
  const aSet = new Set(a.map((t) => t.toLowerCase()));
  for (const t of b) if (!aSet.has(t.toLowerCase())) return false;
  return true;
}

/**
 * True when the candidate's name tokens are a strict, non-trivial subset of
 * the source's - i.e., the candidate is a more-generic version of the source
 * (e.g. "Epic Mosaic Nurse Practitioner" relative to "Epic Mosaic Nurse
 * Practitioner - Anesthesia"). Used to allow such candidates through even
 * when no specialty-token match exists.
 */
function isGenericNameSubset(sourceTokens, candTokens) {
  if (!candTokens || candTokens.size < 3) return false;
  if (!sourceTokens || candTokens.size >= sourceTokens.size) return false;
  for (const t of candTokens) {
    if (!sourceTokens.has(t)) return false;
  }
  return true;
}

/**
 * Strict template/subtemplate match required for a candidate to be suggested.
 * Both template-id sets and subtemplate-id sets must match exactly (after
 * stripping the "No Subtemplate" sentinel).
 */
function templatesAndSubtemplatesMatch(jobTemplates, jobSubtemplates, candTemplates, candSubtemplates) {
  if (jobTemplates.length === 0) return false;
  if (!tokenSetsEqual(jobTemplates, candTemplates)) return false;
  if (!tokenSetsEqual(jobSubtemplates, candSubtemplates)) return false;
  return true;
}

/** Token document-frequency across the full SailPoint catalog. */
function buildNameTokenDocFrequency(roles) {
  const df = new Map();
  let docs = 0;
  for (const r of roles) {
    const toks = nameTokens(r.sailpointRole);
    if (!toks.size) continue;
    docs++;
    for (const t of toks) df.set(t, (df.get(t) || 0) + 1);
  }
  return { df, docs };
}

function tokenIdf(token, dfCtx) {
  const f = dfCtx.df.get(token) || 0;
  return Math.log((dfCtx.docs + 1) / (f + 1));
}

/** Tokens with low document frequency are treated as distinctive markers. */
function distinctiveTokens(name, dfCtx, maxFraction = 0.12) {
  const out = new Set();
  if (!dfCtx.docs) return out;
  const limit = Math.max(2, Math.floor(dfCtx.docs * maxFraction));
  for (const t of nameTokens(name)) {
    if (t.length < 2) continue;
    if (/^\d+$/.test(t)) continue;
    const freq = dfCtx.df.get(t) || 0;
    if (freq <= limit) out.add(t);
  }
  return out;
}

/**
 * Very rare tokens (≤ ~3% of catalog) — typically clinical specialty markers
 * like "Allergy", "Burn", "Endocrinology". When present in the inactive role
 * a candidate must share at least one, otherwise we'd suggest an unrelated
 * specialty just because role-type tokens match.
 */
function specialtyTokens(name, dfCtx, maxFraction = 0.04) {
  const out = new Set();
  if (!dfCtx.docs) return out;
  const limit = Math.max(2, Math.floor(dfCtx.docs * maxFraction));
  for (const t of nameTokens(name)) {
    if (t.length < 3) continue;
    if (/^\d+$/.test(t)) continue;
    const freq = dfCtx.df.get(t) || 0;
    if (freq <= limit) out.add(t);
  }
  return out;
}

function jaccardSets(a, b) {
  if (!a.size || !b.size) return 0;
  let inter = 0;
  for (const x of a) if (b.has(x)) inter++;
  return inter / (a.size + b.size - inter);
}

/**
 * Score one active candidate (already filtered to template/subtemplate match)
 * against the row context. Higher is better. Specialty matches dominate via
 * IDF-weighted shared distinctive tokens; full-name Jaccard and category-name
 * Jaccard break ties between specialty-aligned candidates. A "generic"
 * candidate whose name tokens are a strict subset of the source's is allowed
 * through without sharing the source's distinctive specialty token.
 */
function scoreCandidate(candidate, ctx, dfCtx) {
  const candNameTokens = nameTokens(candidate.sailpointRole);
  const isGeneric = isGenericNameSubset(ctx.inactiveNameTokens, candNameTokens);
  const candDistinct = distinctiveTokens(candidate.sailpointRole, dfCtx);

  let sharedDistinct = 0;
  let sharedIdf = 0;
  for (const t of ctx.inactiveDistinct) {
    if (candDistinct.has(t)) {
      sharedDistinct++;
      sharedIdf += tokenIdf(t, dfCtx);
    }
  }
  if (!isGeneric) {
    if (ctx.inactiveDistinct.size > 0 && sharedDistinct === 0) return -Infinity;
    // When the inactive role has a strong specialty marker, require the candidate
    // to share something at least 85% as rare; otherwise we'd suggest "Cardiology"
    // for an inactive "Allergy" row just because both share "Practitioner".
    if (ctx.inactiveSpecialtyIdfMax > 0 && sharedIdf < ctx.inactiveSpecialtyIdfMax * 0.85) {
      return -Infinity;
    }
  }

  const nameOverlapAll = jaccardSets(ctx.inactiveNameTokens, candNameTokens);
  const catNameOverlap = jaccardSets(ctx.jobCategoryNameTokens, candNameTokens);

  return 2.0 * sharedIdf + 1.5 * nameOverlapAll + 0.75 * catNameOverlap;
}

const MIN_SUGGESTION_SCORE = 1.0;

function findSuggestion(row, activeRoles, dfCtx) {
  const jobTemplates = splitTokens(row.jobCategoryTemplateIds);
  const jobSubtemplates = splitTokens(row.jobCategorySubtemplateIds);
  if (!jobTemplates.length) return '';

  const inactiveSpecialty = new Set([
    ...specialtyTokens(row.sailpointRole, dfCtx),
    ...specialtyTokens(row.jobCategoryName, dfCtx),
  ]);
  let inactiveSpecialtyIdfMax = 0;
  for (const t of inactiveSpecialty) {
    const idf = tokenIdf(t, dfCtx);
    if (idf > inactiveSpecialtyIdfMax) inactiveSpecialtyIdfMax = idf;
  }
  const ctx = {
    jobTemplates,
    jobSubtemplates,
    inactiveNameTokens: nameTokens(row.sailpointRole),
    jobCategoryNameTokens: nameTokens(row.jobCategoryName),
    inactiveDistinct: distinctiveTokens(row.sailpointRole, dfCtx),
    inactiveSpecialty,
    inactiveSpecialtyIdfMax,
  };
  if (!ctx.inactiveDistinct.size) {
    ctx.inactiveDistinct = distinctiveTokens(row.jobCategoryName, dfCtx);
  }

  const inactiveLc = String(row.sailpointRole || '').trim().toLowerCase();

  let best = null;
  let bestScore = -Infinity;
  for (const cand of activeRoles) {
    if (String(cand.sailpointRole || '').trim().toLowerCase() === inactiveLc) continue;
    const candTemplates = splitTokens(cand.templates);
    const candSubs = splitTokens(cand.subtemplates);
    if (!templatesAndSubtemplatesMatch(jobTemplates, jobSubtemplates, candTemplates, candSubs)) {
      continue;
    }
    const score = scoreCandidate(cand, ctx, dfCtx);
    if (score > bestScore) {
      bestScore = score;
      best = cand;
    }
  }
  if (!best || bestScore < MIN_SUGGESTION_SCORE) return '';
  return best.sailpointRole;
}

function main() {
  const args = parseArgs(process.argv);
  const inputPath = args.in || DEFAULT_REPORT;
  const outputPath = args.out || inputPath;
  const backupPath = args.backup || pickLatestBackup(DEFAULT_BACKUP_DIR);

  console.log(`Reading report : ${inputPath}`);
  console.log(`Reading backup : ${backupPath}`);

  const csvText = fs.readFileSync(inputPath, 'utf8').replace(/^\ufeff/, '');
  const rows = parseCsv(csvText);
  if (!rows.length) {
    console.error('Empty CSV.');
    process.exit(1);
  }
  const headers = rows[0];
  const dataRows = rows.slice(1);
  const idx = Object.fromEntries(headers.map((h, i) => [h, i]));
  for (const required of [
    'sailpointRole',
    'requestable',
    'jobCategoryTemplateIds',
    'jobCategorySubtemplateIds',
    'jobCategoryName',
  ]) {
    if (!(required in idx)) {
      console.error(`Missing required column: ${required}`);
      process.exit(1);
    }
  }

  const backup = JSON.parse(fs.readFileSync(backupPath, 'utf8'));
  const sailpointRoles = Array.isArray(backup.sailpointRoles) ? backup.sailpointRoles : [];
  const activeRoles = sailpointRoles.filter(
    (r) =>
      String(r.requestable || '').trim().toUpperCase() === 'TRUE' &&
      String(r.status || 'Active').trim().toLowerCase() !== 'inactive'
  );
  const dfCtx = buildNameTokenDocFrequency(sailpointRoles);
  console.log(
    `SailPoint roles: ${sailpointRoles.length} total / ${activeRoles.length} active+requestable`
  );

  let newColIdx = idx[NEW_COLUMN];
  if (newColIdx == null) {
    newColIdx = headers.length;
    headers.push(NEW_COLUMN);
  }

  let filled = 0;
  for (const r of dataRows) {
    while (r.length < headers.length) r.push('');
    const rowObj = Object.fromEntries(headers.map((h, i) => [h, r[i] ?? '']));
    const isNonReq = String(rowObj.requestable || '').trim().toUpperCase() === 'FALSE';
    if (!isNonReq) {
      r[newColIdx] = '';
      continue;
    }
    const suggestion = findSuggestion(rowObj, activeRoles, dfCtx);
    r[newColIdx] = suggestion;
    if (suggestion) filled++;
  }

  const outText = writeCsv([headers, ...dataRows]);
  fs.writeFileSync(outputPath, outText, 'utf8');
  console.log(
    `Wrote ${outputPath} (${dataRows.length} rows; ${filled} suggestions populated).`
  );
}

main();
