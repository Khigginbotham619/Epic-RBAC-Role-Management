/**
 * One-time script: load a backup JSON into the data folder.
 * Usage: node scripts/load-backup.js <path-to-backup.json>
 */
const fs = require('fs');
const path = require('path');

const backupPath = process.argv[2] || path.join(__dirname, '..', 'rbac_backup_2026-01-23.json');
const dataDir = process.env.DATA_DIR || path.join(__dirname, '..', 'data');

const fullPath = path.isAbsolute(backupPath) ? backupPath : path.resolve(process.cwd(), backupPath);

if (!fs.existsSync(fullPath)) {
  console.error('Backup file not found:', fullPath);
  process.exit(1);
}

const raw = fs.readFileSync(fullPath, 'utf8');
let backup;
try {
  backup = JSON.parse(raw);
} catch (e) {
  console.error('Invalid JSON:', e.message);
  process.exit(1);
}

const data = backup.data || backup;
if (!data) {
  console.error('Backup has no "data" or root keys (roles, jobCategories, etc.)');
  process.exit(1);
}

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const mappings = [
  { key: 'roles', file: 'roles.json' },
  { key: 'jobCategories', file: 'job-categories.json' },
  { key: 'jobCodes', file: 'job-codes.json' },
  { key: 'departments', file: 'departments.json' },
  { key: 'blueprints', file: 'blueprints.json' },
  { key: 'audit', file: 'audit.json', altKey: 'auditLogs' },
  { key: 'trainingTracks', file: 'training-tracks.json' },
];

let written = 0;
for (const { key, file, altKey } of mappings) {
  const value = data[key] !== undefined ? data[key] : (altKey && data[altKey]);
  if (value === undefined) continue;
  const outPath = path.join(dataDir, file);
  const arr = Array.isArray(value) ? value : (value && typeof value === 'object' ? Object.values(value) : [value]);
  const content = JSON.stringify(arr, null, 2);
  fs.writeFileSync(outPath, content, 'utf8');
  console.log(`Wrote ${file} (${arr.length} items)`);
  written++;
}

console.log(`Done. Wrote ${written} files to ${dataDir}`);
