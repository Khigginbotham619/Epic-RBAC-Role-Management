/**
 * Load data from JSON files in the data directory into MSSQL tables.
 * Run after creating tables (scripts/create_tables_mssql.sql).
 * Requires: datastore=MSSQL and MSSQL_connectionstring in .env (or environment).
 *
 * Usage: node scripts/load-data-to-mssql.js --confirm-overwrite
 * Optional: DATA_DIR=/path/to/data node scripts/load-data-to-mssql.js --confirm-overwrite
 *
 * WARNING: Replaces ALL rows in MSSQL tables from local JSON files. Never run against
 * production unless you intend to overwrite production data with dev export files.
 */
require('dotenv').config();
const path = require('path');
const fs = require('fs').promises;

const DATA_DIR = process.env.DATA_DIR
  ? path.resolve(process.env.DATA_DIR)
  : path.resolve(__dirname, '..', 'data');

async function readJsonFile(filename) {
  const filePath = path.join(DATA_DIR, filename);
  try {
    const data = await fs.readFile(filePath, 'utf8');
    const parsed = JSON.parse(data || '[]');
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    if (err.code === 'ENOENT') {
      console.warn(`  (no file: ${filename})`);
      return [];
    }
    if (err instanceof SyntaxError) {
      console.warn(`  (invalid JSON: ${filename}, skipping)`);
      return [];
    }
    throw err;
  }
}

async function readUsers() {
  const filePath = path.join(DATA_DIR, 'users.json');
  try {
    const data = await fs.readFile(filePath, 'utf8');
    const parsed = JSON.parse(data || '[]');
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    if (err.code === 'ENOENT' || err instanceof SyntaxError) {
      console.warn('  (no or invalid users.json)');
      return [];
    }
    throw err;
  }
}

async function main() {
  if ((process.env.datastore || '').toUpperCase() !== 'MSSQL') {
    console.error('Set datastore=MSSQL and MSSQL_connectionstring in .env (or environment), then run again.');
    process.exit(1);
  }

  if (!process.argv.includes('--confirm-overwrite')) {
    console.error(
      'Refusing to run: this script DELETEs and reloads all MSSQL tables from JSON files in DATA_DIR.'
    );
    console.error('To proceed, pass --confirm-overwrite (only on the database you intend to replace).');
    process.exit(1);
  }

  console.log('Data directory:', DATA_DIR);
  console.log('Reading JSON files...');

  const [
    users,
    roles,
    auditLogs,
    jobCategories,
    jobCodes,
    departments,
    sailpointRoles,
    blueprints,
    trainingTracks
  ] = await Promise.all([
    readUsers(),
    readJsonFile('roles.json'),
    readJsonFile('audit.json'),
    readJsonFile('job-categories.json'),
    readJsonFile('job-codes.json'),
    readJsonFile('departments.json'),
    readJsonFile('sailpoint-roles.json'),
    readJsonFile('blueprints.json'),
    readJsonFile('training-tracks.json')
  ]);

  console.log('  users:', users.length);
  console.log('  roles:', roles.length);
  console.log('  audit logs:', auditLogs.length);
  console.log('  job categories:', jobCategories.length);
  console.log('  job codes:', jobCodes.length);
  console.log('  departments:', departments.length);
  console.log('  sailpoint roles:', sailpointRoles.length);
  console.log('  blueprints:', blueprints.length);
  console.log('  training tracks:', trainingTracks.length);

  const db = require('../db-mssql');

  console.log('Connecting to MSSQL and loading data...');

  await db.saveUsers(users);
  console.log('  Loaded users');

  await db.saveRoles(roles);
  console.log('  Loaded roles');

  await db.replaceAuditLogs(auditLogs);
  console.log('  Loaded audit log');

  await db.saveJobCategories(jobCategories);
  console.log('  Loaded job categories');

  await db.saveJobCodes(jobCodes);
  console.log('  Loaded job codes');

  await db.saveDepartments(departments);
  console.log('  Loaded departments');

  await db.saveSailpointRoles(sailpointRoles);
  console.log('  Loaded sailpoint roles');

  await db.saveBlueprints(blueprints);
  console.log('  Loaded blueprints');

  await db.saveTrainingTracks(trainingTracks);
  console.log('  Loaded training tracks');

  await db.close();
  console.log('Done.');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
