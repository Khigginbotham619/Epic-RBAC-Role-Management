/**
 * One-time script: load training tracks from the "Training tracks.xlsx" Excel file into data/training-tracks.json.
 * Usage: node scripts/load-training-tracks.js [path-to-Training tracks.xlsx]
 * Default path: C:\Users\dev\Downloads\Training tracks .xlsx
 */
const fs = require('fs');
const path = require('path');
const XLSX = require('xlsx');
const crypto = require('crypto');

const defaultPath = path.join('c:', 'Users', 'dev', 'Downloads', 'Training tracks .xlsx');
const excelPath = process.argv[2] ? path.resolve(process.cwd(), process.argv[2]) : defaultPath;
const dataDir = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const outPath = path.join(dataDir, 'training-tracks.json');

if (!fs.existsSync(excelPath)) {
  console.error('Excel file not found:', excelPath);
  console.error('Usage: node scripts/load-training-tracks.js [path-to-Training tracks.xlsx]');
  process.exit(1);
}

const wb = XLSX.readFile(excelPath);
const ws = wb.Sheets[wb.SheetNames[0]];
const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });

const header = (rows[0] || [])[0];
const nameKey = typeof header === 'string' && header.trim() ? header.trim() : 'Training tracks ';
const seen = new Set();
const tracks = [];

for (let i = 1; i < rows.length; i++) {
  const row = rows[i];
  const name = (Array.isArray(row) ? row[0] : row[nameKey] || row['Training tracks '] || row.trackName) != null
    ? String(Array.isArray(row) ? row[0] : row[nameKey] || row['Training tracks '] || row.trackName).trim()
    : '';
  if (!name || seen.has(name.toLowerCase())) continue;
  seen.add(name.toLowerCase());
  tracks.push({
    id: crypto.randomUUID(),
    trackName: name,
  });
}

if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

fs.writeFileSync(outPath, JSON.stringify(tracks, null, 2), 'utf8');
console.log(`Wrote ${tracks.length} training tracks to ${outPath}`);
