const kill = require('kill-port');

const PORTS = [3000, 3001]; // frontend, server

async function main() {
  for (const port of PORTS) {
    try {
      await kill(port, 'tcp');
      console.log(`Freed port ${port}`);
    } catch {
      // Port not in use, ignore
    }
  }
}

main();
