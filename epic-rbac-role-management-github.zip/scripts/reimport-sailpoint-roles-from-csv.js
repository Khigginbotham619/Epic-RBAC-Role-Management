/**
 * Replace sailpoint_roles in MSSQL from a roles-entitlements CSV export.
 *
 * Usage:
 *   node scripts/reimport-sailpoint-roles-from-csv.js [path-to.csv]
 */
require('dotenv').config();
const fs = require('fs').promises;
const path = require('path');
const crypto = require('crypto');


const DEFAULT_CSV = path.join(
  process.env.USERPROFILE || '',
  'Downloads',
  'roles-entitlements-output 1.csv'
);

function parseCSV(text) {
  const rows = [];
  let currentRow = [];
  let currentField = '';
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const nextChar = text[i + 1];

    if (char === '"') {
      if (inQuotes && nextChar === '"') {
        currentField += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      currentRow.push(currentField);
      currentField = '';
    } else if ((char === '\n' || char === '\r') && !inQuotes) {
      if (char === '\r' && nextChar === '\n') i++;
      currentRow.push(currentField);
      if (currentRow.some((f) => f.trim() !== '')) rows.push([...currentRow]);
      currentRow = [];
      currentField = '';
    } else {
      currentField += char;
    }
  }

  if (currentField !== '' || currentRow.length > 0) {
    currentRow.push(currentField);
    if (currentRow.some((f) => f.trim() !== '')) rows.push([...currentRow]);
  }
  return rows;
}

function csvToObjects(text) {
  const cleaned = String(text || '').replace(/^\uFEFF/, '');
  const rows = parseCSV(cleaned);
  if (rows.length < 2) return [];
  const headers = rows[0].map((h) => String(h || '').replace(/^\uFEFF/, '').trim());
  const data = [];
  for (let i = 1; i < rows.length; i++) {
    const row = rows[i];
    if (row.every((cell) => !cell || cell.trim() === '')) continue;
    const rowObj = {};
    headers.forEach((header, index) => {
      rowObj[header] = row[index] !== undefined && row[index] !== null ? row[index] : '';
    });
    data.push(rowObj);
  }
  return data;
}

async function main() {
  const { mapImportedSailpointRows } = await import('../src/utils/sailpointImport.js');

  if ((process.env.datastore || '').toUpperCase() !== 'MSSQL') {
    console.error('datastore must be MSSQL. Set datastore=MSSQL in .env');
    process.exit(1);
  }

  const csvPath = path.resolve(process.argv[2] || DEFAULT_CSV);
  console.log('Reading:', csvPath);
  const text = await fs.readFile(csvPath, 'utf8');
  const rawRows = csvToObjects(text);
  const mappedRows = mapImportedSailpointRows(rawRows);

  if (mappedRows.length === 0) {
    console.error('No valid sailpoint rows found in CSV.');
    process.exit(1);
  }

  const finalRows = mappedRows.map((row) => ({
    ...row,
    id: crypto.randomUUID(),
    description: row.description || '',
    entitlements: row.instructions || row.entitlements || '',
  }));

  const withTemplates = finalRows.filter((r) => r.templates).length;
  const withSubtemplates = finalRows.filter((r) => r.subtemplates).length;

  const db = require('../db-mssql');
  console.log(`Importing ${finalRows.length} rows (replace)...`);
  console.log(`  With template ID: ${withTemplates}`);
  console.log(`  With subtemplate: ${withSubtemplates}`);

  await db.saveSailpointRoles(finalRows);
  console.log('Done. sailpoint_roles table replaced.');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
