# Epic RBAC Role Management

Web application for maintaining Epic RBAC roles and related reference data (job categories, job codes, departments, templates, blueprints, training tracks, and SailPoint roles). Changes are audit-logged. Data can be stored in **SQL Server** or JSON files.

**GitHub description:** Web app for managing Epic RBAC roles, job categories, templates, and SailPoint mappings with audit logging, CSV import/export, and SQL Server persistence.

Suggested topics: `epic` `rbac` `react` `express` `sql-server` `sailpoint` `identity`

---

## What it does

- Create, edit, search, and delete RBAC roles
- Maintain reference tables used to populate roles
- Import and export CSV / Excel
- Match job categories to SailPoint roles
- Find blank fields and run integrity checks
- Export a SailPoint-oriented table
- Record CREATE / UPDATE / DELETE actions in an audit log
- Optional admin backup, restore, and data tools

Select an audit user in the header so edits are attributed. Restricted tools (reference data, integrity fixes, admin, SailPoint export) are available to the `admin` user.

---

## Requirements

- Node.js 18 or later
- npm
- SQL Server (optional; JSON file storage works for local demos)

---

## Quick start (local)

1. Unzip this folder and open a terminal in it.
2. Install dependencies:

```bash
npm install
```

3. Copy the example environment file and edit values:

```bash
copy .env.example .env
```

4. For a file-based demo (no database), set in `.env`:

```
datastore=file
```

   Or leave `datastore=MSSQL` and fill in a real connection string (see below).

5. Start the API and React UI together:

```bash
npm run dev
```

6. Open [http://localhost:3000](http://localhost:3000). The API defaults to [http://localhost:3001](http://localhost:3001).

### Scripts

| Command | Purpose |
|---|---|
| `npm run dev` | API + React together (development) |
| `npm start` | React UI only (`localhost:3000`) |
| `npm run server` | Express API only (`localhost:3001`) |
| `npm run build` | Production React build into `build/` |
| `npm test` | Unit tests |
| `npm run load-data-mssql` | Load local JSON into SQL Server (**overwrites tables**) |

---

## SQL Server setup

Production and shared environments should use MSSQL.

1. Create an empty database (example name: `EpicRbac`).
2. Run `scripts/create_tables_mssql.sql` against that database.
3. Put a connection string in `.env` (never commit this file):

```
datastore=MSSQL
MSSQL_connectionstring="Server=sql.example.local,1433;User=app_user;Password=CHANGE_ME;Database=EpicRbac;TrustServerCertificate=True;"
```

4. Confirm the API is using SQL:

   Open `/api/health` — `datastore` should be `"MSSQL"` and `database` should be your database name.

Use a least-privileged SQL login. Do not point a development `.env` at a production database unless you intend to write there.

To load demo JSON into SQL after tables exist:

```bash
npm run load-data-mssql -- --confirm-overwrite
```

That command **replaces** existing rows. Do not run it against production unless you mean to overwrite it.

---

## Production deploy

1. `npm run build`
2. Deploy `build/`, `server.js`, `db-mssql.js`, `lib/`, `package.json`, and `package-lock.json`. **Do not** deploy a `data/` folder or run the SQL load script against production unless you intend to replace live data.
3. Set environment variables on the server (IIS / PM2 / Windows service), not in the React build:

```
NODE_ENV=production
datastore=MSSQL
MSSQL_connectionstring=<production connection string>
PORT=8021
```

4. Start the server:

```bash
set PORT=8021
node server.js
```

   Or: `pm2 start server.js --name rbac -- --port 8021`

5. Verify `http://localhost:8021/api/health` returns `ok: true`.
6. Users should hard-refresh the browser (Ctrl+F5) after a deploy.

If IIS sits in front of Node, the physical path must include the `build` folder and iisnode (see `public/web.config`). Increase proxy timeouts for large CSV imports (the app uses a 90-second request timeout and batches role imports).

Writes merge by role id so a stale browser tab cannot wipe rows added on the server. After each save, the UI reloads roles from SQL.

---

## Main screens

| Area | Use |
|---|---|
| Roles | Primary grid: add, edit, search, import, export |
| Job Categories | Categories that drive template and SailPoint suggestions |
| Job Codes / Departments | Reference tables |
| Templates/Subtemplates | Epic template link catalog |
| Blueprints / Training Tracks | SER / training metadata |
| SailPoint Roles | Identity catalog used for matching and export |
| Find Blanks / Integrity Fixes | Data quality |
| SailPoint Match | Suggest catalog roles for a category |
| SP Export Table | Flattened export for SailPoint |
| Admin | Backup, restore, bulk tools |
| Audit Log | History of changes |

---

## Data storage

| Mode | Where data lives |
|---|---|
| `datastore=MSSQL` | SQL Server tables created by `scripts/create_tables_mssql.sql` |
| otherwise | JSON files under `data/` (override with `DATA_DIR`) |

Do not commit `.env`, `data/`, or database backups.

---

## Security notes

- Keep SQL credentials in environment variables only.
- Change `CHANGE_ME` in `.env.example` and the in-app user-switch password before any real deployment.
- This package was prepared for public GitHub: hostnames, employee IDs, and organization data were removed. Point it at **your** database and credentials.
