# GitHub listing

Paste these when you create the repository.

## Repository name

`epic-rbac-role-management`

## About / description

Web app for managing Epic RBAC roles, job categories, templates, and SailPoint mappings with audit logging, CSV import/export, and SQL Server persistence.

## Topics

`epic` `rbac` `react` `express` `mssql` `sql-server` `sailpoint` `identity-governance`

## First-time publish

```bash
unzip epic-rbac-role-management-github.zip
cd epic-rbac-role-management
git init
git add .
git commit -m "Initial public snapshot of Epic RBAC role management."
git branch -M main
git remote add origin https://github.com/<your-account>/epic-rbac-role-management.git
git push -u origin main
```

Confirm `.env` is not in the commit (`git status` should not list it). Use `.env.example` only.
