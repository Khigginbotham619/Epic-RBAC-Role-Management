require('dotenv').config();
const express = require('express');
const fs = require('fs').promises;
const fsSync = require('fs');
const path = require('path');
const crypto = require('crypto');
const cors = require('cors');

const USE_MSSQL = (process.env.datastore || '').toUpperCase() === 'MSSQL';
const {
  propagateLinkedRolesFromCategories,
  syncAllRolesFromCategories,
} = require('./lib/categoryRolePropagate.cjs');
const { normalizeRoleId } = require('./lib/categorySyncShared.cjs');

const APP_BUILD_ID =
  process.env.BUILD_ID ||
  (() => {
    try {
      return require('./package.json').version;
    } catch (_) {
      return 'unknown';
    }
  })();

function mssqlDatabaseName() {
  const connStr = process.env.MSSQL_connectionstring || process.env.MSSQL_connectionString || '';
  const match = String(connStr).match(/(?:^|;)Database=([^;]+)/i);
  return match ? match[1].trim() : null;
}

/** Production must persist to MSSQL — not local JSON files. */
if (
  (process.env.NODE_ENV === 'production' || process.env.REQUIRE_MSSQL === 'true') &&
  !USE_MSSQL
) {
  console.error(
    'FATAL: datastore=MSSQL is required in production (set datastore and MSSQL_connectionstring on the server).'
  );
  process.exit(1);
}

async function readRolesFromStore(store, { fresh = false } = {}) {
  if (fresh && typeof store.getRolesFresh === 'function') {
    return store.getRolesFresh();
  }
  return store.getRoles();
}

const app = express();
const PORT = process.env.PORT || 3001;
// All entered data is stored as JSON files in the data folder (override with DATA_DIR env)
const DATA_DIR = process.env.DATA_DIR
  ? path.resolve(process.env.DATA_DIR)
  : path.join(__dirname, 'data');

const BUILD_DIR = path.join(__dirname, 'build');

// Middleware
app.use(cors());
app.use(express.json({ limit: '25mb' }));

// Catch JSON parse and payload-too-large errors so they don't crash the server
app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && 'body' in err) {
    return res.status(400).json({ error: 'Invalid JSON in request body' });
  }
  if (err.type === 'entity.too.large' || err.status === 413) {
    return res.status(413).json({ error: 'Request body too large. Try importing in smaller batches or use the batch import.' });
  }
  next(err);
});

// Health check (no dependency on data folder)
app.get('/api/health', (req, res) => {
  res.json({
    ok: true,
    dataDir: DATA_DIR,
    datastore: USE_MSSQL ? 'MSSQL' : 'file',
    database: USE_MSSQL ? mssqlDatabaseName() : null,
    buildId: APP_BUILD_ID,
  });
});

// Serve React build in production (so GET / returns the app, not 500/404)
if (fsSync.existsSync(BUILD_DIR)) {
  app.use(express.static(BUILD_DIR));
}

// Ensure data directory exists
async function ensureDataDir() {
  try {
    await fs.mkdir(DATA_DIR, { recursive: true });
  } catch (error) {
    console.error('Error creating data directory:', error);
  }
}

// Initialize data directory on startup
ensureDataDir();

// In-memory cache for JSON file reads (invalidated on write) to speed up repeated reads
const jsonFileCache = new Map();
// Track which files we've already backed up for invalid JSON (avoid repeated backup + log spam)
const invalidJsonBackedUp = new Set();
// Per-file mutex for append: ensures read-modify-write is serialized per file (avoids lost updates)
const appendLocks = new Map();
async function withAppendLock(filename, fn) {
  const next = appendLocks.get(filename) ?? Promise.resolve();
  const ourPromise = next.then(() => fn());
  const tail = ourPromise.then(() => undefined, () => undefined);
  appendLocks.set(filename, tail);
  return ourPromise;
}

// Per-file mutex for writeJsonFile: avoids concurrent writes to same file (e.g. audit.json)
// which would both use the same .tmp path and cause ENOENT on the second rename.
const writeLocks = new Map();
async function withWriteLock(filename, fn) {
  const next = writeLocks.get(filename) ?? Promise.resolve();
  const ourPromise = next.then(() => fn());
  const tail = ourPromise.then(() => undefined, () => undefined);
  writeLocks.set(filename, tail);
  return ourPromise;
}

// Helper function to read JSON file (from data folder); uses cache to avoid repeated disk reads
async function readJsonFile(filename) {
  const filePath = path.join(DATA_DIR, filename);
  try {
    const data = await fs.readFile(filePath, 'utf8');
    const parsed = JSON.parse(data || '[]');
    const result = Array.isArray(parsed) ? parsed : [];
    jsonFileCache.set(filename, result);
    return result;
  } catch (error) {
    if (error.code === 'ENOENT') {
      jsonFileCache.set(filename, []);
      return [];
    }
    if (error instanceof SyntaxError) {
      if (!invalidJsonBackedUp.has(filename)) {
        invalidJsonBackedUp.add(filename);
        console.error(`Invalid JSON in ${filename}; refusing to auto-repair to empty to prevent data loss`);
        try {
          const raw = await fs.readFile(filePath, 'utf8');
          const backupPath = path.join(DATA_DIR, filename + '.invalid.bak');
          await fs.writeFile(backupPath, raw, 'utf8');
          console.error(`Corrupt content backed up to ${path.basename(backupPath)}`);
        } catch (backupErr) {
          // ignore backup failure
        }
      }
      const err = new Error(`Corrupt JSON in ${filename}. Restore from backup or repair file manually.`);
      err.code = 'CORRUPT_JSON';
      throw err;
    }
    throw error;
  }
}

// Read with cache: return cached copy if present, else read from disk (readJsonFile caches)
async function readJsonFileCached(filename) {
  if (jsonFileCache.has(filename)) {
    return jsonFileCache.get(filename);
  }
  return readJsonFile(filename);
}

// Helper function to write JSON file (atomic write to avoid corruption); invalidates cache.
// Uses a per-file lock so concurrent writes (e.g. multiple audit log appends) don't share
// the same .tmp file and cause ENOENT on rename.
async function writeJsonFile(filename, data) {
  return withWriteLock(filename, async () => {
    try {
      await fs.mkdir(DATA_DIR, { recursive: true });
    } catch (e) {
      if (e.code === 'EACCES' || e.code === 'EPERM') {
        const err = new Error(`Cannot create data directory: ${DATA_DIR} (permission denied)`);
        err.code = e.code;
        throw err;
      }
      throw e;
    }
    const filePath = path.join(DATA_DIR, filename);
    const tmpPath = path.join(DATA_DIR, filename + '.tmp');
    let jsonStr;
    try {
      jsonStr = JSON.stringify(data, null, 2);
    } catch (e) {
      throw new Error('Data cannot be serialized to JSON (e.g. circular reference)');
    }
    try {
      await fs.writeFile(tmpPath, jsonStr, 'utf8');
      try {
        await fs.rename(tmpPath, filePath);
      } catch (renameErr) {
        // On Windows, rename over an existing file can fail with EPERM; remove destination and retry
        if (renameErr.code === 'EPERM' || renameErr.code === 'EEXIST' || renameErr.code === 'EACCES') {
          await fs.unlink(filePath).catch(() => {});
          await fs.rename(tmpPath, filePath);
        } else {
          throw renameErr;
        }
      }
      jsonFileCache.delete(filename);
    } catch (e) {
      try { await fs.unlink(tmpPath); } catch (_) {}
      if (e.code === 'EACCES' || e.code === 'EPERM') {
        const err = new Error('Cannot write to data directory (permission denied)');
        err.code = e.code;
        throw err;
      }
      throw e;
    }
  });
}

// Scheduled weekly backup: write all data to data/backups/rbac_backup_YYYY-MM-DD.json; keep last 4
const BACKUP_DIR = path.join(DATA_DIR, 'backups');
const BACKUP_RETENTION_COUNT = 4;

async function runScheduledBackup() {
  try {
    await fs.mkdir(BACKUP_DIR, { recursive: true });
    const [roles, jobCategories, jobCodes, departments, templateLinks, sailpointRoles, blueprints, auditLogs, users, trainingTracks, spExportTable] = await Promise.all([
      dataStore.getRoles(),
      dataStore.getJobCategories(),
      dataStore.getJobCodes(),
      dataStore.getDepartments(),
      dataStore.getTemplateLinks(),
      dataStore.getSailpointRoles(),
      dataStore.getBlueprints(),
      dataStore.getAuditLogs(),
      dataStore.getUsers(),
      dataStore.getTrainingTracks(),
      dataStore.getSPExportTable()
    ]);
    const dateStr = new Date().toISOString().split('T')[0];
    const backupPath = path.join(BACKUP_DIR, `rbac_backup_${dateStr}.json`);
    const payload = { roles, jobCategories, jobCodes, departments, templateLinks, sailpointRoles, blueprints, auditLogs, users, trainingTracks, spExportTable, exportDate: new Date().toISOString() };
    await fs.writeFile(backupPath, JSON.stringify(payload, null, 2), 'utf8');
    console.log(`Scheduled backup written: ${path.basename(backupPath)}`);

    const files = await fs.readdir(BACKUP_DIR);
    const backupFiles = files.filter((f) => f.startsWith('rbac_backup_') && f.endsWith('.json'));
    const withDates = backupFiles
      .map((f) => {
        const match = f.match(/rbac_backup_(\d{4}-\d{2}-\d{2})\.json/);
        return { f, date: match ? match[1] : '' };
      })
      .filter((x) => x.date);
    withDates.sort((a, b) => b.date.localeCompare(a.date));
    const toDelete = withDates.slice(BACKUP_RETENTION_COUNT);
    for (const { f } of toDelete) {
      await fs.unlink(path.join(BACKUP_DIR, f));
      console.log(`Pruned old backup: ${f}`);
    }
  } catch (err) {
    console.error('Scheduled backup failed:', err);
  }
}

// Read users (array of { id, username, passwordHash, createdAt })
async function readUsers() {
  const filePath = path.join(DATA_DIR, 'users.json');
  try {
    const data = await fs.readFile(filePath, 'utf8');
    const parsed = JSON.parse(data || '[]');
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    if (error.code === 'ENOENT') return [];
    if (error instanceof SyntaxError) return [];
    throw error;
  }
}

// List users (id, username only) for audit user dropdown
app.get('/api/users', async (req, res) => {
  try {
    const users = await dataStore.getUsers();
    res.json(users.map(u => ({ id: u.id, username: u.username })));
  } catch (error) {
    console.error('Error reading users:', error);
    res.status(500).json({ error: 'Failed to read users' });
  }
});

// Create user (username only, no password) for audit dropdown
app.post('/api/users', async (req, res) => {
  try {
    const { username } = req.body || {};
    if (!username || !String(username).trim()) {
      return res.status(400).json({ error: 'Username is required' });
    }
    const users = await dataStore.getUsers();
    const name = String(username).trim();
    if (users.some(u => (u.username || '').toLowerCase() === name.toLowerCase())) {
      return res.status(400).json({ error: 'Username already exists' });
    }
    const id = crypto.randomUUID();
    const newUser = { id, username: name, passwordHash: '', createdAt: new Date().toISOString() };
    users.push(newUser);
    await dataStore.saveUsers(users);
    res.status(201).json({ user: { id, username: newUser.username } });
  } catch (error) {
    console.error('Error creating user:', error);
    res.status(500).json({ error: 'Failed to create user' });
  }
});

// Rename user (by id).
app.put('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { username } = req.body || {};
    if (!id) return res.status(400).json({ error: 'User id is required' });
    if (!username || !String(username).trim()) return res.status(400).json({ error: 'Username is required' });
    const users = await dataStore.getUsers();
    const name = String(username).trim();
    const idx = users.findIndex(u => u.id === id);
    if (idx === -1) return res.status(404).json({ error: 'User not found' });
    if (users.some(u => u.id !== id && (u.username || '').toLowerCase() === name.toLowerCase())) {
      return res.status(400).json({ error: 'Username already exists' });
    }
    users[idx] = { ...users[idx], username: name };
    await dataStore.saveUsers(users);
    res.json({ user: { id, username: name } });
  } catch (error) {
    console.error('Error updating user:', error);
    res.status(500).json({ error: 'Failed to update user' });
  }
});

// Delete user (by id). Idempotent: returns success even if user already gone (audit list only).
app.delete('/api/users/:id', async (req, res) => {
  try {
    const { id } = req.params;
    if (!id) return res.status(400).json({ error: 'User id is required' });
    const users = await dataStore.getUsers();
    const index = users.findIndex(u => u.id === id);
    if (index !== -1) {
      users.splice(index, 1);
      await dataStore.saveUsers(users);
    }
    res.json({ success: true });
  } catch (error) {
    console.error('Error deleting user:', error);
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

// Batch delete users by array of ids.
app.post('/api/users/batch-delete', async (req, res) => {
  try {
    const { ids } = req.body || {};
    if (!Array.isArray(ids) || ids.length === 0) return res.status(400).json({ error: 'ids array is required' });
    const users = await dataStore.getUsers();
    const idsSet = new Set(ids);
    const remaining = users.filter(u => !idsSet.has(u.id));
    await dataStore.saveUsers(remaining);
    res.json({ success: true, deleted: users.length - remaining.length });
  } catch (error) {
    console.error('Error batch deleting users:', error);
    res.status(500).json({ error: 'Failed to batch delete users' });
  }
});

// Roles endpoints
app.get('/api/roles', async (req, res) => {
  try {
    const fresh = req.query.fresh === 'true' || req.headers['x-fresh-read'] === 'true';
    const roles = await readRolesFromStore(dataStore, { fresh });
    res.json(roles);
  } catch (error) {
    console.error('Error reading roles:', error);
    res.status(500).json({ error: 'Failed to read roles' });
  }
});

function isDangerousRolesShrink(currentCount, nextCount) {
  if (currentCount <= 0) return false;
  if (nextCount === 0) return true;
  // Block large drops when there is meaningful existing data.
  if (currentCount >= 1000 && nextCount < Math.floor(currentCount * 0.5)) return true;
  return false;
}

function parseRoleCountHeader(value) {
  if (value == null || value === '') return null;
  const n = parseInt(String(value), 10);
  return Number.isNaN(n) ? null : n;
}

function roleIdSet(roles) {
  return new Set((roles || []).map((r) => normalizeRoleId(r?.id)).filter(Boolean));
}

app.post('/api/roles', async (req, res) => {
  try {
    const body = req.body;
    if (!Array.isArray(body)) {
      return res.status(400).json({ error: 'Request body must be a JSON array of roles' });
    }
    const forceSave = req.headers['x-force-save'] === 'true';
    const allowShrink = req.headers['x-allow-role-shrink'] === 'true';
    const expectedCount = parseRoleCountHeader(req.headers['x-expected-role-count']);

    const current = await readRolesFromStore(dataStore, { fresh: true });
    const currentList = Array.isArray(current) ? current : [];
    const currentCount = currentList.length;
    const nextCount = body.length;

    if (!forceSave && expectedCount != null && expectedCount !== currentCount) {
      return res.status(409).json({
        error: `Server has ${currentCount} role(s) but this save expected ${expectedCount}. Reload the page and retry.`,
        currentCount,
        expectedCount,
      });
    }

    if (!forceSave && !allowShrink) {
      const bodyIds = roleIdSet(body);
      const dropped = currentList.filter((r) => !bodyIds.has(normalizeRoleId(r.id)));
      if (dropped.length > 0) {
        return res.status(409).json({
          error: `Save would remove ${dropped.length} role(s) already on the server. Reload, then delete explicitly if needed.`,
          droppedCount: dropped.length,
          currentCount,
        });
      }
    }

    if (isDangerousRolesShrink(currentCount, nextCount) && !forceSave) {
      return res.status(409).json({
        error: `Blocked potentially destructive roles replace: ${currentCount} -> ${nextCount}. Use an explicit restore/import flow.`
      });
    }
    await dataStore.saveRoles(body);
    res.json({ success: true });
  } catch (error) {
    console.error('Error saving roles:', error);
    const message = error.message || 'Failed to save roles';
    res.status(500).json({ error: message });
  }
});

// Delete roles by id (read current, filter, save). Avoids sending a stale full-array snapshot.
app.post('/api/roles/delete', async (req, res) => {
  try {
    const ids = req.body?.ids;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: 'Request body must include ids: string[]' });
    }
    const deleteIds = new Set(ids.map((id) => normalizeRoleId(id)).filter(Boolean));
    const current = await readRolesFromStore(dataStore, { fresh: true });
    const currentList = Array.isArray(current) ? current : [];
    const remaining = currentList.filter((r) => !deleteIds.has(normalizeRoleId(r.id)));
    const deleted = currentList.length - remaining.length;
    if (deleted === 0) {
      return res.json({ success: true, deleted: 0 });
    }
    await dataStore.saveRoles(remaining);
    res.json({ success: true, deleted });
  } catch (error) {
    console.error('Error deleting roles:', error);
    const message = error.message || 'Failed to delete roles';
    res.status(500).json({ error: message });
  }
});

// Batch append or replace roles (avoids one huge POST and timeouts on large CSV import)
// Merge role patches by id (read current from DB, apply patches, save). Avoids stale full-array overwrites.
// Sync all RBAC roles from the full job category table (server-side merge).
app.post('/api/roles/sync-from-categories', async (req, res) => {
  try {
    const result = await syncAllRolesFromCategories(dataStore);
    res.json({
      success: true,
      applied: result.applied ?? 0,
      roleUpdateCount: result.roleUpdateCount ?? 0,
    });
  } catch (error) {
    console.error('Error syncing roles from job categories:', error);
    const message = error.message || 'Failed to sync roles from job categories';
    res.status(500).json({ error: message });
  }
});

app.post('/api/roles/merge', async (req, res) => {
  try {
    const updates = req.body;
    if (!Array.isArray(updates)) {
      return res.status(400).json({ error: 'Request body must be a JSON array of role updates' });
    }
    const patchById = new Map();
    for (const patch of updates) {
      if (!patch?.id) continue;
      patchById.set(normalizeRoleId(patch.id), patch);
    }
    if (patchById.size === 0) {
      return res.status(400).json({ error: 'No valid role updates (each entry needs an id)' });
    }
    const current = await readRolesFromStore(dataStore, { fresh: true });
    const currentList = Array.isArray(current) ? current : [];
    let applied = 0;
    const merged = currentList.map((role) => {
      const patch = patchById.get(normalizeRoleId(role.id));
      if (!patch) return role;
      applied += 1;
      const { id: _id, ...fields } = patch;
      return { ...role, ...fields };
    });
    await dataStore.saveRoles(merged);
    const savedRoles = merged.filter((role) => patchById.has(normalizeRoleId(role.id)));
    res.json({ success: true, applied, roles: savedRoles });
  } catch (error) {
    console.error('Error merging roles:', error);
    const message = error.message || 'Failed to merge roles';
    res.status(500).json({ error: message });
  }
});

app.post('/api/roles/batch', async (req, res) => {
  try {
    const { roles = [], replace = false, destructiveReplaceConfirmed = false } = req.body || {};
    const batch = Array.isArray(roles) ? roles : [];
    if (replace) {
      const current = await readRolesFromStore(dataStore, { fresh: true });
      const currentCount = Array.isArray(current) ? current.length : 0;
      const nextCount = batch.length;
      if (isDangerousRolesShrink(currentCount, nextCount) && !destructiveReplaceConfirmed) {
        return res.status(409).json({
          error: `Blocked potentially destructive roles replace: ${currentCount} -> ${nextCount}. Confirm destructive replace to proceed.`
        });
      }
      await dataStore.saveRoles(batch);
    } else {
      const current = await readRolesFromStore(dataStore, { fresh: true });
      const combined = Array.isArray(current) ? [...current, ...batch] : [...batch];
      await dataStore.saveRoles(combined);
    }
    res.json({ success: true });
  } catch (error) {
    console.error('Error saving roles batch:', error);
    res.status(500).json({ error: 'Failed to save roles batch' });
  }
});

// Audit logs endpoints
app.get('/api/audit', async (req, res) => {
  try {
    const logs = await dataStore.getAuditLogs();
    res.json(logs);
  } catch (error) {
    console.error('Error reading audit logs:', error);
    res.status(500).json({ error: 'Failed to read audit logs' });
  }
});

app.post('/api/audit', async (req, res) => {
  try {
    await dataStore.appendAuditLog(req.body);
    res.json({ success: true });
  } catch (error) {
    console.error('Error saving audit log:', error);
    res.status(500).json({ error: 'Failed to save audit log' });
  }
});

app.post('/api/audit/replace', async (req, res) => {
  try {
    await dataStore.replaceAuditLogs(req.body);
    res.json({ success: true });
  } catch (error) {
    console.error('Error replacing audit logs:', error);
    res.status(500).json({ error: 'Failed to replace audit logs' });
  }
});

// Job Categories endpoints
app.get('/api/job-categories', async (req, res) => {
  try {
    const categories = await dataStore.getJobCategories();
    res.json(categories);
  } catch (error) {
    console.error('Error reading job categories:', error);
    res.status(500).json({ error: 'Failed to read job categories' });
  }
});

app.post('/api/job-categories', async (req, res) => {
  try {
    const previous =
      typeof dataStore.getJobCategoriesFresh === 'function'
        ? await dataStore.getJobCategoriesFresh()
        : await dataStore.getJobCategories();
    const next = req.body;
    await dataStore.saveJobCategories(next);
    let rolesUpdated = 0;
    let rolePropagationError = null;
    try {
      const result = await propagateLinkedRolesFromCategories(dataStore, previous, next);
      rolesUpdated = result?.applied ?? 0;
    } catch (propErr) {
      console.error('Error propagating job category changes to roles:', propErr);
      rolePropagationError = propErr?.message || String(propErr);
    }
    res.json({ success: true, rolesUpdated, rolePropagationError });
  } catch (error) {
    console.error('Error saving job categories:', error);
    res.status(500).json({ error: 'Failed to save job categories' });
  }
});

// Job Codes endpoints
app.get('/api/job-codes', async (req, res) => {
  try {
    const jobCodes = await dataStore.getJobCodes();
    res.json(jobCodes);
  } catch (error) {
    console.error('Error reading job codes:', error);
    res.status(500).json({ error: 'Failed to read job codes' });
  }
});

app.post('/api/job-codes', async (req, res) => {
  try {
    await dataStore.saveJobCodes(req.body);
    res.json({ success: true });
  } catch (error) {
    console.error('Error saving job codes:', error);
    res.status(500).json({ error: 'Failed to save job codes' });
  }
});

// Job code is always 4 characters; leading zeros preserved (no removal).
function normalizeJobCode(value) {
  if (value == null) return '';
  let s = String(value).replace(/\s/g, '');
  if (s.length === 0) return '';
  if (s.length > 4) s = s.slice(-4);
  else if (s.length < 4) s = s.padStart(4, '0');
  return s;
}

// Data store: file (default) or MSSQL when datastore=MSSQL and MSSQL_connectionstring is set
function createFileDataLayer() {
  return {
    getUsers: readUsers,
    async saveUsers(users) { await writeJsonFile('users.json', users); },
    getRoles: () => readJsonFileCached('roles.json'),
    async saveRoles(body) { await writeJsonFile('roles.json', body); },
    getAuditLogs: () => readJsonFileCached('audit.json'),
    async appendAuditLog(entry) {
      const cached = await readJsonFileCached('audit.json');
      const logs = Array.isArray(cached) ? [...cached] : [];
      logs.unshift(entry);
      await writeJsonFile('audit.json', logs);
    },
    async replaceAuditLogs(logs) { await writeJsonFile('audit.json', logs); },
    getJobCategories: () => readJsonFileCached('job-categories.json'),
    async saveJobCategories(body) { await writeJsonFile('job-categories.json', body); },
    getJobCodes: () => readJsonFileCached('job-codes.json'),
    async saveJobCodes(body) { await writeJsonFile('job-codes.json', body); },
    getDepartments: () => readJsonFileCached('departments.json'),
    async saveDepartments(body) { await writeJsonFile('departments.json', body); },
    getTemplateLinks: () => readJsonFileCached('template-links.json'),
    async saveTemplateLinks(body) { await writeJsonFile('template-links.json', body); },
    getSailpointRoles: () => readJsonFileCached('sailpoint-roles.json'),
    async saveSailpointRoles(body) { await writeJsonFile('sailpoint-roles.json', body); },
    getBlueprints: () => readJsonFileCached('blueprints.json'),
    async saveBlueprints(body) { await writeJsonFile('blueprints.json', body); },
    getTrainingTracks: () => readJsonFileCached('training-tracks.json'),
    async saveTrainingTracks(body) { await writeJsonFile('training-tracks.json', body); },
    getSPExportTable: () => readJsonFileCached('sp-export-table.json'),
    async saveSPExportTable(body) { await writeJsonFile('sp-export-table.json', body); },
    async appendJobCodes(toAdd) {
      return withAppendLock('job-codes.json', async () => {
        const current = await readJsonFile('job-codes.json');
        const existingCodes = new Set((current || []).map((j) => normalizeJobCode(j.jobCode)));
        const added = [];
        for (const item of toAdd) {
          const code = normalizeJobCode(item.jobCode);
          if (!code) continue;
          if (existingCodes.has(code)) continue;
          existingCodes.add(code);
          added.push({
            id: item.id || crypto.randomUUID(),
            jobCode: code,
            jobTitle: (item.jobTitle || '').trim() || '',
            currentStatus: item.currentStatus || 'Active'
          });
        }
        if (added.length === 0) return { added: 0 };
        const merged = [...(Array.isArray(current) ? current : []), ...added];
        await writeJsonFile('job-codes.json', merged);
        return { added: added.length };
      });
    },
    async appendDepartments(toAdd) {
      return withAppendLock('departments.json', async () => {
        const current = await readJsonFile('departments.json');
        const existingIds = new Set((current || []).map((d) => (d.deptId || '').trim().toUpperCase()));
        const added = [];
        for (const item of toAdd) {
          const deptId = (item.deptId || '').trim();
          if (!deptId) continue;
          const key = deptId.toUpperCase();
          if (existingIds.has(key)) continue;
          existingIds.add(key);
          added.push({
            id: item.id || crypto.randomUUID(),
            deptId,
            deptDescription: (item.deptDescription || '').trim() || ''
          });
        }
        if (added.length === 0) return { added: 0 };
        const merged = [...(Array.isArray(current) ? current : []), ...added];
        await writeJsonFile('departments.json', merged);
        return { added: added.length };
      });
    },
    async appendSailpointRoles(toAdd) {
      return withAppendLock('sailpoint-roles.json', async () => {
        const current = await readJsonFile('sailpoint-roles.json');
        const existingRoles = new Set((current || []).map((r) => (r.sailpointRole || '').trim().toUpperCase()));
        const added = [];
        for (const item of toAdd) {
          const sailpointRole = (item.sailpointRole || '').trim();
          if (!sailpointRole) continue;
          const key = sailpointRole.toUpperCase();
          if (existingRoles.has(key)) continue;
          existingRoles.add(key);
          added.push({
            id: item.id || crypto.randomUUID(),
            sailpointRole,
            status: (item.status || '').trim() || 'Active',
            templates: (item.templates || item.description || '').trim() || '',
            subtemplates: (item.subtemplates || '').trim() || '',
            requestable: (item.requestable || '').trim() || '',
            matchedAccessProfile: (item.matchedAccessProfile || '').trim() || '',
            entitlementType: (item.entitlementType || '').trim() || '',
            instructions: (item.instructions || item.entitlements || '').trim() || '',
            description: (item.description || '').trim() || '',
            entitlements: (item.entitlements || '').trim() || ''
          });
        }
        if (added.length === 0) return { added: 0 };
        const merged = [...(Array.isArray(current) ? current : []), ...added];
        await writeJsonFile('sailpoint-roles.json', merged);
        return { added: added.length };
      });
    },
    async appendBlueprints(toAdd) {
      return withAppendLock('blueprints.json', async () => {
        const current = await readJsonFile('blueprints.json');
        const existingIds = new Set((current || []).map((b) => (b.blueprintId || '').trim().toUpperCase()));
        const added = [];
        for (const item of toAdd) {
          const blueprintId = (item.blueprintId || '').trim();
          if (!blueprintId) continue;
          const key = blueprintId.toUpperCase();
          if (existingIds.has(key)) continue;
          existingIds.add(key);
          added.push({
            id: item.id || crypto.randomUUID(),
            blueprintId,
            blueprintName: (item.blueprintName || '').trim() || ''
          });
        }
        if (added.length === 0) return { added: 0 };
        const merged = [...(Array.isArray(current) ? current : []), ...added];
        await writeJsonFile('blueprints.json', merged);
        return { added: added.length };
      });
    },
    async appendTrainingTracks(toAdd) {
      return withAppendLock('training-tracks.json', async () => {
        const current = await readJsonFile('training-tracks.json');
        const existingNames = new Set(
          (current || []).map((t) => (t.trackName || '').trim().toLowerCase()).filter(Boolean)
        );
        const added = [];
        for (const item of toAdd || []) {
          const trackName = (item.trackName || '').trim();
          if (!trackName) continue;
          const key = trackName.toLowerCase();
          if (existingNames.has(key)) continue;
          existingNames.add(key);
          added.push({
            id: item.id || crypto.randomUUID(),
            trackName,
          });
        }
        if (added.length === 0) return { added: 0 };
        const merged = [...(Array.isArray(current) ? current : []), ...added];
        await writeJsonFile('training-tracks.json', merged);
        return { added: added.length };
      });
    },
    async appendTemplateLinks(toAdd) {
      return withAppendLock('template-links.json', async () => {
        const current = await readJsonFile('template-links.json');
        const merged = [...(Array.isArray(current) ? current : [])];
        let addedCount = 0;
        for (const item of toAdd || []) {
          const ut = String(item.userRecordType || '').trim();
          const templateId = String(item.templateId ?? '');
          const templateName = String(item.templateName ?? '');
          if (!ut || (!templateId.trim() && !templateName.trim())) continue;
          merged.push({
            id: item.id || crypto.randomUUID(),
            userRecordType: ut || 'Linkable Template',
            templateId,
            templateName,
            primaryTemplateOwner: String(item.primaryTemplateOwner ?? ''),
            templateDisplayTitle: String(item.templateDisplayTitle ?? ''),
            subtemplateId: String(item.subtemplateId ?? ''),
            subtemplateName: String(item.subtemplateName ?? ''),
            currentStatus: String(item.currentStatus || 'Active').trim() || 'Active',
          });
          addedCount += 1;
        }
        if (addedCount === 0) return { added: 0 };
        await writeJsonFile('template-links.json', merged);
        return { added: addedCount };
      });
    },
  };
}

/** In-memory read-through cache for MSSQL GET endpoints (avoids repeated full-table queries). */
const MSSQL_READ_CACHE_TTL_MS = 60 * 1000;

function createCachedDataLayer(store, ttlMs = MSSQL_READ_CACHE_TTL_MS) {
  const cache = new Map();
  const cachedGet = (key, fn) => async () => {
    const hit = cache.get(key);
    if (hit && Date.now() - hit.ts < ttlMs) return hit.value;
    const value = await fn();
    cache.set(key, { value, ts: Date.now() });
    return value;
  };
  const bust = (...keys) => {
    for (const k of keys) cache.delete(k);
  };
  const wrapSave = (key, fn) => async (...args) => {
    const result = await fn(...args);
    const saved = args[0];
    // Warm cache with the payload we just wrote so the next GET cannot return stale pre-save data.
    if (Array.isArray(saved)) {
      cache.set(key, { value: saved, ts: Date.now() });
    } else {
      bust(key);
    }
    return result;
  };

  const getRolesFromDb = () => store.getRoles();
  const getJobCategoriesFromDb = () => store.getJobCategories();

  return {
    ...store,
    getRoles: cachedGet('roles', getRolesFromDb),
    getRolesFresh: getRolesFromDb,
    saveRoles: wrapSave('roles', (...args) => store.saveRoles(...args)),
    getJobCategories: cachedGet('jobCategories', getJobCategoriesFromDb),
    getJobCategoriesFresh: getJobCategoriesFromDb,
    saveJobCategories: wrapSave('jobCategories', (...args) => store.saveJobCategories(...args)),
    getJobCodes: cachedGet('jobCodes', () => store.getJobCodes()),
    saveJobCodes: wrapSave('jobCodes', (...args) => store.saveJobCodes(...args)),
    appendJobCodes: wrapSave('jobCodes', (...args) => store.appendJobCodes(...args)),
    getDepartments: cachedGet('departments', () => store.getDepartments()),
    saveDepartments: wrapSave('departments', (...args) => store.saveDepartments(...args)),
    appendDepartments: wrapSave('departments', (...args) => store.appendDepartments(...args)),
    getTemplateLinks: cachedGet('templateLinks', () => store.getTemplateLinks()),
    saveTemplateLinks: wrapSave('templateLinks', (...args) => store.saveTemplateLinks(...args)),
    appendTemplateLinks: wrapSave('templateLinks', (...args) => store.appendTemplateLinks(...args)),
    getSailpointRoles: cachedGet('sailpointRoles', () => store.getSailpointRoles()),
    saveSailpointRoles: wrapSave('sailpointRoles', (...args) => store.saveSailpointRoles(...args)),
    appendSailpointRoles: wrapSave('sailpointRoles', (...args) => store.appendSailpointRoles(...args)),
    getBlueprints: cachedGet('blueprints', () => store.getBlueprints()),
    saveBlueprints: wrapSave('blueprints', (...args) => store.saveBlueprints(...args)),
    appendBlueprints: wrapSave('blueprints', (...args) => store.appendBlueprints(...args)),
    getTrainingTracks: cachedGet('trainingTracks', () => store.getTrainingTracks()),
    saveTrainingTracks: wrapSave('trainingTracks', (...args) => store.saveTrainingTracks(...args)),
    appendTrainingTracks: wrapSave('trainingTracks', (...args) => store.appendTrainingTracks(...args)),
    getSPExportTable: cachedGet('spExportTable', () => store.getSPExportTable()),
    saveSPExportTable: wrapSave('spExportTable', (...args) => store.saveSPExportTable(...args)),
    getAuditLogs: cachedGet('auditLogs', () => store.getAuditLogs()),
    appendAuditLog: wrapSave('auditLogs', (...args) => store.appendAuditLog(...args)),
    replaceAuditLogs: wrapSave('auditLogs', (...args) => store.replaceAuditLogs(...args)),
    getUsers: cachedGet('users', () => store.getUsers()),
    saveUsers: wrapSave('users', (...args) => store.saveUsers(...args)),
  };
}

const dataStore = USE_MSSQL
  ? createCachedDataLayer(require('./db-mssql'))
  : createFileDataLayer();

// Append new job code(s) without removing existing ones (for RBAC edit flow)
app.post('/api/job-codes/append', async (req, res) => {
  try {
    const toAdd = Array.isArray(req.body) ? req.body : (req.body?.jobCodes ? req.body.jobCodes : []);
    if (toAdd.length === 0) {
      return res.status(400).json({ error: 'No job codes to add' });
    }
    const result = await dataStore.appendJobCodes(toAdd);
    if (result.added === 0) {
      return res.json({ success: true, added: 0, message: 'All job codes already exist' });
    }
    res.json({ success: true, added: result.added });
  } catch (error) {
    console.error('Error appending job codes:', error);
    res.status(500).json({ error: 'Failed to append job codes' });
  }
});

// Departments endpoints
app.get('/api/departments', async (req, res) => {
  try {
    const departments = await dataStore.getDepartments();
    res.json(departments);
  } catch (error) {
    console.error('Error reading departments:', error);
    res.status(500).json({ error: 'Failed to read departments' });
  }
});

app.post('/api/departments', async (req, res) => {
  try {
    await dataStore.saveDepartments(req.body);
    res.json({ success: true });
  } catch (error) {
    console.error('Error saving departments:', error);
    res.status(500).json({ error: 'Failed to save departments' });
  }
});

// Template Links endpoints
app.get('/api/template-links', async (req, res) => {
  try {
    const templateLinks = await dataStore.getTemplateLinks();
    res.json(templateLinks);
  } catch (error) {
    console.error('Error reading template links:', error);
    res.status(500).json({ error: 'Failed to read template links' });
  }
});

app.post('/api/template-links', async (req, res) => {
  try {
    await dataStore.saveTemplateLinks(req.body);
    res.json({ success: true });
  } catch (error) {
    console.error('Error saving template links:', error);
    res.status(500).json({ error: 'Failed to save template links' });
  }
});

app.post('/api/template-links/append', async (req, res) => {
  try {
    const toAdd = Array.isArray(req.body) ? req.body : (req.body?.templateLinks ? req.body.templateLinks : []);
    if (toAdd.length === 0) {
      return res.status(400).json({ error: 'No template links to add' });
    }
    const result = await dataStore.appendTemplateLinks(toAdd);
    if (result.added === 0) {
      return res.json({ success: true, added: 0, message: 'No valid template link rows to insert' });
    }
    res.json({ success: true, added: result.added });
  } catch (error) {
    console.error('Error appending template links:', error);
    res.status(500).json({ error: 'Failed to append template links' });
  }
});

app.post('/api/departments/append', async (req, res) => {
  try {
    const toAdd = Array.isArray(req.body) ? req.body : (req.body?.departments ? req.body.departments : []);
    if (toAdd.length === 0) {
      return res.status(400).json({ error: 'No departments to add' });
    }
    const result = await dataStore.appendDepartments(toAdd);
    if (result.added === 0) {
      return res.json({ success: true, added: 0, message: 'All departments already exist' });
    }
    res.json({ success: true, added: result.added });
  } catch (error) {
    console.error('Error appending departments:', error);
    res.status(500).json({ error: 'Failed to append departments' });
  }
});

// Sailpoint Roles endpoints
app.get('/api/sailpoint-roles', async (req, res) => {
  try {
    const sailpointRoles = await dataStore.getSailpointRoles();
    res.json(sailpointRoles);
  } catch (error) {
    console.error('Error reading sailpoint roles:', error);
    res.status(500).json({ error: 'Failed to read sailpoint roles' });
  }
});

// SP Export Table endpoints
app.get('/api/sp-export-table', async (req, res) => {
  try {
    const rows = await dataStore.getSPExportTable();
    res.json(rows);
  } catch (error) {
    console.error('Error reading SP export table:', error);
    res.status(500).json({ error: 'Failed to read SP export table' });
  }
});

app.post('/api/sp-export-table', async (req, res) => {
  try {
    await dataStore.saveSPExportTable(req.body);
    res.json({ success: true });
  } catch (error) {
    console.error('Error saving SP export table:', error);
    res.status(500).json({ error: 'Failed to save SP export table' });
  }
});

app.post('/api/sailpoint-roles', async (req, res) => {
  try {
    await dataStore.saveSailpointRoles(req.body);
    res.json({ success: true });
  } catch (error) {
    console.error('Error saving sailpoint roles:', error);
    res.status(500).json({ error: 'Failed to save sailpoint roles' });
  }
});

app.post('/api/sailpoint-roles/append', async (req, res) => {
  try {
    const toAdd = Array.isArray(req.body) ? req.body : (req.body?.sailpointRoles ? req.body.sailpointRoles : []);
    if (toAdd.length === 0) {
      return res.status(400).json({ error: 'No sailpoint roles to add' });
    }
    const result = await dataStore.appendSailpointRoles(toAdd);
    if (result.added === 0) {
      return res.json({ success: true, added: 0, message: 'All sailpoint roles already exist' });
    }
    res.json({ success: true, added: result.added });
  } catch (error) {
    console.error('Error appending sailpoint roles:', error);
    res.status(500).json({ error: 'Failed to append sailpoint roles' });
  }
});

// Blueprints endpoints
app.get('/api/blueprints', async (req, res) => {
  try {
    const blueprints = await dataStore.getBlueprints();
    res.json(blueprints);
  } catch (error) {
    console.error('Error reading blueprints:', error);
    res.status(500).json({ error: 'Failed to read blueprints' });
  }
});

app.post('/api/blueprints', async (req, res) => {
  try {
    await dataStore.saveBlueprints(req.body);
    res.json({ success: true });
  } catch (error) {
    console.error('Error saving blueprints:', error);
    res.status(500).json({ error: 'Failed to save blueprints' });
  }
});

// Training Tracks endpoints (reference table for role dropdown, like job categories)
app.get('/api/training-tracks', async (req, res) => {
  try {
    const tracks = await dataStore.getTrainingTracks();
    res.json(tracks);
  } catch (error) {
    console.error('Error reading training tracks:', error);
    res.status(500).json({ error: 'Failed to read training tracks' });
  }
});

app.post('/api/training-tracks', async (req, res) => {
  try {
    await dataStore.saveTrainingTracks(req.body);
    res.json({ success: true });
  } catch (error) {
    console.error('Error saving training tracks:', error);
    res.status(500).json({ error: 'Failed to save training tracks' });
  }
});

app.post('/api/training-tracks/append', async (req, res) => {
  try {
    const toAdd = Array.isArray(req.body) ? req.body : (req.body?.trainingTracks ? req.body.trainingTracks : []);
    if (toAdd.length === 0) {
      return res.status(400).json({ error: 'No training tracks to add' });
    }
    const result = await dataStore.appendTrainingTracks(toAdd);
    if (result.added === 0) {
      return res.json({ success: true, added: 0, message: 'All training tracks already exist' });
    }
    res.json({ success: true, added: result.added });
  } catch (error) {
    console.error('Error appending training tracks:', error);
    res.status(500).json({ error: 'Failed to append training tracks' });
  }
});

app.post('/api/blueprints/append', async (req, res) => {
  try {
    const toAdd = Array.isArray(req.body) ? req.body : (req.body?.blueprints ? req.body.blueprints : []);
    if (toAdd.length === 0) {
      return res.status(400).json({ error: 'No blueprints to add' });
    }
    const result = await dataStore.appendBlueprints(toAdd);
    if (result.added === 0) {
      return res.json({ success: true, added: 0, message: 'All blueprints already exist' });
    }
    res.json({ success: true, added: result.added });
  } catch (error) {
    console.error('Error appending blueprints:', error);
    res.status(500).json({ error: 'Failed to append blueprints' });
  }
});

// SPA fallback: serve index.html for non-API routes; 404 JSON for unknown API routes (so they don't hang)
if (fsSync.existsSync(BUILD_DIR)) {
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) {
      return res.status(404).json({ error: 'Not found', path: req.path });
    }
    const indexPath = path.join(BUILD_DIR, 'index.html');
    if (!fsSync.existsSync(indexPath)) {
      return res.status(500).json({ error: 'Build index.html not found' });
    }
    res.sendFile(indexPath, (err) => {
      if (err) {
        console.error('Error sending index.html:', err);
        if (!res.headersSent) res.status(500).json({ error: 'Failed to serve app' });
      }
    });
  });
} else {
  // No build folder: still respond to GET / so the server doesn't 404/hang
  app.get('*', (req, res) => {
    if (req.path.startsWith('/api')) {
      return res.status(404).json({ error: 'Not found', path: req.path });
    }
    res.status(503).json({
      error: 'App not built',
      message: 'Run "npm run build" and restart the server to serve the React app.',
      dataDir: DATA_DIR
    });
  });
}

// Global error handler: catch any unhandled errors and return 500 (don't leave requests hanging)
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  if (res.headersSent) return next(err);
  res.status(500).json({
    error: 'Internal server error',
    message: err.message || 'An unexpected error occurred'
  });
});

const WEEK_MS = 7 * 24 * 60 * 60 * 1000;

const server = app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
  if (USE_MSSQL) {
    console.log(`Datastore: MSSQL (database: ${mssqlDatabaseName() || 'unknown'})`);
  } else {
    console.log(`Datastore: JSON files in ${DATA_DIR}`);
  }
  console.log(`Data directory: ${DATA_DIR}`);
  console.log(`Build folder: ${fsSync.existsSync(BUILD_DIR) ? 'present' : 'MISSING (run npm run build)'}`);
  console.log(`Scheduled backups: weekly to ${path.join(DATA_DIR, 'backups')} (retain ${BACKUP_RETENTION_COUNT})`);
  setTimeout(runScheduledBackup, 60 * 1000);
  setInterval(runScheduledBackup, WEEK_MS);
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\nPort ${PORT} is already in use.`);
    console.error('Either stop the other process using this port, or run with a different port:');
    console.error(`  set PORT=3002 && npm run server   (Windows)`);
    console.error(`  PORT=3002 npm run server         (Mac/Linux)\n`);
  } else {
    console.error('Server error:', err);
  }
  process.exit(1);
});
