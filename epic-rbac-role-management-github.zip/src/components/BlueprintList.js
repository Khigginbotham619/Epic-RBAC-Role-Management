import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { getBlueprints, saveBlueprints, addBlueprintAuditLog, addAuditLogsBatch, generateId } from '../utils/storage';
import { exportToCSV } from '../utils/csvExport';
import { importFromCSV } from '../utils/csvImport';
import { importFromExcel } from '../utils/excelImport';
import { sanitizeCellText } from '../utils/textSanitize';
import BlueprintForm from './BlueprintForm';
import ImportPreviewDialog from './ImportPreviewDialog';
import { useToast } from '../context/ToastContext';
import SortableTh from './SortableTh';
import { sortRowsByKey, nextSortState } from '../utils/tableSort';
import './BlueprintList.css';

const BP_BULK_FIELDS = [
  { key: 'blueprintId', label: 'Blueprint ID' },
  { key: 'blueprintName', label: 'Blueprint Name' },
];

const BpBulkUpdateDialog = ({ selectedCount, onApply, onClose }) => {
  const [field, setField] = useState('');
  const [value, setValue] = useState('');
  const fieldDef = BP_BULK_FIELDS.find((f) => f.key === field);
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!field) { alert('Please select a field.'); return; }
    if (!window.confirm(`Set "${fieldDef?.label || field}" to "${value}" on ${selectedCount} blueprint(s)?`)) return;
    onApply(field, value);
  };
  return (
    <div className="find-replace-overlay" onClick={onClose}>
      <div className="find-replace-dialog" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 420 }}>
        <div className="find-replace-header">
          <h3>Bulk Update ({selectedCount} selected)</h3>
          <button type="button" className="find-replace-close" onClick={onClose}>&times;</button>
        </div>
        <form onSubmit={handleSubmit} style={{ padding: '1rem 1.25rem' }}>
          <div style={{ marginBottom: '0.75rem' }}>
            <label style={{ display: 'block', marginBottom: '0.25rem', fontWeight: 500, fontSize: '0.9rem' }}>Field</label>
            <select value={field} onChange={(e) => { setField(e.target.value); setValue(''); }} style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1' }}>
              <option value="">Select field...</option>
              {BP_BULK_FIELDS.map((f) => <option key={f.key} value={f.key}>{f.label}</option>)}
            </select>
          </div>
          {field && (
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', marginBottom: '0.25rem', fontWeight: 500, fontSize: '0.9rem' }}>New Value</label>
              <input type="text" value={value} onChange={(e) => setValue(e.target.value)} style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1', boxSizing: 'border-box' }} autoFocus placeholder="Enter new value (leave empty to clear)" />
            </div>
          )}
          <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
            <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn-primary" disabled={!field}>Apply</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const BlueprintList = () => {
  const { showToast } = useToast();
  const [blueprints, setBlueprints] = useState([]);
  const [filteredBlueprints, setFilteredBlueprints] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isImporting, setIsImporting] = useState(false);
  const [editingBlueprint, setEditingBlueprint] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [selectedRowId, setSelectedRowId] = useState(null);
  const [selectedRows, setSelectedRows] = useState(new Set());
  const [showBulkUpdate, setShowBulkUpdate] = useState(false);
  const undoRef = useRef(null);
  const [canUndo, setCanUndo] = useState(false);
  const [importPreview, setImportPreview] = useState(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    loadBlueprints();
  }, []);

  useEffect(() => {
    filterBlueprints();
  }, [searchTerm, blueprints]);

  const loadBlueprints = async () => {
    const loadedBlueprints = await getBlueprints();
    setBlueprints(loadedBlueprints);
    setFilteredBlueprints(loadedBlueprints);
  };

  const snapshotForUndo = useCallback((description) => {
    undoRef.current = { data: [...blueprints], description };
    setCanUndo(true);
  }, [blueprints]);

  const handleUndo = async () => {
    if (!undoRef.current) return;
    const { data: prevData, description } = undoRef.current;
    if (!window.confirm(`Undo "${description}"?`)) return;
    setBlueprints(prevData);
    try {
      await saveBlueprints(prevData);
      undoRef.current = null;
      setCanUndo(false);
      loadBlueprints();
      showToast(`Undone: ${description}`);
    } catch (err) {
      alert(err?.message || 'Undo failed.');
    }
  };

  const handleRowSelect = (id) => {
    setSelectedRows((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const handleDeleteSelected = async () => {
    if (selectedRows.size === 0) return;
    if (!window.confirm(`Delete ${selectedRows.size} selected blueprint(s)?`)) return;
    snapshotForUndo(`Bulk delete ${selectedRows.size} blueprint(s)`);
    const updated = blueprints.filter((b) => !selectedRows.has(b.id));
    setBlueprints(updated);
    try {
      await saveBlueprints(updated);
      for (const b of blueprints) {
        if (selectedRows.has(b.id)) await addBlueprintAuditLog('DELETE', b, b);
      }
      const count = selectedRows.size;
      setSelectedRows(new Set());
      loadBlueprints();
      showToast(`Deleted ${count} blueprint(s).`);
    } catch (err) {
      alert(err?.message || 'Delete failed.');
    }
  };

  const handleBulkUpdate = async (field, value) => {
    if (selectedRows.size === 0) return;
    snapshotForUndo(`Bulk update ${selectedRows.size} blueprint(s) → ${field}`);
    const prevData = blueprints;
    const updated = blueprints.map((b) => {
      if (!selectedRows.has(b.id)) return b;
      return { ...b, [field]: value };
    });
    setBlueprints(updated);
    try {
      await saveBlueprints(updated);
      for (const b of updated) {
        if (selectedRows.has(b.id)) {
          const old = prevData.find((o) => o.id === b.id);
          if (old) await addBlueprintAuditLog('UPDATE', b, old);
        }
      }
      const count = selectedRows.size;
      setSelectedRows(new Set());
      loadBlueprints();
      showToast(`Updated ${count} blueprint(s).`);
    } catch (err) {
      alert(err?.message || 'Update failed.');
    }
    setShowBulkUpdate(false);
  };

  const filterBlueprints = () => {
    if (!searchTerm.trim()) {
      setFilteredBlueprints(blueprints);
      return;
    }

    const term = searchTerm.trim().toLowerCase();
    const filtered = blueprints.filter((blueprint) =>
      Object.values(blueprint).some((value) =>
        value && value.toString().toLowerCase().includes(term)
      )
    );
    setFilteredBlueprints(filtered);
  };

  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  const handleSort = useCallback((key) => {
    setSortConfig((prev) => nextSortState(prev, key));
  }, []);
  const displayBlueprints = useMemo(
    () => sortRowsByKey(filteredBlueprints, sortConfig.key, sortConfig.direction),
    [filteredBlueprints, sortConfig.key, sortConfig.direction]
  );

  const allVisibleSelected = displayBlueprints.length > 0 && displayBlueprints.every((b) => selectedRows.has(b.id));

  const handleSelectAll = () => {
    if (allVisibleSelected) {
      setSelectedRows((prev) => { const next = new Set(prev); displayBlueprints.forEach((b) => next.delete(b.id)); return next; });
    } else {
      setSelectedRows((prev) => { const next = new Set(prev); displayBlueprints.forEach((b) => next.add(b.id)); return next; });
    }
  };

  const handleAdd = () => {
    setEditingBlueprint(null);
    setShowForm(true);
  };

  const handleEdit = (blueprint) => {
    setEditingBlueprint(blueprint);
    setShowForm(true);
    setSelectedRowId(null);
  };

  const handleDelete = async (blueprint) => {
    if (window.confirm('Are you sure you want to delete this blueprint?')) {
      snapshotForUndo(`Delete blueprint ${blueprint.blueprintId || blueprint.id}`);
      const updatedBlueprints = blueprints.filter((b) => b.id !== blueprint.id);
      setBlueprints(updatedBlueprints);
      await saveBlueprints(updatedBlueprints);
      await addBlueprintAuditLog('DELETE', blueprint, blueprint);
      loadBlueprints();
    }
  };

  const handleFormSubmit = async (blueprintData) => {
    snapshotForUndo(editingBlueprint ? `Edit blueprint ${editingBlueprint.blueprintId || editingBlueprint.id}` : 'Create new blueprint');
    if (editingBlueprint) {
      const oldData = { ...editingBlueprint };
      const updatedBlueprints = blueprints.map((b) =>
        b.id === editingBlueprint.id ? { ...blueprintData, id: editingBlueprint.id } : b
      );
      setBlueprints(updatedBlueprints);
      await saveBlueprints(updatedBlueprints);
      await addBlueprintAuditLog('UPDATE', { ...blueprintData, id: editingBlueprint.id }, oldData);
    } else {
      const newBlueprint = { ...blueprintData, id: generateId() };
      const updatedBlueprints = [...blueprints, newBlueprint];
      setBlueprints(updatedBlueprints);
      await saveBlueprints(updatedBlueprints);
      await addBlueprintAuditLog('CREATE', newBlueprint);
    }
    setShowForm(false);
    setEditingBlueprint(null);
    loadBlueprints();
  };

  const handleExport = () => {
    const fieldToHeaderMap = {
      'blueprintId': 'Blueprint ID',
      'blueprintName': 'Blueprint Name'
    };

    const fieldNames = Object.keys(fieldToHeaderMap);
    const csvHeaders = Object.values(fieldToHeaderMap);

    const exportData = blueprints.map(blueprint => {
      const row = {};
      fieldNames.forEach(fieldName => {
        row[fieldToHeaderMap[fieldName]] = blueprint[fieldName] || '';
      });
      return row;
    });

    const count = exportData.length;
    if (count >= 500) {
      showToast('Preparing export…');
      setTimeout(() => {
        try {
          exportToCSV(exportData, 'blueprints.csv', csvHeaders);
          showToast(`Exported ${count} blueprint(s)`);
        } catch (e) {
          showToast('Export failed');
        }
      }, 0);
    } else {
      exportToCSV(exportData, 'blueprints.csv', csvHeaders);
      showToast(`Exported ${count} blueprint(s)`);
    }
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const name = (file.name || '').toLowerCase();
    const isCsv = name.endsWith('.csv');
    const isExcel = name.endsWith('.xlsx') || name.endsWith('.xls');
    if (!isCsv && !isExcel) {
      alert('Please select a CSV or Excel file (.csv, .xlsx, .xls)');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    const headerMap = {
      'Blueprint ID': 'blueprintId', 'blueprintId': 'blueprintId',
      'Blueprint Name': 'blueprintName', 'blueprintName': 'blueprintName'
    };

    const runImport = (importedData) => {
      const rawData = Array.isArray(importedData) ? importedData : [];
      const mappedData = rawData.map((row) => {
        const mapped = {};
        Object.keys(row).forEach((csvHeader) => {
          const normalizedHeader = String(csvHeader).trim();
          const match = Object.keys(headerMap).find(
            key => key.toLowerCase() === normalizedHeader.toLowerCase()
          );
          const internalKey = match ? headerMap[match] : normalizedHeader;
          let value = row[csvHeader] || '';
          mapped[internalKey] = String(value).replace(/\s+/g, ' ').trim();
        });
        return mapped;
      });

      if (!mappedData.length) {
        setIsImporting(false);
        alert('No valid data rows found.');
        if (fileInputRef.current) fileInputRef.current.value = '';
        return;
      }

      const commitImport = async (importMode = 'merge') => {
        const shouldMerge = importMode === 'merge';
        try {
          snapshotForUndo(`Import ${mappedData.length} blueprint(s)`);
          let finalData;
          if (shouldMerge) {
            const allBlueprints = await getBlueprints();
            const existingByKey = {};
            allBlueprints.forEach((b) => {
              const key = (b.blueprintId || '').trim().toLowerCase();
              if (key) existingByKey[key] = b;
            });
            const auditEntries = [];
            const newBlueprints = [];
            mappedData.forEach((row) => {
              const key = (row.blueprintId || '').trim().toLowerCase();
              if (key && existingByKey[key]) {
                const prev = { ...existingByKey[key] };
                Object.assign(existingByKey[key], { ...row, id: existingByKey[key].id });
                auditEntries.push({ entityType: 'BLUEPRINT', action: 'UPDATE', entityData: existingByKey[key], previousData: prev });
              } else {
                const newBp = { ...row, id: generateId() };
                newBlueprints.push(newBp);
                auditEntries.push({ entityType: 'BLUEPRINT', action: 'CREATE', entityData: newBp });
              }
            });
            finalData = [...allBlueprints, ...newBlueprints];
            await Promise.all([addAuditLogsBatch(auditEntries), saveBlueprints(finalData)]);
          } else {
            finalData = mappedData.map(row => ({ ...row, id: generateId() }));
            const auditEntries = finalData.map((bp) => ({
              entityType: 'BLUEPRINT',
              action: 'CREATE',
              entityData: bp,
            }));
            await Promise.all([addAuditLogsBatch(auditEntries), saveBlueprints(finalData)]);
          }
          loadBlueprints();
          showToast(`Successfully imported ${mappedData.length} blueprint(s)!`);
        } finally {
          setIsImporting(false);
          if (fileInputRef.current) fileInputRef.current.value = '';
        }
      };

      (async () => {
        const existing = await getBlueprints();
        setImportPreview({
          rows: mappedData,
          columns: ['blueprintId', 'blueprintName'],
          existingData: existing,
          matchKey: 'blueprintId',
          onConfirm: commitImport,
        });
      })();
    };

    const onError = (error) => {
      setIsImporting(false);
      alert(`Import failed: ${error}`);
      if (fileInputRef.current) fileInputRef.current.value = '';
    };

    setIsImporting(true);
    if (isCsv) {
      importFromCSV(file, runImport, onError);
    } else {
      importFromExcel(file, (data) => runImport(data), onError);
    }
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingBlueprint(null);
  };

  const handleRowClick = (blueprint) => {
    setSelectedRowId(blueprint.id);
  };

  if (showForm) {
    return (
      <BlueprintForm
        blueprint={editingBlueprint}
        onSubmit={handleFormSubmit}
        onCancel={handleCancel}
      />
    );
  }

  return (
    <div className="blueprint-list">
      <div className="blueprint-list-header">
        <h2>Blueprint List</h2>
        <div className="actions">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".csv,.xlsx,.xls"
            style={{ display: 'none' }}
          />
          <button className="btn-import" onClick={handleImportClick} title="Import blueprints from CSV or Excel" disabled={isImporting}>
            {isImporting ? 'Importing…' : 'Import from CSV or Excel'}
          </button>
          {isImporting && <span className="import-status" role="status">Importing…</span>}
          <button className="btn-export" onClick={handleExport} title="Download blueprints as CSV">
            Export to CSV
          </button>
          <button className="btn-add" onClick={handleAdd} title="Create a new SER blueprint">
            Add New Blueprint
          </button>
          {canUndo && (
            <button type="button" className="btn-secondary btn-undo" onClick={handleUndo} title={undoRef.current ? `Undo: ${undoRef.current.description}` : 'Undo'}>Undo</button>
          )}
          <button type="button" className="btn-secondary" onClick={() => { if (selectedRows.size === 0) { alert('Select rows first.'); return; } setShowBulkUpdate(true); }} disabled={selectedRows.size === 0}>Bulk Update ({selectedRows.size})</button>
          <button type="button" className="btn-secondary btn-danger-outline" onClick={handleDeleteSelected} disabled={selectedRows.size === 0}>Bulk Delete ({selectedRows.size})</button>
        </div>
      </div>

      <div className="search-container">
        <input
          type="text"
          placeholder="Search all fields..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="search-input"
        />
      </div>

      <div className="table-container">
        <table className="blueprint-table">
          <thead>
            <tr>
              <th style={{ width: 36, textAlign: 'center' }}><input type="checkbox" checked={allVisibleSelected} onChange={handleSelectAll} title="Select all" /></th>
              <SortableTh columnKey="blueprintId" sortConfig={sortConfig} onSort={handleSort}>Blueprint ID</SortableTh>
              <SortableTh columnKey="blueprintName" sortConfig={sortConfig} onSort={handleSort}>Blueprint Name</SortableTh>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredBlueprints.length === 0 ? (
              <tr>
                <td colSpan="4" className="no-data">
                  {searchTerm ? 'No blueprints found matching your search.' : 'No blueprints found. Click "Add New Blueprint" to create one.'}
                </td>
              </tr>
            ) : (
              displayBlueprints.map((blueprint) => (
                <tr 
                  key={blueprint.id}
                  className={selectedRowId === blueprint.id ? 'selected' : ''}
                  onClick={() => handleRowClick(blueprint)}
                  style={{ cursor: 'pointer' }}
                >
                  <td style={{ textAlign: 'center' }} onClick={(e) => e.stopPropagation()}><input type="checkbox" checked={selectedRows.has(blueprint.id)} onChange={() => handleRowSelect(blueprint.id)} /></td>
                  <td>{sanitizeCellText(blueprint.blueprintId)}</td>
                  <td className="text-cell">{sanitizeCellText(blueprint.blueprintName)}</td>
                  <td>
                    <button
                      className="btn-edit"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleEdit(blueprint);
                      }}
                    >
                      Edit
                    </button>
                    <button
                      className="btn-delete"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(blueprint);
                      }}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      {showBulkUpdate && (
        <BpBulkUpdateDialog selectedCount={selectedRows.size} onApply={handleBulkUpdate} onClose={() => setShowBulkUpdate(false)} />
      )}
      {importPreview && (
        <ImportPreviewDialog
          rows={importPreview.rows}
          columns={importPreview.columns}
          existingData={importPreview.existingData}
          matchKey={importPreview.matchKey}
          onConfirm={(mode) => { setImportPreview(null); importPreview.onConfirm(mode); }}
          onCancel={() => { setImportPreview(null); setIsImporting(false); if (fileInputRef.current) fileInputRef.current.value = ''; }}
          enableImportMode
          defaultImportMode="merge"
        />
      )}
    </div>
  );
};

export default BlueprintList;
