import React, { useEffect, useRef } from 'react';
import './TableContextMenu.css';

const TableContextMenu = ({ x, y, actions, onClose }) => {
  const menuRef = useRef(null);

  useEffect(() => {
    const handleClick = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) onClose();
    };
    const handleKey = (e) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('mousedown', handleClick);
    document.addEventListener('keydown', handleKey);
    return () => {
      document.removeEventListener('mousedown', handleClick);
      document.removeEventListener('keydown', handleKey);
    };
  }, [onClose]);

  useEffect(() => {
    if (!menuRef.current) return;
    const rect = menuRef.current.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    if (rect.right > vw) menuRef.current.style.left = `${x - rect.width}px`;
    if (rect.bottom > vh) menuRef.current.style.top = `${y - rect.height}px`;
  }, [x, y]);

  return (
    <div ref={menuRef} className="table-context-menu" style={{ left: x, top: y }}>
      {actions.map((action) => (
        <button
          key={action.label}
          className="table-context-menu-item"
          onClick={() => { action.onClick(); onClose(); }}
          disabled={action.disabled}
        >
          {action.label}
        </button>
      ))}
    </div>
  );
};

export default TableContextMenu;
