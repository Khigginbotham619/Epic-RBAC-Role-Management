import React, { useMemo } from 'react';
import { FixedSizeList as List } from 'react-window';

/**
 * Virtualized table component for large datasets
 * Only renders visible rows for better performance
 */
const VirtualizedTable = ({ 
  data, 
  columns, 
  rowHeight = 50,
  tableHeight = 600,
  onRowClick,
  selectedRowId,
  selectedRows,
  onRowSelect
}) => {
  const Row = ({ index, style }) => {
    const row = data[index];
    if (!row) return null;

    const isSelected = selectedRowId === row.id || (selectedRows && selectedRows.has(row.id));

    return (
      <div
        style={{
          ...style,
          display: 'flex',
          borderBottom: '1px solid #e2e8f0',
          backgroundColor: isSelected ? '#dbeafe' : index % 2 === 0 ? '#ffffff' : '#f8fafc',
          cursor: 'pointer',
        }}
        onClick={() => onRowClick && onRowClick(row)}
        className={isSelected ? 'selected' : ''}
      >
        {columns.map((column, colIndex) => {
          const cellValue = column.render 
            ? column.render(row, index) 
            : row[column.key] || '';
          
          return (
            <div
              key={colIndex}
              style={{
                width: column.width || '150px',
                padding: '0.75rem',
                borderRight: colIndex < columns.length - 1 ? '1px solid #e2e8f0' : 'none',
                overflow: 'hidden',
                textOverflow: 'ellipsis',
                whiteSpace: 'nowrap',
                fontSize: '0.9rem',
                color: '#1f2937',
              }}
              title={typeof cellValue === 'string' ? cellValue : ''}
            >
              {cellValue}
            </div>
          );
        })}
      </div>
    );
  };

  const Header = () => (
    <div
      style={{
        display: 'flex',
        backgroundColor: '#eff6ff',
        borderBottom: '2px solid #3b82f6',
        position: 'sticky',
        top: 0,
        zIndex: 10,
      }}
    >
      {columns.map((column, index) => (
        <div
          key={index}
          onClick={() => column.onSort && column.onSort(column.key)}
          style={{
            width: column.width || '150px',
            padding: '1rem 0.75rem',
            fontWeight: 600,
            color: '#1e3a8a',
            borderRight: index < columns.length - 1 ? '1px solid #3b82f6' : 'none',
            cursor: column.onSort ? 'pointer' : 'default',
            fontSize: '0.85rem',
          }}
        >
          {column.header}
          {column.sortIndicator && ` ${column.sortIndicator}`}
        </div>
      ))}
    </div>
  );

  if (data.length === 0) {
    return (
      <div style={{ padding: '3rem', textAlign: 'center', color: '#64748b' }}>
        No data available
      </div>
    );
  }

  return (
    <div style={{ height: tableHeight, overflow: 'auto' }}>
      <Header />
      <List
        height={tableHeight - 60} // Subtract header height
        itemCount={data.length}
        itemSize={rowHeight}
        width="100%"
      >
        {Row}
      </List>
    </div>
  );
};

export default VirtualizedTable;
