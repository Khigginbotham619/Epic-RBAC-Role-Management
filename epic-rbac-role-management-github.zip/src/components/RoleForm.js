import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import './RoleForm.css';
import './JobCategoryForm.css';
import { getJobCategories, getTrainingTracks, appendTrainingTracks, getDepartments, getJobCodes, getBlueprints, getTemplateLinks, getRoles, appendJobCodes, appendDepartments, appendBlueprints, appendTemplateLinks, saveJobCodes, generateId, addJobCodeAuditLog, addDepartmentAuditLog, addBlueprintAuditLog, addTemplateLinkAuditLog, invalidateCache } from '../utils/storage';
import {
  displayTitlesFromTemplateLinks,
  formatCommaSeparatedTemplateNamesUpper,
  formatTemplateNameTitleCase,
  hasTemplateLookupInput,
  normalizeSubtemplateCommaList,
  syncJobCategorySubtemplatesFromTemplateLinks,
  syncRoleLinkedTemplateFromTemplateLinks,
  templateNamesFromTemplateLinks,
} from '../utils/templateLinkRoleMatch';
import { buildTemplateLinkRowsToAppendFromRole } from '../utils/templateLinkAppend';
import {
  buildBlueprintsToAppend,
  buildTrainingTracksToAppend,
  roleFormTrainingTrackFieldValues,
} from '../utils/referenceTableAppend';
import { normalizeJobCode } from '../utils/jobCodeUtils';
import { buildLastEditStamp } from '../utils/lastEditStamp';
import { getFillUpdatesForRole } from '../utils/fillBlanks';
import TrainingTrackDropdown, { TRAINING_TRACK_OTHER } from './TrainingTrackDropdown';
import BlueprintDropdown, { BLUEPRINT_OTHER } from './BlueprintDropdown';

const validateRbacCode = (value) => {
  if (!value || !String(value).trim()) return 'RBAC CODE is required.';
  return '';
};

const validateRoleJobTitle = (value) => {
  if (!value || !String(value).trim()) return 'Job title is required.';
  return '';
};

const departmentImpliesAffiliate = (department) =>
  String(department || '').toLowerCase().includes('affiliate');

const EXTRA_FORM_FIELD_LABELS = {
  rbacCode: 'RBAC CODE',
  status: 'Status',
  sailpointRole: 'Sailpoint Role',
  publishToSailpoint: 'Publish to Sailpoint',
  affiliate: 'Affiliate',
};

const RBAC_FILL_LABELS = {
  deptCodeId: 'Dept Code/ID',
  jobCodeId: 'Job Code/ID',
  department: 'Department',
  jobTitle: 'Job Title',
  jobCategory: 'Job Category',
  linkedRoleTemplateId: 'Linked Role Template ID',
  linkedRoleTemplateName: 'Linked Role Template Name',
  subtemplateId: 'Subtemplate ID',
  subtemplateDescription: 'Subtemplate Description',
  templateDisplayTitle: 'Template Display Title',
  empNeeded: 'EMP Needed',
  slaNeeded: 'SER Needed',
  slaBlueprintId: 'SER Blueprint ID',
  blueprintName: 'Blueprint Name',
  trainingTrack: 'Training Track 1',
  trainingTrack2: 'Training Track 2',
  trainingTrack3: 'Training Track 3',
  trainingTrack4: 'Training Track 4',
  trainingTrack5: 'Training Track 5',
  trainingTrack6: 'Training Track 6',
};

const FORM_FIELD_LABELS = { ...RBAC_FILL_LABELS, ...EXTRA_FORM_FIELD_LABELS };

function normFieldVal(v) {
  if (v == null) return '';
  return String(v).trim();
}

/** Compare saved role vs payload; returns stamp detail string (not including date/user). */
function summarizeRoleFormEdit(initial, next) {
  const skip = new Set(['lastEditChangeControlDateReason']);
  const keys = new Set([
    ...Object.keys(initial || {}),
    ...Object.keys(next || {}),
  ]);
  const changed = [];
  for (const k of keys) {
    if (skip.has(k)) continue;
    if (normFieldVal(initial?.[k]) !== normFieldVal(next?.[k])) {
      changed.push(FORM_FIELD_LABELS[k] || k);
    }
  }
  if (changed.length === 0) return 'Edited role (form)';
  return `Edited: ${changed.join(', ')}`;
}

const RoleForm = ({ role, onSubmit, onCancel, allowTrainingTrackDropdown = false }) => {
  const firstInputRef = useRef(null);
  const [isDirty, setIsDirty] = useState(false);
  const [errors, setErrors] = useState({ rbacCode: '', jobTitle: '' });
  const [formData, setFormData] = useState({
    rbacCode: '',
    deptCodeId: '',
    department: '',
    jobCodeId: '',
    jobTitle: '',
    jobCategory: '',
    linkedRoleTemplateId: '',
    linkedRoleTemplateName: '',
    templateDisplayTitle: '',
    subtemplateId: '',
    subtemplateDescription: '',
    empNeeded: '',
    slaNeeded: '',
    slaBlueprintId: '',
    blueprintName: '',
    trainingTrack: '',
    trainingTrack2: '',
    trainingTrack3: '',
    trainingTrack4: '',
    trainingTrack5: '',
    trainingTrack6: '',
    sailpointRole: '',
    publishToSailpoint: 'Yes',
    affiliate: '',
    lastEditChangeControlDateReason: '',
    status: 'Active',
  });

  const [jobCategories, setJobCategories] = useState([]);
  const [trainingTracks, setTrainingTracks] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [jobCodes, setJobCodes] = useState([]);
  const [blueprints, setBlueprints] = useState([]);
  const [templateLinks, setTemplateLinks] = useState([]);
  const [allRoles, setAllRoles] = useState([]);
  // Focus first field when form is shown so users can start typing immediately
  useEffect(() => {
    const t = setTimeout(() => firstInputRef.current?.focus(), 0);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    // Load job categories, training tracks, departments, job codes, blueprints from storage
    (async () => {
      const categories = await getJobCategories();
      const tracks = await getTrainingTracks();
      const depts = await getDepartments();
      const codes = await getJobCodes();
      const blueprintsData = await getBlueprints();
      invalidateCache('template-links');
      const templateLinksData = await getTemplateLinks();
      const rolesList = await getRoles();
      setJobCategories(categories || []);
      setTrainingTracks(tracks || []);
      setDepartments(depts || []);
      setJobCodes(codes || []);
      setBlueprints(blueprintsData || []);
      setTemplateLinks(Array.isArray(templateLinksData) ? templateLinksData : []);
      setAllRoles(Array.isArray(rolesList) ? rolesList : []);
    })();
  }, []);

  const roleForFill = useMemo(
    () => ({
      ...formData,
      id: role?.id || '__draft__',
    }),
    [formData, role]
  );

  const fillContext = useMemo(
    () => ({
      roles: allRoles,
      jobCategories,
      jobCodes,
      departments,
      blueprints,
      templateLinks,
    }),
    [allRoles, jobCategories, jobCodes, departments, blueprints, templateLinks]
  );

  const rbacFillUpdates = useMemo(() => {
    const code = String(formData.rbacCode || '').trim();
    if (code.length < 4) return {};
    return getFillUpdatesForRole(roleForFill, fillContext);
  }, [roleForFill, fillContext, formData.rbacCode]);

  const rbacFillSuggestions = useMemo(() => {
    const out = {};
    for (const [key, val] of Object.entries(rbacFillUpdates)) {
      if (key === 'sailpointRole') continue;
      const s = val == null ? '' : String(val).trim();
      if (s !== '') out[key] = val;
    }
    return out;
  }, [rbacFillUpdates]);

  // Helper function to add a new job code if it doesn't exist (append only; never removes existing). Job code is always 4 chars with leading zeros.
  const addJobCodeIfMissing = useCallback(async (jobCodeId, jobTitle = '') => {
    const code = normalizeJobCode(jobCodeId);
    if (!code) return false;
    const existingJobCode = jobCodes.find(j => normalizeJobCode(j.jobCode) === code);
    if (existingJobCode) return false; // Already in local list
    
    const newJobCode = {
      id: generateId(),
      jobCode: code,
      jobTitle: (jobTitle || '').trim() || '',
      currentStatus: 'Active'
    };
    const result = await appendJobCodes([newJobCode]);
    if (result.added === 0) return false; // Server said already exists
    await addJobCodeAuditLog('CREATE', newJobCode);
    const updatedCodes = await getJobCodes();
    setJobCodes(updatedCodes || []);
    return true;
  }, [jobCodes]);

  // Helper function to add a new department if it doesn't exist (from RBAC/role edit; append only)
  const addDepartmentIfMissing = useCallback(async (deptCodeId, deptDescription = '') => {
    if (!deptCodeId || !deptCodeId.trim()) return false;
    const trimmed = deptCodeId.trim();
    const existingDept = departments.find(d => (d.deptId || '').trim() === trimmed);
    if (existingDept) return false;
    const newDepartment = { id: generateId(), deptId: trimmed, deptDescription: (deptDescription || '').trim() || '' };
    const result = await appendDepartments([newDepartment]);
    if (result.added === 0) return false;
    await addDepartmentAuditLog('CREATE', newDepartment);
    const updatedDepts = await getDepartments();
    setDepartments(updatedDepts || []);
    return true;
  }, [departments]);

  // Helper function to add a new blueprint if it doesn't exist (from RBAC/role edit; append only). Job Category is never added from RBAC.
  const addBlueprintIfMissing = useCallback(async (blueprintId, blueprintName = '') => {
    const trimmed = String(blueprintId == null ? '' : blueprintId).trim();
    if (!trimmed) return false;
    const existing = blueprints.find(b => String(b.blueprintId ?? b.id ?? '').trim() === trimmed);
    if (existing) return false;
    const newBlueprint = { id: generateId(), blueprintId: trimmed, blueprintName: (blueprintName || '').trim() || '' };
    const result = await appendBlueprints([newBlueprint]);
    if (result.added === 0) return false;
    await addBlueprintAuditLog('CREATE', newBlueprint);
    const updated = await getBlueprints();
    setBlueprints(updated || []);
    return true;
  }, [blueprints]);

  useEffect(() => {
    let cancelled = false;
    const syncRoleData = async () => {
      if (!role) {
        return;
      }
      const initialData = {
        rbacCode: role.rbacCode || '',
        deptCodeId: role.deptCodeId || '',
        department: role.department || '',
        jobCodeId: normalizeJobCode(role.jobCodeId || ''),
        jobTitle: role.jobTitle || '',
        jobCategory: role.jobCategory || '',
        linkedRoleTemplateId: role.linkedRoleTemplateId || '',
        linkedRoleTemplateName: formatTemplateNameTitleCase(role.linkedRoleTemplateName || ''),
        templateDisplayTitle: (role.templateDisplayTitle || '').trim(),
        subtemplateId: role.subtemplateId || '',
        subtemplateDescription: role.subtemplateDescription || '',
        empNeeded: role.empNeeded || '',
        slaNeeded: role.slaNeeded || '',
        slaBlueprintId: role.slaBlueprintId || '',
        blueprintName: role.blueprintName || '',
        trainingTrack: role.trainingTrack || '',
        trainingTrack2: role.trainingTrack2 || '',
        trainingTrack3: role.trainingTrack3 || '',
        trainingTrack4: role.trainingTrack4 || '',
        trainingTrack5: role.trainingTrack5 || '',
        trainingTrack6: role.trainingTrack6 || '',
        sailpointRole: role.sailpointRole || '',
        publishToSailpoint: role.publishToSailpoint || 'Yes',
        affiliate: role.affiliate || '',
        lastEditChangeControlDateReason: role.lastEditChangeControlDateReason || '',
        status: role.status || 'Active',
      };

      // Auto-populate Department from Dept Code/ID if available
      if (initialData.deptCodeId) {
        const foundDept = departments.find(d => d.deptId === initialData.deptCodeId);
        if (foundDept) {
          initialData.department = foundDept.deptDescription;
        } else if (initialData.deptCodeId.trim()) {
          // If department doesn't exist, add it to the table
          await addDepartmentIfMissing(initialData.deptCodeId.trim(), initialData.department || '');
          // Reload departments
          const updatedDepts = await getDepartments();
          setDepartments(updatedDepts || []);
          const newFoundDept = updatedDepts.find(d => d.deptId === initialData.deptCodeId.trim());
          if (newFoundDept) {
            initialData.department = newFoundDept.deptDescription || initialData.department;
          }
        }
      }

      // Auto-populate Job Title from Job Code/ID if available
      if (initialData.jobCodeId) {
        const jobCodeNorm = normalizeJobCode(initialData.jobCodeId);
        const foundJobCode = jobCodes.find(j => normalizeJobCode(j.jobCode) === jobCodeNorm);
        if (foundJobCode) {
          initialData.jobTitle = foundJobCode.jobTitle;
        } else if (initialData.jobCodeId.trim()) {
          // If job code doesn't exist, add it to the table
          await addJobCodeIfMissing(initialData.jobCodeId.trim(), initialData.jobTitle || '');
          // Reload job codes
          const updatedCodes = await getJobCodes();
          setJobCodes(updatedCodes || []);
          const newFoundJobCode = updatedCodes.find(j => normalizeJobCode(j.jobCode) === jobCodeNorm);
          if (newFoundJobCode) {
            initialData.jobTitle = newFoundJobCode.jobTitle || initialData.jobTitle;
          }
        }
      }

      // If RBAC code exists but deptCodeId/jobCodeId are missing, try to split it. Job code is always 4 chars (leading zeros preserved).
      if (initialData.rbacCode && initialData.rbacCode.length >= 4 && (!initialData.deptCodeId || !initialData.jobCodeId)) {
        const jobCodeId = normalizeJobCode(initialData.rbacCode.slice(-4));
        const deptCodeId = initialData.rbacCode.slice(0, -4);
        initialData.deptCodeId = deptCodeId;
        initialData.jobCodeId = jobCodeId;

        // Look up department and job title from the split values, or add if missing
        let foundDept = departments.find(d => d.deptId === deptCodeId);
        if (!foundDept && deptCodeId.trim()) {
          await addDepartmentIfMissing(deptCodeId.trim(), initialData.department || '');
          const updatedDepts = await getDepartments();
          setDepartments(updatedDepts || []);
          foundDept = updatedDepts.find(d => d.deptId === deptCodeId.trim());
        }
        if (foundDept) {
          initialData.department = foundDept.deptDescription;
        }

        let foundJobCode = jobCodes.find(j => normalizeJobCode(j.jobCode) === jobCodeId);
        if (!foundJobCode && jobCodeId) {
          await addJobCodeIfMissing(jobCodeId, initialData.jobTitle || '');
          const updatedCodes = await getJobCodes();
          setJobCodes(updatedCodes || []);
          foundJobCode = updatedCodes.find(j => normalizeJobCode(j.jobCode) === jobCodeId);
        }
        if (foundJobCode) {
          initialData.jobTitle = foundJobCode.jobTitle;
        }
      }

      // Auto-populate Blueprint Name from SER Blueprint ID; add blueprint to table if missing (from RBAC)
      if (initialData.slaBlueprintId && initialData.slaBlueprintId.trim()) {
        let foundBlueprint = blueprints.find(b => (b.blueprintId || '').trim() === initialData.slaBlueprintId.trim());
        if (!foundBlueprint) {
          await addBlueprintIfMissing(initialData.slaBlueprintId.trim(), initialData.blueprintName || '');
          const updatedBps = await getBlueprints();
          setBlueprints(updatedBps || []);
          foundBlueprint = (updatedBps || []).find(b => (b.blueprintId || '').trim() === initialData.slaBlueprintId.trim());
        }
        if (foundBlueprint) {
          initialData.blueprintName = foundBlueprint.blueprintName;
          if (!initialData.slaNeeded) initialData.slaNeeded = 'Yes';
        }
      }

      // EMP is only needed when a template or subtemplate exists; default to "Yes" if not already set
      const hasTemplateOrSubtemplate = (initialData.linkedRoleTemplateId || '').trim() || (initialData.linkedRoleTemplateName || '').trim() || (initialData.subtemplateId || '').trim() || (initialData.subtemplateDescription || '').trim();
      if (hasTemplateOrSubtemplate && !initialData.empNeeded) {
        initialData.empNeeded = 'Yes';
      }

      if (departmentImpliesAffiliate(initialData.department)) {
        initialData.affiliate = 'yes';
      }

      if (!initialData.templateDisplayTitle.trim() && templateLinks.length > 0) {
        const fromLinks = displayTitlesFromTemplateLinks(
          templateLinks,
          initialData.linkedRoleTemplateId,
          initialData.linkedRoleTemplateName
        );
        if (fromLinks) initialData.templateDisplayTitle = fromLinks;
      }

      if (cancelled) return;
      setFormData(initialData);
      setIsDirty(false);
      setErrors({ rbacCode: '', jobTitle: '' });
    };

    syncRoleData();
    return () => {
      cancelled = true;
    };
  }, [role, departments, jobCodes, blueprints, templateLinks, addJobCodeIfMissing, addDepartmentIfMissing, addBlueprintIfMissing]);

  // Keep Template Display Title in sync with Template Links when template ID/name changes (not only on blur).
  useEffect(() => {
    if (!templateLinks.length) return;
    const t = setTimeout(() => {
      const computed = displayTitlesFromTemplateLinks(
        templateLinks,
        formData.linkedRoleTemplateId,
        formData.linkedRoleTemplateName
      );
      const hasLinked = hasTemplateLookupInput(
        formData.linkedRoleTemplateId,
        formData.linkedRoleTemplateName
      );
      setFormData((prev) => {
        if (!hasLinked) {
          if (!(prev.templateDisplayTitle || '').trim()) return prev;
          return { ...prev, templateDisplayTitle: '' };
        }
        if (!computed) return prev;
        if ((prev.templateDisplayTitle || '').trim() === (computed || '').trim()) return prev;
        return { ...prev, templateDisplayTitle: computed };
      });
    }, 280);
    return () => clearTimeout(t);
  }, [formData.linkedRoleTemplateId, formData.linkedRoleTemplateName, templateLinks]);

  useEffect(() => {
    const onBeforeUnload = (e) => {
      if (isDirty) {
        e.preventDefault();
        e.returnValue = '';
      }
    };
    window.addEventListener('beforeunload', onBeforeUnload);
    return () => window.removeEventListener('beforeunload', onBeforeUnload);
  }, [isDirty]);

  const handleChange = (e) => {
    setIsDirty(true);
    const { name, value } = e.target;
    
    // Auto-split RBAC code into Dept Code/ID and Job Code/ID. Job code is always 4 chars (leading zeros preserved).
    if (name === 'rbacCode' && value.length >= 4) {
      const jobCodeId = normalizeJobCode(value.slice(-4));
      const deptCodeId = value.slice(0, -4);
      const foundDept = departments.find(d => d.deptId === deptCodeId);
      const foundJobCode = jobCodes.find(j => normalizeJobCode(j.jobCode) === jobCodeId);

      setFormData((prev) => ({
        ...prev,
        rbacCode: value,
        deptCodeId: deptCodeId,
        jobCodeId: jobCodeId,
        department: foundDept ? foundDept.deptDescription : prev.department,
        jobTitle: foundJobCode ? foundJobCode.jobTitle : prev.jobTitle,
      }));
      return;
    } else if (name === 'rbacCode' && value.length < 4) {
      // If less than 4 characters, clear jobCodeId and set deptCodeId to the whole value
      const foundDept = departments.find(d => d.deptId === value);

      setFormData((prev) => ({
        ...prev,
        rbacCode: value,
        deptCodeId: value,
        jobCodeId: '',
        department: foundDept ? foundDept.deptDescription : prev.department,
        jobTitle: '', // Clear job title if no job code
      }));
      return;
    }
    
    // Handle Dept Code/ID change - lookup department description
    if (name === 'deptCodeId') {
      const foundDept = departments.find(d => d.deptId === value);

      setFormData((prev) => ({
        ...prev,
        deptCodeId: value,
        department: foundDept ? foundDept.deptDescription : prev.department,
      }));
      return;
    }
    
    // Handle Job Code/ID change - lookup job title. Job code is always 4 chars (leading zeros preserved).
    if (name === 'jobCodeId') {
      const code = normalizeJobCode(value);
      const foundJobCode = jobCodes.find(j => normalizeJobCode(j.jobCode) === code);
      setFormData((prev) => ({
        ...prev,
        jobCodeId: code,
        jobTitle: foundJobCode ? foundJobCode.jobTitle : prev.jobTitle,
      }));
      return;
    }

    // Handle SER Blueprint ID change - lookup blueprint name; new IDs are added on blur (addBlueprintIfMissing)
    if (name === 'slaBlueprintId') {
      const valueNorm = String(value == null ? '' : value).trim();
      const foundBlueprint = blueprints.find(b => String(b.blueprintId ?? b.id ?? '').trim() === valueNorm);
      setFormData((prev) => ({
        ...prev,
        slaBlueprintId: valueNorm,
        blueprintName: foundBlueprint ? foundBlueprint.blueprintName : prev.blueprintName,
        slaNeeded: valueNorm ? 'Yes' : prev.slaNeeded,
      }));
      return;
    }

    // If a blueprint name is entered, SER Needed is Yes
    if (name === 'blueprintName') {
      const valueNorm = String(value == null ? '' : value).trim();
      setFormData((prev) => ({
        ...prev,
        blueprintName: value,
        slaNeeded: valueNorm ? 'Yes' : prev.slaNeeded,
      }));
      return;
    }

    // Handle Job Title change - update job code if it exists and was just created with empty title
    if (name === 'jobTitle') {
      const jobCodeId = normalizeJobCode(formData.jobCodeId || '');
      if (jobCodeId) {
        (async () => {
          const allJobCodes = await getJobCodes();
          const foundJobCode = allJobCodes.find(j => normalizeJobCode(j.jobCode) === jobCodeId);
          
          // If job code exists but has empty job title, update it
          if (foundJobCode && (!foundJobCode.jobTitle || foundJobCode.jobTitle.trim() === '') && value && value.trim()) {
            const updatedJobCodes = allJobCodes.map(j => 
              j.id === foundJobCode.id 
                ? { ...j, jobTitle: value.trim() }
                : j
            );
            await saveJobCodes(updatedJobCodes);
            await addJobCodeAuditLog('UPDATE', { ...foundJobCode, jobTitle: value.trim() }, foundJobCode);
            setJobCodes(updatedJobCodes);
          }
        })();
      }
      
      setFormData((prev) => ({
        ...prev,
        jobTitle: value,
      }));
      return;
    }

    // Handle Linked Role Template ID change - if template is listed, default EMP to "Yes"
    if (name === 'linkedRoleTemplateId') {
      setFormData((prev) => ({
        ...prev,
        linkedRoleTemplateId: value,
        empNeeded: value && value.trim() ? 'Yes' : prev.empNeeded,
      }));
      return;
    }

    // Handle Subtemplate ID or Description - EMP is only needed when template or subtemplate exists
    if (name === 'subtemplateId' || name === 'subtemplateDescription') {
      setFormData((prev) => {
        const next = { ...prev, [name]: value };
        const hasTemplateOrSubtemplate = (next.linkedRoleTemplateId || '').trim() || (next.linkedRoleTemplateName || '').trim() || (next.subtemplateId || '').trim() || (next.subtemplateDescription || '').trim();
        return { ...next, empNeeded: hasTemplateOrSubtemplate ? (prev.empNeeded || 'Yes') : prev.empNeeded };
      });
      return;
    }
    
    // For all other fields, update normally
    if (name === 'department') {
      setFormData((prev) => ({
        ...prev,
        department: value,
        affiliate: departmentImpliesAffiliate(value) ? 'yes' : prev.affiliate,
      }));
      return;
    }

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleJobCategoryChange = (e) => {
    setIsDirty(true);
    const { value } = e.target;

    // Find the selected job category by its name
    const selectedCategory = jobCategories.find(
      (category) => category.jobCategoryName === value
    );

    if (!selectedCategory) {
      // If no category found (e.g., cleared), just update the jobCategory field
      setFormData((prev) => ({
        ...prev,
        jobCategory: value,
      }));
      return;
    }

    // Overwrite category-derived fields with the new category's values
    setFormData((prev) => {
      const s = (v) => (v == null ? '' : String(v).trim());
      const serNo = s(selectedCategory.needSER).toLowerCase() === 'no';
      const slaId = serNo ? '' : s(selectedCategory.blueprintId);
      const foundBlueprint = slaId ? blueprints.find(b => (b.blueprintId || '').trim() === slaId) : null;
      const blueprintNameVal = serNo ? '' : (foundBlueprint ? s(foundBlueprint.blueprintName) : s(selectedCategory.blueprintName));
      const linkableId = s(selectedCategory.linkableTemplateId);
      const templateDescription = s(selectedCategory.linkableTemplateName);
      const formattedDescription = templateDescription ? formatTemplateNameTitleCase(templateDescription) : '';
      const templateNameFromLinks =
        linkableId && templateLinks.length > 0
          ? templateNamesFromTemplateLinks(templateLinks, linkableId)
          : '';
      const formattedName = templateNameFromLinks ? formatTemplateNameTitleCase(templateNameFromLinks) : '';
      const hasTemplateOrSub =
        linkableId || formattedName || formattedDescription || s(selectedCategory.subtemplatesId) || s(selectedCategory.subtemplatesName);
      const fromTemplateTable =
        formattedDescription ||
        (templateLinks.length > 0
          ? displayTitlesFromTemplateLinks(templateLinks, linkableId, formattedName)
          : '');
      return {
        ...prev,
        jobCategory: s(selectedCategory.jobCategoryName) || prev.jobCategory || '',
        linkedRoleTemplateId: linkableId,
        linkedRoleTemplateName: formattedName,
        templateDisplayTitle: fromTemplateTable,
        subtemplateId: s(selectedCategory.subtemplatesId),
        subtemplateDescription: s(selectedCategory.subtemplatesName),
        slaBlueprintId: slaId,
        blueprintName: blueprintNameVal,
        trainingTrack: s(selectedCategory.trainingTrack1),
        trainingTrack2: s(selectedCategory.trainingTrack2),
        trainingTrack3: s(selectedCategory.trainingTrack3),
        trainingTrack4: s(selectedCategory.trainingTrack4),
        trainingTrack5: s(selectedCategory.trainingTrack5),
        trainingTrack6: s(selectedCategory.trainingTrack6),
        sailpointRole: s(selectedCategory.sailpointRole),
        empNeeded: s(selectedCategory.needEMP) || (hasTemplateOrSub ? 'Yes' : ''),
        slaNeeded: s(selectedCategory.needSER) || (slaId ? 'Yes' : ''),
      };
    });
  };

  const handleRbacCodeBlur = async () => {
    const value = formData.rbacCode;
    if (!value || !value.trim()) return;

    const jobCodeId = value.length >= 4 ? normalizeJobCode(value.slice(-4)) : '';
    const deptCodeId = value.length >= 4 ? value.slice(0, -4).trim() : value.trim();

    let updatedDepts = departments;
    let updatedCodes = jobCodes;

    if (deptCodeId) {
      await addDepartmentIfMissing(deptCodeId, formData.department || '');
      updatedDepts = await getDepartments();
      setDepartments(updatedDepts || []);
    }

    if (jobCodeId) {
      await addJobCodeIfMissing(jobCodeId, formData.jobTitle || '');
      updatedCodes = await getJobCodes();
      setJobCodes(updatedCodes || []);
    }

    const foundDept = updatedDepts.find(d => (d.deptId || '').trim() === deptCodeId);
    const foundJobCode = updatedCodes.find(j => normalizeJobCode(j.jobCode) === jobCodeId);

    setFormData((prev) => ({
      ...prev,
      deptCodeId,
      jobCodeId,
      department: foundDept ? foundDept.deptDescription : prev.department,
      jobTitle: foundJobCode ? foundJobCode.jobTitle : prev.jobTitle,
    }));
  };

  const handleDeptCodeBlur = async () => {
    const value = formData.deptCodeId;
    if (!value || !value.trim()) return;

    await addDepartmentIfMissing(value.trim(), formData.department || '');
    const updatedDepts = await getDepartments();
    setDepartments(updatedDepts || []);
    const foundDept = updatedDepts.find(d => d.deptId === value.trim());

    if (foundDept) {
      setFormData((prev) => ({
        ...prev,
        department: foundDept.deptDescription || prev.department,
      }));
    }
  };

  const handleJobCodeBlur = async () => {
    const value = formData.jobCodeId;
    const code = normalizeJobCode(value);
    if (!code) return;

    await addJobCodeIfMissing(value, formData.jobTitle || '');
    const updatedCodes = await getJobCodes();
    setJobCodes(updatedCodes || []);
    const foundJobCode = updatedCodes.find(j => normalizeJobCode(j.jobCode) === code);

    setFormData((prev) => ({
      ...prev,
      jobCodeId: code,
      jobTitle: foundJobCode ? foundJobCode.jobTitle || prev.jobTitle : prev.jobTitle,
    }));
  };

  const handleSlaBlueprintBlur = async () => {
    const valueNorm = String(formData.slaBlueprintId == null ? '' : formData.slaBlueprintId).trim();
    if (!valueNorm) return;
    await addBlueprintIfMissing(valueNorm, formData.blueprintName || '');
    const updated = await getBlueprints();
    setBlueprints(updated || []);
    const found = (updated || []).find(b => String(b.blueprintId ?? b.id ?? '').trim() === valueNorm);
    if (found) {
      setFormData((prev) => ({ ...prev, blueprintName: found.blueprintName || prev.blueprintName }));
    }
  };

  const handleValidationBlur = (field) => (e) => {
    const value = e.target.value;
    const fn = field === 'rbacCode' ? validateRbacCode : field === 'jobTitle' ? validateRoleJobTitle : () => '';
    setErrors((prev) => ({ ...prev, [field]: fn(value) }));
  };

  const applyRbacFillAll = () => {
    if (Object.keys(rbacFillSuggestions).length === 0) return;
    setIsDirty(true);
    setFormData((prev) => ({ ...prev, ...rbacFillSuggestions }));
  };

  const applyRbacFillField = (key) => {
    const val = rbacFillSuggestions[key];
    if (val === undefined) return;
    setIsDirty(true);
    setFormData((prev) => ({ ...prev, [key]: val }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const rbacErr = validateRbacCode(formData.rbacCode);
    const jobTitleErr = validateRoleJobTitle(formData.jobTitle);
    setErrors({ rbacCode: rbacErr, jobTitle: jobTitleErr });
    if (rbacErr || jobTitleErr) return;
    
    // Ensure job code has the job title if it was created with empty title. Job code is always 4 chars.
    const jobCodeId = normalizeJobCode(formData.jobCodeId || '');
    if (jobCodeId && formData.jobTitle && formData.jobTitle.trim()) {
      (async () => {
        const allJobCodes = await getJobCodes();
        const foundJobCode = allJobCodes.find(j => normalizeJobCode(j.jobCode) === jobCodeId);
        
        // If job code exists but has empty or different job title, update it
        if (foundJobCode && foundJobCode.jobTitle !== formData.jobTitle.trim()) {
          const updatedJobCodes = allJobCodes.map(j => 
            j.id === foundJobCode.id 
              ? { ...j, jobTitle: formData.jobTitle.trim() }
              : j
          );
          await saveJobCodes(updatedJobCodes);
          await addJobCodeAuditLog('UPDATE', { ...foundJobCode, jobTitle: formData.jobTitle.trim() }, foundJobCode);
          setJobCodes(updatedJobCodes);
        }
      })();
    }
    
    const formDataWithTimestamp = {
      ...formData,
      lastEditChangeControlDateReason: '',
    };
    ['trainingTrack', 'trainingTrack2', 'trainingTrack3', 'trainingTrack4', 'trainingTrack5', 'trainingTrack6'].forEach((f) => {
      if (formDataWithTimestamp[f] === TRAINING_TRACK_OTHER) formDataWithTimestamp[f] = '';
    });
    if (formDataWithTimestamp.slaBlueprintId === BLUEPRINT_OTHER) {
      formDataWithTimestamp.slaBlueprintId = '';
      formDataWithTimestamp.blueprintName = '';
    }
    // If a blueprint is listed, SER Needed must be Yes
    const hasBlueprint = (formDataWithTimestamp.slaBlueprintId || '').toString().trim() || (formDataWithTimestamp.blueprintName || '').toString().trim();
    if (hasBlueprint) formDataWithTimestamp.slaNeeded = 'Yes';
    if (departmentImpliesAffiliate(formDataWithTimestamp.department)) {
      formDataWithTimestamp.affiliate = 'yes';
    }

    const editDetail = !role ? 'New role' : summarizeRoleFormEdit(role, formDataWithTimestamp);
    formDataWithTimestamp.lastEditChangeControlDateReason = buildLastEditStamp(editDetail);

    (async () => {
      try {
        const toTpl = buildTemplateLinkRowsToAppendFromRole(templateLinks, formDataWithTimestamp);
        if (toTpl.length > 0) {
          const withIds = toTpl.map((r) => ({ ...r, id: generateId() }));
          const res = await appendTemplateLinks(withIds);
          if (res?.added > 0) {
            for (const row of withIds) {
              await addTemplateLinkAuditLog('CREATE', row);
            }
            setTemplateLinks(await getTemplateLinks());
          }
        }

        const toBp = buildBlueprintsToAppend(
          blueprints,
          formDataWithTimestamp.slaBlueprintId,
          formDataWithTimestamp.blueprintName
        );
        if (toBp.length > 0) {
          const withIds = toBp.map((b) => ({ ...b, id: generateId() }));
          const res = await appendBlueprints(withIds);
          if (res?.added > 0) {
            for (const row of withIds) {
              await addBlueprintAuditLog('CREATE', row);
            }
            setBlueprints(await getBlueprints());
          }
        }

        const toTr = buildTrainingTracksToAppend(
          trainingTracks,
          roleFormTrainingTrackFieldValues(formDataWithTimestamp)
        );
        if (toTr.length > 0) {
          const withIds = toTr.map((t) => ({ ...t, id: generateId() }));
          await appendTrainingTracks(withIds);
          setTrainingTracks(await getTrainingTracks());
        }
      } catch (err) {
        console.error('Append reference tables failed:', err);
      }
      onSubmit(formDataWithTimestamp);
    })().catch((err) => {
      console.error('Append reference tables failed:', err);
      onSubmit(formDataWithTimestamp);
    });
  };

  return (
    <div className="role-form-container">
      <div className="role-form">
        <h2>{role ? 'Edit Role' : 'Add New Role'}</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="rbacCode" title="Role-based access control code: Department code + 4-character Job Code">RBAC CODE *</label>
              <input
                ref={firstInputRef}
                type="text"
                id="rbacCode"
                name="rbacCode"
                value={formData.rbacCode}
                onChange={handleChange}
                onBlur={(e) => { handleValidationBlur('rbacCode')(e); handleRbacCodeBlur(); }}
                required
                className={errors.rbacCode ? 'input-error' : ''}
                aria-invalid={!!errors.rbacCode}
                aria-describedby={errors.rbacCode ? 'rbacCode-error' : undefined}
              />
              {errors.rbacCode && (
                <span id="rbacCode-error" className="form-error" role="alert">{errors.rbacCode}</span>
              )}
            </div>

            <div className="form-group">
              <label htmlFor="deptCodeId">Dept Code/ID</label>
              <input
                type="text"
                id="deptCodeId"
                name="deptCodeId"
                value={formData.deptCodeId}
                onChange={handleChange}
                onBlur={handleDeptCodeBlur}
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="department">Department</label>
              <input
                type="text"
                id="department"
                name="department"
                value={formData.department}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="jobCodeId">Job Code/ID</label>
              <input
                type="text"
                id="jobCodeId"
                name="jobCodeId"
                value={formData.jobCodeId}
                onChange={handleChange}
                onBlur={handleJobCodeBlur}
              />
            </div>

            <div className="form-group">
              <label htmlFor="jobTitle">Job Title *</label>
              <input
                type="text"
                id="jobTitle"
                name="jobTitle"
                value={formData.jobTitle}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="jobCategory">Job Category</label>
              <input
                type="text"
                id="jobCategory"
                name="jobCategory"
                list="jobCategoryList"
                value={formData.jobCategory}
                onChange={(e) => {
                  handleJobCategoryChange(e);
                }}
                placeholder="Type to search job categories..."
                autoComplete="off"
              />
              <datalist id="jobCategoryList">
                {jobCategories.map((category) => (
                  <option key={category.id} value={category.jobCategoryName}>
                    {category.jobCategoryName}
                  </option>
                ))}
              </datalist>
            </div>
            <div className="form-group">
              <label id="role-sailpoint-readonly-label">Sailpoint Role</label>
              <p className="form-hint form-hint--compact">
                Enter or change this on the <strong>Job Category</strong> form. It is copied to the role when you select a
                category (and can still be updated by Fill blanks / category sync).
              </p>
              <div
                id="role-sailpoint-readonly"
                className="role-form-readonly-value"
                role="status"
                aria-labelledby="role-sailpoint-readonly-label"
              >
                {(formData.sailpointRole || '').trim() || '—'}
              </div>
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="linkedRoleTemplateId" title="Same field as Template Links → Template ID(s)">
                Linked Role Template ID
              </label>
              <textarea
                id="linkedRoleTemplateId"
                name="linkedRoleTemplateId"
                rows={3}
                value={formData.linkedRoleTemplateId}
                onChange={handleChange}
                onBlur={(e) => {
                  const v = e.target.value;
                  setFormData((prev) => {
                    const synced = syncRoleLinkedTemplateFromTemplateLinks(
                      templateLinks,
                      v,
                      prev.linkedRoleTemplateName,
                      'id'
                    );
                    const nextId = synced.linkedRoleTemplateId;
                    const nextName = synced.linkedRoleTemplateName
                      ? formatTemplateNameTitleCase(synced.linkableTemplateName)
                      : prev.linkedRoleTemplateName;
                    const title =
                      templateLinks.length > 0
                        ? displayTitlesFromTemplateLinks(templateLinks, nextId, nextName)
                        : prev.templateDisplayTitle;
                    return {
                      ...prev,
                      linkedRoleTemplateId: nextId,
                      linkedRoleTemplateName: nextName,
                      templateDisplayTitle: title,
                    };
                  });
                }}
                placeholder="One per line or comma/pipe separated; duplicates allowed"
              />
            </div>

            <div className="form-group">
              <label htmlFor="linkedRoleTemplateName" title="Same field as Template Links → Template Name(s)">
                Linked Role Template Name
              </label>
              <textarea
                id="linkedRoleTemplateName"
                name="linkedRoleTemplateName"
                rows={3}
                value={formData.linkedRoleTemplateName}
                onChange={handleChange}
                onBlur={(e) => {
                  const formatted = formatTemplateNameTitleCase(e.target.value);
                  setFormData((prev) => {
                    const synced = syncRoleLinkedTemplateFromTemplateLinks(
                      templateLinks,
                      prev.linkedRoleTemplateId,
                      formatted,
                      'name'
                    );
                    const nextName = synced.linkedRoleTemplateName || formatted;
                    const nextId = synced.linkedRoleTemplateId || prev.linkedRoleTemplateId;
                    const title =
                      templateLinks.length > 0
                        ? displayTitlesFromTemplateLinks(templateLinks, nextId, nextName)
                        : prev.templateDisplayTitle;
                    return {
                      ...prev,
                      linkedRoleTemplateName: nextName,
                      linkedRoleTemplateId: nextId,
                      templateDisplayTitle: title,
                    };
                  });
                }}
                placeholder="One per line or comma/pipe separated; duplicates allowed"
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label
                htmlFor="templateDisplayTitle"
                title="Same field as Template Links → Template Display Title. Lookup matches Linked Role Template ID to Template ID(s), else Linked Role Template Name to Template Name(s); editable."
              >
                Template Display Title
              </label>
              <textarea
                id="templateDisplayTitle"
                name="templateDisplayTitle"
                rows={2}
                value={formData.templateDisplayTitle}
                onChange={handleChange}
                placeholder="Filled from Template Links (Template Display Title); you can edit"
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="subtemplateId">Subtemplate ID</label>
              <textarea
                id="subtemplateId"
                name="subtemplateId"
                rows={3}
                value={formData.subtemplateId}
                onChange={handleChange}
                onBlur={(e) => {
                  const v = e.target.value;
                  setFormData((prev) => {
                    const synced = syncJobCategorySubtemplatesFromTemplateLinks(
                      templateLinks,
                      v,
                      prev.subtemplateDescription,
                      'id'
                    );
                    const nextDesc = synced.subtemplatesName
                      ? normalizeSubtemplateCommaList(
                          formatCommaSeparatedTemplateNamesUpper(synced.subtemplatesName)
                        )
                      : prev.subtemplateDescription;
                    return {
                      ...prev,
                      subtemplateId: normalizeSubtemplateCommaList(synced.subtemplatesId),
                      subtemplateDescription: nextDesc,
                    };
                  });
                }}
                placeholder="One per line or comma/pipe separated; duplicates allowed"
              />
            </div>

            <div className="form-group">
              <label htmlFor="subtemplateDescription">Subtemplate Description</label>
              <textarea
                id="subtemplateDescription"
                name="subtemplateDescription"
                rows={3}
                value={formData.subtemplateDescription}
                onChange={handleChange}
                onBlur={(e) => {
                  const normalizedIn = normalizeSubtemplateCommaList(e.target.value);
                  const formattedForSync = formatCommaSeparatedTemplateNamesUpper(normalizedIn);
                  setFormData((prev) => {
                    const synced = syncJobCategorySubtemplatesFromTemplateLinks(
                      templateLinks,
                      prev.subtemplateId,
                      formattedForSync,
                      'name'
                    );
                    return {
                      ...prev,
                      subtemplateDescription: normalizeSubtemplateCommaList(
                        formatCommaSeparatedTemplateNamesUpper(
                          synced.subtemplatesName || formattedForSync
                        )
                      ),
                      subtemplateId: normalizeSubtemplateCommaList(
                        synced.subtemplatesId || prev.subtemplateId
                      ),
                    };
                  });
                }}
                placeholder="One per line or comma/pipe separated; duplicates allowed"
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="empNeeded" title="Employee: required when a Linked Role Template or Subtemplate is set">EMP Needed</label>
              <select
                id="empNeeded"
                name="empNeeded"
                value={formData.empNeeded}
                onChange={handleChange}
              >
                <option value="">Select...</option>
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select>
            </div>

            <div className="form-group">
              <label htmlFor="slaNeeded">SER Needed</label>
              <select
                id="slaNeeded"
                name="slaNeeded"
                value={formData.slaNeeded}
                onChange={handleChange}
              >
                <option value="">Select...</option>
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select>
            </div>
          </div>

          <div className="form-row">
            {blueprints.length > 0 ? (
              <div className="form-group" style={{ flex: '1 1 100%' }}>
                <label htmlFor="slaBlueprintId" title="Blueprint ID for SER (Service); used when SER Needed is Yes">SER Blueprint</label>
                <BlueprintDropdown
                  id="slaBlueprintId"
                  value={formData.slaBlueprintId}
                  options={blueprints}
                  allowFreeText
                  placeholder="Select blueprint..."
                  onChange={(blueprint) => {
                    setFormData((prev) => ({
                      ...prev,
                      slaBlueprintId: blueprint ? blueprint.blueprintId : '',
                      blueprintName: blueprint ? blueprint.blueprintName : '',
                      slaNeeded: blueprint ? 'Yes' : prev.slaNeeded,
                    }));
                  }}
                  onAddNew={async ({ blueprintId, blueprintName }) => {
                    const newBlueprint = { id: generateId(), blueprintId, blueprintName };
                    await appendBlueprints([newBlueprint]);
                    await addBlueprintAuditLog('CREATE', newBlueprint);
                    const updated = await getBlueprints();
                    setBlueprints(updated || []);
                    setFormData((prev) => ({
                      ...prev,
                      slaBlueprintId: blueprintId,
                      blueprintName: blueprintName,
                      slaNeeded: 'Yes',
                    }));
                  }}
                />
              </div>
            ) : (
              <>
                <div className="form-group">
                  <label htmlFor="slaBlueprintId" title="Blueprint ID for SER (Service); used when SER Needed is Yes">SER Blueprint ID</label>
                  <input
                    type="text"
                    id="slaBlueprintId"
                    name="slaBlueprintId"
                    value={formData.slaBlueprintId}
                    onChange={handleChange}
                    onBlur={handleSlaBlueprintBlur}
                    placeholder="Type to search blueprints..."
                    autoComplete="off"
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="blueprintName">Blueprint Name</label>
                  <input
                    type="text"
                    id="blueprintName"
                    name="blueprintName"
                    value={formData.blueprintName}
                    onChange={handleChange}
                  />
                </div>
              </>
            )}
          </div>

          {(() => {
            const trackNames = (trainingTracks || []).map((t) => (t.trackName || '').trim()).filter(Boolean);
            const hasDropdown = allowTrainingTrackDropdown && trackNames.length > 0;
            const renderTrackField = (name, label) => {
              const value = formData[name] || '';
              const clearBtn = value ? (
                <button
                  type="button"
                  className="btn-clear-field"
                  onClick={() => { setIsDirty(true); setFormData((prev) => ({ ...prev, [name]: '' })); }}
                  title={`Clear ${label}`}
                  aria-label={`Clear ${label}`}
                >
                  &times;
                </button>
              ) : null;
              return (
                <div className="form-group" key={name}>
                  <label htmlFor={name}>{label}</label>
                  <div className="field-with-clear">
                    {hasDropdown ? (
                      <TrainingTrackDropdown
                        id={name}
                        value={value}
                        options={trainingTracks}
                        onChange={(v) => setFormData((prev) => ({ ...prev, [name]: v }))}
                        onAddNew={async (newName) => {
                          const trackName = (newName || '').trim();
                          if (!trackName) return;
                          const id = generateId();
                          await appendTrainingTracks([{ id, trackName }]);
                          setTrainingTracks(await getTrainingTracks());
                        }}
                        placeholder="Select..."
                      />
                    ) : (
                      <input type="text" id={name} name={name} value={value} onChange={handleChange} />
                    )}
                    {clearBtn}
                  </div>
                </div>
              );
            };
            return (
              <>
                <div className="form-row">
                  {renderTrackField('trainingTrack', 'Training Track 1')}
                  {renderTrackField('trainingTrack2', 'Training Track 2')}
                </div>
                <div className="form-row">
                  {renderTrackField('trainingTrack3', 'Training Track 3')}
                  {renderTrackField('trainingTrack4', 'Training Track 4')}
                </div>
                <div className="form-row">
                  {renderTrackField('trainingTrack5', 'Training Track 5')}
                  {renderTrackField('trainingTrack6', 'Training Track 6')}
                </div>
              </>
            );
          })()}

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="status">Status</label>
              <select
                id="status"
                name="status"
                value={formData.status}
                onChange={handleChange}
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
            <div className="form-group">
              <label htmlFor="publishToSailpoint">Publish to Sailpoint</label>
              <select
                id="publishToSailpoint"
                name="publishToSailpoint"
                value={String(formData.publishToSailpoint || '').toLowerCase() === 'yes' ? 'Yes' : 'No'}
                onChange={handleChange}
              >
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select>
            </div>
            <div className="form-group">
              <label htmlFor="affiliate">Affiliate</label>
              <select
                id="affiliate"
                name="affiliate"
                value={String(formData.affiliate || '').toLowerCase() === 'yes' ? 'yes' : ''}
                onChange={handleChange}
              >
                <option value="">Blank</option>
                <option value="yes">yes</option>
              </select>
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="lastEditChangeControlDateReason">Last Edit/Change Control Date/Reason</label>
            <textarea
              id="lastEditChangeControlDateReason"
              name="lastEditChangeControlDateReason"
              value={formData.lastEditChangeControlDateReason}
              onChange={handleChange}
              rows="3"
              readOnly
              style={{ backgroundColor: '#f5f5f5', cursor: 'not-allowed' }}
              title="This field is automatically populated on save"
            />
          </div>

          {Object.keys(rbacFillSuggestions).length > 0 && (
            <div className="form-group role-form-rbac-suggest" role="region" aria-label="Suggested values from RBAC code and reference data">
              <div className="role-form-rbac-suggest-head">
                <strong>Suggested from RBAC</strong>
                <span className="role-form-rbac-suggest-hint">
                  Same rules as Fill blanks — only fields that are empty in the form are listed.
                </span>
              </div>
              <button type="button" className="btn-role-suggest-all" onClick={applyRbacFillAll}>
                Apply all
              </button>
              <ul className="role-form-rbac-suggest-list">
                {Object.entries(rbacFillSuggestions).map(([key, val]) => (
                  <li key={key}>
                    <span className="role-form-rbac-suggest-k">{RBAC_FILL_LABELS[key] || key}</span>
                    <code className="role-form-rbac-suggest-v">{String(val)}</code>
                    <button type="button" className="btn-role-suggest-one" onClick={() => applyRbacFillField(key)}>
                      Apply
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="form-actions">
            <button
              type="button"
              className="btn-cancel"
              onClick={() => {
                if (isDirty && !window.confirm('You have unsaved changes. Leave anyway?')) return;
                onCancel();
              }}
            >
              Cancel
            </button>
            <button type="submit" className="btn-submit">
              {role ? 'Update Role' : 'Create Role'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RoleForm;
