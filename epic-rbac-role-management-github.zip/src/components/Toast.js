import React from 'react';
import './Toast.css';

export default function Toast({ id, message, type, onDismiss }) {
  return (
    <div
      className={`toast toast-${type}`}
      role="status"
      onClick={() => onDismiss(id)}
    >
      <span className="toast-message">{message}</span>
      <button
        type="button"
        className="toast-dismiss"
        aria-label="Dismiss"
        onClick={(e) => { e.stopPropagation(); onDismiss(id); }}
      >
        ×
      </button>
    </div>
  );
}
