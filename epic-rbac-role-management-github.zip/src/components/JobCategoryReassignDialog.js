import React, { useEffect, useMemo, useRef, useState } from 'react';
import { rankReplacementCategories } from '../utils/jobCategoryReassignment';
import './JobCategoryReassignDialog.css';

const TOP_SUGGESTION_LIMIT = 5;

const s = (v) => (v == null ? '' : String(v).trim());

/**
 * Modal used when a Job Category is being inactivated while one or more active
 * RBAC roles are still assigned to it. Lets the admin either:
 *   - reassign affected roles to a different active category, then inactivate, or
 *   - inactivate the category anyway (leaving the orphaned roles), or
 *   - cancel.
 *
 * Props:
 *   sourceCategory          The category being inactivated.
 *   affectedRoles           Active roles currently assigned to sourceCategory.
 *   candidateCategories     Categories the admin may choose from (typically active + in-scope).
 *   includeInactive         Whether inactive roles should also be reassigned (default false).
 *   onConfirm(targetCategory, { includeInactive })  Called when admin confirms reassignment.
 *   onInactivateOnly()      Called when admin opts to inactivate without reassignment.
 *   onInactivateConnectedRoles() Called when admin opts to set connected roles inactive, then inactivate.
 *   onCancel()              Called when admin closes/cancels.
 */
const JobCategoryReassignDialog = ({
  sourceCategory,
  affectedRoles = [],
  candidateCategories = [],
  onConfirm,
  onInactivateOnly,
  onInactivateConnectedRoles,
  onCancel,
}) => {
  const filteredCandidates = useMemo(() => {
    const srcName = s(sourceCategory && sourceCategory.jobCategoryName).toLowerCase();
    return (candidateCategories || [])
      .filter((c) => c && s(c.status || 'Active') !== 'Inactive' && s(c.jobCategoryName).toLowerCase() !== srcName)
      .slice()
      .sort((a, b) => s(a.jobCategoryName).localeCompare(s(b.jobCategoryName)));
  }, [candidateCategories, sourceCategory]);

  const rankedSuggestions = useMemo(
    () => rankReplacementCategories(sourceCategory, filteredCandidates, { limit: TOP_SUGGESTION_LIMIT }),
    [sourceCategory, filteredCandidates],
  );

  const defaultSuggestion = rankedSuggestions[0]?.category || null;

  const [targetId, setTargetId] = useState(defaultSuggestion ? defaultSuggestion.id : '');
  const [includeInactive, setIncludeInactive] = useState(false);
  const [filter, setFilter] = useState('');
  const selectRef = useRef(null);

  useEffect(() => {
    const t = setTimeout(() => selectRef.current?.focus(), 50);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === 'Escape') onCancel?.();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [onCancel]);

  const visibleCandidates = useMemo(() => {
    const q = filter.trim().toLowerCase();
    if (!q) return filteredCandidates;
    return filteredCandidates.filter((c) => {
      const name = s(c.jobCategoryName).toLowerCase();
      const id = s(c.jobCategoryId).toLowerCase();
      return name.includes(q) || id.includes(q);
    });
  }, [filter, filteredCandidates]);

  const target = useMemo(
    () => filteredCandidates.find((c) => c.id === targetId) || null,
    [filteredCandidates, targetId],
  );

  const activeCount = affectedRoles.filter((r) => s(r.status || 'Active') !== 'Inactive').length;
  const inactiveCount = affectedRoles.length - activeCount;

  const handleConfirm = () => {
    if (!target) return;
    onConfirm?.(target, { includeInactive });
  };

  return (
    <div className="jcr-overlay" onClick={onCancel}>
      <div className="jcr-dialog" onClick={(e) => e.stopPropagation()}>
        <div className="jcr-header">
          <h3>Inactivate &amp; Reassign Roles</h3>
          <button type="button" className="jcr-close" onClick={onCancel} aria-label="Close">
            &times;
          </button>
        </div>

        <div className="jcr-body">
          <p className="jcr-lede">
            You're inactivating <strong>{s(sourceCategory?.jobCategoryName) || '(unnamed)'}</strong>.
            {' '}
            <strong>{activeCount}</strong> active RBAC role{activeCount === 1 ? '' : 's'} {activeCount === 1 ? 'is' : 'are'} currently assigned to this category
            {inactiveCount > 0 ? ` (plus ${inactiveCount} inactive)` : ''}.
            Reassigning them to another category will also resync their template, subtemplate, blueprint, EMP/SER and training tracks from the chosen category.
          </p>

          {rankedSuggestions.length > 0 && (
            <div className="jcr-suggestions">
              <div className="jcr-suggestions-label">
                Top matches by template, subtemplate, and training tracks
              </div>
              <div className="jcr-suggestion-list" role="radiogroup" aria-label="Top suggested replacement categories">
                {rankedSuggestions.map((sug) => {
                  const checked = sug.category.id === targetId;
                  return (
                    <label
                      key={sug.category.id}
                      className={`jcr-suggestion ${checked ? 'jcr-suggestion-selected' : ''}`}
                    >
                      <input
                        type="radio"
                        name="jcr-suggestion"
                        value={sug.category.id}
                        checked={checked}
                        onChange={() => setTargetId(sug.category.id)}
                      />
                      <div className="jcr-suggestion-body">
                        <div className="jcr-suggestion-title">
                          {s(sug.category.jobCategoryName) || '(unnamed)'}
                          {sug.category.jobCategoryId ? (
                            <span className="jcr-suggestion-id">· {sug.category.jobCategoryId}</span>
                          ) : null}
                        </div>
                        <div className="jcr-suggestion-meta">
                          <span className="jcr-suggestion-badges">
                            {sug.signals.templateMatch && (
                              <span className="jcr-badge jcr-badge-strong">Template match</span>
                            )}
                            {sug.signals.subtemplateMatch && (
                              <span className="jcr-badge jcr-badge-strong">Subtemplate match</span>
                            )}
                            {sug.signals.sharedTrainingTracks.length > 0 && (
                              <span className="jcr-badge">
                                {sug.signals.sharedTrainingTracks.length} training track
                                {sug.signals.sharedTrainingTracks.length === 1 ? '' : 's'}
                              </span>
                            )}
                          </span>
                        </div>
                        {sug.reasons.length > 0 && (
                          <ul className="jcr-suggestion-reasons">
                            {sug.reasons.map((r, i) => (
                              <li key={i}>{r}</li>
                            ))}
                          </ul>
                        )}
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>
          )}

          <div className="jcr-field">
            <label htmlFor="jcr-filter">Or pick any active category</label>
            <input
              id="jcr-filter"
              type="text"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              placeholder="Filter by name or ID..."
              autoComplete="off"
            />
          </div>

          <div className="jcr-field">
            <label htmlFor="jcr-target" className="jcr-field-label-hidden">Reassign to</label>
            <select
              ref={selectRef}
              id="jcr-target"
              value={targetId}
              onChange={(e) => setTargetId(e.target.value)}
              size={Math.min(8, Math.max(4, visibleCandidates.length))}
            >
              <option value="">— Select a category —</option>
              {visibleCandidates.map((c) => (
                <option key={c.id} value={c.id}>
                  {s(c.jobCategoryName) || '(unnamed)'}
                  {c.jobCategoryId ? ` · ${c.jobCategoryId}` : ''}
                  {c.linkableTemplateId ? ` · ${c.linkableTemplateId}` : ''}
                  {defaultSuggestion && c.id === defaultSuggestion.id ? '   (suggested)' : ''}
                </option>
              ))}
            </select>
          </div>

          {inactiveCount > 0 && (
            <label className="jcr-checkbox" htmlFor="jcr-include-inactive">
              <input
                id="jcr-include-inactive"
                type="checkbox"
                checked={includeInactive}
                onChange={(e) => setIncludeInactive(e.target.checked)}
              />
              Also reassign {inactiveCount} inactive role{inactiveCount === 1 ? '' : 's'}
            </label>
          )}

          {affectedRoles.length > 0 && (
            <div className="jcr-table-wrap">
              <table className="jcr-table">
                <thead>
                  <tr>
                    <th>RBAC Code</th>
                    <th>Job Title</th>
                    <th>Department</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {affectedRoles.slice(0, 200).map((r) => (
                    <tr key={r.id}>
                      <td>{s(r.rbacCode)}</td>
                      <td>{s(r.jobTitle)}</td>
                      <td>{s(r.department) || s(r.deptCodeId)}</td>
                      <td>{s(r.status) || 'Active'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {affectedRoles.length > 200 && (
                <div className="jcr-truncated">…and {affectedRoles.length - 200} more.</div>
              )}
            </div>
          )}
        </div>

        <div className="jcr-footer">
          <button type="button" className="jcr-btn jcr-btn-secondary" onClick={onCancel}>
            Cancel
          </button>
          <button
            type="button"
            className="jcr-btn jcr-btn-warn"
            onClick={() => onInactivateOnly?.()}
            title="Inactivate the category without reassigning any roles"
          >
            Inactivate without reassigning
          </button>
          <button
            type="button"
            className="jcr-btn jcr-btn-warn"
            onClick={() => onInactivateConnectedRoles?.()}
            title="Set connected roles to Inactive, then inactivate this category"
          >
            Inactivate connected roles &amp; category
          </button>
          <button
            type="button"
            className="jcr-btn jcr-btn-primary"
            disabled={!target}
            onClick={handleConfirm}
          >
            Reassign &amp; Inactivate
          </button>
        </div>
      </div>
    </div>
  );
};

export default JobCategoryReassignDialog;
