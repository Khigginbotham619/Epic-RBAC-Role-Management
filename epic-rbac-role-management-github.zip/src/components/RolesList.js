import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { getRoles, saveRoles, saveRolesBatch, mergeRoles, patchRole, deleteRoles, addAuditLog, generateId, getJobCategories, getJobCodes, getDepartments, getBlueprints, getTemplateLinks, getStoredCurrentUser, invalidateCache } from '../utils/storage';
import { exportToCSV } from '../utils/csvExport';
import { exportForSP } from '../utils/spExport';
import { importFromCSV } from '../utils/csvImport';
import { useDebounce } from '../utils/useDebounce';
import { sanitizeCellText, sanitizeRow } from '../utils/textSanitize';
import { normalizeJobCode } from '../utils/jobCodeUtils';
import { fillBlanksForRole, applyCategoryUpdatesToRole } from '../utils/fillBlanks';
import JobCategoryRoleSyncButton from './JobCategoryRoleSyncButton';
import { SYNC_SCOPE_ALL } from '../utils/jobCategoryRoleSync';
import { useResizableColumns } from '../utils/useResizableColumns';
import { useToast } from '../context/ToastContext';
import {
  formatTemplateNameTitleCase,
  displayTitlesFromTemplateLinks,
  buildTemplateLookupIndex,
  displayTitlesFromTemplateIndex,
  normalizeTemplateLinksForLookup,
  hasTemplateLookupInput,
} from '../utils/templateLinkRoleMatch';
import { normalizeSearchInput } from '../utils/searchInput';
import {
  buildLastEditStamp,
  parseLastEditTimestamp,
  isLastEditOnLocalCalendarDay,
  isRoleBulkEditedToday,
} from '../utils/lastEditStamp';
import { RBAC_ROLES_UPDATED_EVENT, notifyRolesUpdated } from '../utils/rbacRolesRefresh';
import { initServerBuildId, subscribeBuildRefresh } from '../utils/appBuildRefresh';
import {
  normalizeRoleId,
  roleIdsEqual,
  findRoleById,
  selectedRowsHasRole,
} from '../utils/roleIdUtils';
import RoleForm from './RoleForm';
import FindReplaceDialog from './FindReplaceDialog';
import TableContextMenu from './TableContextMenu';
import ImportPreviewDialog from './ImportPreviewDialog';
import './RolesList.css';

const LARGE_EXPORT_THRESHOLD = 500;
const SAILPOINT_REPAIR_DISMISSED_KEY = 'rbac_sailpoint_role_repair_done_v1';
const RBAC_HIGHLIGHT_DISMISSED_IDS_KEY = 'rbac_roles_highlight_dismissed_ids_v1';

const MS_24_HOURS = 24 * 60 * 60 * 1000;

/** Hover text for template columns — values align with Template Links (see template table). */
const RBAC_TEMPLATE_CELL_TOOLTIP = {
  linkedRoleTemplateId: 'Matches Template Links → Template ID(s).',
  linkedRoleTemplateName: 'Matches Template Links → Template Name(s).',
  templateDisplayTitle:
    'Text from Template Links → Template Display Title for the matched row only (blank if that cell is blank). Refreshes from links when Linked Role Template ID/Name change.',
};

/** On load, set role Template Display Title from Template Links so the grid matches the template table (no auto-save). */
function mergeTemplateDisplayTitlesFromLinks(roles, templateLinks) {
  if (!Array.isArray(roles) || !templateLinks?.length) return roles;
  const normalizedLinks = normalizeTemplateLinksForLookup(templateLinks);
  if (!normalizedLinks.length) return roles;
  const lookupIndex = buildTemplateLookupIndex(normalizedLinks);
  let changed = false;
  const next = roles.map((role) => {
    if (!role || typeof role !== 'object') return role;
    if (!hasTemplateLookupInput(role.linkedRoleTemplateId, role.linkedRoleTemplateName)) return role;
    const computed = displayTitlesFromTemplateIndex(
      lookupIndex,
      role.linkedRoleTemplateId,
      role.linkedRoleTemplateName
    );
    if (String(role.templateDisplayTitle ?? '').trim() === String(computed ?? '').trim()) return role;
    changed = true;
    return { ...role, templateDisplayTitle: computed };
  });
  return changed ? next : roles;
}

const ROLES_COL_WIDTHS_KEY = 'rbac_roles_table_col_widths_v1';
const ROLES_DEFAULT_COL_WIDTHS = {
  __checkbox__: 40,
  rbacCode: 140,
  deptCodeId: 120,
  department: 200,
  jobCodeId: 110,
  jobTitle: 260,
  jobCategory: 200,
  linkedRoleTemplateId: 180,
  linkedRoleTemplateName: 260,
  templateDisplayTitle: 260,
  subtemplateId: 180,
  subtemplateDescription: 300,
  empNeeded: 95,
  slaNeeded: 95,
  slaBlueprintId: 300,
  trainingTrack: 180,
  trainingTrack2: 180,
  trainingTrack3: 180,
  trainingTrack4: 180,
  trainingTrack5: 180,
  trainingTrack6: 180,
  sailpointRole: 180,
  publishToSailpoint: 150,
  affiliate: 90,
  status: 110,
  lastEditChangeControlDateReason: 280,
  __row_status__: 110,
  __actions__: 260,
};

function isRoleEditedInLast24Hours(role) {
  const stamp = String(role?.lastEditChangeControlDateReason || '').toLowerCase();
  // Operational maintenance actions should not create edited-row highlight.
  if (stamp.includes('fill blanks') || stamp.includes('repair sailpoint role')) return false;
  const d = parseLastEditTimestamp(role?.lastEditChangeControlDateReason);
  if (!d) return false;
  return Date.now() - d.getTime() < MS_24_HOURS;
}

function parseLastEditUser(role) {
  const str = (role?.lastEditChangeControlDateReason || '').trim();
  if (!str) return '';
  const parts = str.split(' - ');
  if (parts.length < 2) return '';
  const userAndMaybeDetail = parts.slice(1).join(' - ');
  const user = userAndMaybeDetail.split(' — ')[0].trim();
  return user;
}

function isRoleEditedByUserToday(role, userId) {
  const user = String(userId || '').trim().toLowerCase();
  if (!user) return false;
  const stampUser = parseLastEditUser(role).toLowerCase();
  if (!stampUser || stampUser !== user) return false;
  return isLastEditOnLocalCalendarDay(role?.lastEditChangeControlDateReason);
}

/** Role was created via Add New Role (stamp ends with detail "New role") within the last 24 hours. */
function isRoleNewInLast24Hours(role) {
  const str = (role?.lastEditChangeControlDateReason || '').trim();
  if (!str) return false;
  const isCreateStamp = /\s(?:\u2014|-)\sNew role\s*$/.test(str);
  if (!isCreateStamp) return false;
  const d = parseLastEditTimestamp(role?.lastEditChangeControlDateReason);
  if (!d) return false;
  return Date.now() - d.getTime() < MS_24_HOURS;
}

// Template/subtemplate: split on newline, comma, pipe, etc.; dedupe; show as one line in table.
// For names (linkedRoleTemplateName, subtemplateDescription) pass splitOnSpaces=false so multi-word names don't get commas between words.
function templateSubtemplateOneLine(value, splitOnSpaces = true) {
  if (value == null || String(value).trim() === '') return '';
  const regex = splitOnSpaces ? /[\n,|;\s]+/ : /[\n,|;]+/;
  const parts = String(value)
    .split(regex)
    .map((p) => p.trim())
    .filter(Boolean);
  const seen = new Set();
  const unique = [];
  for (const p of parts) {
    const key = p.toUpperCase();
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(p);
  }
  return unique.join(', ');
}

function isNullFilterToken(value) {
  const normalized = String(value || '').trim().toLowerCase();
  return normalized === 'null' || normalized === 'blank' || normalized === 'empty';
}

function departmentImpliesAffiliate(department) {
  return String(department || '').toLowerCase().includes('affiliate');
}

function applyAutoAffiliate(role) {
  if (!role || typeof role !== 'object') return role;
  if (departmentImpliesAffiliate(role.department)) {
    return { ...role, affiliate: 'yes' };
  }
  return role;
}

function prepareRolesForGrid(rows) {
  return (Array.isArray(rows) ? rows : []).map((r) => {
    const sanitized = sanitizeRow(r);
    return applyAutoAffiliate({
      ...sanitized,
      publishToSailpoint: String(sanitized.publishToSailpoint || '').trim() || 'Yes',
    });
  });
}

const BULK_UPDATABLE_FIELDS = [
  { key: 'status', label: 'Status', type: 'select', options: ['Active', 'Inactive'] },
  { key: 'deptCodeId', label: 'Dept Code/ID' },
  { key: 'department', label: 'Department' },
  { key: 'jobCodeId', label: 'Job Code/ID' },
  { key: 'jobTitle', label: 'Job Title' },
  { key: 'jobCategory', label: 'Job Category', type: 'jobCategory' },
  { key: 'linkedRoleTemplateId', label: 'Linked Role Template ID' },
  { key: 'linkedRoleTemplateName', label: 'Linked Role Template Name' },
  { key: 'templateDisplayTitle', label: 'Template Display Title' },
  { key: 'subtemplateId', label: 'Subtemplate ID' },
  { key: 'subtemplateDescription', label: 'Subtemplate Description' },
  { key: 'empNeeded', label: 'EMP Needed', type: 'select', options: ['Yes', 'No'] },
  { key: 'slaNeeded', label: 'SER Needed', type: 'select', options: ['Yes', 'No'] },
  { key: 'slaBlueprintId', label: 'SER Blueprint ID' },
  { key: 'blueprintName', label: 'Blueprint Name' },
  { key: 'trainingTrack', label: 'Training Track 1' },
  { key: 'trainingTrack2', label: 'Training Track 2' },
  { key: 'trainingTrack3', label: 'Training Track 3' },
  { key: 'trainingTrack4', label: 'Training Track 4' },
  { key: 'trainingTrack5', label: 'Training Track 5' },
  { key: 'trainingTrack6', label: 'Training Track 6' },
  { key: 'publishToSailpoint', label: 'Publish to Sailpoint', type: 'select', options: ['Yes', 'No'] },
  { key: 'affiliate', label: 'Affiliate', type: 'select', options: ['yes'] },
  { key: 'lastEditChangeControlDateReason', label: 'Last Edit/Change Control Date/Reason' },
];

/** Human-readable suffix for inline/table edits (maps field key → label). */
function roleFieldEditDetail(field) {
  const bulk = BULK_UPDATABLE_FIELDS.find((f) => f.key === field);
  if (bulk) return `Edited: ${bulk.label}`;
  if (field === 'rbacCode') return 'Edited: RBAC CODE';
  return `Edited: ${field}`;
}

const BulkUpdateDialog = ({ selectedCount, columnDefs, jobCategories, onApply, onClose }) => {
  const [field, setField] = useState('');
  const [value, setValue] = useState('');

  const fieldDef = BULK_UPDATABLE_FIELDS.find((f) => f.key === field);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!field) { alert('Please select a field to update.'); return; }
    if (!window.confirm(`Set "${fieldDef?.label || field}" to "${value}" on ${selectedCount} role(s)?`)) return;
    onApply(field, value);
  };

  return (
    <div className="find-replace-overlay" onClick={onClose}>
      <div className="find-replace-dialog" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 440 }}>
        <div className="find-replace-header">
          <h3>Bulk Update ({selectedCount} selected)</h3>
          <button type="button" className="find-replace-close" onClick={onClose}>&times;</button>
        </div>
        <form onSubmit={handleSubmit} style={{ padding: '1rem 1.25rem' }}>
          <div style={{ marginBottom: '0.75rem' }}>
            <label style={{ display: 'block', marginBottom: '0.25rem', fontWeight: 500, fontSize: '0.9rem' }}>Field</label>
            <select
              value={field}
              onChange={(e) => { setField(e.target.value); setValue(''); }}
              style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1' }}
            >
              <option value="">Select field...</option>
              {BULK_UPDATABLE_FIELDS.map((f) => (
                <option key={f.key} value={f.key}>{f.label}</option>
              ))}
            </select>
          </div>
          {field && (
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', marginBottom: '0.25rem', fontWeight: 500, fontSize: '0.9rem' }}>New Value</label>
              {fieldDef?.type === 'select' ? (
                <select
                  value={value}
                  onChange={(e) => setValue(e.target.value)}
                  style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1' }}
                  autoFocus
                >
                  <option value="">— (clear) —</option>
                  {fieldDef.options.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              ) : fieldDef?.type === 'jobCategory' ? (
                <select
                  value={value}
                  onChange={(e) => setValue(e.target.value)}
                  style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1' }}
                  autoFocus
                >
                  <option value="">— (clear) —</option>
                  {jobCategories.map((c) => (
                    <option key={c.id || c.jobCategoryName} value={c.jobCategoryName || ''}>{c.jobCategoryName || ''}</option>
                  ))}
                </select>
              ) : (
                <input
                  type="text"
                  value={value}
                  onChange={(e) => setValue(e.target.value)}
                  style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1', boxSizing: 'border-box' }}
                  autoFocus
                  placeholder="Enter new value (leave empty to clear)"
                />
              )}
            </div>
          )}
          <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
            <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn-primary" disabled={!field}>Apply</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const ROLE_EDITABLE_FIELDS = [
  'rbacCode', 'deptCodeId', 'department', 'jobCodeId', 'jobTitle', 'jobCategory',
  'linkedRoleTemplateId', 'linkedRoleTemplateName', 'templateDisplayTitle', 'subtemplateId', 'subtemplateDescription',
  'empNeeded', 'slaNeeded', 'slaBlueprintId',
  'trainingTrack', 'trainingTrack2', 'trainingTrack3', 'trainingTrack4', 'trainingTrack5', 'trainingTrack6',
  'publishToSailpoint',
  'affiliate',
  'status'
];

const RolesList = ({ allowBulkActions = false, canEditRoles = false, canSyncRoles = false, showSaveButton = false }) => {
  const { showToast } = useToast();
  const [roles, setRoles] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounce(searchTerm, 300);
  const [statusFilter, setStatusFilter] = useState('Active'); // 'All', 'Active', 'Inactive'
  const [recentlyEditedFilter, setRecentlyEditedFilter] = useState(false); // true = show only roles edited in last 24h
  const [newIn24hFilter, setNewIn24hFilter] = useState(false); // true = show only roles newly created (Add Role) in last 24h
  const [bulkEditedTodayFilter, setBulkEditedTodayFilter] = useState(false); // true = show only roles bulk edited today
  const [editedByUserTodayFilter, setEditedByUserTodayFilter] = useState(false); // true = show only roles edited today by selected audit user
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  const [selectedRows, setSelectedRows] = useState(new Set());
  const [showAdvancedSearch, setShowAdvancedSearch] = useState(false);
  const [showBulkUpdate, setShowBulkUpdate] = useState(false);
  const undoRef = useRef(null);
  const loadRolesGenerationRef = useRef(0);
  const [canUndo, setCanUndo] = useState(false);
  const [advancedFilters, setAdvancedFilters] = useState({});
  const debouncedAdvancedFilters = useDebounce(advancedFilters, 300);
  const [editingRole, setEditingRole] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [selectedRowId, setSelectedRowId] = useState(null);
  const [visibleColumns] = useState({
    rbacCode: true, actions: true, deptCodeId: true, department: true, jobCodeId: true, jobTitle: true, jobCategory: true,
    linkedRoleTemplateId: true, linkedRoleTemplateName: true, templateDisplayTitle: true, subtemplateId: true, subtemplateDescription: true,
    empNeeded: true, slaNeeded: true, slaBlueprintId: true,
    trainingTrack: true, trainingTrack2: true, trainingTrack3: true, trainingTrack4: true, trainingTrack5: true, trainingTrack6: true, sailpointRole: true,
    publishToSailpoint: true,
    affiliate: true,
    status: true, lastEditChangeControlDateReason: true
  });
  const [importProgress, setImportProgress] = useState({ active: false, current: 0, total: 0 });
  const [isImporting, setIsImporting] = useState(false);
  const [saveFeedback, setSaveFeedback] = useState(false);
  const [exportFeedback, setExportFeedback] = useState(null);
  const [showSailpointRepair, setShowSailpointRepair] = useState(() => {
    try {
      return localStorage.getItem(SAILPOINT_REPAIR_DISMISSED_KEY) !== '1';
    } catch (_) {
      return true;
    }
  });
  const [rolesLoading, setRolesLoading] = useState(true);
  const [editingCell, setEditingCell] = useState(null); // { roleId, field }
  const [showFindReplace, setShowFindReplace] = useState(false);
  const [isDirty, setIsDirty] = useState(false);
  const [contextMenu, setContextMenu] = useState(null);
  const [importPreview, setImportPreview] = useState(null);
  const [dismissedHighlightIds, setDismissedHighlightIds] = useState(() => {
    try {
      const raw = JSON.parse(localStorage.getItem(RBAC_HIGHLIGHT_DISMISSED_IDS_KEY) || '[]');
      return new Set(Array.isArray(raw) ? raw.map((x) => String(x)) : []);
    } catch (_) {
      return new Set();
    }
  });
  const editingOriginalRef = useRef(null);
  const [jobCategories, setJobCategories] = useState([]);
  const [jobCodes, setJobCodes] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [blueprints, setBlueprints] = useState([]);
  const { getWidth: getColWidth, startResize } = useResizableColumns(ROLES_COL_WIDTHS_KEY);
  const fileInputRef = useRef(null);
  const selectAllCheckboxRef = useRef(null);
  const handleSaveRef = useRef(() => {});
  const selectedAuditUserId = (() => {
    try {
      const u = getStoredCurrentUser();
      return (u?.username || '').toString().trim();
    } catch (_) {
      return '';
    }
  })();
  const hasAuditUser = !!selectedAuditUserId;

  useEffect(() => {
    loadRoles();
    initServerBuildId();
    return subscribeBuildRefresh(() => {
      invalidateCache('roles');
      loadRoles();
      showToast('App was updated on the server — reloaded roles from database.', 'info');
    });
  }, []);

  useEffect(() => {
    const onRolesUpdated = (event) => {
      const snapshot = event?.detail?.updatedRoles;
      if (Array.isArray(snapshot) && snapshot.length > 0) {
        loadRolesGenerationRef.current += 1;
        setRoles(prepareRolesForGrid(snapshot));
        return;
      }
      loadRoles();
    };
    window.addEventListener(RBAC_ROLES_UPDATED_EVENT, onRolesUpdated);
    return () => window.removeEventListener(RBAC_ROLES_UPDATED_EVENT, onRolesUpdated);
  }, []);

  useEffect(() => {
    (async () => {
      const [cats, codes, depts, bps] = await Promise.all([
        getJobCategories(),
        getJobCodes(),
        getDepartments(),
        getBlueprints()
      ]);
      setJobCategories(Array.isArray(cats) ? cats : []);
      setJobCodes(Array.isArray(codes) ? codes : []);
      setDepartments(Array.isArray(depts) ? depts : []);
      setBlueprints(Array.isArray(bps) ? bps : []);
    })();
  }, []);

  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'h') {
        e.preventDefault();
        if (canEditRoles) setShowFindReplace(true);
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 's' && showSaveButton) {
        e.preventDefault();
        handleSaveRef.current();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [canEditRoles, showSaveButton]);

  useEffect(() => {
    if (!showSaveButton || !isDirty) return;
    const handler = (e) => { e.preventDefault(); };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [showSaveButton, isDirty]);

  useEffect(() => {
    try {
      localStorage.setItem(
        RBAC_HIGHLIGHT_DISMISSED_IDS_KEY,
        JSON.stringify([...dismissedHighlightIds])
      );
    } catch (_) {
      // noop
    }
  }, [dismissedHighlightIds]);

  useEffect(() => {
    if (hasAuditUser) return;
    setBulkEditedTodayFilter(false);
    setEditedByUserTodayFilter(false);
  }, [hasAuditUser]);

  const loadRoles = async () => {
    const generation = ++loadRolesGenerationRef.current;
    setRolesLoading(true);
    let roleCount = 0;
    try {
      const loadedRoles = await getRoles({ fresh: true });
      if (generation !== loadRolesGenerationRef.current) return;
      const rows = prepareRolesForGrid(loadedRoles);
      roleCount = rows.length;
      setRoles(rows);
    } catch (err) {
      if (generation !== loadRolesGenerationRef.current) return;
      console.error('Load roles failed:', err);
      setRoles([]);
    } finally {
      if (generation === loadRolesGenerationRef.current) setRolesLoading(false);
    }

    if (generation !== loadRolesGenerationRef.current) return;

    // Fetch template links after the grid is shown; merge display titles without re-normalizing links per row.
    // Large lists: defer merge to idle/next tick so the tab stays responsive.
    try {
      const tls = await getTemplateLinks();
      const links = Array.isArray(tls) ? tls : [];
      const applyMerge = () => {
        if (generation !== loadRolesGenerationRef.current) return;
        setRoles((prev) => {
          try {
            return mergeTemplateDisplayTitlesFromLinks(prev, links);
          } catch (mergeErr) {
            console.error('Merge template display titles failed:', mergeErr);
            return prev;
          }
        });
      };
      if (
        roleCount > 2000 &&
        typeof window !== 'undefined' &&
        typeof window.requestIdleCallback === 'function'
      ) {
        window.requestIdleCallback(applyMerge, { timeout: 3000 });
      } else if (roleCount > 2000) {
        setTimeout(applyMerge, 0);
      } else {
        applyMerge();
      }
    } catch (err) {
      console.error('Template links load failed:', err);
    }
  };

  const snapshotForUndo = useCallback((description) => {
    undoRef.current = { roles: [...roles], description };
    setCanUndo(true);
  }, [roles]);

  const handleUndo = async () => {
    if (!undoRef.current) return;
    const { roles: prevRoles, description } = undoRef.current;
    if (!window.confirm(`Undo "${description}"?`)) return;
    const beforeUndo = roles;
    setRoles(prevRoles);
    try {
      await saveRoles(prevRoles, { force: true, allowShrink: true });
      await addAuditLog('UNDO', { id: 'undo', description });
      undoRef.current = null;
      setCanUndo(false);
      setIsDirty(false);
      notifyRolesUpdated(prevRoles);
      showToast(`Undone: ${description}`);
    } catch (err) {
      setRoles(beforeUndo);
      await loadRoles();
      alert(err?.message || 'Undo failed. Check the server and try again.');
    }
  };

  // Memoize filtered roles to prevent unnecessary recalculations and memory issues
  const filteredRoles = useMemo(() => {
    let filtered = roles;

    // Apply status filter
    if (statusFilter !== 'All') {
      filtered = filtered.filter((role) => (role.status || 'Active') === statusFilter);
    }

    // Apply recently edited filter
    if (recentlyEditedFilter) {
      filtered = filtered.filter(
        (role) => !dismissedHighlightIds.has(String(role.id)) && isRoleEditedInLast24Hours(role)
      );
    }

    if (newIn24hFilter) {
      filtered = filtered.filter(
        (role) => !dismissedHighlightIds.has(String(role.id)) && isRoleNewInLast24Hours(role)
      );
    }

    if (bulkEditedTodayFilter) {
      filtered = filtered.filter(
        (role) => !dismissedHighlightIds.has(String(role.id)) && isRoleBulkEditedToday(role)
      );
    }

    if (editedByUserTodayFilter) {
      filtered = filtered.filter(
        (role) =>
          !dismissedHighlightIds.has(String(role.id)) &&
          isRoleEditedByUserToday(role, selectedAuditUserId)
      );
    }

    // Apply advanced filters (using debounced value).
    // The synthetic `blueprint` key matches against either slaBlueprintId or
    // blueprintName so admins can type an ID or a name into one input.
    Object.keys(debouncedAdvancedFilters).forEach((field) => {
      const filterValue = debouncedAdvancedFilters[field];
      if (!filterValue || !filterValue.trim()) return;
      const term = filterValue.toLowerCase();
      const useNullFilter = isNullFilterToken(term);
      if (field === 'blueprint') {
        filtered = filtered.filter((role) => {
          const id = role.slaBlueprintId;
          const name = role.blueprintName;
          if (useNullFilter) {
            const idBlank = id == null || String(id).trim() === '';
            const nameBlank = name == null || String(name).trim() === '';
            return idBlank && nameBlank;
          }
          return (
            (id && id.toString().toLowerCase().includes(term)) ||
            (name && name.toString().toLowerCase().includes(term))
          );
        });
        return;
      }
      filtered = filtered.filter((role) => {
        const value = role[field];
        if (useNullFilter) return value == null || String(value).trim() === '';
        return value && value.toString().toLowerCase().includes(term);
      });
    });

    // Apply search term filter (if no advanced filters, using debounced value)
    if (debouncedSearchTerm.trim() && Object.keys(debouncedAdvancedFilters).length === 0) {
      const term = debouncedSearchTerm.trim().toLowerCase();
      filtered = filtered.filter((role) =>
        Object.values(role).some((value) =>
          value && value.toString().toLowerCase().includes(term)
        )
      );
    }

    // Apply sorting
    if (sortConfig.key) {
      filtered = [...filtered].sort((a, b) => {
        const aValue = a[sortConfig.key] || '';
        const bValue = b[sortConfig.key] || '';
        if (sortConfig.direction === 'asc') {
          return aValue.toString().localeCompare(bValue.toString());
        } else {
          return bValue.toString().localeCompare(aValue.toString());
        }
      });
    }

    return filtered;
  }, [roles, dismissedHighlightIds, debouncedSearchTerm, statusFilter, recentlyEditedFilter, newIn24hFilter, bulkEditedTodayFilter, editedByUserTodayFilter, selectedAuditUserId, debouncedAdvancedFilters, sortConfig]);

  // Cap rendered rows for performance (avoid 1000+ DOM nodes). Export/operations still use full filtered list.
  const MAX_RENDERED_ROWS = 400;
  const rolesToRender = useMemo(() => {
    if (filteredRoles.length <= MAX_RENDERED_ROWS) return filteredRoles;
    return filteredRoles.slice(0, MAX_RENDERED_ROWS);
  }, [filteredRoles]);

  const handleSort = useCallback((key) => {
    setSortConfig((prev) => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc',
    }));
  }, []);

  const clearFilters = () => {
    setSearchTerm('');
    setStatusFilter('All');
    setRecentlyEditedFilter(false);
    setNewIn24hFilter(false);
    setBulkEditedTodayFilter(false);
    setEditedByUserTodayFilter(false);
    setAdvancedFilters({});
    setShowAdvancedSearch(false);
    setSelectedRows(new Set());
  };

  // Persist selected row IDs for Admin "Edit Selected"
  useEffect(() => {
    sessionStorage.setItem('rbac_selected_role_ids', JSON.stringify([...selectedRows]));
  }, [selectedRows]);

  // Persist current filters so Admin "Saved" can save preset
  useEffect(() => {
    sessionStorage.setItem(
      'rbac_current_filters',
      JSON.stringify({ searchTerm, statusFilter, recentlyEditedFilter, newIn24hFilter, bulkEditedTodayFilter, editedByUserTodayFilter, advancedFilters })
    );
  }, [searchTerm, statusFilter, recentlyEditedFilter, newIn24hFilter, bulkEditedTodayFilter, editedByUserTodayFilter, advancedFilters]);

  // Apply pending preset or open Edit Selected when returning from Admin
  useEffect(() => {
    if (roles.length === 0) return;
    const pendingPresetId = sessionStorage.getItem('rbac_pending_preset_id');
    if (pendingPresetId) {
      sessionStorage.removeItem('rbac_pending_preset_id');
      const presets = JSON.parse(localStorage.getItem('rbac_filter_presets') || '[]');
      const preset = presets.find((p) => p.id === pendingPresetId);
      if (preset) {
        setSearchTerm(normalizeSearchInput(preset.searchTerm || ''));
        setStatusFilter(preset.statusFilter || 'All');
        setRecentlyEditedFilter(!!preset.recentlyEditedFilter);
        setNewIn24hFilter(!!preset.newIn24hFilter);
        setBulkEditedTodayFilter(!!preset.bulkEditedTodayFilter);
        setEditedByUserTodayFilter(!!preset.editedByUserTodayFilter);
        setAdvancedFilters(preset.advancedFilters || {});
        if (Object.keys(preset.advancedFilters || {}).length > 0) setShowAdvancedSearch(true);
      }
      return;
    }
    const editSelected = sessionStorage.getItem('adminEditSelected');
    if (editSelected) {
      sessionStorage.removeItem('adminEditSelected');
      const ids = JSON.parse(sessionStorage.getItem('rbac_selected_role_ids') || '[]');
      const first = roles.find((r) => ids.includes(r.id));
      if (first) {
        setEditingRole(first);
        setShowForm(true);
      }
    }
  }, [roles]);

  const handleAdd = () => {
    setEditingRole(null);
    setShowForm(true);
  };

  const handleEdit = (role) => {
    setEditingRole(role);
    setShowForm(true);
  };

  const handleDelete = async (role) => {
    if (window.confirm('Are you sure you want to delete this role?')) {
      snapshotForUndo(`Delete role ${role.rbacCode || role.id}`);
      const prevRoles = roles;
      const updatedRoles = roles.filter((r) => !roleIdsEqual(r.id, role.id));
      setRoles(updatedRoles);
      try {
        await deleteRoles([role.id]);
        await addAuditLog('DELETE', role, role);
        setIsDirty(false);
        loadRoles();
      } catch (err) {
        setRoles(prevRoles);
        await loadRoles();
        alert(err?.message || 'Failed to save. Check the server and try again.');
      }
    }
  };

  const handleDeleteSelected = async () => {
    if (selectedRows.size === 0) {
      alert('Please select one or more roles to delete.');
      return;
    }
    if (!window.confirm(`Delete ${selectedRows.size} selected role(s)?`)) return;
    snapshotForUndo(`Bulk delete ${selectedRows.size} role(s)`);
    const prevRoles = roles;
    const idsToDelete = prevRoles
      .filter((r) => selectedRowsHasRole(selectedRows, r.id))
      .map((r) => r.id);
    const updatedRoles = roles.filter((r) => !selectedRowsHasRole(selectedRows, r.id));
    setRoles(updatedRoles);
    try {
      await deleteRoles(idsToDelete);
      for (const role of prevRoles) {
        if (selectedRowsHasRole(selectedRows, role.id)) await addAuditLog('DELETE', role, role);
      }
      setSelectedRows(new Set());
      setIsDirty(false);
      loadRoles();
    } catch (err) {
      setRoles(prevRoles);
      await loadRoles();
      alert(err?.message || 'Failed to save. Check the server and try again.');
    }
  };

  const getLastEditValue = (detail) => buildLastEditStamp(detail);

  const updateRoleField = async (roleId, field, value) => {
    const role = findRoleById(roles, roleId);
    if (!role) return;
    snapshotForUndo(`Edit ${role.rbacCode || roleId} → ${field}`);
    const prevRoles = roles;
    const oldData = { ...role };
    const sanitized = typeof value === 'string' ? sanitizeCellText(value) : value;
    let updated = {
      ...role,
      [field]: sanitized,
      lastEditChangeControlDateReason: getLastEditValue(roleFieldEditDetail(field)),
    };
    // When any reference field is edited, fill corresponding RBAC columns from the matching table (blanks only)
    const fillIfEmpty = (roleKey, tableValue) => {
      const v = tableValue != null && String(tableValue).trim() ? String(tableValue).trim() : '';
      if (v && !(updated[roleKey] || '').trim()) updated[roleKey] = v;
    };
    if (field === 'deptCodeId' && (sanitized || '').toString().trim()) {
      const dept = departments.find((d) => (d.deptId || '').trim() === (sanitized || '').toString().trim());
      if (dept) fillIfEmpty('department', dept.deptDescription);
    }
    if (field === 'jobCodeId') {
      const code = normalizeJobCode(sanitized);
      if (code) {
        updated[field] = code;
        const jc = jobCodes.find((j) => normalizeJobCode(j.jobCode) === code);
        if (jc) fillIfEmpty('jobTitle', jc.jobTitle);
      }
    }
    if (field === 'slaBlueprintId') {
      const valueNorm = String(sanitized == null ? '' : sanitized).trim();
      if (valueNorm) updated.slaNeeded = 'Yes';
      const serNo = (updated.slaNeeded || role.slaNeeded || '').toString().trim().toLowerCase() === 'no';
      if (valueNorm && !serNo) {
        const bp = blueprints.find((b) => String(b.blueprintId ?? b.id ?? '').trim() === valueNorm);
        if (bp) fillIfEmpty('blueprintName', bp.blueprintName);
      }
    }
    if (field === 'blueprintName' && (sanitized || '').toString().trim()) {
      updated.slaNeeded = 'Yes';
    }
    if (field === 'jobCategory' && (sanitized || '').toString().trim()) {
      const category = jobCategories.find(
        (c) => (c.jobCategoryName || '').trim() === (sanitized || '').toString().trim()
      );
      if (category) {
        const bps = blueprints.length > 0 ? blueprints : (await getBlueprints()) || [];
        const tls = await getTemplateLinks();
        updated = applyCategoryUpdatesToRole(updated, category, bps, Array.isArray(tls) ? tls : []);
      }
    }
    if (field === 'linkedRoleTemplateId' || field === 'linkedRoleTemplateName') {
      const tls = await getTemplateLinks();
      const list = Array.isArray(tls) ? tls : [];
      updated.templateDisplayTitle = displayTitlesFromTemplateLinks(
        list,
        updated.linkedRoleTemplateId,
        updated.linkedRoleTemplateName
      );
    }
    // If a blueprint is listed, SER Needed must be Yes
    const hasBlueprint = (updated.slaBlueprintId || '').toString().trim() || (updated.blueprintName || '').toString().trim();
    if (hasBlueprint) updated.slaNeeded = 'Yes';
    updated = applyAutoAffiliate(updated);
    const updatedRoles = roles.map((r) => (roleIdsEqual(r.id, roleId) ? updated : r));
    setRoles(updatedRoles);
    setIsDirty(true);
    try {
      const mergeResult = await patchRole(updated);
      await addAuditLog('UPDATE', updated, oldData);
      const fromDb = mergeResult?.rolesFromDb;
      if (Array.isArray(fromDb)) {
        const rows = prepareRolesForGrid(fromDb);
        setRoles(rows);
        notifyRolesUpdated(fromDb);
      } else {
        notifyRolesUpdated(updatedRoles);
      }
      setIsDirty(false);
      setEditingCell(null);
    } catch (err) {
      setRoles(prevRoles);
      alert(err?.message || 'Failed to save. Check the server and try again.');
    }
  };

  const handleDuplicateRole = async (role) => {
    snapshotForUndo(`Duplicate role ${role.rbacCode || role.id}`);
    const clone = {
      ...role,
      id: generateId(),
      lastEditChangeControlDateReason: getLastEditValue('Duplicated role')
    };
    const fresh = await getRoles({ fresh: true });
    const updatedRoles = [...fresh];
    const idx = updatedRoles.findIndex((r) => roleIdsEqual(r.id, role.id));
    updatedRoles.splice(idx >= 0 ? idx + 1 : updatedRoles.length, 0, clone);
    setRoles(prepareRolesForGrid(updatedRoles));
    setIsDirty(true);
    try {
      await saveRoles(updatedRoles);
      await addAuditLog('CREATE', clone);
      notifyRolesUpdated(updatedRoles);
      showToast(`Duplicated role ${role.rbacCode || ''}`);
    } catch (err) {
      alert(err?.message || 'Duplicate failed.');
    }
  };

  const handleCopyRow = (role) => {
    const fields = ROLE_EDITABLE_FIELDS;
    const values = fields.map((f) => (role[f] ?? '').toString().replace(/\t/g, ' '));
    const header = fields.join('\t');
    const row = values.join('\t');
    navigator.clipboard.writeText(`${header}\n${row}`).then(
      () => showToast('Row copied to clipboard'),
      () => alert('Failed to copy to clipboard')
    );
  };

  const handleToggleStatus = async (role) => {
    const current = (role.status || 'Active').trim();
    const newStatus = current === 'Active' ? 'Inactive' : 'Active';
    await updateRoleField(role.id, 'status', newStatus);
  };

  const handleFillBlanks = async () => {
    // Use latest reference data from API/cache so fill works even if state was empty or stale
    const [cats, codes, depts, bps, tls] = await Promise.all([
      getJobCategories(),
      getJobCodes(),
      getDepartments(),
      getBlueprints(),
      getTemplateLinks()
    ]);
    const context = {
      roles,
      jobCategories: Array.isArray(cats) ? cats : [],
      jobCodes: Array.isArray(codes) ? codes : [],
      departments: Array.isArray(depts) ? depts : [],
      blueprints: Array.isArray(bps) ? bps : [],
      templateLinks: Array.isArray(tls) ? tls : [],
      getLastEditValue: () => getLastEditValue('Fill blanks (reference data)'),
    };
    const updatedRoles = roles.map((role) => fillBlanksForRole(role, context));
    const changed = updatedRoles.filter((r, i) => JSON.stringify(r) !== JSON.stringify(roles[i])).length;
    if (changed === 0) {
      alert('No blanks could be filled from other tables. Ensure Job Codes, Departments, Blueprints, and Job Categories are loaded and that roles have Dept/Job Code (or Job Category) set where needed.');
      return;
    }
    snapshotForUndo(`Fill blanks in ${changed} role(s)`);
    const prevRoles = roles;
    const patches = updatedRoles.filter((role) => {
      const old = findRoleById(prevRoles, role.id);
      return old && JSON.stringify(old) !== JSON.stringify(role);
    });
    setRoles(updatedRoles);
    try {
      await mergeRoles(patches);
      for (const role of patches) {
        const old = findRoleById(prevRoles, role.id);
        if (old) await addAuditLog('UPDATE', role, old);
      }
      notifyRolesUpdated(updatedRoles);
      showToast(`Filled blanks in ${changed} role(s).`);
    } catch (err) {
      alert(err?.message || 'Failed to save. Check the server and try again.');
    }
  };

  const handleRepairMissingSailpointRoles = async () => {
    if (!window.confirm('Repair missing Sailpoint Role values from Job Categories now? This runs once and then hides.')) return;

    const cats = jobCategories.length > 0 ? jobCategories : (await getJobCategories());
    const categoryToSailpoint = new Map(
      (Array.isArray(cats) ? cats : [])
        .map((c) => [String(c.jobCategoryName || '').trim(), String(c.sailpointRole || '').trim()])
        .filter(([catName, spRole]) => catName && spRole)
    );

    const updatedRoles = roles.map((role) => {
      const currentSailpointRole = String(role.sailpointRole || '').trim();
      if (currentSailpointRole) return role;
      const jobCategoryName = String(role.jobCategory || '').trim();
      const mappedSailpointRole = categoryToSailpoint.get(jobCategoryName);
      if (!mappedSailpointRole) return role;
      return {
        ...role,
        sailpointRole: mappedSailpointRole,
        lastEditChangeControlDateReason: getLastEditValue('Repair Sailpoint Role (from job category)'),
      };
    });

    const changed = updatedRoles.filter((r, i) => JSON.stringify(r) !== JSON.stringify(roles[i]));
    if (changed.length === 0) {
      showToast('No missing Sailpoint Role values found to repair.');
      try { localStorage.setItem(SAILPOINT_REPAIR_DISMISSED_KEY, '1'); } catch (_) { /* noop */ }
      setShowSailpointRepair(false);
      return;
    }

    snapshotForUndo(`Repair Sailpoint Role in ${changed.length} role(s)`);
    const prevRoles = roles;
    setRoles(updatedRoles);
    try {
      await mergeRoles(changed);
      for (const role of changed) {
        const old = findRoleById(prevRoles, role.id);
        if (old) await addAuditLog('UPDATE', role, old);
      }
      try { localStorage.setItem(SAILPOINT_REPAIR_DISMISSED_KEY, '1'); } catch (_) { /* noop */ }
      setShowSailpointRepair(false);
      notifyRolesUpdated(updatedRoles);
      showToast(`Repaired Sailpoint Role on ${changed.length} role(s).`);
    } catch (err) {
      alert(err?.message || 'Repair failed. Check the server and try again.');
    }
  };

  const handleSave = async () => {
    try {
      const fresh = await getRoles({ fresh: true });
      const freshById = new Map(fresh.map((r) => [normalizeRoleId(r.id), r]));
      const patches = roles.filter((role) => {
        const server = freshById.get(normalizeRoleId(role.id));
        return server && JSON.stringify(server) !== JSON.stringify(role);
      });
      if (patches.length === 0) {
        setIsDirty(false);
        showToast('No unsaved changes (already in sync with server).');
        return;
      }
      await mergeRoles(patches);
      notifyRolesUpdated(roles);
      setIsDirty(false);
      setSaveFeedback(true);
      setTimeout(() => setSaveFeedback(false), 2000);
    } catch (err) {
      alert(err.message || 'Failed to save. Check the server.');
    }
  };
  handleSaveRef.current = handleSave;

  const handleFindReplace = async (updatedRoles, matchCount) => {
    snapshotForUndo(`Find & Replace (${matchCount} match${matchCount !== 1 ? 'es' : ''})`);
    const prevRoles = roles;
    const touchedByFindReplaceIds = new Set(
      updatedRoles
        .filter((role) => {
          const prev = findRoleById(prevRoles, role.id);
          return !!prev && JSON.stringify(role) !== JSON.stringify(prev);
        })
        .map((r) => normalizeRoleId(r.id))
    );
    // When jobCategory changed, apply category-derived field updates
    const bps = blueprints.length > 0 ? blueprints : (await getBlueprints()) || [];
    const tls = await getTemplateLinks();
    const templateLinks = Array.isArray(tls) ? tls : [];
    const finalRoles = updatedRoles.map((role) => {
      const prev = findRoleById(prevRoles, role.id);
      if (!prev) return role;
      const catChanged = (role.jobCategory || '').trim() !== (prev.jobCategory || '').trim();
      if (!catChanged || !(role.jobCategory || '').trim()) return role;
      const category = jobCategories.find(
        (c) => (c.jobCategoryName || '').trim() === (role.jobCategory || '').trim()
      );
      if (!category) return role;
      return applyCategoryUpdatesToRole(role, category, bps, templateLinks);
    });
    const withTemplateTitles = finalRoles.map((role) => {
      const prev = findRoleById(prevRoles, role.id);
      if (!prev) return role;
      const linkedChanged =
        String(role.linkedRoleTemplateId ?? '') !== String(prev.linkedRoleTemplateId ?? '') ||
        String(role.linkedRoleTemplateName ?? '') !== String(prev.linkedRoleTemplateName ?? '');
      if (!linkedChanged) return role;
      return {
        ...role,
        templateDisplayTitle: displayTitlesFromTemplateLinks(
          templateLinks,
          role.linkedRoleTemplateId,
          role.linkedRoleTemplateName
        ),
      };
    });
    const finalRolesStamped = withTemplateTitles.map((role) => {
      const prev = findRoleById(prevRoles, role.id);
      if (!prev) return role;
      const changedAfterDerivations = JSON.stringify(role) !== JSON.stringify(prev);
      const shouldStamp = touchedByFindReplaceIds.has(normalizeRoleId(role.id)) || changedAfterDerivations;
      if (!shouldStamp) return role;
      return { ...role, lastEditChangeControlDateReason: getLastEditValue('Find & Replace') };
    });
    const finalRolesWithAutoAffiliate = finalRolesStamped.map((role) => applyAutoAffiliate(role));
    setRoles(finalRolesWithAutoAffiliate);
    try {
      const changed = finalRolesWithAutoAffiliate.filter((role) => {
        const old = findRoleById(prevRoles, role.id);
        return old && JSON.stringify(old) !== JSON.stringify(role);
      });
      await mergeRoles(changed);
      for (const role of changed) {
        const old = findRoleById(prevRoles, role.id);
        if (old) await addAuditLog('UPDATE', role, old);
      }
      setIsDirty(false);
      notifyRolesUpdated(finalRolesWithAutoAffiliate);
      showToast(`Replaced ${matchCount} match${matchCount !== 1 ? 'es' : ''} in ${changed.length} role${changed.length !== 1 ? 's' : ''}.`);
    } catch (err) {
      setRoles(prevRoles);
      alert(err?.message || 'Replace failed. Check the server and try again.');
    }
    setShowFindReplace(false);
  };

  const handleFormSubmit = async (roleData) => {
    const prevRoles = roles;
    try {
      if (editingRole) {
        snapshotForUndo(`Edit role ${editingRole.rbacCode || editingRole.id}`);
        // Update existing role: merge existing role with form data so no fields are dropped
        const oldData = { ...editingRole };
        const updatedRole = applyAutoAffiliate({ ...editingRole, ...roleData, id: editingRole.id });
        const updatedRoles = roles.map((r) =>
          roleIdsEqual(r.id, editingRole.id) ? updatedRole : r
        );
        setRoles(updatedRoles);
        await patchRole(updatedRole);
        await addAuditLog('UPDATE', updatedRole, oldData);
        notifyRolesUpdated(updatedRoles);
        setIsDirty(false);
      } else {
        snapshotForUndo('Create new role');
        const newRole = applyAutoAffiliate({ ...roleData, id: generateId() });
        const fresh = await getRoles({ fresh: true });
        const updatedRoles = [...fresh, newRole];
        setRoles(prepareRolesForGrid(updatedRoles));
        await saveRoles(updatedRoles);
        await addAuditLog('CREATE', newRole);
        notifyRolesUpdated(updatedRoles);
        setIsDirty(false);
      }
      setShowForm(false);
      setEditingRole(null);
    } catch (err) {
      setRoles(prevRoles);
      await loadRoles();
      const message = err?.message || 'Failed to save role. Check the server and try again.';
      alert(message);
    }
  };

  const handleExport = () => {
    // Map field names to CSV header names
    const fieldToHeaderMap = {
      'rbacCode': 'RBAC CODE',
      'deptCodeId': 'Dept Code/ID',
      'department': 'Department',
      'jobCodeId': 'Job Code/ID',
      'jobTitle': 'Job Title',
      'jobCategory': 'Job Category',
      'linkedRoleTemplateId': 'Linked Role Template ID',
      'linkedRoleTemplateName': 'Linked Role Template Name',
      'templateDisplayTitle': 'Template Display Title',
      'subtemplateId': 'Subtemplate ID',
      'subtemplateDescription': 'Subtemplate Description',
      'empNeeded': 'EMP Needed',
      'slaNeeded': 'SER Needed',
      'slaBlueprintId': 'SER Blueprint ID',
      'blueprintName': 'Blueprint Name',
      'trainingTrack': 'Training Track 1',
      'trainingTrack2': 'Training Track 2',
      'trainingTrack3': 'Training Track 3',
      'trainingTrack4': 'Training Track 4',
      'trainingTrack5': 'Training Track 5',
      'trainingTrack6': 'Training Track 6',
      'sailpointRole': 'Sailpoint Role',
      'publishToSailpoint': 'Publish to Sailpoint',
      'affiliate': 'Affiliate',
      'status': 'Status',
      'lastEditChangeControlDateReason': 'Last Edit/Change Control Date/Reason'
    };

    const fieldNames = Object.keys(fieldToHeaderMap);
    const csvHeaders = Object.values(fieldToHeaderMap);

    // Export filtered results only; jobCodeId always 4 chars with leading zeros
    const exportData = filteredRoles.map(role => {
      const row = {};
      fieldNames.forEach(fieldName => {
        const val = fieldName === 'jobCodeId' ? normalizeJobCode(role[fieldName] || '') : (role[fieldName] || '');
        row[fieldToHeaderMap[fieldName]] = val;
      });
      return row;
    });

    const count = exportData.length;
    if (count >= LARGE_EXPORT_THRESHOLD) {
      setExportFeedback('Preparing export…');
      setTimeout(() => {
        try {
          exportToCSV(exportData, 'epic_rbac_roles.csv', csvHeaders);
          showToast(`Exported ${count} role(s)`);
        } finally {
          setExportFeedback(null);
        }
      }, 0);
    } else {
      exportToCSV(exportData, 'epic_rbac_roles.csv', csvHeaders);
      showToast(`Exported ${count} role(s)`);
    }
  };

  const handleBulkUpdate = async (field, value) => {
    if (selectedRows.size === 0) return;
    const fieldLabel = BULK_UPDATABLE_FIELDS.find((f) => f.key === field)?.label || field;
    snapshotForUndo(`Bulk update ${selectedRows.size} role(s) → ${fieldLabel}`);
    const prevRoles = roles;
    const nextValue = typeof value === 'string' ? sanitizeCellText(value) : value;
    const bps = blueprints.length > 0 ? blueprints : (await getBlueprints()) || [];
    const tls = await getTemplateLinks();
    const templateLinks = Array.isArray(tls) ? tls : [];
    const updatedRoles = roles.map(role => {
      if (!selectedRowsHasRole(selectedRows, role.id)) return role;
      let updated = {
        ...role,
        [field]: nextValue,
        lastEditChangeControlDateReason: getLastEditValue(`Bulk update: ${fieldLabel}`),
      };
      if (field === 'jobCategory' && String(nextValue || '').trim()) {
        const category = jobCategories.find(
          (c) => (c.jobCategoryName || '').trim() === String(nextValue || '').trim()
        );
        if (category) updated = applyCategoryUpdatesToRole(updated, category, bps, templateLinks);
      }
      if (field === 'linkedRoleTemplateId' || field === 'linkedRoleTemplateName') {
        updated.templateDisplayTitle = displayTitlesFromTemplateLinks(
          templateLinks,
          updated.linkedRoleTemplateId,
          updated.linkedRoleTemplateName
        );
      }
      return applyAutoAffiliate(updated);
    });
    setRoles(updatedRoles);
    try {
      const patches = updatedRoles.filter((role) => {
        if (!selectedRowsHasRole(selectedRows, role.id)) return false;
        const old = findRoleById(prevRoles, role.id);
        return old && JSON.stringify(old) !== JSON.stringify(role);
      });
      await mergeRoles(patches);
      for (const role of patches) {
        const old = findRoleById(prevRoles, role.id);
        if (old) await addAuditLog('UPDATE', role, old);
      }
      const count = selectedRows.size;
      setSelectedRows(new Set());
      notifyRolesUpdated(updatedRoles);
      showToast(`Updated ${count} role(s).`);
    } catch (err) {
      setRoles(prevRoles);
      alert(err?.message || 'Failed to save. Check the server and try again.');
    }
    setShowBulkUpdate(false);
  };

  const handleRowSelect = (roleId, e) => {
    e.stopPropagation();
    const id = normalizeRoleId(roleId);
    setSelectedRows(prev => {
      const newSet = new Set(prev);
      if (selectedRowsHasRole(newSet, id)) {
        for (const existing of newSet) {
          if (roleIdsEqual(existing, id)) newSet.delete(existing);
        }
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  // Select-all applies only to visible (capped) rows so bulk actions don't affect hidden rows
  const allVisibleSelected =
    rolesToRender.length > 0 && rolesToRender.every((r) => selectedRowsHasRole(selectedRows, r.id));

  const handleSelectAll = () => {
    if (allVisibleSelected) {
      setSelectedRows((prev) => {
        const next = new Set(prev);
        rolesToRender.forEach((r) => {
          for (const existing of next) {
            if (roleIdsEqual(existing, r.id)) next.delete(existing);
          }
        });
        return next;
      });
    } else {
      setSelectedRows((prev) => {
        const next = new Set(prev);
        rolesToRender.forEach((r) => next.add(normalizeRoleId(r.id)));
        return next;
      });
    }
  };

  const handleDismissSelectedHighlights = () => {
    if (selectedRows.size === 0) {
      alert('Select one or more rows first.');
      return;
    }
    setDismissedHighlightIds((prev) => {
      const next = new Set(prev);
      selectedRows.forEach((id) => next.add(String(id)));
      return next;
    });
    showToast(`Removed highlight from ${selectedRows.size} role(s).`);
  };

  const handleRestoreAllHighlights = () => {
    if (dismissedHighlightIds.size === 0) return;
    setDismissedHighlightIds(new Set());
    showToast('Restored all role highlights.');
  };

  useEffect(() => {
    const el = selectAllCheckboxRef.current;
    if (!el) return;
    const someSelected = rolesToRender.some((r) => selectedRowsHasRole(selectedRows, r.id));
    el.indeterminate = someSelected && !allVisibleSelected;
  }, [rolesToRender, selectedRows, allVisibleSelected]);

  const handleExportForSP = () => {
    // Export filtered results only
    exportForSP(filteredRoles, jobCategories);
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (!file.name.endsWith('.csv')) {
      alert('Please select a CSV file');
      return;
    }

    // Map CSV header names (both display names and internal names) to field names
    // This allows importing CSVs with either format
    const headerMapping = {
      // Display header names
      'RBAC CODE': 'rbacCode',
      'RBAC Code': 'rbacCode',
      'Dept Code/ID': 'deptCodeId',
      'Department': 'department',
      'Job Code/ID': 'jobCodeId',
      'Job Title': 'jobTitle',
      'Job Category': 'jobCategory',
      'Linked Role Template ID': 'linkedRoleTemplateId',
      'Linked Role Template Name': 'linkedRoleTemplateName',
      'Template Display Title': 'templateDisplayTitle',
      'Subtemplate ID': 'subtemplateId',
      'Subtemplate Description': 'subtemplateDescription',
      'EMP Needed': 'empNeeded',
      'SER Needed': 'slaNeeded',
      'SLA Needed': 'slaNeeded', // Support old name for backward compatibility
      'SER Blueprint ID': 'slaBlueprintId',
      'SER Blueprint': 'slaBlueprintId', // Support variant without "ID"
      'SLA Blueprint ID': 'slaBlueprintId', // Support old name for backward compatibility
      'Blueprint Name': 'blueprintName',
      'Training Track (1-6)': 'trainingTrack',
      'Training Track 1': 'trainingTrack',
      'Training Track 2': 'trainingTrack2',
      'Training Track 3': 'trainingTrack3',
      'Training Track 4': 'trainingTrack4',
      'Training Track 5': 'trainingTrack5',
      'Training Track 6': 'trainingTrack6',
      'Sailpoint Role': 'sailpointRole',
      'Publish to Sailpoint': 'publishToSailpoint',
      'Affiliate': 'affiliate',
      'Status': 'status',
      'Last Edit/Change Control Date/Reason': 'lastEditChangeControlDateReason',
      // Internal field names (for CSVs exported from this app)
      'rbacCode': 'rbacCode',
      'deptCodeId': 'deptCodeId',
      'department': 'department',
      'jobCodeId': 'jobCodeId',
      'jobTitle': 'jobTitle',
      'jobCategory': 'jobCategory',
      'linkedRoleTemplateId': 'linkedRoleTemplateId',
      'linkedRoleTemplateName': 'linkedRoleTemplateName',
      'templateDisplayTitle': 'templateDisplayTitle',
      'subtemplateId': 'subtemplateId',
      'subtemplateDescription': 'subtemplateDescription',
      'empNeeded': 'empNeeded',
      'slaNeeded': 'slaNeeded',
      'slaBlueprintId': 'slaBlueprintId',
      'blueprintName': 'blueprintName',
      'trainingTrack': 'trainingTrack',
      'trainingTrack2': 'trainingTrack2',
      'trainingTrack3': 'trainingTrack3',
      'trainingTrack4': 'trainingTrack4',
      'trainingTrack5': 'trainingTrack5',
      'trainingTrack6': 'trainingTrack6',
      'sailpointRole': 'sailpointRole',
      'publishToSailpoint': 'publishToSailpoint',
      'affiliate': 'affiliate',
      'status': 'status',
      'lastEditChangeControlDateReason': 'lastEditChangeControlDateReason'
    };

    setIsImporting(true);
    importFromCSV(
      file,
      (importedData, errors) => {
        if (errors && errors.length > 0) {
          console.warn('Import warnings:', errors);
        }

        console.log('Raw imported data sample:', importedData.slice(0, 3));
        console.log('Total rows before filtering:', importedData.length);

        // Map CSV headers to field names
        const mappedData = importedData
          .map((row) => {
            const mappedRow = {};
            Object.keys(row).forEach((key) => {
              const mappedKey = headerMapping[key] || key;
              mappedRow[mappedKey] = sanitizeCellText(row[key]);
            });
            return applyAutoAffiliate(mappedRow);
          })
          .filter((row) => {
            // Skip rows that look like header rows
            // Check if RBAC CODE field contains header text or if it's clearly a header row
            const rbacCode = (row.rbacCode || '').toString().trim();
            const rbacCodeUpper = rbacCode.toUpperCase();
            const jobCategory = (row.jobCategory || '').toString().toUpperCase().trim();
            
            // Skip if RBAC CODE is exactly a header indicator (case-insensitive)
            if (rbacCodeUpper === 'RBAC CODE' || rbacCodeUpper === 'RBAC CODE,') {
              console.log('Skipping header row:', rbacCode);
              return false;
            }
            
            // Skip if RBAC CODE contains header-like text
            if (rbacCodeUpper.includes('*IN SAILPOINT') || rbacCodeUpper.includes('LINKABLE TEMPLATE')) {
              console.log('Skipping header-like row:', rbacCode);
              return false;
            }
            
            // Skip if Job Category contains header-like text
            if (jobCategory.includes('*IN SAILPOINT') || jobCategory.includes('EPIC MOSAIC') || 
                jobCategory === 'JOB CATEGORY' || jobCategory.includes('LINKABLE TEMPLATE')) {
              console.log('Skipping header row by job category:', jobCategory);
              return false;
            }
            
            // Skip rows where RBAC CODE is empty (but allow short codes)
            if (!rbacCode || rbacCode.length === 0) {
              console.log('Skipping row with empty RBAC code');
              return false;
            }
            
            // Additional check: if the row looks like it's all header text, skip it
            // Check if multiple fields contain header-like text
            const deptCode = (row.deptCodeId || '').toString().toUpperCase().trim();
            const jobCode = (row.jobCodeId || '').toString().toUpperCase().trim();
            if ((deptCode === 'DEPT CODE/ID' || deptCode === 'DEPT CODE/ID,') && 
                (jobCode === 'JOB CODE/ID' || jobCode.includes('JOB CODE'))) {
              console.log('Skipping header row by multiple header fields');
              return false;
            }
            
            return true;
          });

        console.log('Total rows after filtering:', mappedData.length);
        console.log('Sample filtered data:', mappedData.slice(0, 2));

        if (mappedData.length === 0) {
          setIsImporting(false);
          alert('No valid data rows found in CSV file. Check browser console for details.');
          if (fileInputRef.current) {
            fileInputRef.current.value = '';
          }
          return;
        }

        const runImport = async (importMode = 'merge') => {
          const shouldReplace = importMode === 'replace';
          snapshotForUndo(`Import ${mappedData.length} role(s)${shouldReplace ? ' (replace)' : ''}`);
          const BATCH_SIZE = 80;
          const [cats, codes, depts, bps, tlsFresh] = await Promise.all([
            getJobCategories(),
            getJobCodes(),
            getDepartments(),
            getBlueprints(),
            getTemplateLinks()
          ]);
          const jobCategoriesFresh = Array.isArray(cats) ? cats : [];
          const jobCodesFresh = Array.isArray(codes) ? codes : [];
          const departmentsFresh = Array.isArray(depts) ? depts : [];
          const blueprintsFresh = Array.isArray(bps) ? bps : [];
          const templateLinksFresh = Array.isArray(tlsFresh) ? tlsFresh : [];

          let mergedRoles;
          if (shouldReplace) {
            mergedRoles = mappedData.map((row) => ({
              ...row,
              id: generateId(),
              jobCodeId: (row.jobCodeId != null && String(row.jobCodeId).trim() !== '') ? normalizeJobCode(row.jobCodeId) : ''
            }));
          } else {
            const existingRoles = await getRoles({ fresh: true });
            const existingByCode = {};
            existingRoles.forEach((r) => {
              const code = (r.rbacCode || '').trim().toUpperCase();
              if (code) existingByCode[code] = r;
            });
            const updatedIds = new Set();
            const newRows = [];
            mappedData.forEach((row) => {
              const code = (row.rbacCode || '').trim().toUpperCase();
              const jobCodeId = (row.jobCodeId != null && String(row.jobCodeId).trim() !== '') ? normalizeJobCode(row.jobCodeId) : '';
              if (code && existingByCode[code]) {
                Object.assign(existingByCode[code], { ...row, id: existingByCode[code].id, jobCodeId });
                updatedIds.add(existingByCode[code].id);
              } else {
                newRows.push({ ...row, id: generateId(), jobCodeId });
              }
            });
            mergedRoles = [...existingRoles, ...newRows];
          }

          const rolesForFillContext = mergedRoles;
          const fillContext = {
            roles: rolesForFillContext,
            jobCategories: jobCategoriesFresh,
            jobCodes: jobCodesFresh,
            departments: departmentsFresh,
            blueprints: blueprintsFresh,
            templateLinks: templateLinksFresh,
            getLastEditValue: () => getLastEditValue('CSV import (reference fill)'),
          };
          const rolesFilled = mergedRoles.map((role) => applyAutoAffiliate(fillBlanksForRole(role, fillContext)));
          setImportProgress({ active: true, current: 0, total: rolesFilled.length });
          try {
            for (let i = 0; i < rolesFilled.length; i += BATCH_SIZE) {
              const chunk = rolesFilled.slice(i, i + BATCH_SIZE);
              const done = Math.min(i + BATCH_SIZE, rolesFilled.length);
              setImportProgress((p) => ({ ...p, current: done }));
              const replace = i === 0;
              await saveRolesBatch(chunk, replace, { destructiveReplaceConfirmed: replace });
            }
            await addAuditLog('BULK_IMPORT', { id: 'bulk', count: mappedData.length });
            await loadRoles();
            showToast(`Successfully imported ${mappedData.length} role(s)!`);
          } catch (err) {
            alert(err?.message || 'Import failed. You may need to try a smaller file or check the server.');
          } finally {
            setIsImporting(false);
            setImportProgress({ active: false, current: 0, total: 0 });
          }
          if (fileInputRef.current) {
            fileInputRef.current.value = '';
          }
        };

        if (canEditRoles) {
          (async () => {
            const existingRoles = await getRoles({ fresh: true });
            const previewCols = ['rbacCode', 'deptCodeId', 'department', 'jobCodeId', 'jobTitle', 'jobCategory', 'status'];
            setImportPreview({
              rows: mappedData,
              columns: previewCols,
              existingData: existingRoles,
              matchKey: 'rbacCode',
              onConfirm: runImport
            });
          })();
        } else {
          runImport('merge');
        }
      },
      (error) => {
        setIsImporting(false);
        alert(`Import failed: ${error}`);
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      }
    );
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingRole(null);
  };

  const sortedJobCategories = useMemo(() =>
    [...jobCategories].sort((a, b) => (a.jobCategoryName || '').localeCompare(b.jobCategoryName || '')),
    [jobCategories]
  );

  const columnDefs = useMemo(() => [
    { key: 'rbacCode', label: 'RBAC CODE' },
    { key: 'actions', label: 'Actions', noSort: true },
    { key: 'deptCodeId', label: 'Dept Code/ID' },
    { key: 'department', label: 'Department' },
    { key: 'jobCodeId', label: 'Job Code/ID' },
    { key: 'jobTitle', label: 'Job Title' },
    { key: 'jobCategory', label: 'Job Category' },
    {
      key: 'linkedRoleTemplateId',
      label: 'Linked Role Template ID',
      headerTitle: 'Template Links → Template ID(s); used with name to resolve display title.',
    },
    {
      key: 'linkedRoleTemplateName',
      label: 'Linked Role Template Name',
      headerTitle: 'Template Links → Template Name(s); used when ID does not match a link row.',
    },
    {
      key: 'templateDisplayTitle',
      label: 'Template Display Title',
      headerTitle:
        'Template Links → Template Display Title only (not template name). Blank on the link row stays blank here; refreshes when linked ID/name change.',
    },
    { key: 'subtemplateId', label: 'Subtemplate ID' },
    { key: 'subtemplateDescription', label: 'Subtemplate Description' },
    { key: 'empNeeded', label: 'EMP Needed' },
    { key: 'slaNeeded', label: 'SER Needed' },
    { key: 'slaBlueprintId', label: 'SER Blueprint' },
    { key: 'trainingTrack', label: 'Training Track 1' },
    { key: 'trainingTrack2', label: 'Training Track 2' },
    { key: 'trainingTrack3', label: 'Training Track 3' },
    { key: 'trainingTrack4', label: 'Training Track 4' },
    { key: 'trainingTrack5', label: 'Training Track 5' },
    { key: 'trainingTrack6', label: 'Training Track 6' },
    { key: 'sailpointRole', label: 'Sailpoint Role' },
    { key: 'publishToSailpoint', label: 'Publish to Sailpoint' },
    { key: 'affiliate', label: 'Affiliate' },
    { key: 'status', label: 'Status' },
    { key: 'lastEditChangeControlDateReason', label: 'Last Edit/Change Control Date/Reason' },
  ], []);

  const needsRowStatusFallback = !canEditRoles && !visibleColumns.status;

  const renderedColumnKeys = useMemo(() => {
    const keys = [];
    if (allowBulkActions) keys.push('__checkbox__');
    if (visibleColumns.rbacCode) keys.push('rbacCode');
    if (visibleColumns.deptCodeId) keys.push('deptCodeId');
    if (visibleColumns.department) keys.push('department');
    if (visibleColumns.jobCodeId) keys.push('jobCodeId');
    if (visibleColumns.jobTitle) keys.push('jobTitle');
    if (visibleColumns.jobCategory) keys.push('jobCategory');
    columnDefs
      .filter((c) => !['rbacCode', 'actions', 'deptCodeId', 'department', 'jobCodeId', 'jobTitle', 'jobCategory'].includes(c.key))
      .forEach((c) => {
        if (visibleColumns[c.key]) keys.push(c.key);
      });
    if (needsRowStatusFallback) keys.push('__row_status__');
    if (canEditRoles) keys.push('__actions__');
    return keys;
  }, [allowBulkActions, visibleColumns, columnDefs, needsRowStatusFallback, canEditRoles]);

  const colW = useCallback((key) => getColWidth(key, ROLES_DEFAULT_COL_WIDTHS[key] || 160), [getColWidth]);

  const renderResizableTh = useCallback((key, inner, thProps = {}) => {
    const widthNow = colW(key);
    const min = key === '__actions__' ? 200 : 80;
    const max = 900;
    return (
      <th {...thProps} className={`${thProps.className || ''} th-resizable`.trim()}>
        <div className="th-content">{inner}</div>
        {key !== '__checkbox__' && (
          <div
            className="col-resizer"
            role="separator"
            aria-orientation="vertical"
            onMouseDown={(e) => startResize(key, e, widthNow, min, max)}
            onClick={(e) => e.stopPropagation()}
          />
        )}
      </th>
    );
  }, [colW, startResize]);

  const visibleColumnCount = (allowBulkActions ? 1 : 0)
    + (visibleColumns.rbacCode ? 1 : 0)
    + (needsRowStatusFallback ? 1 : 0)
    + (canEditRoles ? 1 : 0)
    + (visibleColumns.deptCodeId ? 1 : 0)
    + (visibleColumns.department ? 1 : 0)
    + (visibleColumns.jobCodeId ? 1 : 0)
    + (visibleColumns.jobTitle ? 1 : 0)
    + (visibleColumns.jobCategory ? 1 : 0)
    + columnDefs
        .filter(c => !['rbacCode', 'actions', 'deptCodeId', 'department', 'jobCodeId', 'jobTitle', 'jobCategory'].includes(c.key))
        .filter(c => visibleColumns[c.key]).length;

  if (showForm) {
    return (
      <RoleForm
        role={editingRole}
        onSubmit={handleFormSubmit}
        onCancel={handleCancel}
        allowTrainingTrackDropdown={allowBulkActions}
      />
    );
  }

  return (
    <div className="roles-list">
      <div className="roles-header">
        <h2>Epic RBAC Roles</h2>
        <div className="actions">
          {canEditRoles && (
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".csv"
              style={{ display: 'none' }}
            />
          )}
          {canEditRoles && (
            <button type="button" className="btn-import" onClick={handleImportClick} title="Import roles from a CSV file" disabled={isImporting}>
              {isImporting ? 'Importing…' : 'Import from CSV'}
            </button>
          )}
          {canEditRoles && (
            <button type="button" className="btn-export" onClick={handleExport} title="Download filtered roles as CSV">
              Export to CSV
            </button>
          )}
          {canEditRoles && (
            <button type="button" className="btn-export-sp" onClick={handleExportForSP} title="Export roles in SailPoint format (RBAC Code, Template, SER Needed, etc.)">
              Export for SP
            </button>
          )}
          {canEditRoles && (
            <button type="button" className="btn-export" onClick={() => setShowFindReplace(true)} title="Find & Replace across all roles (Ctrl+H)">
              Find &amp; Replace
            </button>
          )}
          {canSyncRoles && (
            <JobCategoryRoleSyncButton
              onSynced={(updatedRoles) => {
                loadRolesGenerationRef.current += 1;
                setRoles(prepareRolesForGrid(updatedRoles));
              }}
            />
          )}
          {canEditRoles && (
            <button type="button" className="btn-add" onClick={handleAdd} title="Create a new RBAC role">
              Add New Role
            </button>
          )}
        </div>
      </div>

      <div className="search-container">
        {importProgress.active && (
          <div className="import-progress" role="status" aria-live="polite">
            Importing roles… {importProgress.current} of {importProgress.total}
          </div>
        )}
        {exportFeedback && (
          <div className="export-progress" role="status" aria-live="polite">
            {exportFeedback}
          </div>
        )}
        <div className="search-row">
          <input
            type="text"
            placeholder="Search all fields..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
            disabled={Object.keys(advancedFilters).length > 0}
          />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="status-select"
          >
            <option value="All">All</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
          <label className="recently-edited-filter" title="Show only roles edited in the last 24 hours">
            <input
              type="checkbox"
              checked={recentlyEditedFilter}
              onChange={(e) => setRecentlyEditedFilter(e.target.checked)}
              style={{ marginRight: '0.35rem' }}
            />
            Edited in 24h
          </label>
          <label className="recently-edited-filter" title="Show only roles added via Add New Role in the last 24 hours (uses Last Edit stamp)">
            <input
              type="checkbox"
              checked={newIn24hFilter}
              onChange={(e) => setNewIn24hFilter(e.target.checked)}
              style={{ marginRight: '0.35rem' }}
            />
            New in 24h
          </label>
          {hasAuditUser && (
            <label
              className="recently-edited-filter"
              title='Show roles batch-edited today: "Bulk update", "Find & Replace", or "Synced from Job Category update"'
            >
              <input
                type="checkbox"
                checked={bulkEditedTodayFilter}
                onChange={(e) => setBulkEditedTodayFilter(e.target.checked)}
                style={{ marginRight: '0.35rem' }}
              />
              Bulk edited today
            </label>
          )}
          {hasAuditUser && (
            <label className="recently-edited-filter" title="Show only roles edited today by the selected audit user">
              <input
                type="checkbox"
                checked={editedByUserTodayFilter}
                onChange={(e) => setEditedByUserTodayFilter(e.target.checked)}
                style={{ marginRight: '0.35rem' }}
              />
              Edited by user today
            </label>
          )}
          <div className="search-buttons">
            <button
              type="button"
              className={`btn-secondary ${showAdvancedSearch ? 'btn-primary' : ''}`}
              onClick={() => setShowAdvancedSearch(!showAdvancedSearch)}
            >
              Advanced Search
            </button>
            <button type="button" className="btn-secondary" onClick={clearFilters}>
              Clear Filters
            </button>
            {canEditRoles && canUndo && (
              <button
                type="button"
                className="btn-secondary btn-undo"
                onClick={handleUndo}
                title={undoRef.current ? `Undo: ${undoRef.current.description}` : 'Undo last action'}
              >
                Undo
              </button>
            )}
            {allowBulkActions && (
              <>
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={() => {
                    if (selectedRows.size === 0) { alert('Please select one or more roles first.'); return; }
                    setShowBulkUpdate(true);
                  }}
                  disabled={selectedRows.size === 0}
                  title="Update a field on all selected roles"
                >
                  Bulk Update ({selectedRows.size})
                </button>
                <button
                  type="button"
                  className="btn-secondary btn-danger-outline"
                  onClick={handleDeleteSelected}
                  disabled={selectedRows.size === 0}
                  title="Delete all selected roles"
                >
                  Bulk Delete ({selectedRows.size})
                </button>
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={handleDismissSelectedHighlights}
                  disabled={selectedRows.size === 0}
                  title="Remove edited/new highlight from selected rows"
                >
                  Remove Highlight ({selectedRows.size})
                </button>
                {dismissedHighlightIds.size > 0 && (
                  <button
                    type="button"
                    className="btn-secondary"
                    onClick={handleRestoreAllHighlights}
                    title="Restore all previously removed highlights"
                  >
                    Restore Highlights
                  </button>
                )}
              </>
            )}
          </div>
        </div>
        {showAdvancedSearch && (
          <div style={{ marginTop: '1rem', padding: '1rem', backgroundColor: '#f3f4f6', borderRadius: '4px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
              <div>
                <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.9rem' }}>RBAC Code</label>
                <input
                  type="text"
                  value={advancedFilters.rbacCode || ''}
                  onChange={(e) => setAdvancedFilters({...advancedFilters, rbacCode: e.target.value})}
                  style={{ width: '100%', padding: '0.5rem' }}
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.9rem' }}>Department</label>
                <input
                  type="text"
                  value={advancedFilters.department || ''}
                  onChange={(e) => setAdvancedFilters({...advancedFilters, department: e.target.value})}
                  style={{ width: '100%', padding: '0.5rem' }}
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.9rem' }}>Job Title</label>
                <input
                  type="text"
                  value={advancedFilters.jobTitle || ''}
                  onChange={(e) => setAdvancedFilters({...advancedFilters, jobTitle: e.target.value})}
                  style={{ width: '100%', padding: '0.5rem' }}
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.9rem' }}>Job Category</label>
                <input
                  type="text"
                  value={advancedFilters.jobCategory || ''}
                  onChange={(e) => setAdvancedFilters({...advancedFilters, jobCategory: e.target.value})}
                  style={{ width: '100%', padding: '0.5rem' }}
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.9rem' }}>Template ID</label>
                <input
                  type="text"
                  value={advancedFilters.linkedRoleTemplateId || ''}
                  onChange={(e) => setAdvancedFilters({...advancedFilters, linkedRoleTemplateId: e.target.value})}
                  style={{ width: '100%', padding: '0.5rem' }}
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.9rem' }}>Template Display Title</label>
                <input
                  type="text"
                  value={advancedFilters.templateDisplayTitle || ''}
                  onChange={(e) => setAdvancedFilters({...advancedFilters, templateDisplayTitle: e.target.value})}
                  style={{ width: '100%', padding: '0.5rem' }}
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.9rem' }}>Affiliate</label>
                <input
                  type="text"
                  value={advancedFilters.affiliate || ''}
                  onChange={(e) => setAdvancedFilters({...advancedFilters, affiliate: e.target.value})}
                  style={{ width: '100%', padding: '0.5rem' }}
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.9rem' }}>Blueprint</label>
                <input
                  type="text"
                  value={advancedFilters.blueprint || ''}
                  onChange={(e) => setAdvancedFilters({...advancedFilters, blueprint: e.target.value})}
                  placeholder="ID or name"
                  style={{ width: '100%', padding: '0.5rem' }}
                />
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="table-container">
        {rolesLoading ? (
          <p className="roles-list-loading" role="status">Loading roles…</p>
        ) : roles.length === 0 ? (
          <div className="empty-state" role="status">
            <p className="empty-state-message">No roles yet</p>
            <p className="empty-state-hint">{canEditRoles ? 'Create your first role to get started.' : 'No roles to display.'}</p>
            {canEditRoles && (
              <button type="button" className="btn-add empty-state-cta" onClick={handleAdd}>
                Add New Role
              </button>
            )}
          </div>
        ) : (
          <>
        {filteredRoles.length > MAX_RENDERED_ROWS && (
          <div className="roles-list-cap-notice" role="status">
            Showing first {MAX_RENDERED_ROWS} of {filteredRoles.length} roles. Use search or filters to narrow.
          </div>
        )}
        <table className={`roles-table${canEditRoles ? ' roles-table--wrap' : ''}`}>
          <colgroup>
            {renderedColumnKeys.map((k) => (
              <col key={k} style={{ width: `${colW(k)}px` }} />
            ))}
          </colgroup>
          <thead>
            <tr>
              {allowBulkActions && (
                <th className="col-checkbox">
                  <input
                    type="checkbox"
                    checked={allVisibleSelected}
                    ref={selectAllCheckboxRef}
                    onChange={handleSelectAll}
                    onClick={(e) => e.stopPropagation()}
                  />
                </th>
              )}
              {visibleColumns.rbacCode &&
                renderResizableTh(
                  'rbacCode',
                  <>RBAC CODE {sortConfig.key === 'rbacCode' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                  { onClick: () => handleSort('rbacCode'), className: 'sortable' }
                )}
              {visibleColumns.deptCodeId &&
                renderResizableTh(
                  'deptCodeId',
                  <>Dept Code/ID {sortConfig.key === 'deptCodeId' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                  { onClick: () => handleSort('deptCodeId'), className: 'sortable' }
                )}
              {visibleColumns.department &&
                renderResizableTh(
                  'department',
                  <>Department {sortConfig.key === 'department' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                  { onClick: () => handleSort('department'), className: 'sortable' }
                )}
              {visibleColumns.jobCodeId &&
                renderResizableTh(
                  'jobCodeId',
                  <>Job Code/ID {sortConfig.key === 'jobCodeId' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                  { onClick: () => handleSort('jobCodeId'), className: 'sortable' }
                )}
              {visibleColumns.jobTitle &&
                renderResizableTh(
                  'jobTitle',
                  <>Job Title {sortConfig.key === 'jobTitle' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                  { onClick: () => handleSort('jobTitle'), className: 'sortable' }
                )}
              {visibleColumns.jobCategory &&
                renderResizableTh(
                  'jobCategory',
                  <>Job Category {sortConfig.key === 'jobCategory' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                  { onClick: () => handleSort('jobCategory'), className: 'sortable' }
                )}
              {columnDefs
                .filter((c) => !['rbacCode', 'actions', 'deptCodeId', 'department', 'jobCodeId', 'jobTitle', 'jobCategory'].includes(c.key))
                .map(
                  (col) =>
                    visibleColumns[col.key] &&
                    renderResizableTh(
                      col.key,
                      <>
                        {col.label} {sortConfig.key === col.key && (sortConfig.direction === 'asc' ? '↑' : '↓')}
                      </>,
                      {
                        key: col.key,
                        onClick: () => !col.noSort && handleSort(col.key),
                        className: col.noSort ? '' : 'sortable',
                        title:
                          col.headerTitle ??
                          (col.key === 'empNeeded'
                            ? 'Employee: required when a template or subtemplate is set'
                            : col.key === 'slaNeeded'
                              ? 'SER (Service) required; when Yes, a SER Blueprint ID is typically needed'
                              : col.key === 'slaBlueprintId'
                                ? 'SER Blueprint (ID – Name); used when SER Needed is Yes'
                                : undefined),
                      }
                    )
                )}
              {needsRowStatusFallback &&
                renderResizableTh(
                  '__row_status__',
                  'Status',
                  { className: 'col-row-status', onClick: undefined }
                )}
              {canEditRoles &&
                renderResizableTh(
                  '__actions__',
                  'Actions',
                  { className: 'col-actions col-actions-frozen', onClick: undefined }
                )}
            </tr>
          </thead>
          <tbody>
            {filteredRoles.length === 0 ? (
              <tr>
                <td colSpan={visibleColumnCount} className="no-data">
                  {searchTerm || statusFilter !== 'All' || Object.keys(advancedFilters).some(k => advancedFilters[k]) ? 'No roles found matching your search.' : 'No roles found. Click "Add New Role" to create one.'}
                </td>
              </tr>
            ) : (
              rolesToRender.map((role) => {
                const isHighlightDismissed = dismissedHighlightIds.has(String(role.id));
                const isEditing = (field) => canEditRoles && editingCell?.roleId === role.id && editingCell?.field === field;
                const tabToCell = (field, dir) => {
                  if (!showSaveButton) return;
                  const visibleFields = ROLE_EDITABLE_FIELDS.filter((f) => visibleColumns[f === 'trainingTrack' ? 'trainingTrack' : f]);
                  const idx = visibleFields.indexOf(field);
                  const next = dir === 1 ? visibleFields[idx + 1] : visibleFields[idx - 1];
                  if (next) setEditingCell({ roleId: role.id, field: next });
                  else setEditingCell(null);
                };
                const startEditing = (field) => {
                  editingOriginalRef.current = role[field] ?? '';
                  setEditingCell({ roleId: role.id, field });
                };
                const revertEditing = (field) => {
                  if (editingOriginalRef.current !== undefined) {
                    setRoles((prev) => prev.map((r) => (r.id === role.id ? { ...r, [field]: editingOriginalRef.current } : r)));
                  }
                  editingOriginalRef.current = null;
                  setEditingCell(null);
                };
                const renderTextCell = (field) => {
                  const isTemplateSubtemplateField = ['linkedRoleTemplateId', 'linkedRoleTemplateName', 'templateDisplayTitle', 'subtemplateId', 'subtemplateDescription'].includes(field);
                  if (isEditing(field)) {
                    const value = field === 'jobCodeId' ? normalizeJobCode(role[field] || '') : (role[field] || '');
                    if (isTemplateSubtemplateField) {
                      const editTip =
                        field === 'linkedRoleTemplateId'
                          ? RBAC_TEMPLATE_CELL_TOOLTIP.linkedRoleTemplateId
                          : field === 'linkedRoleTemplateName'
                            ? RBAC_TEMPLATE_CELL_TOOLTIP.linkedRoleTemplateName
                            : field === 'templateDisplayTitle'
                              ? RBAC_TEMPLATE_CELL_TOOLTIP.templateDisplayTitle
                              : undefined;
                      const editPlaceholder =
                        field === 'templateDisplayTitle'
                          ? 'From Template Links Template Display Title when linked ID/name match; editable'
                          : undefined;
                      return (
                        <textarea
                          className="inline-edit-input inline-edit-textarea"
                          rows={3}
                          value={value}
                          title={editTip}
                          placeholder={editPlaceholder}
                          onChange={(e) => {
                            const raw = e.target.value;
                            setRoles((prev) => prev.map((r) => (r.id === role.id ? { ...r, [field]: raw } : r)));
                          }}
                          onBlur={(e) => {
                            updateRoleField(role.id, field, e.target.value || '');
                          }}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                              e.preventDefault();
                              updateRoleField(role.id, field, e.target.value || '');
                              setEditingCell(null);
                            }
                            if (e.key === 'Escape') revertEditing(field);
                            if (e.key === 'Tab' && showSaveButton) { e.preventDefault(); updateRoleField(role.id, field, e.target.value || ''); tabToCell(field, e.shiftKey ? -1 : 1); }
                          }}
                          onClick={(e) => e.stopPropagation()}
                          autoFocus
                        />
                      );
                    }
                    return (
                      <input
                        type="text"
                        className="inline-edit-input"
                        value={value}
                        onChange={(e) => {
                          const raw = e.target.value;
                          const next = roles.map((r) => (r.id === role.id ? { ...r, [field]: raw } : r));
                          setRoles(next);
                        }}
                        onBlur={(e) => {
                          const currentValue = e.target.value;
                          updateRoleField(role.id, field, field === 'jobCodeId' ? normalizeJobCode(currentValue || '') : (currentValue || ''));
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            const currentValue = e.target.value;
                            updateRoleField(role.id, field, field === 'jobCodeId' ? normalizeJobCode(currentValue || '') : (currentValue || ''));
                            setEditingCell(null);
                          }
                          if (e.key === 'Escape') revertEditing(field);
                          if (e.key === 'Tab' && showSaveButton) { e.preventDefault(); updateRoleField(role.id, field, e.target.value || ''); tabToCell(field, e.shiftKey ? -1 : 1); }
                        }}
                        onClick={(e) => e.stopPropagation()}
                        autoFocus
                      />
                    );
                  }
                  const raw = role[field] ?? '';
                  let displayValue =
                    field === 'jobCodeId'
                      ? normalizeJobCode(raw || '')
                      : (['linkedRoleTemplateId', 'linkedRoleTemplateName', 'templateDisplayTitle', 'subtemplateId', 'subtemplateDescription'].includes(field)
                          ? templateSubtemplateOneLine(raw, field !== 'linkedRoleTemplateName' && field !== 'templateDisplayTitle' && field !== 'subtemplateDescription')
                          : raw);
                  if (field === 'linkedRoleTemplateName' || field === 'subtemplateDescription') {
                    displayValue = formatTemplateNameTitleCase(displayValue);
                  }
                  const cellTip = RBAC_TEMPLATE_CELL_TOOLTIP[field];
                  return (
                    <span
                      className="inline-edit-span"
                      title={cellTip}
                      onDoubleClick={canEditRoles ? (e) => { e.stopPropagation(); startEditing(field); } : undefined}
                    >
                      {sanitizeCellText(displayValue)}
                    </span>
                  );
                };
                const renderJobCategoryCell = () => {
                  if (isEditing('jobCategory')) {
                    return (
                      <select
                        className="inline-edit-select"
                        value={role.jobCategory || ''}
                        onChange={(e) => updateRoleField(role.id, 'jobCategory', e.target.value)}
                        onBlur={() => setEditingCell(null)}
                        onKeyDown={(e) => {
                          if (e.key === 'Escape') setEditingCell(null);
                          if (e.key === 'Tab' && showSaveButton) { e.preventDefault(); tabToCell('jobCategory', e.shiftKey ? -1 : 1); }
                        }}
                        onClick={(e) => e.stopPropagation()}
                        autoFocus
                      >
                        <option value="">—</option>
                        {sortedJobCategories.map((c) => (
                          <option key={c.id || c.jobCategoryName} value={c.jobCategoryName || ''}>{c.jobCategoryName || ''}</option>
                        ))}
                      </select>
                    );
                  }
                  return (
                    <span
                      className="inline-edit-span"
                      onDoubleClick={canEditRoles ? (e) => { e.stopPropagation(); startEditing('jobCategory'); } : undefined}
                    >
                      {sanitizeCellText(role.jobCategory)}
                    </span>
                  );
                };
                const renderStatusCell = () => {
                  if (isEditing('status')) {
                    return (
                      <select
                        className="inline-edit-select"
                        value={role.status || 'Active'}
                        onChange={(e) => updateRoleField(role.id, 'status', e.target.value)}
                        onBlur={() => setEditingCell(null)}
                        onKeyDown={(e) => {
                          if (e.key === 'Escape') setEditingCell(null);
                          if (e.key === 'Tab' && showSaveButton) { e.preventDefault(); tabToCell('status', e.shiftKey ? -1 : 1); }
                        }}
                        onClick={(e) => e.stopPropagation()}
                        autoFocus
                      >
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                      </select>
                    );
                  }
                  return (
                    <span
                      className="inline-edit-span"
                      onDoubleClick={canEditRoles ? (e) => { e.stopPropagation(); startEditing('status'); } : undefined}
                    >
                      {sanitizeCellText(role.status || 'Active')}
                    </span>
                  );
                };
                const handleContextMenu = showSaveButton ? (e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setContextMenu({
                    x: e.clientX,
                    y: e.clientY,
                    actions: [
                      { label: 'Edit', onClick: () => handleEdit(role) },
                      { label: 'Duplicate', onClick: () => handleDuplicateRole(role) },
                      { label: 'Delete', onClick: () => handleDelete(role) },
                      { label: 'Copy Row', onClick: () => handleCopyRow(role) },
                    ]
                  });
                } : undefined;
                return (
                  <tr
                    key={role.id}
                    className={[
                      selectedRowId === role.id ? 'selected' : '',
                      !isHighlightDismissed && isRoleBulkEditedToday(role) ? 'role-bulk-edited-today' : '',
                      !isHighlightDismissed && isRoleEditedInLast24Hours(role) ? 'role-recently-edited' : '',
                      !isHighlightDismissed && isRoleNewInLast24Hours(role) ? 'role-new-in-24h' : '',
                    ].filter(Boolean).join(' ')}
                    onContextMenu={handleContextMenu}
                    onClick={() => setSelectedRowId(role.id)}
                  >
                    {allowBulkActions && (
                      <td className="col-checkbox" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="checkbox"
                          checked={selectedRowsHasRole(selectedRows, role.id)}
                          onChange={(e) => handleRowSelect(role.id, e)}
                        />
                      </td>
                    )}
                    {visibleColumns.rbacCode && <td onClick={(e) => e.stopPropagation()}>{renderTextCell('rbacCode')}</td>}
                    {visibleColumns.deptCodeId && <td onClick={(e) => e.stopPropagation()}>{renderTextCell('deptCodeId')}</td>}
                    {visibleColumns.department && <td onClick={(e) => e.stopPropagation()}>{renderTextCell('department')}</td>}
                    {visibleColumns.jobCodeId && <td onClick={(e) => e.stopPropagation()}>{renderTextCell('jobCodeId')}</td>}
                    {visibleColumns.jobTitle && <td onClick={(e) => e.stopPropagation()}>{renderTextCell('jobTitle')}</td>}
                    {visibleColumns.jobCategory && <td onClick={(e) => e.stopPropagation()}>{renderJobCategoryCell()}</td>}
                    {visibleColumns.linkedRoleTemplateId && <td onClick={(e) => e.stopPropagation()}>{renderTextCell('linkedRoleTemplateId')}</td>}
                    {visibleColumns.linkedRoleTemplateName && <td onClick={(e) => e.stopPropagation()}>{renderTextCell('linkedRoleTemplateName')}</td>}
                    {visibleColumns.templateDisplayTitle && <td onClick={(e) => e.stopPropagation()}>{renderTextCell('templateDisplayTitle')}</td>}
                    {visibleColumns.subtemplateId && <td onClick={(e) => e.stopPropagation()}>{renderTextCell('subtemplateId')}</td>}
                    {visibleColumns.subtemplateDescription && <td onClick={(e) => e.stopPropagation()}>{renderTextCell('subtemplateDescription')}</td>}
                    {visibleColumns.empNeeded && (
                      <td className="col-checkbox" onClick={(e) => e.stopPropagation()}>
                        {canEditRoles ? (
                          <input
                            type="checkbox"
                            checked={(role.empNeeded || '').toLowerCase() === 'yes'}
                            onChange={() => updateRoleField(role.id, 'empNeeded', (role.empNeeded || '').toLowerCase() === 'yes' ? 'No' : 'Yes')}
                          />
                        ) : (
                          <span>{(role.empNeeded || '').trim() || '—'}</span>
                        )}
                      </td>
                    )}
                    {visibleColumns.slaNeeded && (
                      <td className="col-checkbox" onClick={(e) => e.stopPropagation()}>
                        {canEditRoles ? (
                          <input
                            type="checkbox"
                            checked={(role.slaNeeded || '').toLowerCase() === 'yes'}
                            onChange={() => updateRoleField(role.id, 'slaNeeded', (role.slaNeeded || '').toLowerCase() === 'yes' ? 'No' : 'Yes')}
                          />
                        ) : (
                          <span>{(role.slaNeeded || '').trim() || '—'}</span>
                        )}
                      </td>
                    )}
                    {visibleColumns.slaBlueprintId && (
                      <td onClick={(e) => e.stopPropagation()} className="text-cell">
                        <span
                          className="inline-edit-span"
                          onDoubleClick={canEditRoles ? (e) => { e.stopPropagation(); startEditing('slaBlueprintId'); } : undefined}
                        >
                          {sanitizeCellText([role.slaBlueprintId, role.blueprintName].filter(Boolean).join(' – '))}
                        </span>
                      </td>
                    )}
                    {visibleColumns.trainingTrack && <td onClick={(e) => e.stopPropagation()}>{renderTextCell('trainingTrack')}</td>}
                    {visibleColumns.trainingTrack2 && <td onClick={(e) => e.stopPropagation()}>{renderTextCell('trainingTrack2')}</td>}
                    {visibleColumns.trainingTrack3 && <td onClick={(e) => e.stopPropagation()}>{renderTextCell('trainingTrack3')}</td>}
                    {visibleColumns.trainingTrack4 && <td onClick={(e) => e.stopPropagation()}>{renderTextCell('trainingTrack4')}</td>}
                    {visibleColumns.trainingTrack5 && <td onClick={(e) => e.stopPropagation()}>{renderTextCell('trainingTrack5')}</td>}
                    {visibleColumns.trainingTrack6 && <td onClick={(e) => e.stopPropagation()}>{renderTextCell('trainingTrack6')}</td>}
                    {visibleColumns.sailpointRole && (
                      <td onClick={(e) => e.stopPropagation()} title="Edit Sailpoint Role on the Job Category record">
                        <span className="roles-sailpoint-readonly">{sanitizeCellText((role.sailpointRole || '').trim() || '—')}</span>
                      </td>
                    )}
                    {visibleColumns.publishToSailpoint && (
                      <td className="col-checkbox" onClick={(e) => e.stopPropagation()}>
                        {canEditRoles ? (
                          <input
                            type="checkbox"
                            checked={String(role.publishToSailpoint || '').toLowerCase() === 'yes'}
                            onChange={() =>
                              updateRoleField(
                                role.id,
                                'publishToSailpoint',
                                String(role.publishToSailpoint || '').toLowerCase() === 'yes' ? 'No' : 'Yes'
                              )
                            }
                          />
                        ) : (
                          <span>{(role.publishToSailpoint || '').trim() || 'Yes'}</span>
                        )}
                      </td>
                    )}
                    {visibleColumns.affiliate && (
                      <td className="col-checkbox" onClick={(e) => e.stopPropagation()}>
                        {canEditRoles ? (
                          <input
                            type="checkbox"
                            checked={(role.affiliate || '').toLowerCase() === 'yes'}
                            onChange={() => updateRoleField(role.id, 'affiliate', (role.affiliate || '').toLowerCase() === 'yes' ? '' : 'yes')}
                          />
                        ) : (
                          <span>{(role.affiliate || '').trim()}</span>
                        )}
                      </td>
                    )}
                    {visibleColumns.status && <td onClick={(e) => e.stopPropagation()}>{renderStatusCell()}</td>}
                    {visibleColumns.lastEditChangeControlDateReason && <td className="text-cell">{role.lastEditChangeControlDateReason || ''}</td>}
                    {needsRowStatusFallback && (
                      <td className="col-row-status">
                        <span className="row-status">{role.status || 'Active'}</span>
                      </td>
                    )}
                    {canEditRoles && (
                      <td className="col-actions-cell col-actions-frozen">
                        <>
                          <button type="button" className="btn-edit" onClick={(e) => { e.stopPropagation(); handleEdit(role); }}>Edit</button>
                          <button
                            type="button"
                            className={(role.status || 'Active').trim() === 'Inactive' ? 'btn-reactivate' : 'btn-inactivate'}
                            onClick={(e) => { e.stopPropagation(); handleToggleStatus(role); }}
                          >
                            {(role.status || 'Active').trim() === 'Inactive' ? 'Reactivate' : 'Inactivate'}
                          </button>
                          <button type="button" className="btn-delete" onClick={(e) => { e.stopPropagation(); handleDelete(role); }}>Delete</button>
                        </>
                        {!visibleColumns.status && <span className="row-status">{role.status || 'Active'}</span>}
                      </td>
                    )}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
          </>
        )}
      </div>

      <div style={{ padding: '1.5rem 2rem', borderTop: '1px solid #e2e8f0', backgroundColor: '#f8fafc' }}>
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', justifyContent: 'center', alignItems: 'center' }}>
          {(canEditRoles || allowBulkActions) && (
            <>
              {canEditRoles && showSaveButton && (
                <>
                  <button type="button" className="btn-import" onClick={handleSave} title="Save all changes to server">
                    Save
                  </button>
                  {saveFeedback && (
                    <span style={{ color: '#16a34a', fontWeight: 500, fontSize: '0.9rem' }}>Saved</span>
                  )}
                  {canSyncRoles && (
                    <JobCategoryRoleSyncButton
                      scope={SYNC_SCOPE_ALL}
                      className="btn-import"
                      onSynced={(updatedRoles) => {
                        loadRolesGenerationRef.current += 1;
                        setRoles(prepareRolesForGrid(updatedRoles));
                      }}
                    />
                  )}
                </>
              )}
              {showSaveButton && (
                <button type="button" className="btn-import" onClick={handleFillBlanks} title="Fill blank Department, Job Title, Job Category, Blueprint Name from other tables">
                  Fill Blanks
                </button>
              )}
              {showSaveButton && showSailpointRepair && (
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={handleRepairMissingSailpointRoles}
                  title="One-time fix: fill blank Sailpoint Role values from Job Categories"
                >
                  Repair Missing Sailpoint Role
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {showFindReplace && (
        <FindReplaceDialog
          columns={columnDefs.filter((c) => c.key !== 'sailpointRole')}
          data={roles}
          onReplace={handleFindReplace}
          onClose={() => setShowFindReplace(false)}
        />
      )}

      {showBulkUpdate && (
        <BulkUpdateDialog
          selectedCount={selectedRows.size}
          columnDefs={columnDefs}
          jobCategories={sortedJobCategories}
          onApply={handleBulkUpdate}
          onClose={() => setShowBulkUpdate(false)}
        />
      )}

      {contextMenu && (
        <TableContextMenu
          x={contextMenu.x}
          y={contextMenu.y}
          actions={contextMenu.actions}
          onClose={() => setContextMenu(null)}
        />
      )}

      {importPreview && (
        <ImportPreviewDialog
          rows={importPreview.rows}
          columns={importPreview.columns}
          existingData={importPreview.existingData}
          matchKey={importPreview.matchKey}
          onConfirm={(mode) => { setImportPreview(null); importPreview.onConfirm(mode); }}
          onCancel={() => { setImportPreview(null); setIsImporting(false); if (fileInputRef.current) fileInputRef.current.value = ''; }}
          enableImportMode
          defaultImportMode="merge"
        />
      )}
    </div>
  );
};

export default RolesList;
