import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useDebounce } from '../utils/useDebounce';
import { getTemplateLinks, saveTemplateLinks, addTemplateLinkAuditLog, addAuditLogsBatch, generateId } from '../utils/storage';
import { exportToCSV } from '../utils/csvExport';
import { importFromExcel } from '../utils/excelImport';
import { sanitizeCellText } from '../utils/textSanitize';
import TemplateLinkForm from './TemplateLinkForm';
import ImportPreviewDialog from './ImportPreviewDialog';
import { useToast } from '../context/ToastContext';
import SortableTh from './SortableTh';
import { sortRowsByKey, nextSortState } from '../utils/tableSort';
import {
  TEMPLATE_LINK_HEADER_ALIASES as HEADER_ALIASES,
  mapCsvCellsToTemplateLinkRow,
  pickImportMultiSlot,
  normalizeImportHeaderKey as normalizeHeaderKey,
} from '../utils/templateLinksImport';
import './TemplateLinks.css';

const TL_BULK_FIELDS = [
  { key: 'userRecordType', label: 'User Record Type', type: 'select', options: ['Linkable Template', 'Subtemplate'] },
  { key: 'templateId', label: 'Template ID(s)' },
  { key: 'templateName', label: 'Template Name(s)' },
  { key: 'primaryTemplateOwner', label: 'Primary Template Owner' },
  { key: 'templateDisplayTitle', label: 'Template Display Title' },
  { key: 'subtemplateId', label: 'Subtemplate ID(s)' },
  { key: 'subtemplateName', label: 'Subtemplate Description' },
  { key: 'currentStatus', label: 'User Record Status', type: 'select', options: ['Active', 'Inactive', 'Pending'] },
];
const VALID_USER_RECORD_TYPES = new Set(['linkable template', 'subtemplate']);
const VALID_STATUS_VALUES = new Set(['active', 'inactive', 'pending']);

function canonicalTemplateLinkStatus(value) {
  const raw = String(value ?? '').replace(/\u00a0/g, ' ').trim().toLowerCase();
  if (!raw) return 'Active';
  if (['active', 'a', 'yes', 'y', 'true', '1', 'enabled'].includes(raw)) return 'Active';
  if (['inactive', 'in active', 'i', 'no', 'n', 'false', '0', 'disabled', '#n/a', 'n/a'].includes(raw)) return 'Inactive';
  if (['pending', 'p', 'review', 'on hold', 'hold'].includes(raw)) return 'Pending';
  return 'Active';
}

/** Normalize User Record Type from API / Excel (handles casing, spacing, driver key variants). */
function canonicalUserRecordType(row) {
  const raw =
    row?.userRecordType ??
    row?.UserRecordType ??
    row?.user_record_type ??
    '';
  let v = String(raw).replace(/\u00a0/g, ' ').trim().toLowerCase().replace(/\s+/g, ' ');
  if (!v) return 'Linkable Template';
  if (v === 'subtemplate' || v === 'sub template' || v === 'sub-template') return 'Subtemplate';
  if (v === 'linkable template' || v === 'linkabletemplate') return 'Linkable Template';
  if (v.startsWith('subtemplate')) return 'Subtemplate';
  if (v.includes('linkable')) return 'Linkable Template';
  return 'Linkable Template';
}

function normalizeImportedRow(row) {
  const get = (internalKey) => {
    const value = row[internalKey];
    if (value !== undefined && value !== null && String(value).trim() !== '') return sanitizeCellText(value);
    const aliases = HEADER_ALIASES[internalKey];
    const aliasSet = new Set(aliases.map((a) => normalizeHeaderKey(a)));
    for (const alias of aliases) {
      for (const key of Object.keys(row)) {
        if (key && (String(key).toLowerCase().trim() === alias || aliasSet.has(normalizeHeaderKey(key)))) {
          const v = row[key];
          if (v !== undefined && v !== null && String(v).trim() !== '') return sanitizeCellText(v);
        }
      }
    }
    return '';
  };
  const templateId = get('templateId');
  const templateName = get('templateName');
  const primaryTemplateOwner = get('primaryTemplateOwner');
  const templateDisplayTitle = get('templateDisplayTitle');
  const subtemplateId = get('subtemplateId');
  const subtemplateName = get('subtemplateName');
  if (!templateId && !templateName && !templateDisplayTitle && !primaryTemplateOwner && !subtemplateId && !subtemplateName) {
    return null;
  }
  return {
    userRecordType: get('userRecordType'),
    templateId,
    templateName,
    primaryTemplateOwner,
    templateDisplayTitle,
    subtemplateId,
    subtemplateName,
    currentStatus: canonicalTemplateLinkStatus(get('currentStatus')),
  };
}

function normalizeMultiTemplateInput(value, { splitCommas = true, uppercase = false } = {}) {
  if (value == null) return '';
  return String(value)
    .replace(/\r\n?/g, '\n')
    .replace(/\n+/g, '\n')
    .split('\n')
    .flatMap((line) => (splitCommas ? line.split(',') : [line]))
    .map((part) => part.trim().replace(/\s+/g, ' '))
    .filter(Boolean)
    .map((part) => (uppercase ? part.toUpperCase() : part))
    .join('\n');
}

function normalizeTemplateLinkRow(row) {
  const userRecordType = canonicalUserRecordType(row);
  let templateId = normalizeMultiTemplateInput(row.templateId);
  let templateName = normalizeMultiTemplateInput(row.templateName, { splitCommas: false, uppercase: true });
  let subtemplateId = normalizeMultiTemplateInput(row.subtemplateId);
  let subtemplateName = normalizeMultiTemplateInput(row.subtemplateName, { splitCommas: false, uppercase: true });

  // Subtemplate rows use the same storage fields as linkable templates: templateId / templateName.
  // Legacy rows may only have subtemplateId / subtemplateName; migrate on read/save.
  if (userRecordType === 'Subtemplate') {
    if (!templateId && subtemplateId) templateId = subtemplateId;
    if (!templateName && subtemplateName) templateName = subtemplateName;
    subtemplateId = '';
    subtemplateName = '';
  }

  return {
    ...row,
    userRecordType,
    templateId,
    templateName,
    primaryTemplateOwner: normalizeMultiTemplateInput(row.primaryTemplateOwner),
    templateDisplayTitle: normalizeMultiTemplateInput(row.templateDisplayTitle, { splitCommas: false, uppercase: true }),
    subtemplateId,
    subtemplateName,
    currentStatus: canonicalTemplateLinkStatus(row.currentStatus),
  };
}

function splitMultiValue(value, options) {
  const normalized = normalizeMultiTemplateInput(value, options);
  if (!normalized) return [];
  return normalized.split('\n').map((v) => v.trim()).filter(Boolean);
}

function summarizeRowForDuplicatePrompt(row) {
  const type = canonicalUserRecordType(row);
  const name = String(row.templateName || '').trim();
  const title = String(row.templateDisplayTitle || '').trim();
  const status = String(row.currentStatus || 'Active').trim() || 'Active';
  const label = name || title || '(no name)';
  return `[${type}] ${label} | status: ${status}`;
}

/**
 * Enforce globally unique Template ID tokens across all rows.
 * If duplicates are detected, prompt the user for which row should retain each ID.
 * Returns null when user cancels.
 */
function resolveDuplicateTemplateIdsWithPrompt(rows) {
  let working = (rows || []).map((r) => normalizeTemplateLinkRow({ ...r }));
  const duplicateIds = new Set();
  const idCounts = new Map();

  for (const row of working) {
    const seenInRow = new Set();
    for (const token of splitMultiValue(row.templateId)) {
      const k = token.toLowerCase();
      if (seenInRow.has(k)) continue;
      seenInRow.add(k);
      idCounts.set(k, (idCounts.get(k) || 0) + 1);
    }
  }
  for (const [k, c] of idCounts.entries()) {
    if (c > 1) duplicateIds.add(k);
  }
  if (!duplicateIds.size) return working;

  for (const dupId of duplicateIds) {
    const rowsWithId = () =>
      working.filter((row) => splitMultiValue(row.templateId).some((t) => t.toLowerCase() === dupId));
    let candidates = rowsWithId();
    if (candidates.length <= 1) continue;

    let keepRowId = null;
    while (!keepRowId) {
      const lines = candidates.map((row, idx) => `${idx + 1}) ${summarizeRowForDuplicatePrompt(row)}`);
      const input = window.prompt(
        [
          `Duplicate Template ID "${dupId}" was found on ${candidates.length} rows.`,
          'Choose which row should keep this ID (other rows will have this ID removed):',
          ...lines,
          '',
          'Enter row number:',
        ].join('\n'),
        '1'
      );
      if (input == null) return null;
      const n = Number.parseInt(String(input).trim(), 10);
      if (!Number.isInteger(n) || n < 1 || n > candidates.length) {
        alert('Please enter a valid row number from the list.');
        continue;
      }
      keepRowId = candidates[n - 1].id;
    }

    working = working.map((row) => {
      const seen = new Set();
      const nextTokens = [];
      for (const token of splitMultiValue(row.templateId)) {
        const k = token.toLowerCase();
        if (seen.has(k)) continue; // also de-duplicate repeated tokens inside the same row
        seen.add(k);
        if (k === dupId && row.id !== keepRowId) continue;
        nextTokens.push(token);
      }
      const nextId = nextTokens.join('\n');
      if (nextId === String(row.templateId || '')) return row;
      return normalizeTemplateLinkRow({ ...row, templateId: nextId });
    });

    candidates = rowsWithId();
    if (candidates.length > 1) {
      // Safety fallback: keep first row if duplicate still remains after prompt cycle.
      const fallbackKeepId = candidates[0].id;
      working = working.map((row) => {
        const nextTokens = splitMultiValue(row.templateId).filter((t) => {
          const k = t.toLowerCase();
          return k !== dupId || row.id === fallbackKeepId;
        });
        return normalizeTemplateLinkRow({ ...row, templateId: nextTokens.join('\n') });
      });
    }
  }
  return working;
}

function removeDuplicateTemplateIdsKeepingFirst(rows) {
  const seen = new Set();
  let removedCount = 0;
  let changedCount = 0;
  const updatedRows = (rows || []).map((row) => {
    const nextTokens = [];
    let changed = false;
    for (const token of splitMultiValue(row?.templateId)) {
      const k = token.toLowerCase();
      if (seen.has(k)) {
        removedCount += 1;
        changed = true;
        continue;
      }
      seen.add(k);
      nextTokens.push(token);
    }
    const nextTemplateId = nextTokens.join('\n');
    if (!changed && String(row?.templateId || '') === nextTemplateId) return row;
    changedCount += 1;
    return normalizeTemplateLinkRow({ ...row, templateId: nextTemplateId });
  });
  return { updatedRows, removedCount, changedCount };
}

function analyzeImportDataQuality(rows) {
  const list = Array.isArray(rows) ? rows : [];
  const duplicateIdCounts = new Map();
  const missingRequired = [];
  const invalidRecordType = [];
  const suspiciousStatus = [];

  list.forEach((row, idx) => {
    const rowNo = idx + 1;
    const recType = String(row?.userRecordType || '').trim().toLowerCase();
    const status = String(row?.currentStatus || '').trim().toLowerCase();

    const missing = [];
    if (!String(row?.templateId || '').trim()) missing.push('Template ID(s)');
    if (!String(row?.templateName || '').trim()) missing.push('Template Name(s)');
    if (missing.length) missingRequired.push({ rowNo, missing });

    if (!VALID_USER_RECORD_TYPES.has(recType)) {
      invalidRecordType.push({ rowNo, value: row?.userRecordType || '' });
    }
    if (status && !VALID_STATUS_VALUES.has(status)) {
      suspiciousStatus.push({ rowNo, value: row?.currentStatus || '' });
    }

    const seenInRow = new Set();
    for (const token of splitMultiValue(row?.templateId)) {
      const k = token.toLowerCase();
      if (seenInRow.has(k)) continue;
      seenInRow.add(k);
      duplicateIdCounts.set(k, (duplicateIdCounts.get(k) || 0) + 1);
    }
  });

  const duplicateTemplateIds = [...duplicateIdCounts.entries()]
    .filter(([, count]) => count > 1)
    .sort((a, b) => b[1] - a[1]);

  return {
    totalRows: list.length,
    duplicateTemplateIds,
    missingRequired,
    invalidRecordType,
    suspiciousStatus,
  };
}

function importQualityConfirmationMessage(quality, importMode) {
  const duplicateCount = quality.duplicateTemplateIds.length;
  const missingCount = quality.missingRequired.length;
  const invalidTypeCount = quality.invalidRecordType.length;
  const suspiciousStatusCount = quality.suspiciousStatus.length;
  const topDupes = quality.duplicateTemplateIds
    .slice(0, 5)
    .map(([id, count]) => `${id} (${count} rows)`)
    .join(', ');

  const lines = [
    `Template Links ${importMode === 'replace' ? 'replace' : 'merge'} import validation:`,
    `- Rows in import file: ${quality.totalRows}`,
    `- duplicate Template ID(s): ${duplicateCount}${topDupes ? ` [${topDupes}]` : ''}`,
    `- missing required fields: ${missingCount}`,
    `- invalid User Record Type: ${invalidTypeCount}`,
    `- suspicious status values: ${suspiciousStatusCount}`,
    '',
    'Continue import?',
  ];
  return lines.join('\n');
}

function mergeKeyForTemplateLink(row) {
  const n = normalizeTemplateLinkRow(row);
  return [
    (n.userRecordType || '').toLowerCase(),
    (n.templateId || '').toLowerCase(),
    (n.templateName || '').toLowerCase(),
    (n.templateDisplayTitle || '').toLowerCase(),
    (n.subtemplateName || '').toLowerCase(),
    (n.primaryTemplateOwner || '').toLowerCase(),
  ].join('|');
}

function processImportedData(importedData) {
  const mapped = [];
  for (const row of importedData) {
    const normalized = normalizeImportedRow(row);
    if (!normalized) continue;

    const templateIds = splitMultiValue(normalized.templateId);
    const templateNames = splitMultiValue(normalized.templateName, { splitCommas: false });
    const owners = splitMultiValue(normalized.primaryTemplateOwner);
    const displayTitles = splitMultiValue(normalized.templateDisplayTitle, { splitCommas: false });
    const subtemplateIds = splitMultiValue(normalized.subtemplateId);
    const subtemplateNames = splitMultiValue(normalized.subtemplateName, { splitCommas: false });

    const templateCount = Math.max(1, templateIds.length, templateNames.length, owners.length, displayTitles.length);
    const subtemplateCount = Math.max(1, subtemplateIds.length, subtemplateNames.length);

    for (let t = 0; t < templateCount; t++) {
      const templatePart = {
        templateId: pickImportMultiSlot(templateIds, t),
        templateName: pickImportMultiSlot(templateNames, t),
        primaryTemplateOwner: pickImportMultiSlot(owners, t),
        templateDisplayTitle: pickImportMultiSlot(displayTitles, t),
      };

      for (let s = 0; s < subtemplateCount; s++) {
        mapped.push(normalizeTemplateLinkRow({
          ...templatePart,
          subtemplateId: pickImportMultiSlot(subtemplateIds, s),
          subtemplateName: pickImportMultiSlot(subtemplateNames, s),
          userRecordType: normalized.userRecordType || '',
          currentStatus: normalized.currentStatus || 'Active',
        }));
      }
    }
  }
  return mapped;
}

function parseCSVRows(text) {
  const rows = [];
  let currentRow = [];
  let currentField = '';
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const nextChar = text[i + 1];
    if (char === '"') {
      if (inQuotes && nextChar === '"') {
        currentField += '"';
        i++;
      } else inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      currentRow.push(currentField);
      currentField = '';
    } else if ((char === '\n' || char === '\r') && !inQuotes) {
      if (char === '\r' && nextChar === '\n') i++;
      currentRow.push(currentField);
      if (currentRow.length > 0 && currentRow.some((f) => String(f).trim() !== '')) rows.push([...currentRow]);
      currentRow = [];
      currentField = '';
    } else {
      currentField += char;
    }
  }
  if (currentField !== '' || currentRow.length > 0) {
    currentRow.push(currentField);
    if (currentRow.length > 0 && currentRow.some((f) => String(f).trim() !== '')) rows.push([...currentRow]);
  }
  return rows;
}

function readTemplateLinksCSV(file, onSuccess, onError) {
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      let text = e.target.result;
      if (!text || typeof text !== 'string') return onError('File is empty or invalid');
      text = text.replace(/^\uFEFF/, '');
      if (!text.trim()) return onError('File is empty');
      const rows = parseCSVRows(text);
      if (rows.length === 0) return onError('No rows found in file');
      const data = [];
      const hasHeader = rows.length >= 2;
      const headers = hasHeader
        ? rows[0].map((h) => String(h || '').replace(/^\uFEFF/, '').trim())
        : ['User Record Type', 'Template ID', 'Template Name', 'Primary Template Owner', 'Template Display Title', 'Subtemplate ID', 'Subtemplate Description', 'User Record Status'];
      const startIndex = hasHeader ? 1 : 0;
      for (let i = startIndex; i < rows.length; i++) {
        const row = rows[i];
        if (!row || row.length === 0 || row.every((c) => !c || String(c).trim() === '')) continue;
        data.push(mapCsvCellsToTemplateLinkRow(row, headers));
      }
      if (data.length === 0) return onError('No valid data rows found');
      onSuccess(data);
    } catch (err) {
      onError(err.message || 'Failed to parse CSV');
    }
  };
  reader.onerror = () => onError('Error reading file');
  reader.readAsText(file, 'UTF-8');
}

const TlBulkUpdateDialog = ({ selectedCount, onApply, onClose }) => {
  const [field, setField] = useState('');
  const [value, setValue] = useState('');
  const fieldDef = TL_BULK_FIELDS.find((f) => f.key === field);
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!field) { alert('Please select a field.'); return; }
    if (!window.confirm(`Set "${fieldDef?.label || field}" to "${value}" on ${selectedCount} template link(s)?`)) return;
    onApply(field, value);
  };
  return (
    <div className="find-replace-overlay" onClick={onClose}>
      <div className="find-replace-dialog" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 420 }}>
        <div className="find-replace-header">
          <h3>Bulk Update ({selectedCount} selected)</h3>
          <button type="button" className="find-replace-close" onClick={onClose}>&times;</button>
        </div>
        <form onSubmit={handleSubmit} style={{ padding: '1rem 1.25rem' }}>
          <div style={{ marginBottom: '0.75rem' }}>
            <label style={{ display: 'block', marginBottom: '0.25rem', fontWeight: 500, fontSize: '0.9rem' }}>Field</label>
            <select value={field} onChange={(e) => { setField(e.target.value); setValue(''); }} style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1' }}>
              <option value="">Select field...</option>
              {TL_BULK_FIELDS.map((f) => <option key={f.key} value={f.key}>{f.label}</option>)}
            </select>
          </div>
          {field && (
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', marginBottom: '0.25rem', fontWeight: 500, fontSize: '0.9rem' }}>New Value</label>
              {fieldDef?.type === 'select' ? (
                <select value={value} onChange={(e) => setValue(e.target.value)} style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1' }} autoFocus>
                  <option value="">— (clear) —</option>
                  {fieldDef.options.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              ) : (
                <input type="text" value={value} onChange={(e) => setValue(e.target.value)} style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1', boxSizing: 'border-box' }} autoFocus placeholder="Enter new value (leave empty to clear)" />
              )}
            </div>
          )}
          <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
            <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn-primary" disabled={!field}>Apply</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const TemplateLinks = () => {
  const { showToast } = useToast();
  const [templateLinks, setTemplateLinks] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounce(searchTerm, 300);
  const [showDuplicateTemplateIdsOnly, setShowDuplicateTemplateIdsOnly] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [editingTemplateLink, setEditingTemplateLink] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [selectedRows, setSelectedRows] = useState(new Set());
  const [showBulkUpdate, setShowBulkUpdate] = useState(false);
  const undoRef = useRef(null);
  const [canUndo, setCanUndo] = useState(false);
  const [importPreview, setImportPreview] = useState(null);
  const fileInputRef = useRef(null);

  const duplicateTemplateIdSet = useMemo(() => {
    const counts = new Map();
    for (const row of templateLinks) {
      for (const id of splitMultiValue(row?.templateId)) {
        const k = id.toLowerCase();
        counts.set(k, (counts.get(k) || 0) + 1);
      }
    }
    return new Set(
      Array.from(counts.entries())
        .filter(([, count]) => count > 1)
        .map(([id]) => id)
    );
  }, [templateLinks]);

  const duplicateTemplateIdsByRow = useMemo(() => {
    const byRow = new Map();
    for (const row of templateLinks) {
      const dupes = splitMultiValue(row?.templateId).filter((id) => duplicateTemplateIdSet.has(id.toLowerCase()));
      if (dupes.length) byRow.set(row.id, dupes);
    }
    return byRow;
  }, [templateLinks, duplicateTemplateIdSet]);

  const filteredTemplateLinks = useMemo(() => {
    if (!debouncedSearchTerm.trim()) return templateLinks;
    const term = debouncedSearchTerm.trim().toLowerCase();
    return templateLinks.filter((row) =>
      Object.values(row).some((v) => v && String(v).toLowerCase().includes(term))
    );
  }, [templateLinks, debouncedSearchTerm]);
  const duplicateFilteredTemplateLinks = useMemo(() => {
    if (!showDuplicateTemplateIdsOnly) return filteredTemplateLinks;
    return filteredTemplateLinks.filter((row) => duplicateTemplateIdsByRow.has(row.id));
  }, [filteredTemplateLinks, showDuplicateTemplateIdsOnly, duplicateTemplateIdsByRow]);
  const linkableTemplateRows = useMemo(
    () => duplicateFilteredTemplateLinks.filter((row) => canonicalUserRecordType(row) === 'Linkable Template'),
    [duplicateFilteredTemplateLinks]
  );
  const subtemplateRows = useMemo(
    () => duplicateFilteredTemplateLinks.filter((row) => canonicalUserRecordType(row) === 'Subtemplate'),
    [duplicateFilteredTemplateLinks]
  );

  const [sortConfigLinkable, setSortConfigLinkable] = useState({ key: null, direction: 'asc' });
  const [sortConfigSub, setSortConfigSub] = useState({ key: null, direction: 'asc' });
  const handleSortLinkable = useCallback((key) => {
    setSortConfigLinkable((prev) => nextSortState(prev, key));
  }, []);
  const handleSortSub = useCallback((key) => {
    setSortConfigSub((prev) => nextSortState(prev, key));
  }, []);
  const sortedLinkableRows = useMemo(
    () => sortRowsByKey(linkableTemplateRows, sortConfigLinkable.key, sortConfigLinkable.direction),
    [linkableTemplateRows, sortConfigLinkable.key, sortConfigLinkable.direction]
  );
  const sortedSubRows = useMemo(
    () => sortRowsByKey(subtemplateRows, sortConfigSub.key, sortConfigSub.direction),
    [subtemplateRows, sortConfigSub.key, sortConfigSub.direction]
  );

  useEffect(() => {
    loadTemplateLinks();
  }, []);

  const loadTemplateLinks = async () => {
    const loaded = await getTemplateLinks();
    setTemplateLinks((loaded || []).map((r) => normalizeTemplateLinkRow({ ...r })));
  };

  const ensureSaved = async (rows) => {
    const ok = await saveTemplateLinks(rows);
    if (!ok) {
      throw new Error('Save failed. Please restart the server and try again.');
    }
  };

  const snapshotForUndo = useCallback((description) => {
    undoRef.current = { data: [...templateLinks], description };
    setCanUndo(true);
  }, [templateLinks]);

  const handleUndo = async () => {
    if (!undoRef.current) return;
    const { data: prevData, description } = undoRef.current;
    if (!window.confirm(`Undo "${description}"?`)) return;
    setTemplateLinks(prevData);
    try {
      await ensureSaved(prevData);
      undoRef.current = null;
      setCanUndo(false);
      loadTemplateLinks();
      showToast(`Undone: ${description}`);
    } catch (err) {
      alert(err?.message || 'Undo failed.');
    }
  };

  const handleRowSelect = (id) => {
    setSelectedRows((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const handleDeleteSelected = async () => {
    if (selectedRows.size === 0) return;
    if (!window.confirm(`Delete ${selectedRows.size} selected template link(s)?`)) return;
    snapshotForUndo(`Bulk delete ${selectedRows.size} template link(s)`);
    const updated = templateLinks.filter((r) => !selectedRows.has(r.id));
    try {
      await ensureSaved(updated);
      for (const r of templateLinks) {
        if (selectedRows.has(r.id)) await addTemplateLinkAuditLog('DELETE', r, r);
      }
      const count = selectedRows.size;
      setSelectedRows(new Set());
      loadTemplateLinks();
      showToast(`Deleted ${count} template link(s).`);
    } catch (err) {
      alert(err?.message || 'Delete failed.');
    }
  };

  const handleDeleteDuplicateIds = async () => {
    if (!duplicateTemplateIdSet.size) {
      showToast('No duplicate Template ID(s) found.');
      return;
    }
    if (
      !window.confirm(
        `Remove duplicate Template ID(s) and keep only the first occurrence of each ID?\n\nDuplicate IDs found: ${duplicateTemplateIdSet.size}`
      )
    ) {
      return;
    }
    const baseRows = await getTemplateLinks();
    const normalizedRows = (baseRows || []).map((r) => normalizeTemplateLinkRow({ ...r }));
    const { updatedRows, removedCount, changedCount } = removeDuplicateTemplateIdsKeepingFirst(normalizedRows);
    if (!removedCount) {
      showToast('No duplicate Template ID(s) found.');
      return;
    }
    snapshotForUndo(`Delete duplicate template IDs (${removedCount})`);
    try {
      await ensureSaved(updatedRows);
      const prevById = new Map(normalizedRows.map((r) => [r.id, r]));
      for (const row of updatedRows) {
        const prev = prevById.get(row.id);
        if (!prev) continue;
        if (String(prev.templateId || '') !== String(row.templateId || '')) {
          await addTemplateLinkAuditLog('UPDATE', row, prev);
        }
      }
      setSelectedRows(new Set());
      loadTemplateLinks();
      showToast(`Removed ${removedCount} duplicate ID token(s) across ${changedCount} row(s).`);
    } catch (err) {
      alert(err?.message || 'Failed to delete duplicate Template IDs.');
    }
  };

  const handleBulkUpdate = async (field, value) => {
    if (selectedRows.size === 0) return;
    const prevData = templateLinks;
    const updated = templateLinks.map((r) => {
      if (!selectedRows.has(r.id)) return r;
      return normalizeTemplateLinkRow({ ...r, [field]: value });
    });
    const resolvedRows = resolveDuplicateTemplateIdsWithPrompt(updated);
    if (!resolvedRows) return;
    snapshotForUndo(`Bulk update ${selectedRows.size} template link(s) → ${field}`);
    try {
      await ensureSaved(resolvedRows);
      for (const r of resolvedRows) {
        if (selectedRows.has(r.id)) {
          const old = prevData.find((o) => o.id === r.id);
          if (old) await addTemplateLinkAuditLog('UPDATE', r, old);
        }
      }
      const count = selectedRows.size;
      setSelectedRows(new Set());
      loadTemplateLinks();
      showToast(`Updated ${count} template link(s).`);
    } catch (err) {
      alert(err?.message || 'Update failed.');
    }
    setShowBulkUpdate(false);
  };

  const [createFormDefaults, setCreateFormDefaults] = useState(null);

  const handleAdd = (userRecordType = 'Linkable Template') => {
    setEditingTemplateLink(null);
    setCreateFormDefaults({ userRecordType });
    setShowForm(true);
  };

  const handleEdit = (templateLink) => {
    setCreateFormDefaults(null);
    setEditingTemplateLink(templateLink);
    setShowForm(true);
  };

  const handleDelete = async (templateLink) => {
    if (window.confirm('Are you sure you want to delete this template link?')) {
      try {
        snapshotForUndo(`Delete template link ${templateLink.templateName || templateLink.id}`);
        const allRows = await getTemplateLinks();
        const updated = allRows.filter((row) => row.id !== templateLink.id);
        setTemplateLinks(updated);
        await ensureSaved(updated);
        await addTemplateLinkAuditLog('DELETE', templateLink, templateLink);
        showToast('Template link deleted.');
        loadTemplateLinks();
      } catch (err) {
        alert(err?.message || 'Delete failed.');
      }
    }
  };

  const handleFormSubmit = async (rowData) => {
    try {
      const allRows = await getTemplateLinks();
      const normalizedRowData = normalizeTemplateLinkRow(rowData);

      if (editingTemplateLink) {
        const oldData = { ...editingTemplateLink };
        const updatedRows = allRows.map((row) =>
          row.id === editingTemplateLink.id
            ? { ...normalizedRowData, id: editingTemplateLink.id }
            : normalizeTemplateLinkRow({ ...row })
        );
        const resolvedRows = resolveDuplicateTemplateIdsWithPrompt(updatedRows);
        if (!resolvedRows) return;
        snapshotForUndo(`Edit template link ${editingTemplateLink.templateName || editingTemplateLink.id}`);
        setTemplateLinks(resolvedRows);
        await ensureSaved(resolvedRows);
        const savedRow = resolvedRows.find((row) => row.id === editingTemplateLink.id) || { ...normalizedRowData, id: editingTemplateLink.id };
        await addTemplateLinkAuditLog('UPDATE', savedRow, oldData);
        showToast('Template link updated.');
      } else {
        const newRow = { ...normalizedRowData, id: generateId() };
        const updatedRows = [...allRows.map((row) => normalizeTemplateLinkRow({ ...row })), newRow];
        const resolvedRows = resolveDuplicateTemplateIdsWithPrompt(updatedRows);
        if (!resolvedRows) return;
        snapshotForUndo('Create new template link');
        setTemplateLinks(resolvedRows);
        await ensureSaved(resolvedRows);
        const savedRow = resolvedRows.find((row) => row.id === newRow.id) || newRow;
        await addTemplateLinkAuditLog('CREATE', savedRow);
        showToast('Template link created.');
      }
      setShowForm(false);
      setEditingTemplateLink(null);
      setCreateFormDefaults(null);
      loadTemplateLinks();
    } catch (err) {
      alert(err?.message || 'Save failed.');
    }
  };

  const handleExport = () => {
    const fieldToHeaderMap = {
      userRecordType: 'User Record Type',
      templateId: 'Template ID(s)',
      templateName: 'Template Name(s)',
      primaryTemplateOwner: 'Primary Template Owner',
      templateDisplayTitle: 'Template Display Title',
      subtemplateId: 'Subtemplate ID(s)',
      subtemplateName: 'Subtemplate Description',
      currentStatus: 'User Record Status'
    };
    const fieldNames = Object.keys(fieldToHeaderMap);
    const csvHeaders = Object.values(fieldToHeaderMap);
    const exportData = templateLinks.map((row) => {
      const out = {};
      fieldNames.forEach((f) => { out[fieldToHeaderMap[f]] = row[f] || ''; });
      return out;
    });
    exportToCSV(exportData, 'template_links.csv', csvHeaders);
    showToast(`Exported ${exportData.length} template link(s)`);
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const runImport = (importedData) => {
    const rawData = Array.isArray(importedData) ? importedData : (importedData && importedData[0] !== undefined ? [importedData] : []);
    const mappedData = processImportedData(rawData);
    if (!mappedData.length) {
      setIsImporting(false);
      alert('No valid template links found. Each row needs at least Template Name(s), Template Display Title, Primary Template Owner, Subtemplate ID, or Subtemplate Description.');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }
    const commitImport = async (importMode = 'merge') => {
      const shouldReplace = importMode === 'replace';
      try {
        const quality = analyzeImportDataQuality(mappedData);
        if (!window.confirm(importQualityConfirmationMessage(quality, importMode))) return;
        let finalData;
        if (shouldReplace) {
          finalData = mappedData.map((row) => ({ ...row, id: generateId() }));
          const resolvedRows = resolveDuplicateTemplateIdsWithPrompt(finalData);
          if (!resolvedRows) return;
          snapshotForUndo(`Import ${mappedData.length} template link(s)`);
          const auditEntries = finalData.map((row) => ({ entityType: 'TEMPLATE_LINK', action: 'CREATE', entityData: row }));
          await ensureSaved(resolvedRows);
          await addAuditLogsBatch(auditEntries);
        } else {
          const allRows = await getTemplateLinks();
          const existingByKey = {};
          allRows.forEach((row) => {
            const key = mergeKeyForTemplateLink(row);
            if (key.replace(/\|/g, '') !== '') existingByKey[key] = row;
          });
          const auditEntries = [];
          const newRows = [];
          mappedData.forEach((row) => {
            const key = mergeKeyForTemplateLink(row);
            if (key.replace(/\|/g, '') !== '' && existingByKey[key]) {
              const prev = { ...existingByKey[key] };
              Object.assign(existingByKey[key], { ...row, id: existingByKey[key].id });
              auditEntries.push({ entityType: 'TEMPLATE_LINK', action: 'UPDATE', entityData: existingByKey[key], previousData: prev });
            } else {
              const newRow = { ...row, id: generateId() };
              newRows.push(newRow);
              auditEntries.push({ entityType: 'TEMPLATE_LINK', action: 'CREATE', entityData: newRow });
            }
          });
          finalData = [...allRows, ...newRows];
          const resolvedRows = resolveDuplicateTemplateIdsWithPrompt(finalData);
          if (!resolvedRows) return;
          snapshotForUndo(`Import ${mappedData.length} template link(s)`);
          await ensureSaved(resolvedRows);
          await addAuditLogsBatch(auditEntries);
        }
        loadTemplateLinks();
        showToast(`Successfully imported ${mappedData.length} template link(s)!`);
      } catch (err) {
        alert(err?.message || 'Import failed while saving.');
      } finally {
        setIsImporting(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };

    (async () => {
      const existing = await getTemplateLinks();
      setImportPreview({
        rows: mappedData,
        columns: ['userRecordType', 'templateId', 'templateName', 'subtemplateId', 'subtemplateName', 'currentStatus'],
        existingData: existing,
        matchKey: 'templateId',
        onConfirm: commitImport,
      });
    })();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const name = (file.name || '').toLowerCase();
    const isCsv = name.endsWith('.csv');
    const isExcel = name.endsWith('.xlsx') || name.endsWith('.xls');
    if (!isCsv && !isExcel) {
      alert('Please select a CSV or Excel file (.csv, .xlsx, .xls)');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }
    const onError = (error) => {
      setIsImporting(false);
      alert(`Import failed: ${error}`);
      if (fileInputRef.current) fileInputRef.current.value = '';
    };
    setIsImporting(true);
    if (isCsv) {
      readTemplateLinksCSV(file, (data) => runImport(data), onError);
    } else {
      importFromExcel(file, (data) => runImport(data), onError);
    }
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingTemplateLink(null);
    setCreateFormDefaults(null);
  };

  if (showForm) {
    return (
      <TemplateLinkForm
        templateLink={editingTemplateLink}
        createFormDefaults={createFormDefaults}
        allTemplateLinks={templateLinks}
        onSubmit={handleFormSubmit}
        onCancel={handleCancel}
      />
    );
  }

  const renderSection = (sectionId, title, rows, emptyMessage, addLabel, addUserRecordType, sectionVariant, sortConfig, onSort) => {
    const isSubtemplateTable = sectionVariant === 'subtemplate';
    return (
      <section className="template-links-section" aria-labelledby={sectionId}>
        <div className="template-links-section-head">
          <h3 id={sectionId}>
            {title}{' '}
            <span className="template-links-count">({rows.length})</span>
          </h3>
          <button type="button" className="btn-add btn-add-section" onClick={() => handleAdd(addUserRecordType)}>
            {addLabel}
          </button>
        </div>
        <div className="table-container template-links-section-table">
          {rows.length === 0 ? (
            <div className="empty-state" role="status">
              <p className="empty-state-message">{emptyMessage}</p>
            </div>
          ) : (
            <table className="template-links-table">
              <thead>
                <tr>
                  <th style={{ width: 36, textAlign: 'center' }}><input type="checkbox" checked={rows.length > 0 && rows.every((row) => selectedRows.has(row.id))} onChange={() => {
                    const allSelected = rows.length > 0 && rows.every((row) => selectedRows.has(row.id));
                    setSelectedRows((prev) => {
                      const next = new Set(prev);
                      if (allSelected) rows.forEach((r) => next.delete(r.id));
                      else rows.forEach((r) => next.add(r.id));
                      return next;
                    });
                  }} title="Select rows in this section" /></th>
                  {isSubtemplateTable ? (
                    <>
                      <SortableTh columnKey="templateId" sortConfig={sortConfig} onSort={onSort} title="Stored as Template ID(s)">Subtemplate ID</SortableTh>
                      <SortableTh columnKey="templateName" sortConfig={sortConfig} onSort={onSort} title="Stored as Template Name(s)">Subtemplate Description</SortableTh>
                      <SortableTh columnKey="userRecordType" sortConfig={sortConfig} onSort={onSort}>User Record Type</SortableTh>
                      <SortableTh columnKey="currentStatus" sortConfig={sortConfig} onSort={onSort}>User Record Status</SortableTh>
                      <SortableTh columnKey="primaryTemplateOwner" sortConfig={sortConfig} onSort={onSort}>Primary Template Owner</SortableTh>
                      <SortableTh columnKey="templateDisplayTitle" sortConfig={sortConfig} onSort={onSort}>Template Display Title</SortableTh>
                    </>
                  ) : (
                    <>
                      <SortableTh
                        columnKey="templateId"
                        sortConfig={sortConfig}
                        onSort={onSort}
                        title="Same values as RBAC role field Linked Role Template ID"
                      >
                        Template ID(s)
                      </SortableTh>
                      <SortableTh
                        columnKey="templateName"
                        sortConfig={sortConfig}
                        onSort={onSort}
                        title="Same values as RBAC role field Linked Role Template Name"
                      >
                        Template Name(s)
                      </SortableTh>
                      <SortableTh columnKey="primaryTemplateOwner" sortConfig={sortConfig} onSort={onSort}>Primary Template Owner</SortableTh>
                      <SortableTh
                        columnKey="templateDisplayTitle"
                        sortConfig={sortConfig}
                        onSort={onSort}
                        title="Same values as RBAC role field Template Display Title"
                      >
                        Template Display Title
                      </SortableTh>
                      <SortableTh columnKey="currentStatus" sortConfig={sortConfig} onSort={onSort}>User Record Status</SortableTh>
                    </>
                  )}
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row) => (
                  <tr key={row.id}>
                    <td style={{ textAlign: 'center' }}><input type="checkbox" checked={selectedRows.has(row.id)} onChange={() => handleRowSelect(row.id)} /></td>
                    {isSubtemplateTable ? (
                      <>
                        <td
                          className={`text-cell${duplicateTemplateIdsByRow.has(row.id) ? ' template-id-duplicate-cell' : ''}`}
                          title={duplicateTemplateIdsByRow.has(row.id) ? `Duplicate ID(s): ${duplicateTemplateIdsByRow.get(row.id).join(', ')}` : undefined}
                        >
                          {sanitizeCellText(row.templateId)}
                        </td>
                        <td className="text-cell">{sanitizeCellText(row.templateName)}</td>
                        <td className="text-cell">{sanitizeCellText(row.userRecordType || canonicalUserRecordType(row))}</td>
                        <td className="text-cell">{sanitizeCellText(row.currentStatus)}</td>
                        <td className="text-cell">{sanitizeCellText(row.primaryTemplateOwner)}</td>
                        <td className="text-cell">{sanitizeCellText(row.templateDisplayTitle)}</td>
                      </>
                    ) : (
                      <>
                        <td
                          className={`text-cell${duplicateTemplateIdsByRow.has(row.id) ? ' template-id-duplicate-cell' : ''}`}
                          title={duplicateTemplateIdsByRow.has(row.id) ? `Duplicate ID(s): ${duplicateTemplateIdsByRow.get(row.id).join(', ')}` : undefined}
                        >
                          {sanitizeCellText(row.templateId)}
                        </td>
                        <td className="text-cell">{sanitizeCellText(row.templateName)}</td>
                        <td className="text-cell">{sanitizeCellText(row.primaryTemplateOwner)}</td>
                        <td className="text-cell">{sanitizeCellText(row.templateDisplayTitle)}</td>
                        <td>{sanitizeCellText(row.currentStatus)}</td>
                      </>
                    )}
                    <td>
                      <button className="btn-edit" type="button" onClick={() => handleEdit(row)}>Edit</button>
                      <button className="btn-delete" type="button" onClick={() => handleDelete(row)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </section>
    );
  };

  return (
    <div className="template-links">
      <div className="template-links-header">
        <h2>Templates/Subtemplates</h2>
        <div className="actions">
          <div className="search-container">
            <input
              type="text"
              className="search-input"
              placeholder="Search templates/subtemplates..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              aria-label="Search templates and subtemplates"
            />
            <label className="template-links-dup-toggle">
              <input
                type="checkbox"
                checked={showDuplicateTemplateIdsOnly}
                onChange={(e) => setShowDuplicateTemplateIdsOnly(e.target.checked)}
              />
              Duplicates only
              <span className="template-links-dup-count">
                ({duplicateTemplateIdSet.size} duplicate ID{duplicateTemplateIdSet.size === 1 ? '' : 's'})
              </span>
            </label>
          </div>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".csv,.xlsx,.xls"
            style={{ display: 'none' }}
          />
          <button className="btn-import" onClick={handleImportClick} title="Import template links from CSV or Excel" disabled={isImporting}>
            {isImporting ? 'Importing…' : 'Import from CSV or Excel'}
          </button>
          {isImporting && <span className="import-status" role="status">Importing…</span>}
          <button className="btn-export" onClick={handleExport} title="Download template links as CSV">
            Export to CSV
          </button>
          <button className="btn-add" type="button" onClick={() => handleAdd('Linkable Template')} title="Add a Linkable Template row">
            Add Linkable Template
          </button>
          <button className="btn-add" type="button" onClick={() => handleAdd('Subtemplate')} title="Add a Subtemplate row">
            Add Subtemplate
          </button>
          {canUndo && (
            <button type="button" className="btn-secondary btn-undo" onClick={handleUndo} title={undoRef.current ? `Undo: ${undoRef.current.description}` : 'Undo'}>Undo</button>
          )}
          <button type="button" className="btn-secondary" onClick={() => { if (selectedRows.size === 0) { alert('Select rows first.'); return; } setShowBulkUpdate(true); }} disabled={selectedRows.size === 0}>Bulk Update ({selectedRows.size})</button>
          <button
            type="button"
            className="btn-secondary"
            onClick={handleDeleteDuplicateIds}
            disabled={!duplicateTemplateIdSet.size}
            title="Remove repeated Template ID tokens and keep first occurrence"
          >
            Delete duplicate IDs
          </button>
          <button type="button" className="btn-secondary btn-danger-outline" onClick={handleDeleteSelected} disabled={selectedRows.size === 0}>Bulk Delete ({selectedRows.size})</button>
        </div>
      </div>

      {templateLinks.length === 0 ? (
        <div className="table-container">
          <div className="empty-state" role="status">
            <p className="empty-state-message">No template links yet</p>
            <p className="empty-state-hint">Add Linkable Template or Subtemplate rows, or import from CSV/Excel.</p>
            <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap', justifyContent: 'center' }}>
              <button type="button" className="btn-add" onClick={() => handleAdd('Linkable Template')}>Add Linkable Template</button>
              <button type="button" className="btn-add" onClick={() => handleAdd('Subtemplate')}>Add Subtemplate</button>
            </div>
          </div>
        </div>
      ) : (
        <div className="template-links-split">
          {renderSection('tl-linkable-heading', 'Linkable Templates', sortedLinkableRows, 'No Linkable Template rows in this list (check import includes User Record Type, or add rows).', 'Add Linkable Template', 'Linkable Template', 'linkable', sortConfigLinkable, handleSortLinkable)}
          {renderSection('tl-sub-heading', 'Subtemplates', sortedSubRows, 'No Subtemplate rows in this list (check import includes User Record Type = Subtemplate, or add rows).', 'Add Subtemplate', 'Subtemplate', 'subtemplate', sortConfigSub, handleSortSub)}
        </div>
      )}
      {showBulkUpdate && (
        <TlBulkUpdateDialog selectedCount={selectedRows.size} onApply={handleBulkUpdate} onClose={() => setShowBulkUpdate(false)} />
      )}
      {importPreview && (
        <ImportPreviewDialog
          rows={importPreview.rows}
          columns={importPreview.columns}
          existingData={importPreview.existingData}
          matchKey={importPreview.matchKey}
          onConfirm={(mode) => { setImportPreview(null); importPreview.onConfirm(mode); }}
          onCancel={() => { setImportPreview(null); setIsImporting(false); if (fileInputRef.current) fileInputRef.current.value = ''; }}
          enableImportMode
          defaultImportMode="merge"
        />
      )}
    </div>
  );
};

export default TemplateLinks;
