import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useDebounce } from '../utils/useDebounce';
import { getDepartments, saveDepartments, addDepartmentAuditLog, addAuditLogsBatch, generateId } from '../utils/storage';
import { exportToCSV } from '../utils/csvExport';
import { importFromCSV } from '../utils/csvImport';
import { importFromExcel } from '../utils/excelImport';
import { sanitizeCellText } from '../utils/textSanitize';
import DepartmentForm from './DepartmentForm';
import ImportPreviewDialog from './ImportPreviewDialog';
import { useToast } from '../context/ToastContext';
import SortableTh from './SortableTh';
import { sortRowsByKey, nextSortState } from '../utils/tableSort';
import './Departments.css';

const DEPT_BULK_FIELDS = [
  { key: 'deptId', label: 'Dept ID' },
  { key: 'deptDescription', label: 'Dept Description' },
];

const DeptBulkUpdateDialog = ({ selectedCount, onApply, onClose }) => {
  const [field, setField] = useState('');
  const [value, setValue] = useState('');
  const fieldDef = DEPT_BULK_FIELDS.find((f) => f.key === field);
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!field) { alert('Please select a field.'); return; }
    if (!window.confirm(`Set "${fieldDef?.label || field}" to "${value}" on ${selectedCount} department(s)?`)) return;
    onApply(field, value);
  };
  return (
    <div className="find-replace-overlay" onClick={onClose}>
      <div className="find-replace-dialog" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 420 }}>
        <div className="find-replace-header">
          <h3>Bulk Update ({selectedCount} selected)</h3>
          <button type="button" className="find-replace-close" onClick={onClose}>&times;</button>
        </div>
        <form onSubmit={handleSubmit} style={{ padding: '1rem 1.25rem' }}>
          <div style={{ marginBottom: '0.75rem' }}>
            <label style={{ display: 'block', marginBottom: '0.25rem', fontWeight: 500, fontSize: '0.9rem' }}>Field</label>
            <select value={field} onChange={(e) => { setField(e.target.value); setValue(''); }} style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1' }}>
              <option value="">Select field...</option>
              {DEPT_BULK_FIELDS.map((f) => <option key={f.key} value={f.key}>{f.label}</option>)}
            </select>
          </div>
          {field && (
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', marginBottom: '0.25rem', fontWeight: 500, fontSize: '0.9rem' }}>New Value</label>
              <input type="text" value={value} onChange={(e) => setValue(e.target.value)} style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1', boxSizing: 'border-box' }} autoFocus placeholder="Enter new value (leave empty to clear)" />
            </div>
          )}
          <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
            <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn-primary" disabled={!field}>Apply</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const Departments = () => {
  const { showToast } = useToast();
  const [departments, setDepartments] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounce(searchTerm, 300);
  const [isImporting, setIsImporting] = useState(false);
  const [editingDepartment, setEditingDepartment] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [selectedRows, setSelectedRows] = useState(new Set());
  const [showBulkUpdate, setShowBulkUpdate] = useState(false);
  const undoRef = useRef(null);
  const [canUndo, setCanUndo] = useState(false);
  const [importPreview, setImportPreview] = useState(null);
  const fileInputRef = useRef(null);

  const filteredDepartments = useMemo(() => {
    if (!debouncedSearchTerm.trim()) return departments;
    const term = debouncedSearchTerm.trim().toLowerCase();
    return departments.filter((d) =>
      Object.values(d).some((v) => v && String(v).toLowerCase().includes(term))
    );
  }, [departments, debouncedSearchTerm]);

  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  const handleSort = useCallback((key) => {
    setSortConfig((prev) => nextSortState(prev, key));
  }, []);
  const displayDepartments = useMemo(
    () => sortRowsByKey(filteredDepartments, sortConfig.key, sortConfig.direction),
    [filteredDepartments, sortConfig.key, sortConfig.direction]
  );

  useEffect(() => {
    loadDepartments();
  }, []);

  const loadDepartments = async () => {
    const loadedDepartments = await getDepartments();
    setDepartments(loadedDepartments);
  };

  const snapshotForUndo = useCallback((description) => {
    undoRef.current = { data: [...departments], description };
    setCanUndo(true);
  }, [departments]);

  const handleUndo = async () => {
    if (!undoRef.current) return;
    const { data: prevData, description } = undoRef.current;
    if (!window.confirm(`Undo "${description}"?`)) return;
    setDepartments(prevData);
    try {
      await saveDepartments(prevData);
      undoRef.current = null;
      setCanUndo(false);
      loadDepartments();
      showToast(`Undone: ${description}`);
    } catch (err) {
      alert(err?.message || 'Undo failed.');
    }
  };

  const handleRowSelect = (id) => {
    setSelectedRows((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const allVisibleSelected = displayDepartments.length > 0 && displayDepartments.every((d) => selectedRows.has(d.id));

  const handleSelectAll = () => {
    if (allVisibleSelected) {
      setSelectedRows((prev) => {
        const next = new Set(prev);
        displayDepartments.forEach((d) => next.delete(d.id));
        return next;
      });
    } else {
      setSelectedRows((prev) => {
        const next = new Set(prev);
        displayDepartments.forEach((d) => next.add(d.id));
        return next;
      });
    }
  };

  const handleDeleteSelected = async () => {
    if (selectedRows.size === 0) return;
    if (!window.confirm(`Delete ${selectedRows.size} selected department(s)?`)) return;
    snapshotForUndo(`Bulk delete ${selectedRows.size} department(s)`);
    const updated = departments.filter((d) => !selectedRows.has(d.id));
    setDepartments(updated);
    try {
      await saveDepartments(updated);
      for (const d of departments) {
        if (selectedRows.has(d.id)) await addDepartmentAuditLog('DELETE', d, d);
      }
      const count = selectedRows.size;
      setSelectedRows(new Set());
      loadDepartments();
      showToast(`Deleted ${count} department(s).`);
    } catch (err) {
      alert(err?.message || 'Delete failed.');
    }
  };

  const handleBulkUpdate = async (field, value) => {
    if (selectedRows.size === 0) return;
    snapshotForUndo(`Bulk update ${selectedRows.size} department(s) → ${field}`);
    const prevData = departments;
    const updated = departments.map((d) => {
      if (!selectedRows.has(d.id)) return d;
      return { ...d, [field]: value };
    });
    setDepartments(updated);
    try {
      await saveDepartments(updated);
      for (const d of updated) {
        if (selectedRows.has(d.id)) {
          const old = prevData.find((o) => o.id === d.id);
          if (old) await addDepartmentAuditLog('UPDATE', d, old);
        }
      }
      const count = selectedRows.size;
      setSelectedRows(new Set());
      loadDepartments();
      showToast(`Updated ${count} department(s).`);
    } catch (err) {
      alert(err?.message || 'Update failed.');
    }
    setShowBulkUpdate(false);
  };

  const handleAdd = () => {
    setEditingDepartment(null);
    setShowForm(true);
  };

  const handleEdit = (department) => {
    setEditingDepartment(department);
    setShowForm(true);
  };

  const handleDelete = async (department) => {
    if (window.confirm('Are you sure you want to delete this department?')) {
      snapshotForUndo(`Delete department ${department.deptId || department.id}`);
      const allDepartments = await getDepartments();
      const updatedDepartments = allDepartments.filter((d) => d.id !== department.id);
      setDepartments(updatedDepartments);
      await saveDepartments(updatedDepartments);
      await addDepartmentAuditLog('DELETE', department, department);
      loadDepartments();
    }
  };

  const handleFormSubmit = async (departmentData) => {
    const allDepartments = await getDepartments();

    if (editingDepartment) {
      snapshotForUndo(`Edit department ${editingDepartment.deptId || editingDepartment.id}`);
      const oldData = { ...editingDepartment };
      const updatedDepartments = allDepartments.map((d) =>
        d.id === editingDepartment.id ? { ...departmentData, id: editingDepartment.id } : d
      );
      setDepartments(updatedDepartments);
      await saveDepartments(updatedDepartments);
      await addDepartmentAuditLog('UPDATE', { ...departmentData, id: editingDepartment.id }, oldData);
    } else {
      snapshotForUndo('Create new department');
      const newDepartment = { ...departmentData, id: generateId() };
      const updatedDepartments = [...allDepartments, newDepartment];
      setDepartments(updatedDepartments);
      await saveDepartments(updatedDepartments);
      await addDepartmentAuditLog('CREATE', newDepartment);
    }
    setShowForm(false);
    setEditingDepartment(null);
    loadDepartments();
  };

  const handleExport = () => {
    const fieldToHeaderMap = {
      'deptId': 'Dept ID',
      'deptDescription': 'Dept Description'
    };

    const fieldNames = Object.keys(fieldToHeaderMap);
    const csvHeaders = Object.values(fieldToHeaderMap);

    const exportData = departments.map(department => {
      const row = {};
      fieldNames.forEach(fieldName => {
        row[fieldToHeaderMap[fieldName]] = department[fieldName] || '';
      });
      return row;
    });

    const count = exportData.length;
    if (count >= 500) {
      showToast('Preparing export…');
      setTimeout(() => {
        try {
          exportToCSV(exportData, 'departments.csv', csvHeaders);
          showToast(`Exported ${count} department(s)`);
        } catch (e) {
          showToast('Export failed');
        }
      }, 0);
    } else {
      exportToCSV(exportData, 'departments.csv', csvHeaders);
      showToast(`Exported ${count} department(s)`);
    }
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const name = (file.name || '').toLowerCase();
    const isCsv = name.endsWith('.csv');
    const isExcel = name.endsWith('.xlsx') || name.endsWith('.xls');
    if (!isCsv && !isExcel) {
      alert('Please select a CSV or Excel file (.csv, .xlsx, .xls)');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    const headerMap = {
      'Dept ID': 'deptId', 'deptId': 'deptId',
      'Dept Description': 'deptDescription', 'deptDescription': 'deptDescription'
    };

    const runImport = (importedData) => {
      const rawData = Array.isArray(importedData) ? importedData : [];
      const mappedData = rawData.map((row) => {        const mapped = {};
        Object.keys(row).forEach((csvHeader) => {
          const normalizedHeader = String(csvHeader).trim();
          const match = Object.keys(headerMap).find(
            key => key.toLowerCase() === normalizedHeader.toLowerCase()
          );
          const internalKey = match ? headerMap[match] : normalizedHeader;
          let value = row[csvHeader] || '';
          mapped[internalKey] = String(value).replace(/\s+/g, ' ').trim();
        });
        return mapped;
      });

      if (!mappedData.length) {
        setIsImporting(false);
        alert('No valid data rows found.');
        if (fileInputRef.current) fileInputRef.current.value = '';
        return;
      }

      const commitImport = async (importMode = 'merge') => {
        const shouldReplace = importMode === 'replace';
        snapshotForUndo(`Import ${mappedData.length} department(s)`);
        try {
          let finalData;
          if (shouldReplace) {
            finalData = mappedData.map(row => ({ ...row, id: generateId() }));
            const auditEntries = finalData.map((dept) => ({
              entityType: 'DEPARTMENT',
              action: 'CREATE',
              entityData: dept,
            }));
            await Promise.all([addAuditLogsBatch(auditEntries), saveDepartments(finalData)]);
          } else {
            const allDepartments = await getDepartments();
            const existingByKey = {};
            allDepartments.forEach((d) => {
              const key = (d.deptId || '').trim().toLowerCase();
              if (key) existingByKey[key] = d;
            });
            const auditEntries = [];
            const newDepts = [];
            mappedData.forEach((row) => {
              const key = (row.deptId || '').trim().toLowerCase();
              if (key && existingByKey[key]) {
                const prev = { ...existingByKey[key] };
                Object.assign(existingByKey[key], { ...row, id: existingByKey[key].id });
                auditEntries.push({ entityType: 'DEPARTMENT', action: 'UPDATE', entityData: existingByKey[key], previousData: prev });
              } else {
                const newDept = { ...row, id: generateId() };
                newDepts.push(newDept);
                auditEntries.push({ entityType: 'DEPARTMENT', action: 'CREATE', entityData: newDept });
              }
            });
            finalData = [...allDepartments, ...newDepts];
            await Promise.all([addAuditLogsBatch(auditEntries), saveDepartments(finalData)]);
          }
          loadDepartments();
          showToast(`Successfully imported ${mappedData.length} department(s)!`);
        } finally {
          setIsImporting(false);
          if (fileInputRef.current) fileInputRef.current.value = '';
        }
      };

      (async () => {
        const existing = await getDepartments();
        setImportPreview({
          rows: mappedData,
          columns: ['deptId', 'deptDescription'],
          existingData: existing,
          matchKey: 'deptId',
          onConfirm: commitImport,
        });
      })();
    };

    const onError = (error) => {
      setIsImporting(false);
      alert(`Import failed: ${error}`);
      if (fileInputRef.current) fileInputRef.current.value = '';
    };

    setIsImporting(true);
    if (isCsv) {
      importFromCSV(file, runImport, onError);
    } else {
      importFromExcel(file, (data) => runImport(data), onError);
    }
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingDepartment(null);
  };

  if (showForm) {
    return (
      <DepartmentForm
        department={editingDepartment}
        onSubmit={handleFormSubmit}
        onCancel={handleCancel}
      />
    );
  }

  return (
    <div className="departments">
      <div className="departments-header">
        <h2>Departments</h2>
        <div className="actions">
          <div className="search-container">
            <input
              type="text"
              className="search-input"
              placeholder="Search departments..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              aria-label="Search departments"
            />
          </div>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".csv,.xlsx,.xls"
            style={{ display: 'none' }}
          />
          <button className="btn-import" onClick={handleImportClick} title="Import departments from CSV or Excel" disabled={isImporting}>
            {isImporting ? 'Importing…' : 'Import from CSV or Excel'}
          </button>
          {isImporting && <span className="import-status" role="status">Importing…</span>}
          <button className="btn-export" onClick={handleExport} title="Download departments as CSV">
            Export to CSV
          </button>
          <button className="btn-add" onClick={handleAdd} title="Create a new department">
            Add New Department
          </button>
          {canUndo && (
            <button type="button" className="btn-secondary btn-undo" onClick={handleUndo} title={undoRef.current ? `Undo: ${undoRef.current.description}` : 'Undo last action'}>Undo</button>
          )}
          <button type="button" className="btn-secondary" onClick={() => { if (selectedRows.size === 0) { alert('Select rows first.'); return; } setShowBulkUpdate(true); }} disabled={selectedRows.size === 0} title="Update a field on selected departments">Bulk Update ({selectedRows.size})</button>
          <button type="button" className="btn-secondary btn-danger-outline" onClick={handleDeleteSelected} disabled={selectedRows.size === 0} title="Delete selected departments">Bulk Delete ({selectedRows.size})</button>
        </div>
      </div>

      <div className="table-container">
        {departments.length === 0 ? (
          <div className="empty-state" role="status">
            <p className="empty-state-message">No departments yet</p>
            <p className="empty-state-hint">Add departments to use in roles, or import from CSV/Excel.</p>
            <button type="button" className="btn-add empty-state-cta" onClick={handleAdd}>
              Add New Department
            </button>
          </div>
        ) : (
        <table className="departments-table">
          <thead>
            <tr>
              <th style={{ width: 36, textAlign: 'center' }}><input type="checkbox" checked={allVisibleSelected} onChange={handleSelectAll} title="Select all" /></th>
              <SortableTh columnKey="deptId" sortConfig={sortConfig} onSort={handleSort}>Dept ID</SortableTh>
              <SortableTh columnKey="deptDescription" sortConfig={sortConfig} onSort={handleSort}>Dept Description</SortableTh>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {displayDepartments.map((department) => (
              <tr key={department.id}>
                <td style={{ textAlign: 'center' }} onClick={(e) => e.stopPropagation()}><input type="checkbox" checked={selectedRows.has(department.id)} onChange={() => handleRowSelect(department.id)} /></td>
                <td>{sanitizeCellText(department.deptId)}</td>
                <td className="text-cell">{sanitizeCellText(department.deptDescription)}</td>
                <td>
                  <button
                    className="btn-edit"
                    onClick={() => handleEdit(department)}
                  >
                    Edit
                  </button>
                  <button
                    className="btn-delete"
                    onClick={() => handleDelete(department)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        )}
      </div>
      {showBulkUpdate && (
        <DeptBulkUpdateDialog
          selectedCount={selectedRows.size}
          onApply={handleBulkUpdate}
          onClose={() => setShowBulkUpdate(false)}
        />
      )}
      {importPreview && (
        <ImportPreviewDialog
          rows={importPreview.rows}
          columns={importPreview.columns}
          existingData={importPreview.existingData}
          matchKey={importPreview.matchKey}
          onConfirm={(mode) => { setImportPreview(null); importPreview.onConfirm(mode); }}
          onCancel={() => { setImportPreview(null); setIsImporting(false); if (fileInputRef.current) fileInputRef.current.value = ''; }}
          enableImportMode
          defaultImportMode="merge"
        />
      )}
    </div>
  );
};

export default Departments;
