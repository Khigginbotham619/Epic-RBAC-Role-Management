import React, { useState, useEffect, useMemo, useCallback, useDeferredValue } from 'react';
import {
  getJobCategories,
  saveJobCategories,
  getSailpointRoles,
  getTemplateLinks,
  getCurrentAuditUser,
  addJobCategoryAuditLog,
} from '../utils/storage';
import {
  suggestSailpointRolesForJobCategory,
  categoryNameForSailpointMatch,
  preparseTemplateLinkRows,
} from '../utils/sailpointCategorySuggestions';
import { isJobCategoryExcludedFromOrgScope, JOB_CATEGORY_SCOPE_NOT_IN_ORG } from '../utils/jobCategoryScope';
import { useToast } from '../context/ToastContext';
import SortableTh from './SortableTh';
import { sortRowsByKey, nextSortState } from '../utils/tableSort';
import './FindSailpointMatches.css';

const REJECTED_IDS_STORAGE_KEY = 'epicFindSailpointMatchRejectedCategoryIds';

function loadRejectedCategoryIds() {
  try {
    const raw = localStorage.getItem(REJECTED_IDS_STORAGE_KEY);
    if (!raw) return new Set();
    const arr = JSON.parse(raw);
    if (!Array.isArray(arr)) return new Set();
    return new Set(arr.filter((id) => id != null && String(id).length > 0).map(String));
  } catch (_) {
    return new Set();
  }
}

function persistRejectedCategoryIds(set) {
  try {
    localStorage.setItem(REJECTED_IDS_STORAGE_KEY, JSON.stringify([...set]));
  } catch (_) {}
}

function templateContextLines(category) {
  const c = category || {};
  const ltId = String(c.linkableTemplateId || '').trim();
  const ltName = String(c.linkableTemplateName || '').trim();
  const stId = String(c.subtemplatesId || '').trim();
  const stName = String(c.subtemplatesName || '').trim();
  const linkLine =
    [ltId && `ID ${ltId}`, ltName || null].filter(Boolean).join(' · ') || '—';
  const subLine =
    [stId && `ID ${stId}`, stName || null].filter(Boolean).join(' · ') || '—';
  const linkTitle = [ltId && `ID: ${ltId}`, ltName && `Name: ${ltName}`].filter(Boolean).join('\n') || 'None';
  const subTitle = [stId && `ID: ${stId}`, stName && `Name: ${stName}`].filter(Boolean).join('\n') || 'None';
  return { linkLine, subLine, linkTitle, subTitle };
}

/** Lowercased haystack for row search; scope limits which fields participate (narrower = fewer false positives). */
function buildRowSearchHaystack(item, pickedByCategoryId, scope) {
  const c = item.category;
  const chosen = chosenSailpointRole(item, pickedByCategoryId);
  const roleTexts = (item.suggestions || []).map((s) => String(s.sailpointRole || ''));
  const parts = [];
  switch (scope) {
    case 'category':
      parts.push(c.jobCategoryId, c.jobCategoryName);
      break;
    case 'templates':
      parts.push(
        c.linkableTemplateId,
        c.linkableTemplateName,
        c.subtemplatesId,
        c.subtemplatesName
      );
      break;
    case 'roles':
      parts.push(item.proposed, chosen, c.sailpointRoleReview, ...roleTexts);
      break;
    case 'jsonKey':
      parts.push(categoryNameForSailpointMatch(c.jobCategoryName));
      break;
    case 'all':
    default:
      parts.push(
        c.jobCategoryId,
        c.jobCategoryName,
        c.linkableTemplateId,
        c.linkableTemplateName,
        c.subtemplatesId,
        c.subtemplatesName,
        item.proposed,
        chosen,
        c.sailpointRoleReview,
        categoryNameForSailpointMatch(c.jobCategoryName),
        ...roleTexts
      );
      break;
  }
  return parts.map((x) => String(x || '').toLowerCase()).join(' ');
}

function csvEscapeCell(val) {
  const s = String(val ?? '');
  if (/[",\r\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

function chosenSailpointRole(item, pickedByCategoryId) {
  const proposed = item.proposed || '';
  const id = String(item.category.id);
  const pick = pickedByCategoryId[id];
  if (!pick) return proposed;
  const names = (item.suggestions || []).map((s) => String(s.sailpointRole || '').trim()).filter(Boolean);
  return names.includes(pick) ? pick : proposed;
}

function stampLastEdit(cat) {
  const now = new Date();
  const dateTimeString = now.toLocaleString('en-US', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });
  return {
    ...cat,
    lastEditDateReasonInitials: `${dateTimeString} - ${getCurrentAuditUser()}`,
  };
}

const FindSailpointMatches = () => {
  const { showToast } = useToast();
  const [jobCategories, setJobCategories] = useState([]);
  const [sailpointRoles, setSailpointRoles] = useState([]);
  const [templateLinks, setTemplateLinks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [rejectedIds, setRejectedIds] = useState(() => loadRejectedCategoryIds());
  /** withMatch: at least one suggested Sailpoint role. noMatch: blank Sailpoint but scorer returned none. */
  const [matchFilterMode, setMatchFilterMode] = useState('withMatch');
  /** Inclusive bounds on suggestSailpointRolesForJobCategory result length (total count including best match). */
  const [minSuggestionCount, setMinSuggestionCount] = useState(1);
  const [maxSuggestionCount, setMaxSuggestionCount] = useState('');
  /** category id → Sailpoint role name to apply (must appear in that row's suggestions). */
  const [pickedSailpointRoleByCategoryId, setPickedSailpointRoleByCategoryId] = useState({});
  const [rowSearchText, setRowSearchText] = useState('');
  /** all | category | templates | roles | jsonKey */
  const [rowSearchScope, setRowSearchScope] = useState('all');
  /** If true, the whole search box (trimmed) must appear as one contiguous substring in the scoped haystack. */
  const [searchExactPhrase, setSearchExactPhrase] = useState(false);

  const reload = useCallback(async () => {
    const [cats, sp, tls] = await Promise.all([
      getJobCategories(),
      getSailpointRoles(),
      getTemplateLinks(),
    ]);
    setJobCategories(Array.isArray(cats) ? cats : []);
    setSailpointRoles(Array.isArray(sp) ? sp : []);
    setTemplateLinks(Array.isArray(tls) ? tls : []);
  }, []);

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        await reload();
      } finally {
        setLoading(false);
      }
    })();
  }, [reload]);

  const preparsedTemplateRows = useMemo(() => preparseTemplateLinkRows(templateLinks), [templateLinks]);

  const enrichedRows = useMemo(() => {
    return jobCategories.map((category) => {
      const blank = !(category.sailpointRole || '').trim();
      const isRejected = rejectedIds.has(String(category.id));
      const outOfOrgScope = isJobCategoryExcludedFromOrgScope(category);
      if (!blank || isRejected || outOfOrgScope) {
        return {
          category,
          suggestions: [],
          proposed: '',
          totalSuggestions: 0,
          alternateCount: 0,
        };
      }
      const suggestions = suggestSailpointRolesForJobCategory(
        category.jobCategoryName,
        sailpointRoles,
        {
          linkableTemplateId: category.linkableTemplateId,
          linkableTemplateName: category.linkableTemplateName,
          subtemplatesId: category.subtemplatesId,
          subtemplatesName: category.subtemplatesName,
        },
        templateLinks,
        preparsedTemplateRows
      );
      const best = suggestions[0] || null;
      const proposed = best ? String(best.sailpointRole || '').trim() : '';
      return {
        category,
        suggestions,
        proposed,
        totalSuggestions: suggestions.length,
        alternateCount: Math.max(0, suggestions.length - 1),
      };
    });
  }, [jobCategories, sailpointRoles, templateLinks, rejectedIds, preparsedTemplateRows]);

  useEffect(() => {
    setPickedSailpointRoleByCategoryId((prev) => {
      const next = { ...prev };
      let changed = false;
      const validIds = new Set(enrichedRows.map((r) => String(r.category.id)));
      for (const k of Object.keys(next)) {
        if (!validIds.has(k)) {
          delete next[k];
          changed = true;
        }
      }
      for (const row of enrichedRows) {
        const id = String(row.category.id);
        const pick = next[id];
        if (!pick) continue;
        const names = row.suggestions.map((s) => String(s.sailpointRole || '').trim()).filter(Boolean);
        if (!names.includes(pick)) {
          delete next[id];
          changed = true;
        }
      }
      return changed ? next : prev;
    });
  }, [enrichedRows]);

  const suggestionCountBounds = useMemo(() => {
    const minN = Math.max(1, parseInt(String(minSuggestionCount), 10) || 1);
    const maxRaw = String(maxSuggestionCount).trim();
    const maxParsed = maxRaw === '' ? null : parseInt(maxRaw, 10);
    const maxN =
      maxParsed == null || !Number.isFinite(maxParsed) ? null : Math.max(1, maxParsed);
    return { minN, maxN };
  }, [minSuggestionCount, maxSuggestionCount]);

  const blankSailpointStats = useMemo(() => {
    let withMatch = 0;
    let noMatch = 0;
    for (const row of enrichedRows) {
      const c = row.category;
      if ((c.sailpointRole || '').trim()) continue;
      if (rejectedIds.has(String(c.id))) continue;
      if (isJobCategoryExcludedFromOrgScope(c)) continue;
      if (row.proposed) withMatch += 1;
      else noMatch += 1;
    }
    return { withMatch, noMatch };
  }, [enrichedRows, rejectedIds]);

  const filteredRows = useMemo(() => {
    if (matchFilterMode === 'noMatch') {
      return enrichedRows.filter(({ category, proposed }) => {
        if ((category.sailpointRole || '').trim()) return false;
        if (rejectedIds.has(String(category.id))) return false;
        if (isJobCategoryExcludedFromOrgScope(category)) return false;
        return !proposed;
      });
    }
    const { minN, maxN } = suggestionCountBounds;
    return enrichedRows.filter(({ category, proposed, totalSuggestions }) => {
      if (!proposed) return false;
      if ((category.sailpointRole || '').trim()) return false;
      if (rejectedIds.has(String(category.id))) return false;
      if (isJobCategoryExcludedFromOrgScope(category)) return false;
      if (totalSuggestions < minN) return false;
      if (maxN != null && totalSuggestions > maxN) return false;
      return true;
    });
  }, [enrichedRows, rejectedIds, suggestionCountBounds, matchFilterMode]);

  const getCell = useCallback((item, key) => {
    const c = item.category;
    if (key === 'jobCategoryId') return c.jobCategoryId || '';
    if (key === 'jobCategoryName') return c.jobCategoryName || '';
    if (key === 'current') return (c.sailpointRole || '').trim();
    if (key === 'proposed') return item.proposed || '';
    if (key === 'alternates') return String(item.alternateCount ?? '');
    if (key === 'totalSuggestions') return String(item.totalSuggestions ?? '');
    if (key === 'sailpointRoleReview') return (c.sailpointRoleReview || '').trim();
    return '';
  }, []);

  const [sortConfig, setSortConfig] = useState({ key: 'jobCategoryName', direction: 'asc' });
  const handleSort = useCallback((key) => {
    setSortConfig((prev) => nextSortState(prev, key));
  }, []);
  const sortedRows = useMemo(
    () => sortRowsByKey(filteredRows, sortConfig.key, sortConfig.direction, getCell),
    [filteredRows, sortConfig.key, sortConfig.direction, getCell]
  );

  const deferredRowSearchText = useDeferredValue(rowSearchText);
  const rowSearchTokens = useMemo(
    () =>
      deferredRowSearchText
        .trim()
        .toLowerCase()
        .split(/\s+/)
        .filter(Boolean),
    [deferredRowSearchText]
  );
  const displayRows = useMemo(() => {
    const phrase = deferredRowSearchText.trim().toLowerCase();
    const usePhrase = searchExactPhrase && phrase.length > 0;
    const useTokens = !searchExactPhrase && rowSearchTokens.length > 0;
    if (!usePhrase && !useTokens) return sortedRows;
    return sortedRows.filter((item) => {
      const hay = buildRowSearchHaystack(item, pickedSailpointRoleByCategoryId, rowSearchScope);
      if (usePhrase) return hay.includes(phrase);
      return rowSearchTokens.every((tok) => hay.includes(tok));
    });
  }, [
    sortedRows,
    rowSearchTokens,
    pickedSailpointRoleByCategoryId,
    rowSearchScope,
    searchExactPhrase,
    deferredRowSearchText,
  ]);

  const setPickedRole = useCallback((categoryId, roleName) => {
    const id = String(categoryId);
    const trimmed = String(roleName || '').trim();
    setPickedSailpointRoleByCategoryId((prev) => {
      const next = { ...prev };
      if (!trimmed) {
        delete next[id];
        return next;
      }
      next[id] = trimmed;
      return next;
    });
  }, []);

  const applicableVisible = useMemo(
    () =>
      displayRows.filter((item) => {
        const role = chosenSailpointRole(item, pickedSailpointRoleByCategoryId);
        return role && (item.category.sailpointRole || '').trim() !== role;
      }),
    [displayRows, pickedSailpointRoleByCategoryId]
  );

  const allApplicableSelected = useMemo(
    () =>
      applicableVisible.length > 0 &&
      applicableVisible.every((r) => selectedIds.has(r.category.id)),
    [applicableVisible, selectedIds]
  );

  const toggleSelect = (id) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const rejectRow = (categoryId) => {
    const id = String(categoryId);
    setRejectedIds((prev) => {
      const next = new Set(prev);
      next.add(id);
      persistRejectedCategoryIds(next);
      return next;
    });
    setSelectedIds((prev) => {
      if (!prev.has(id)) return prev;
      const next = new Set(prev);
      next.delete(id);
      return next;
    });
  };

  const clearAllRejected = () => {
    setRejectedIds(new Set());
    persistRejectedCategoryIds(new Set());
  };

  const exportVisibleCsv = useCallback(() => {
    const modeLabel = matchFilterMode === 'noMatch' ? 'no_suggested_match' : 'with_suggested_match';
    const headers = [
      'view_mode',
      'job_category_id',
      'job_category_name',
      'linkable_template',
      'subtemplate',
      'current_sailpoint',
      'sailpoint_role_review',
      'best_match',
      'role_to_apply',
      'total_suggestions',
      'other_suggestions',
      'normalized_json_key',
    ];
    const lines = [headers.join(',')];
    for (const item of displayRows) {
      const c = item.category;
      const chosen = chosenSailpointRole(item, pickedSailpointRoleByCategoryId);
      const tmpl = templateContextLines(c);
      const others = (item.suggestions || [])
        .slice(1)
        .map((s) => String(s.sailpointRole || '').trim())
        .filter(Boolean)
        .join('; ');
      lines.push(
        [
          csvEscapeCell(modeLabel),
          csvEscapeCell(c.jobCategoryId),
          csvEscapeCell(c.jobCategoryName),
          csvEscapeCell(tmpl.linkLine),
          csvEscapeCell(tmpl.subLine),
          csvEscapeCell((c.sailpointRole || '').trim()),
          csvEscapeCell((c.sailpointRoleReview || '').trim()),
          csvEscapeCell(item.proposed),
          csvEscapeCell(chosen),
          csvEscapeCell(item.totalSuggestions),
          csvEscapeCell(others),
          csvEscapeCell(categoryNameForSailpointMatch(c.jobCategoryName)),
        ].join(',')
      );
    }
    const blob = new Blob([`\ufeff${lines.join('\r\n')}`], {
      type: 'text/csv;charset=utf-8',
    });
    const a = document.createElement('a');
    const stamp = new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-');
    a.href = URL.createObjectURL(blob);
    a.download = `sailpoint-best-match-${modeLabel}-${stamp}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
    showToast(`Exported ${displayRows.length} row(s) to CSV`);
  }, [
    displayRows,
    matchFilterMode,
    pickedSailpointRoleByCategoryId,
    showToast,
  ]);

  const copyText = useCallback(
    async (text, successMessage) => {
      const t = String(text || '').trim();
      if (!t) return;
      try {
        await navigator.clipboard.writeText(t);
        showToast(successMessage);
      } catch (_) {
        showToast('Copy failed — try again or copy manually.');
      }
    },
    [showToast]
  );

  const selectAllApplicableVisible = () => {
    if (applicableVisible.length === 0) return;
    if (allApplicableSelected) {
      setSelectedIds(new Set());
      return;
    }
    setSelectedIds(new Set(applicableVisible.map((r) => r.category.id)));
  };

  const applyProposed = async (item) => {
    const role = chosenSailpointRole(item, pickedSailpointRoleByCategoryId);
    if (!role) return;
    const old = item.category;
    if ((old.sailpointRole || '').trim() === role) return;
    setSaving(true);
    try {
      const updatedCat = stampLastEdit({
        ...old,
        sailpointRole: role,
        sailpointRoleReview: '',
      });
      const next = jobCategories.map((c) => (c.id === old.id ? updatedCat : c));
      setJobCategories(next);
      await saveJobCategories(next);
      await addJobCategoryAuditLog('UPDATE', updatedCat, old);
      await reload();
      showToast(`Updated Sailpoint role for ${old.jobCategoryName || old.jobCategoryId}`);
    } catch (e) {
      alert(e?.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const applyBulk = async (items) => {
    const targets = items.filter((item) => {
      const role = chosenSailpointRole(item, pickedSailpointRoleByCategoryId);
      return role && (item.category.sailpointRole || '').trim() !== role;
    });
    if (targets.length === 0) {
      alert('No changes to apply.');
      return;
    }
    if (!window.confirm(`Apply chosen Sailpoint role to ${targets.length} job categor(y/ies)?`)) return;
    setSaving(true);
    try {
      const byId = new Map(jobCategories.map((c) => [c.id, { ...c }]));
      const prevSnap = new Map();
      for (const item of targets) {
        const role = chosenSailpointRole(item, pickedSailpointRoleByCategoryId);
        const { category } = item;
        const old = byId.get(category.id);
        if (!old) continue;
        prevSnap.set(category.id, old);
        byId.set(category.id, stampLastEdit({ ...old, sailpointRole: role, sailpointRoleReview: '' }));
      }
      const next = jobCategories.map((c) => byId.get(c.id) || c);
      setJobCategories(next);
      await saveJobCategories(next);
      for (const id of prevSnap.keys()) {
        const updated = byId.get(id);
        const old = prevSnap.get(id);
        if (updated && old) await addJobCategoryAuditLog('UPDATE', updated, old);
      }
      setSelectedIds(new Set());
      await reload();
      showToast(`Applied chosen Sailpoint role to ${targets.length} job categor(y/ies).`);
    } catch (e) {
      alert(e?.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  const setSailpointReviewFlag = async (category, flag) => {
    const want = flag ? 'Review' : '';
    if ((category.sailpointRoleReview || '').trim() === want) return;
    if (flag && (category.sailpointRole || '').trim()) {
      showToast('This category already has a Sailpoint role; clear it on the job category to use review flag.');
      return;
    }
    setSaving(true);
    try {
      const old = category;
      const updatedCat = stampLastEdit({
        ...old,
        sailpointRoleReview: want,
      });
      const next = jobCategories.map((c) => (c.id === old.id ? updatedCat : c));
      setJobCategories(next);
      await saveJobCategories(next);
      await addJobCategoryAuditLog('UPDATE', updatedCat, old);
      await reload();
      showToast(
        want
          ? `Marked "${old.jobCategoryName || old.jobCategoryId}" for Sailpoint review`
          : `Cleared Sailpoint review for "${old.jobCategoryName || old.jobCategoryId}"`
      );
    } catch (e) {
      alert(e?.message || 'Save failed');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="find-sp-match">
        <div className="find-sp-match-header">
          <h2>Sailpoint best match</h2>
        </div>
        <p className="find-sp-match-loading">Loading job categories and Sailpoint data…</p>
      </div>
    );
  }

  const selectedItems = displayRows.filter((r) => selectedIds.has(r.category.id));
  const applicableSelected = selectedItems.filter((item) => {
    const role = chosenSailpointRole(item, pickedSailpointRoleByCategoryId);
    return role && (item.category.sailpointRole || '').trim() !== role;
  });

  return (
    <div className="find-sp-match">
      <div className="find-sp-match-header">
        <h2>Sailpoint best match</h2>
        <p className="find-sp-match-desc">
          Suggestions only appear when the category has linkable template and/or subtemplate fields set, and each
          populated side must match the catalog role text (name, description, entitlements); name-only matches are not
          shown. If the category name does not include <strong>SiteB</strong> as its own word, roles that mention{' '}
          <strong>SiteB</strong> are excluded; if it does include <strong>SiteB</strong>, SiteB catalog roles can match like
          any other. Ranking still uses the job category name (a leading &quot;Epic Mosaic&quot; prefix is ignored),
          template/subtemplate IDs and names, and Template Links rows that match those fields. To pin an exact role,
          add{' '}
          <code className="find-sp-match-code">src/data/sailpointCategoryPreferredRoles.json</code> — normalized key
          (same rules as the name above) to full Sailpoint role name. Save the file and refresh the app to reload.
        </p>
        <p className="find-sp-match-desc find-sp-match-desc--secondary">
          Categories with Organization Job Category Scope set to{' '}
          <strong>{JOB_CATEGORY_SCOPE_NOT_IN_ORG}</strong> are omitted from matching and from these lists. This list is
          only categories with a blank Sailpoint role. When template/subtemplate fields are set, both sides
          must align with the suggestion where applicable. Use the dropdown or <strong>Use</strong> on an alternate to
          pick which suggested role to apply. Search narrows by ID, name, template fields, or role text (all tokens must
          match). <strong>Search scope</strong> limits which columns are searched; <strong>Exact phrase</strong> requires
          the full text as one substring (stricter than word tokens). <strong>Mark review</strong> /{' '}
          <strong>Clear review</strong> update the job category&apos;s Sailpoint Review flag (also in Job Categories).{' '}
          <strong>Export CSV</strong> downloads the current table (after sort/search/filters).{' '}
          <strong>Copy JSON key</strong> pastes the normalized key for{' '}
          <code className="find-sp-match-code">sailpointCategoryPreferredRoles.json</code>. Reject hides a row in this
          browser only. Switch to <strong>No suggested match</strong> to list blank Sailpoint categories the scorer
          could not rank (fix templates, Template Links, or add a JSON pin).
        </p>
        <div className="find-sp-match-toolbar">
          <div className="find-sp-match-mode" role="group" aria-label="Which categories to list">
            <button
              type="button"
              className={matchFilterMode === 'withMatch' ? 'find-sp-match-mode-btn is-active' : 'find-sp-match-mode-btn'}
              onClick={() => {
                setMatchFilterMode('withMatch');
                setSelectedIds(new Set());
              }}
            >
              With suggested match ({blankSailpointStats.withMatch})
            </button>
            <button
              type="button"
              className={matchFilterMode === 'noMatch' ? 'find-sp-match-mode-btn is-active' : 'find-sp-match-mode-btn'}
              onClick={() => {
                setMatchFilterMode('noMatch');
                setSelectedIds(new Set());
              }}
            >
              No suggested match ({blankSailpointStats.noMatch})
            </button>
          </div>
          <div className="find-sp-match-search-wrap">
            <label className="find-sp-match-search">
              <span>Search rows</span>
              <input
                type="search"
                autoComplete="off"
                placeholder={
                  searchExactPhrase
                    ? 'Exact substring (case-insensitive)…'
                    : 'Tokens (each must appear); or turn on Exact phrase…'
                }
                value={rowSearchText}
                onChange={(e) => {
                  setRowSearchText(e.target.value);
                  setSelectedIds(new Set());
                }}
              />
            </label>
            <label className="find-sp-match-search-scope">
              <span>Search in</span>
              <select
                value={rowSearchScope}
                onChange={(e) => {
                  setRowSearchScope(e.target.value);
                  setSelectedIds(new Set());
                }}
                aria-label="Limit search to specific fields"
              >
                <option value="all">All fields</option>
                <option value="category">Category ID &amp; name only</option>
                <option value="templates">Template &amp; subtemplate fields only</option>
                <option value="roles">Suggested Sailpoint roles only</option>
                <option value="jsonKey">Normalized JSON key only</option>
              </select>
            </label>
            <label className="find-sp-match-search-exact">
              <input
                type="checkbox"
                checked={searchExactPhrase}
                onChange={(e) => {
                  setSearchExactPhrase(e.target.checked);
                  setSelectedIds(new Set());
                }}
              />
              Exact phrase
            </label>
            {(rowSearchTokens.length > 0 || (searchExactPhrase && rowSearchText.trim())) && (
              <button
                type="button"
                className="find-sp-match-btn-secondary find-sp-match-search-clear"
                onClick={() => {
                  setRowSearchText('');
                  setSelectedIds(new Set());
                }}
              >
                Clear search
              </button>
            )}
          </div>
          <div
            className={`find-sp-match-filters${matchFilterMode === 'noMatch' ? ' find-sp-match-filters--disabled' : ''}`}
            role="group"
            aria-label="Filter by suggestion count"
            title={
              matchFilterMode === 'noMatch'
                ? 'Suggestion count filters apply only to “With suggested match”.'
                : undefined
            }
          >
            <label className="find-sp-match-filter">
              <span>Min suggestions (total)</span>
              <input
                type="number"
                min={1}
                max={99}
                value={minSuggestionCount}
                disabled={matchFilterMode === 'noMatch'}
                onChange={(e) => {
                  const v = parseInt(e.target.value, 10);
                  setMinSuggestionCount(Number.isFinite(v) ? Math.max(1, Math.min(99, v)) : 1);
                  setSelectedIds(new Set());
                }}
              />
            </label>
            <label className="find-sp-match-filter">
              <span>Max (optional)</span>
              <input
                type="number"
                min={1}
                max={99}
                placeholder="No max"
                value={maxSuggestionCount}
                disabled={matchFilterMode === 'noMatch'}
                onChange={(e) => {
                  const raw = e.target.value.trim();
                  if (raw === '') {
                    setMaxSuggestionCount('');
                    setSelectedIds(new Set());
                    return;
                  }
                  const v = parseInt(raw, 10);
                  if (!Number.isFinite(v)) return;
                  setMaxSuggestionCount(String(Math.max(1, Math.min(99, v))));
                  setSelectedIds(new Set());
                }}
              />
            </label>
          </div>
          <div className="find-sp-match-bulk">
            <button
              type="button"
              className="find-sp-match-btn-secondary"
              onClick={selectAllApplicableVisible}
              disabled={matchFilterMode === 'noMatch' || !applicableVisible.length}
            >
              {allApplicableSelected ? 'Clear selection' : 'Select all with changes'}
            </button>
            <button
              type="button"
              className="find-sp-match-btn-fill-all"
              disabled={matchFilterMode === 'noMatch' || saving || applicableSelected.length === 0}
              onClick={() => applyBulk(applicableSelected)}
            >
              {saving ? 'Saving…' : `Apply chosen role to selected (${applicableSelected.length})`}
            </button>
            <button
              type="button"
              className="find-sp-match-btn-fill-all"
              disabled={matchFilterMode === 'noMatch' || saving || applicableVisible.length === 0}
              onClick={() => applyBulk(displayRows)}
            >
              {saving ? 'Saving…' : `Apply to all visible (${applicableVisible.length})`}
            </button>
            <button
              type="button"
              className="find-sp-match-btn-secondary"
              disabled={rejectedIds.size === 0}
              onClick={clearAllRejected}
              title="Show categories you previously rejected on this screen"
            >
              Clear rejected ({rejectedIds.size})
            </button>
            <button
              type="button"
              className="find-sp-match-btn-secondary"
              disabled={displayRows.length === 0}
              onClick={exportVisibleCsv}
              title="Download current visible rows (sort, search, and filters applied) as CSV"
            >
              Export CSV ({displayRows.length})
            </button>
          </div>
        </div>
      </div>

      {sortedRows.length === 0 ? (
        <p className="find-sp-match-empty">
          {matchFilterMode === 'noMatch' ? (
            <>
              No job categories with a blank Sailpoint role and <strong>no</strong> suggested match
              {rejectedIds.size > 0 ? ` (excluding ${rejectedIds.size} rejected).` : '.'}
            </>
          ) : (
            <>
              No categories with a blank Sailpoint role and a suggested match in this range.
              {(rejectedIds.size > 0 ||
                suggestionCountBounds.minN > 1 ||
                suggestionCountBounds.maxN != null) && (
                <span className="find-sp-match-empty-hint">
                  {rejectedIds.size > 0 && <> Rejected hidden: {rejectedIds.size}. </>}
                  {(suggestionCountBounds.minN > 1 || suggestionCountBounds.maxN != null) && (
                    <>
                      Suggestion total must be {suggestionCountBounds.minN}
                      {suggestionCountBounds.maxN != null
                        ? `–${suggestionCountBounds.maxN} (inclusive).`
                        : ' or more.'}
                    </>
                  )}
                </span>
              )}
            </>
          )}
        </p>
      ) : displayRows.length === 0 ? (
        <p className="find-sp-match-empty">
          No rows match your search ({rowSearchTokens.join(' ')}).
          <span className="find-sp-match-empty-hint">
            {' '}
            <button
              type="button"
              className="find-sp-match-empty-clear-search"
              onClick={() => {
                setRowSearchText('');
                setSelectedIds(new Set());
              }}
            >
              Clear search
            </button>{' '}
            to show all {sortedRows.length} categor
            {sortedRows.length === 1 ? 'y' : 'ies'} in the current filters.
          </span>
        </p>
      ) : (
        <div className="find-sp-match-table-wrap">
          <table className="find-sp-match-table">
            <thead>
              <tr>
                <th style={{ width: 36 }} aria-label="Select row">
                  <input
                    type="checkbox"
                    checked={allApplicableSelected}
                    onChange={selectAllApplicableVisible}
                    disabled={matchFilterMode === 'noMatch' || !applicableVisible.length}
                    title="Select all rows that would change"
                  />
                </th>
                <SortableTh columnKey="jobCategoryId" sortConfig={sortConfig} onSort={handleSort}>
                  Category ID
                </SortableTh>
                <SortableTh columnKey="jobCategoryName" sortConfig={sortConfig} onSort={handleSort}>
                  Job Category Name
                </SortableTh>
                <th>Templates on category</th>
                <SortableTh columnKey="current" sortConfig={sortConfig} onSort={handleSort}>
                  Current Sailpoint
                </SortableTh>
                <SortableTh columnKey="sailpointRoleReview" sortConfig={sortConfig} onSort={handleSort}>
                  SP review
                </SortableTh>
                <SortableTh columnKey="proposed" sortConfig={sortConfig} onSort={handleSort}>
                  Best match
                </SortableTh>
                <th>Role to apply</th>
                <SortableTh columnKey="totalSuggestions" sortConfig={sortConfig} onSort={handleSort}>
                  Total
                </SortableTh>
                <SortableTh columnKey="alternates" sortConfig={sortConfig} onSort={handleSort}>
                  Other matches
                </SortableTh>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {displayRows.map((item) => {
                const { category, proposed, totalSuggestions, suggestions } = item;
                const isNoMatchRow = matchFilterMode === 'noMatch';
                const otherMatches = (suggestions || []).slice(1);
                const chosen = chosenSailpointRole(item, pickedSailpointRoleByCategoryId);
                const unchanged = (category.sailpointRole || '').trim() === chosen;
                const chosenIndex = (suggestions || []).findIndex(
                  (s) => String(s.sailpointRole || '').trim() === chosen
                );
                const selectIdx = chosenIndex >= 0 ? chosenIndex : 0;
                const tmpl = templateContextLines(category);
                const pickedAlternate = !isNoMatchRow && chosen && proposed && chosen !== proposed;
                return (
                  <tr
                    key={category.id}
                    className={
                      pickedAlternate ? 'find-sp-match-row--alt-pick' : isNoMatchRow ? 'find-sp-match-row--no-match' : undefined
                    }
                  >
                    <td>
                      <input
                        type="checkbox"
                        checked={selectedIds.has(category.id)}
                        onChange={() => toggleSelect(category.id)}
                        disabled={isNoMatchRow || unchanged || !chosen}
                      />
                    </td>
                    <td>{category.jobCategoryId || '—'}</td>
                    <td>{category.jobCategoryName || '—'}</td>
                    <td className="find-sp-match-tmpl-cell">
                      <div className="find-sp-match-tmpl-line" title={tmpl.linkTitle}>
                        <span className="find-sp-match-tmpl-k">Linkable</span> {tmpl.linkLine}
                      </div>
                      <div className="find-sp-match-tmpl-line" title={tmpl.subTitle}>
                        <span className="find-sp-match-tmpl-k">Sub</span> {tmpl.subLine}
                      </div>
                    </td>
                    <td className={unchanged ? 'find-sp-match-same' : ''}>
                      {(category.sailpointRole || '').trim() || '—'}
                    </td>
                    <td>
                      {(category.sailpointRoleReview || '').trim() === 'Review' ? (
                        <span className="find-sp-match-review-badge">Review</span>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td title={isNoMatchRow ? '' : proposed}>
                      {isNoMatchRow ? <span className="find-sp-match-none">None</span> : proposed}
                    </td>
                    <td>
                      {isNoMatchRow ? (
                        <span className="find-sp-match-none" title="Add templates, Template Links, or a JSON pin, then refresh">
                          —
                        </span>
                      ) : (
                        <select
                          className="find-sp-match-role-select"
                          aria-label={`Sailpoint role to apply for ${category.jobCategoryName || category.jobCategoryId || 'category'}`}
                          disabled={saving || !(suggestions && suggestions.length)}
                          value={String(selectIdx)}
                          onChange={(e) => {
                            const idx = parseInt(e.target.value, 10);
                            const row = suggestions[idx];
                            const name = row ? String(row.sailpointRole || '').trim() : '';
                            if (!name) return;
                            if (idx === 0 || name === proposed) {
                              setPickedSailpointRoleByCategoryId((prev) => {
                                const next = { ...prev };
                                delete next[String(category.id)];
                                return next;
                              });
                            } else {
                              setPickedRole(category.id, name);
                            }
                          }}
                        >
                          {(suggestions || []).map((row, i) => (
                            <option key={row.id != null ? `${row.id}-${i}` : `opt-${i}`} value={String(i)}>
                              {i + 1}. {String(row.sailpointRole || '').trim() || '—'}
                            </option>
                          ))}
                        </select>
                      )}
                    </td>
                    <td>{isNoMatchRow ? '0' : totalSuggestions}</td>
                    <td className="find-sp-match-others-cell">
                      {isNoMatchRow ? '—' : otherMatches.length === 0 ? (
                        '—'
                      ) : (
                        <ol className="find-sp-match-alt-list" start={2}>
                          {otherMatches.map((row, idx) => {
                            const label = String(row.sailpointRole || '').trim() || '—';
                            return (
                              <li key={row.id != null ? String(row.id) : `alt-${idx}`}>
                                <span className="find-sp-match-alt-line">
                                  <span className="find-sp-match-alt-label">{label}</span>
                                  <button
                                    type="button"
                                    className="find-sp-match-pick-alt"
                                    disabled={saving}
                                    onClick={() => setPickedRole(category.id, label)}
                                  >
                                    Use
                                  </button>
                                </span>
                              </li>
                            );
                          })}
                        </ol>
                      )}
                    </td>
                    <td className="find-sp-match-actions">
                      <button
                        type="button"
                        className="find-sp-match-btn-one"
                        disabled={isNoMatchRow || saving || !chosen || unchanged}
                        onClick={() => applyProposed(item)}
                      >
                        Apply
                      </button>
                      <button
                        type="button"
                        className="find-sp-match-btn-aux"
                        disabled={isNoMatchRow || saving || !chosen}
                        title="Copy chosen Sailpoint role name"
                        onClick={() => copyText(chosen, 'Copied Sailpoint role name')}
                      >
                        Copy role
                      </button>
                      <button
                        type="button"
                        className="find-sp-match-btn-aux"
                        disabled={saving || !category.jobCategoryName}
                        title="Copy normalized key for sailpointCategoryPreferredRoles.json"
                        onClick={() =>
                          copyText(
                            categoryNameForSailpointMatch(category.jobCategoryName),
                            'Copied normalized key for JSON'
                          )
                        }
                      >
                        Copy JSON key
                      </button>
                      <button
                        type="button"
                        className="find-sp-match-btn-aux"
                        disabled={
                          saving ||
                          (category.sailpointRoleReview || '').trim() === 'Review' ||
                          !!(category.sailpointRole || '').trim()
                        }
                        title="Flag this job category for Sailpoint follow-up (saved on the category)"
                        onClick={() => setSailpointReviewFlag(category, true)}
                      >
                        Mark review
                      </button>
                      <button
                        type="button"
                        className="find-sp-match-btn-aux"
                        disabled={saving || (category.sailpointRoleReview || '').trim() !== 'Review'}
                        title="Clear Sailpoint review flag on this job category"
                        onClick={() => setSailpointReviewFlag(category, false)}
                      >
                        Clear review
                      </button>
                      <button
                        type="button"
                        className="find-sp-match-btn-reject"
                        disabled={saving}
                        title="Hide this suggestion (browser only); use Clear rejected to show again"
                        onClick={() => rejectRow(category.id)}
                      >
                        Reject
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default FindSailpointMatches;
