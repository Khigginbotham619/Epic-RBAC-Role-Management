import React, { useState } from 'react';
import {
  getJobCategories,
  getRoles,
  getBlueprints,
  getTemplateLinks,
  mergeRoles,
  addAuditLogsBatch,
} from '../utils/storage';
import { buildLastEditStamp } from '../utils/lastEditStamp';
import {
  SYNC_RECENT_EDIT_DAYS,
  SYNC_SCOPE_ALL,
  SYNC_SCOPE_RECENT,
  buildJobCategoryRoleSyncPlan,
  applyJobCategoryRoleSyncPlan,
  countAppliedRoleSyncPatches,
  countSelectedRoleSyncUpdates,
  buildRoleSyncSelectionKey,
  normalizeRoleId,
  remapRoleSyncSelectionToFreshPlan,
} from '../utils/jobCategoryRoleSync';
import { useToast } from '../context/ToastContext';
import { notifyRolesUpdated } from '../utils/rbacRolesRefresh';
import JobCategoryRoleSyncDialog from './JobCategoryRoleSyncDialog';

const JobCategoryRoleSyncButton = ({
  className = 'btn-export',
  onSynced,
  title,
  scope = SYNC_SCOPE_RECENT,
  label,
}) => {
  const { showToast } = useToast();
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const syncAll = scope === SYNC_SCOPE_ALL;

  const defaultLabel = syncAll ? 'Sync All Roles with Categories' : 'Sync Roles from Categories';
  const defaultTitle = syncAll
    ? 'Review and sync all RBAC roles against the full job category table'
    : `Review and sync RBAC roles from job categories edited in the last ${SYNC_RECENT_EDIT_DAYS} days`;

  const handleOpenReview = async () => {
    setLoading(true);
    try {
      const [jobCategories, roles, blueprints, templateLinks] = await Promise.all([
        getJobCategories({ fresh: true }),
        getRoles({ fresh: true }),
        getBlueprints(),
        getTemplateLinks(),
      ]);
      setPlan(
        buildJobCategoryRoleSyncPlan({
          jobCategories,
          roles,
          blueprints,
          templateLinks: Array.isArray(templateLinks) ? templateLinks : [],
          scope,
        })
      );
    } catch (err) {
      console.error('Failed to build job category role sync plan:', err);
      alert(err?.message || 'Failed to load data for sync review.');
    } finally {
      setLoading(false);
    }
  };

  const handleConfirm = async (selectedKeys) => {
    if (!plan || plan.roleUpdateCount === 0 || !selectedKeys?.size) return;
    setSyncing(true);
    try {
      const planScope = plan.scope || scope;
      const [jobCategories, roles, blueprints, templateLinks] = await Promise.all([
        getJobCategories({ fresh: true }),
        getRoles({ fresh: true }),
        getBlueprints(),
        getTemplateLinks(),
      ]);
      const freshPlan = buildJobCategoryRoleSyncPlan({
        jobCategories,
        roles,
        blueprints,
        templateLinks: Array.isArray(templateLinks) ? templateLinks : [],
        scope: planScope,
      });
      const effectiveKeys = remapRoleSyncSelectionToFreshPlan(plan, freshPlan, selectedKeys);
      const editDetail = planScope === SYNC_SCOPE_ALL
        ? 'Synced all roles from Job Category table'
        : 'Synced from Job Category update';
      const editStamp = buildLastEditStamp(editDetail);
      const updatedRoles = applyJobCategoryRoleSyncPlan(roles, freshPlan, editStamp, effectiveKeys);
      const appliedCount = countAppliedRoleSyncPatches(roles, updatedRoles, effectiveKeys);
      if (appliedCount === 0) {
        alert(
          'No role changes were applied. The data may have changed since this review opened — close the dialog and run Sync again.'
        );
        setPlan(freshPlan);
        return;
      }
      const rolePatches = updatedRoles.filter((role) => {
        const prev = roles.find((r) => normalizeRoleId(r.id) === normalizeRoleId(role.id));
        return prev && JSON.stringify(prev) !== JSON.stringify(role);
      });
      await mergeRoles(rolePatches);
      const auditEntries = updatedRoles
        .map((role) => {
          const old = roles.find((r) => String(r.id) === String(role.id));
          if (!old || JSON.stringify(old) === JSON.stringify(role)) return null;
          return { entityType: 'ROLE', action: 'UPDATE', entityData: role, oldData: old };
        })
        .filter(Boolean);
      if (auditEntries.length > 0) await addAuditLogsBatch(auditEntries);
      notifyRolesUpdated(updatedRoles);
      onSynced?.(updatedRoles, freshPlan);
      const syncedCodes = [
        ...new Set(
          freshPlan.roleUpdates
            .filter((u) =>
              (u.changes || []).some((change) =>
                effectiveKeys.has(buildRoleSyncSelectionKey(u.roleId, change.field))
              )
            )
            .map((u) => u.rbacCode)
        ),
      ].sort();
      const roleCount = countSelectedRoleSyncUpdates(effectiveKeys);
      const preview =
        syncedCodes.length <= 10
          ? syncedCodes.join(', ')
          : `${syncedCodes.slice(0, 10).join(', ')} … and ${syncedCodes.length - 10} more`;
      showToast(`Synced ${roleCount} role(s): ${preview}`);
      setPlan(null);
    } catch (err) {
      console.error('Failed to sync roles from job categories:', err);
      alert(err?.message || 'Sync failed. Check the server and try again.');
    } finally {
      setSyncing(false);
    }
  };

  return (
    <>
      <button
        type="button"
        className={className}
        onClick={handleOpenReview}
        disabled={loading || syncing}
        title={title || defaultTitle}
      >
        {loading ? 'Loading…' : label || defaultLabel}
      </button>
      {plan && (
        <JobCategoryRoleSyncDialog
          plan={plan}
          busy={syncing}
          onConfirm={handleConfirm}
          onCancel={() => !syncing && setPlan(null)}
        />
      )}
    </>
  );
};

export default JobCategoryRoleSyncButton;
