import React, { useState, useEffect } from 'react';
import './DepartmentForm.css';

const DepartmentForm = ({ department, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    deptId: '',
    deptDescription: '',
  });

  useEffect(() => {
    if (department) {
      setFormData({
        deptId: department.deptId || '',
        deptDescription: department.deptDescription || '',
      });
    }
  }, [department]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <div className="department-form-container">
      <div className="department-form">
        <h2>{department ? 'Edit Department' : 'Add New Department'}</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="deptId">Dept ID *</label>
            <input
              type="text"
              id="deptId"
              name="deptId"
              value={formData.deptId}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="deptDescription">Dept Description *</label>
            <textarea
              id="deptDescription"
              name="deptDescription"
              value={formData.deptDescription}
              onChange={handleChange}
              rows="4"
              required
            />
          </div>

          <div className="form-actions">
            <button type="button" className="btn-cancel" onClick={onCancel}>
              Cancel
            </button>
            <button type="submit" className="btn-submit">
              {department ? 'Update Department' : 'Create Department'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DepartmentForm;
