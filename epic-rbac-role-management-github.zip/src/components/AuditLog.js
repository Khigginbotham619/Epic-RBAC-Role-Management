import React, { useState, useEffect } from 'react';
import { getAuditLogs } from '../utils/storage';
import { exportToCSV } from '../utils/csvExport';
import './AuditLog.css';

const AuditLog = () => {
  const [auditLogs, setAuditLogs] = useState([]);
  const [filteredLogs, setFilteredLogs] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [dateRange, setDateRange] = useState('all'); // all | today | 7days

  useEffect(() => {
    loadAuditLogs();
  }, []);

  useEffect(() => {
    filterLogs();
  }, [searchTerm, dateRange, auditLogs]);

  const loadAuditLogs = async () => {
    const logs = await getAuditLogs();
    setAuditLogs(logs);
    setFilteredLogs(logs);
  };

  const filterLogs = () => {
    const filtered = auditLogs.filter((log) => {
      const date = new Date(log.timestamp);
      const now = new Date();
      const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const sevenDaysAgo = new Date(now);
      sevenDaysAgo.setDate(now.getDate() - 7);

      const inDateRange =
        dateRange === 'today'
          ? date >= todayStart
          : dateRange === '7days'
            ? date >= sevenDaysAgo
            : true;
      if (!inDateRange) return false;

      if (!searchTerm.trim()) return true;
      const term = searchTerm.trim().toLowerCase();
      const searchableText = [
        log.user,
        log.action,
        log.timestamp,
        log.roleId,
        JSON.stringify(log.newData),
        JSON.stringify(log.oldData),
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();

      return searchableText.includes(term);
    });
    setFilteredLogs(filtered);
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  const getActionColor = (action) => {
    switch (action) {
      case 'CREATE':
        return '#10b981';
      case 'UPDATE':
        return '#3b82f6';
      case 'DELETE':
        return '#ef4444';
      default:
        return '#64748b';
    }
  };

  const renderDataDiff = (log) => {
    if (log.action === 'CREATE') {
      return (
        <div className="data-preview">
          <strong>New Data:</strong>
          <pre>{JSON.stringify(log.newData, null, 2)}</pre>
        </div>
      );
    } else if (log.action === 'UPDATE') {
      return (
        <div className="data-diff">
          <div className="data-preview">
            <strong>Old Data:</strong>
            <pre>{JSON.stringify(log.oldData, null, 2)}</pre>
          </div>
          <div className="data-preview">
            <strong>New Data:</strong>
            <pre>{JSON.stringify(log.newData, null, 2)}</pre>
          </div>
        </div>
      );
    } else if (log.action === 'DELETE') {
      return (
        <div className="data-preview">
          <strong>Deleted Data:</strong>
          <pre>{JSON.stringify(log.oldData, null, 2)}</pre>
        </div>
      );
    }
    return null;
  };

  const handleExport = () => {
    if (!filteredLogs || filteredLogs.length === 0) {
      alert('No audit logs to export');
      return;
    }
    const exportRows = filteredLogs.map((log) => ({
      timestamp: formatTimestamp(log.timestamp),
      user: log.user || '',
      action: log.action || '',
      roleId: log.roleId || '',
      newData: log.newData ? JSON.stringify(log.newData) : '',
      oldData: log.oldData ? JSON.stringify(log.oldData) : '',
    }));
    exportToCSV(exportRows, 'audit_log_export.csv', [
      'timestamp',
      'user',
      'action',
      'roleId',
      'newData',
      'oldData',
    ]);
  };

  return (
    <div className="audit-log">
      <div className="audit-header">
        <h2>Audit Log</h2>
      </div>

      <div className="search-container">
        <div className="search-row">
          <input
            type="text"
            placeholder="Search audit logs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
          <select
            className="date-range-select"
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            title="Filter audit logs by date range"
          >
            <option value="all">All dates</option>
            <option value="today">Today</option>
            <option value="7days">Last 7 days</option>
          </select>
          <button type="button" className="btn-export-audit" onClick={handleExport}>
            Export CSV
          </button>
        </div>
      </div>

      <div className="audit-list">
        {filteredLogs.length === 0 ? (
          <div className="no-data">
            {(searchTerm || dateRange !== 'all')
              ? 'No audit logs found matching your search.'
              : 'No audit logs found.'}
          </div>
        ) : (
          filteredLogs.map((log) => (
            <div key={log.id} className="audit-item">
              <div className="audit-item-header">
                <div className="audit-meta">
                  <span
                    className="action-badge"
                    style={{ backgroundColor: getActionColor(log.action) }}
                  >
                    {log.action}
                  </span>
                  <span className="timestamp">{formatTimestamp(log.timestamp)}</span>
                  <span className="user">User: {log.user}</span>
                  {log.roleId && (
                    <span className="role-id">Role ID: {log.roleId}</span>
                  )}
                </div>
              </div>
              {renderDataDiff(log)}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AuditLog;
