import React, { useState, useEffect } from 'react';
import './BlueprintForm.css';

const BlueprintForm = ({ blueprint, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    blueprintId: '',
    blueprintName: '',
  });

  useEffect(() => {
    if (blueprint) {
      setFormData({
        blueprintId: blueprint.blueprintId || '',
        blueprintName: blueprint.blueprintName || '',
      });
    }
  }, [blueprint]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <div className="blueprint-form-container">
      <form className="blueprint-form" onSubmit={handleSubmit}>
        <h2>{blueprint ? 'Edit Blueprint' : 'Add New Blueprint'}</h2>

        <div className="form-group">
          <label htmlFor="blueprintId">Blueprint ID *</label>
          <input
            type="text"
            id="blueprintId"
            name="blueprintId"
            value={formData.blueprintId}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="blueprintName">Blueprint Name *</label>
          <input
            type="text"
            id="blueprintName"
            name="blueprintName"
            value={formData.blueprintName}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-actions">
          <button type="submit" className="btn-submit">
            {blueprint ? 'Update Blueprint' : 'Create Blueprint'}
          </button>
          <button type="button" className="btn-cancel" onClick={onCancel}>
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
};

export default BlueprintForm;
