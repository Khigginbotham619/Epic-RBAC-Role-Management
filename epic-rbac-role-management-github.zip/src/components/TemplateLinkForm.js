import React, { useState, useEffect } from 'react';
import {
  splitTemplateIdTokens,
  canonicalTemplateLinkRecordType,
  normalizeTemplateLinkRow,
  syncRoleLinkedTemplateFromTemplateLinks,
  syncJobCategorySubtemplatesFromTemplateLinks,
} from '../utils/templateLinkRoleMatch';
import './TemplateLinkForm.css';

function preferActiveRows(rows) {
  if (!rows || rows.length === 0) return [];
  const active = rows.filter(
    (r) => String(r.currentStatus || 'Active').trim().toLowerCase() !== 'inactive'
  );
  const pool = active.length ? active : rows;
  return pool.slice(0, 8);
}

function matchesByRowTemplateIdField(allRows, token, recordType, excludeId) {
  const want = String(token || '').trim().toLowerCase();
  if (!want) return [];
  return allRows.filter((row) => {
    if (excludeId && row.id === excludeId) return false;
    if (canonicalTemplateLinkRecordType(row) !== recordType) return false;
    const n = normalizeTemplateLinkRow(row);
    const ids = splitTemplateIdTokens(n.templateId);
    return ids.some((t) => t.toLowerCase() === want);
  });
}

function matchesByLinkableSubtemplateId(allRows, token, excludeId) {
  const want = String(token || '').trim().toLowerCase();
  if (!want) return [];
  return allRows.filter((row) => {
    if (excludeId && row.id === excludeId) return false;
    if (canonicalTemplateLinkRecordType(row) !== 'Linkable Template') return false;
    const n = normalizeTemplateLinkRow(row);
    const ids = splitTemplateIdTokens(n.subtemplateId);
    return ids.some((t) => t.toLowerCase() === want);
  });
}

function dedupeRows(rows) {
  const seen = new Set();
  const out = [];
  for (const r of rows) {
    if (!r?.id || seen.has(r.id)) continue;
    seen.add(r.id);
    out.push(r);
  }
  return out;
}

const TemplateLinkForm = ({
  templateLink,
  createFormDefaults,
  onSubmit,
  onCancel,
  allTemplateLinks = [],
}) => {
  const [formData, setFormData] = useState({
    userRecordType: 'Linkable Template',
    templateId: '',
    templateName: '',
    primaryTemplateOwner: '',
    templateDisplayTitle: '',
    subtemplateId: '',
    subtemplateName: '',
    currentStatus: 'Active',
  });
  const [templateIdLookupMatches, setTemplateIdLookupMatches] = useState([]);
  const [subtemplateIdLookupMatches, setSubtemplateIdLookupMatches] = useState([]);

  useEffect(() => {
    setTemplateIdLookupMatches([]);
    setSubtemplateIdLookupMatches([]);
  }, [templateLink, createFormDefaults]);

  useEffect(() => {
    if (templateLink) {
      const recType = templateLink.userRecordType || 'Linkable Template';
      const isSub = recType === 'Subtemplate';
      setFormData({
        userRecordType: recType,
        templateId:
          (isSub && !(templateLink.templateId || '').trim() ? templateLink.subtemplateId : templateLink.templateId) || '',
        templateName:
          (isSub && !(templateLink.templateName || '').trim() ? templateLink.subtemplateName : templateLink.templateName) ||
          '',
        primaryTemplateOwner: templateLink.primaryTemplateOwner || '',
        templateDisplayTitle: templateLink.templateDisplayTitle || '',
        subtemplateId: isSub ? '' : templateLink.subtemplateId || '',
        subtemplateName: isSub ? '' : templateLink.subtemplateName || '',
        currentStatus: templateLink.currentStatus || 'Active',
      });
    } else if (createFormDefaults?.userRecordType) {
      setFormData((prev) => ({
        ...prev,
        userRecordType: createFormDefaults.userRecordType,
      }));
    }
  }, [templateLink, createFormDefaults]);

  const excludeId = templateLink?.id;
  const isSubtemplate = formData.userRecordType === 'Subtemplate';
  const recordTypeForMainId = isSubtemplate ? 'Subtemplate' : 'Linkable Template';

  const runTemplateIdLookup = (rawId) => {
    const tokens = splitTemplateIdTokens(rawId);
    const acc = [];
    for (const t of tokens.slice(0, 5)) {
      acc.push(...matchesByRowTemplateIdField(allTemplateLinks, t, recordTypeForMainId, excludeId));
    }
    setTemplateIdLookupMatches(preferActiveRows(dedupeRows(acc)));
  };

  const runLinkableSubtemplateIdLookup = (rawId) => {
    const tokens = splitTemplateIdTokens(rawId);
    const acc = [];
    for (const t of tokens.slice(0, 5)) {
      acc.push(...matchesByLinkableSubtemplateId(allTemplateLinks, t, excludeId));
    }
    setSubtemplateIdLookupMatches(preferActiveRows(dedupeRows(acc)));
  };

  const applyMainIdMatch = (row) => {
    const n = normalizeTemplateLinkRow(row);
    setFormData((prev) => ({
      ...prev,
      templateName: prev.templateName.trim() || n.templateName || '',
      templateDisplayTitle: prev.templateDisplayTitle.trim() || n.templateDisplayTitle || '',
      primaryTemplateOwner: prev.primaryTemplateOwner.trim() || n.primaryTemplateOwner || '',
    }));
  };

  const applySubIdMatch = (row) => {
    const n = normalizeTemplateLinkRow(row);
    setFormData((prev) => ({
      ...prev,
      subtemplateName: prev.subtemplateName.trim() || n.subtemplateName || '',
      templateDisplayTitle: prev.templateDisplayTitle.trim() || n.templateDisplayTitle || '',
      primaryTemplateOwner: prev.primaryTemplateOwner.trim() || n.primaryTemplateOwner || '',
    }));
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const hasCore =
      String(formData.templateId || '').trim() ||
      String(formData.templateName || '').trim() ||
      String(formData.templateDisplayTitle || '').trim() ||
      String(formData.primaryTemplateOwner || '').trim() ||
      String(formData.subtemplateId || '').trim() ||
      String(formData.subtemplateName || '').trim();
    if (!hasCore) {
      alert(
        'Enter at least one of: Template ID(s), Template Name(s), Template Display Title, Primary Template Owner, or related subtemplate fields.'
      );
      return;
    }
    onSubmit(formData);
  };

  const renderLookupChips = (matches, onApply, summaryLabel) => {
    if (!matches.length) return null;
    return (
      <div className="template-link-form-lookup-matches" role="region" aria-label="Matching existing template link rows">
        <div className="template-link-form-lookup-matches-label">{summaryLabel}</div>
        <ul className="template-link-form-lookup-matches-list">
          {matches.map((row) => {
            const n = normalizeTemplateLinkRow(row);
            const summary = [n.templateName, n.templateDisplayTitle].filter(Boolean).join(' · ').slice(0, 120);
            return (
              <li key={row.id}>
                <button type="button" className="template-link-form-lookup-apply" onClick={() => onApply(row)}>
                  Apply: {summary || n.templateId || row.id}
                </button>
              </li>
            );
          })}
        </ul>
      </div>
    );
  };

  return (
    <div className="template-link-form-container">
      <div className="template-link-form">
        <h2>{templateLink ? 'Edit Template Link' : 'Add New Template Link'}</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="userRecordType">User Record Type</label>
            <select
              id="userRecordType"
              name="userRecordType"
              value={formData.userRecordType}
              onChange={handleChange}
            >
              <option value="Linkable Template">Linkable Template</option>
              <option value="Subtemplate">Subtemplate</option>
            </select>
          </div>

          {isSubtemplate ? (
            <>
              <div className="form-group">
                <label htmlFor="templateId" title="Same field as Template ID(s) on linkable rows">
                  Subtemplate ID
                </label>
                <textarea
                  id="templateId"
                  name="templateId"
                  value={formData.templateId}
                  onChange={handleChange}
                  onBlur={(e) => {
                    const raw = e.target.value;
                    runTemplateIdLookup(raw);
                    setFormData((prev) => {
                      const synced = syncJobCategorySubtemplatesFromTemplateLinks(
                        allTemplateLinks,
                        raw,
                        prev.templateName,
                        'id'
                      );
                      return {
                        ...prev,
                        templateId: synced.subtemplatesId,
                        templateName: synced.subtemplatesName || prev.templateName,
                      };
                    });
                  }}
                  rows="3"
                  placeholder="Same storage as Template ID(s); comma or newline separated"
                />
                {renderLookupChips(
                  templateIdLookupMatches,
                  applyMainIdMatch,
                  'Rows with the same template ID — fill empty name, display title, owner:'
                )}
              </div>
              <div className="form-group">
                <label htmlFor="templateName" title="Same field as Template Name(s) on linkable rows">
                  Subtemplate Description
                </label>
                <textarea
                  id="templateName"
                  name="templateName"
                  value={formData.templateName}
                  onChange={handleChange}
                  onBlur={(e) => {
                    const raw = e.target.value;
                    setFormData((prev) => {
                      const synced = syncJobCategorySubtemplatesFromTemplateLinks(
                        allTemplateLinks,
                        prev.templateId,
                        raw,
                        'name'
                      );
                      return {
                        ...prev,
                        templateName: synced.subtemplatesName || raw,
                        templateId: synced.subtemplatesId || prev.templateId,
                      };
                    });
                  }}
                  rows="3"
                  placeholder="Same storage as Template Name(s); newline separated (commas are preserved)"
                />
              </div>
              <div className="form-group">
                <label htmlFor="primaryTemplateOwner">Primary Template Owner</label>
                <textarea
                  id="primaryTemplateOwner"
                  name="primaryTemplateOwner"
                  value={formData.primaryTemplateOwner}
                  onChange={handleChange}
                  rows="3"
                  placeholder="One or more owners (comma or newline separated)"
                />
              </div>
              <div className="form-group">
                <label htmlFor="templateDisplayTitle">Template Display Title</label>
                <textarea
                  id="templateDisplayTitle"
                  name="templateDisplayTitle"
                  value={formData.templateDisplayTitle}
                  onChange={handleChange}
                  rows="3"
                  placeholder="One or more display titles (comma or newline separated)"
                />
              </div>
            </>
          ) : (
            <>
              <div className="form-group">
                <label htmlFor="templateId" title="Same values as RBAC role field Linked Role Template ID">
                  Template ID(s)
                </label>
                <textarea
                  id="templateId"
                  name="templateId"
                  value={formData.templateId}
                  onChange={handleChange}
                  onBlur={(e) => {
                    const raw = e.target.value;
                    runTemplateIdLookup(raw);
                    setFormData((prev) => {
                      const synced = syncRoleLinkedTemplateFromTemplateLinks(
                        allTemplateLinks,
                        raw,
                        prev.templateName,
                        'id'
                      );
                      return {
                        ...prev,
                        templateId: synced.linkedRoleTemplateId,
                        templateName: synced.linkedRoleTemplateName || prev.templateName,
                      };
                    });
                  }}
                  rows="3"
                  placeholder="Enter one or more template IDs (comma or newline separated)"
                />
                {renderLookupChips(
                  templateIdLookupMatches,
                  applyMainIdMatch,
                  'Rows with the same template ID — fill empty name, display title, owner:'
                )}
              </div>
              <div className="form-group">
                <label htmlFor="templateName" title="Same values as RBAC role field Linked Role Template Name">
                  Template Name(s)
                </label>
                <textarea
                  id="templateName"
                  name="templateName"
                  value={formData.templateName}
                  onChange={handleChange}
                  onBlur={(e) => {
                    const raw = e.target.value;
                    setFormData((prev) => {
                      const synced = syncRoleLinkedTemplateFromTemplateLinks(
                        allTemplateLinks,
                        prev.templateId,
                        raw,
                        'name'
                      );
                      return {
                        ...prev,
                        templateName: synced.linkedRoleTemplateName || raw,
                        templateId: synced.linkedRoleTemplateId || prev.templateId,
                      };
                    });
                  }}
                  rows="3"
                  placeholder="Enter one or more template names (newline separated; commas are preserved)"
                />
              </div>
              <div className="form-group">
                <label htmlFor="primaryTemplateOwner">Primary Template Owner</label>
                <textarea
                  id="primaryTemplateOwner"
                  name="primaryTemplateOwner"
                  value={formData.primaryTemplateOwner}
                  onChange={handleChange}
                  rows="3"
                  placeholder="One or more owners (comma or newline separated)"
                />
              </div>
              <div className="form-group">
                <label htmlFor="templateDisplayTitle" title="Same values as RBAC role field Template Display Title">
                  Template Display Title
                </label>
                <textarea
                  id="templateDisplayTitle"
                  name="templateDisplayTitle"
                  value={formData.templateDisplayTitle}
                  onChange={handleChange}
                  rows="3"
                  placeholder="One or more display titles (comma or newline separated)"
                />
              </div>
              <div className="form-group">
                <label htmlFor="subtemplateId">Subtemplate ID(s)</label>
                <textarea
                  id="subtemplateId"
                  name="subtemplateId"
                  value={formData.subtemplateId}
                  onChange={handleChange}
                  onBlur={(e) => {
                    const raw = e.target.value;
                    runLinkableSubtemplateIdLookup(raw);
                    setFormData((prev) => {
                      const synced = syncJobCategorySubtemplatesFromTemplateLinks(
                        allTemplateLinks,
                        raw,
                        prev.subtemplateName,
                        'id'
                      );
                      return {
                        ...prev,
                        subtemplateId: synced.subtemplatesId,
                        subtemplateName: synced.subtemplatesName || prev.subtemplateName,
                      };
                    });
                  }}
                  rows="2"
                  placeholder="Optional related subtemplate IDs"
                />
                {renderLookupChips(
                  subtemplateIdLookupMatches,
                  applySubIdMatch,
                  'Linkable rows with the same subtemplate ID — fill empty subtemplate description, display title, owner:'
                )}
              </div>
              <div className="form-group">
                <label htmlFor="subtemplateName">Subtemplate Description</label>
                <textarea
                  id="subtemplateName"
                  name="subtemplateName"
                  value={formData.subtemplateName}
                  onChange={handleChange}
                  onBlur={(e) => {
                    const raw = e.target.value;
                    setFormData((prev) => {
                      const synced = syncJobCategorySubtemplatesFromTemplateLinks(
                        allTemplateLinks,
                        prev.subtemplateId,
                        raw,
                        'name'
                      );
                      return {
                        ...prev,
                        subtemplateName: synced.subtemplatesName || raw,
                        subtemplateId: synced.subtemplatesId || prev.subtemplateId,
                      };
                    });
                  }}
                  rows="2"
                  placeholder="Optional descriptions for related subtemplates"
                />
              </div>
            </>
          )}

          <div className="form-group">
            <label htmlFor="currentStatus">User Record Status</label>
            <select
              id="currentStatus"
              name="currentStatus"
              value={formData.currentStatus}
              onChange={handleChange}
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
              <option value="Pending">Pending</option>
            </select>
          </div>

          <div className="form-actions">
            <button type="button" className="btn-cancel" onClick={onCancel}>
              Cancel
            </button>
            <button type="submit" className="btn-submit">
              {templateLink ? 'Update Template Link' : 'Create Template Link'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TemplateLinkForm;
