import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useDebounce } from '../utils/useDebounce';
import { getSailpointRoles, saveSailpointRoles, addSailpointRoleAuditLog, getJobCategories, saveJobCategories, generateId } from '../utils/storage';
import { exportToCSV } from '../utils/csvExport';
import { importFromCSV } from '../utils/csvImport';
import { importFromExcel } from '../utils/excelImport';
import SailpointRoleForm from './SailpointRoleForm';
import ImportPreviewDialog from './ImportPreviewDialog';
import { useToast } from '../context/ToastContext';
import SortableTh from './SortableTh';
import { sortRowsByKey, nextSortState } from '../utils/tableSort';
import { parseTemplateAndSubtemplate } from '../utils/sailpointEntitlementParse';
import { mapImportedSailpointRow } from '../utils/sailpointImport';
import './Departments.css';

const MAX_RENDERED_ROWS = 1500;

const SailpointRoles = () => {
  const { showToast } = useToast();
  const [sailpointRoles, setSailpointRoles] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounce(searchTerm, 300);
  const [isImporting, setIsImporting] = useState(false);
  const [editingRole, setEditingRole] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [importPreview, setImportPreview] = useState(null);
  const fileInputRef = useRef(null);

  const filteredRows = useMemo(() => {
    if (!debouncedSearchTerm.trim()) return sailpointRoles;
    const term = debouncedSearchTerm.trim().toLowerCase();
    return sailpointRoles.filter((r) =>
      Object.values(r).some((v) => v && String(v).toLowerCase().includes(term))
    );
  }, [sailpointRoles, debouncedSearchTerm]);

  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  const handleSort = useCallback((key) => {
    setSortConfig((prev) => nextSortState(prev, key));
  }, []);
  const displayRows = useMemo(
    () => sortRowsByKey(filteredRows, sortConfig.key, sortConfig.direction),
    [filteredRows, sortConfig.key, sortConfig.direction]
  );
  const rowsToRender = useMemo(
    () => (displayRows.length <= MAX_RENDERED_ROWS ? displayRows : displayRows.slice(0, MAX_RENDERED_ROWS)),
    [displayRows]
  );

  const loadSailpointRoles = async () => {
    const rows = await getSailpointRoles();
    setSailpointRoles(rows);
  };

  useEffect(() => {
    loadSailpointRoles();
  }, []);

  const handleAdd = () => {
    setEditingRole(null);
    setShowForm(true);
  };

  const handleEdit = (row) => {
    setEditingRole(row);
    setShowForm(true);
  };

  const handleDelete = async (row) => {
    if (!window.confirm('Are you sure you want to delete this Sailpoint role?')) return;
    const updated = sailpointRoles.filter((r) => r.id !== row.id);
    setSailpointRoles(updated);
    await saveSailpointRoles(updated);
    await addSailpointRoleAuditLog('DELETE', row, row);
    loadSailpointRoles();
  };

  const handleFormSubmit = async (rowData) => {
    const trimmedRole = (rowData.sailpointRole || '').trim();
    if (!trimmedRole) return;
    const normalizedRow = {
      ...rowData,
      sailpointRole: trimmedRole,
      status: rowData.status || 'Active',
      templates: rowData.templates || rowData.description || '',
      subtemplates: rowData.subtemplates || '',
      requestable: rowData.requestable || '',
      matchedAccessProfile: rowData.matchedAccessProfile || '',
      entitlementType: rowData.entitlementType || '',
      instructions: rowData.instructions || rowData.entitlements || '',
      // Keep legacy fields populated for backward compatibility.
      description: rowData.templates || rowData.description || '',
      entitlements: rowData.instructions || rowData.entitlements || '',
    };
    const entitlementSource = rowData.instructions || rowData.entitlements || '';
    if (entitlementSource) {
      const parsed = parseTemplateAndSubtemplate(entitlementSource);
      if (parsed.template) normalizedRow.templates = parsed.template;
      if (parsed.subtemplate) normalizedRow.subtemplates = parsed.subtemplate;
    } else if (!normalizedRow.templates || !normalizedRow.subtemplates) {
      const parsed = parseTemplateAndSubtemplate(rowData.templates || rowData.description || '');
      if (!normalizedRow.templates && parsed.template) normalizedRow.templates = parsed.template;
      if (!normalizedRow.subtemplates && parsed.subtemplate) normalizedRow.subtemplates = parsed.subtemplate;
    }
    const duplicate = sailpointRoles.some((r) =>
      r.id !== editingRole?.id &&
      (r.sailpointRole || '').trim().toLowerCase() === trimmedRole.toLowerCase()
    );
    if (duplicate) {
      alert('Sailpoint role already exists.');
      return;
    }

    if (editingRole) {
      const updatedRow = { ...normalizedRow, id: editingRole.id };
      const updated = sailpointRoles.map((r) => (r.id === editingRole.id ? updatedRow : r));
      setSailpointRoles(updated);
      await saveSailpointRoles(updated);
      await addSailpointRoleAuditLog('UPDATE', updatedRow, editingRole);
    } else {
      const newRow = { ...normalizedRow, id: generateId() };
      const updated = [...sailpointRoles, newRow];
      setSailpointRoles(updated);
      await saveSailpointRoles(updated);
      await addSailpointRoleAuditLog('CREATE', newRow);
    }
    setShowForm(false);
    setEditingRole(null);
    loadSailpointRoles();
  };

  const handleExport = () => {
    // Export every visible table column with the same fallbacks used in the grid.
    const exportData = sailpointRoles.map((r) => {
      const entitlementValue = r.instructions || r.entitlements || '';
      const parsed = entitlementValue ? parseTemplateAndSubtemplate(entitlementValue) : { template: '', subtemplate: '' };
      return {
        role_name: r.sailpointRole || '',
        role_description: r.description || '',
        template: r.templates || parsed.template || '',
        subtemplate: r.subtemplates || parsed.subtemplate || '',
        role_status: r.status || 'Active',
        requestable: r.requestable || '',
        matched_access_profile: r.matchedAccessProfile || '',
        entitlement_type: r.entitlementType || '',
        entitlement_value: entitlementValue,
      };
    });
    exportToCSV(
      exportData,
      'sailpoint_roles.csv',
      [
        'role_name',
        'role_description',
        'template',
        'subtemplate',
        'role_status',
        'requestable',
        'matched_access_profile',
        'entitlement_type',
        'entitlement_value',
      ]
    );
    showToast(`Exported ${exportData.length} sailpoint row(s)`);
  };

  const handleImportClick = () => fileInputRef.current?.click();

  const syncJobCategoriesFromMappingRows = async (rows) => {
    const mapping = new Map();
    rows.forEach((row) => {
      const jobCategoryName = String(row.description || '').trim().toLowerCase();
      const templatesText = String(row.templates || '').trim().toLowerCase();
      const sailpointRoleName = String(row.sailpointRole || '').trim();
      const keyName = jobCategoryName || templatesText;
      if (!keyName || !sailpointRoleName) return;
      if (!mapping.has(keyName)) mapping.set(keyName, sailpointRoleName);
    });
    if (mapping.size === 0) return 0;

    const categories = await getJobCategories();
    const updated = (categories || []).map((cat) => {
      const key = String(cat.jobCategoryName || '').trim().toLowerCase();
      if (!key || !mapping.has(key)) return cat;
      const nextRole = mapping.get(key);
      if ((cat.sailpointRole || '') === nextRole) return cat;
      return { ...cat, sailpointRole: nextRole };
    });
    const changedCount = updated.reduce((acc, cat, idx) => acc + (cat !== (categories || [])[idx] ? 1 : 0), 0);
    if (changedCount > 0) await saveJobCategories(updated);
    return changedCount;
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const name = (file.name || '').toLowerCase();
    const isCsv = name.endsWith('.csv');
    const isExcel = name.endsWith('.xlsx') || name.endsWith('.xls');
    if (!isCsv && !isExcel) {
      alert('Please select a CSV or Excel file (.csv, .xlsx, .xls)');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    const runImport = async (importedData) => {
      const mappedRows = (Array.isArray(importedData) ? importedData : [])
        .map(mapImportedSailpointRow)
        .filter((r) => (r.sailpointRole || '').trim());

      if (mappedRows.length === 0) {
        alert('No valid sailpoint rows found.');
        setIsImporting(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
        return;
      }

      const commitImport = async (importMode = 'merge') => {
        const shouldReplace = importMode === 'replace';
        let finalRows;
        if (shouldReplace) {
          finalRows = mappedRows.map((r) => ({ ...r, id: generateId() }));
        } else {
          const existingByKey = {};
          sailpointRoles.forEach((r) => {
            const key = (r.sailpointRole || '').trim().toLowerCase();
            if (key) existingByKey[key] = r;
          });
          const newRows = [];
          mappedRows.forEach((row) => {
            const key = (row.sailpointRole || '').trim().toLowerCase();
            if (key && existingByKey[key]) {
              Object.assign(existingByKey[key], { ...row, id: existingByKey[key].id });
            } else {
              newRows.push({ ...row, id: generateId() });
            }
          });
          finalRows = [...sailpointRoles, ...newRows];
        }
        await saveSailpointRoles(finalRows);
        setSailpointRoles(finalRows);
        const syncedCount = await syncJobCategoriesFromMappingRows(mappedRows);
        if (syncedCount > 0) {
          showToast(`Mapped sailpoint rows to ${syncedCount} job categor${syncedCount === 1 ? 'y' : 'ies'}.`);
        }
        showToast(`Successfully imported ${mappedRows.length} sailpoint row(s)!`);
      };

      const runWithCleanup = async () => {
        try {
          await commitImport();
        } finally {
          setIsImporting(false);
          if (fileInputRef.current) fileInputRef.current.value = '';
        }
      };

      setImportPreview({
        rows: mappedRows,
        columns: ['sailpointRole', 'templates', 'subtemplates', 'status'],
        existingData: sailpointRoles,
        matchKey: 'sailpointRole',
        onConfirm: runWithCleanup,
      });
    };

    const onError = (error) => {
      setIsImporting(false);
      alert(`Import failed: ${error}`);
      if (fileInputRef.current) fileInputRef.current.value = '';
    };

    setIsImporting(true);
    if (isCsv) importFromCSV(file, runImport, onError);
    else importFromExcel(file, (data) => runImport(data), onError);
  };

  if (showForm) {
    return (
      <SailpointRoleForm
        sailpointRole={editingRole}
        onSubmit={handleFormSubmit}
        onCancel={() => { setShowForm(false); setEditingRole(null); }}
      />
    );
  }

  return (
    <div className="departments">
      <div className="departments-header">
        <h2>Sailpoint Roles</h2>
        <div className="actions">
          <div className="search-container">
            <input
              type="text"
              className="search-input"
              placeholder="Search sailpoint roles..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              aria-label="Search sailpoint roles"
            />
          </div>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".csv,.xlsx,.xls"
            style={{ display: 'none' }}
          />
          <button className="btn-import" onClick={handleImportClick} disabled={isImporting}>
            {isImporting ? 'Importing…' : 'Import from CSV or Excel'}
          </button>
          <button className="btn-export" onClick={handleExport}>Export to CSV</button>
          <button className="btn-add" onClick={handleAdd}>Add New Sailpoint Role</button>
        </div>
      </div>
      <div className="table-container">
        {displayRows.length > MAX_RENDERED_ROWS && (
          <p className="admin-muted" style={{ padding: '0.5rem 0.75rem' }}>
            Showing first {MAX_RENDERED_ROWS.toLocaleString()} of {displayRows.length.toLocaleString()} rows.
            Narrow search to see the rest.
          </p>
        )}
        {sailpointRoles.length === 0 ? (
          <div className="empty-state" role="status">
            <p className="empty-state-message">No sailpoint roles yet</p>
            <button type="button" className="btn-add empty-state-cta" onClick={handleAdd}>
              Add New Sailpoint Role
            </button>
          </div>
        ) : (
          <table className="departments-table">
            <thead>
              <tr>
                <SortableTh columnKey="sailpointRole" sortConfig={sortConfig} onSort={handleSort}>role_name</SortableTh>
                <SortableTh columnKey="description" sortConfig={sortConfig} onSort={handleSort}>role_description</SortableTh>
                <SortableTh columnKey="templates" sortConfig={sortConfig} onSort={handleSort}>template</SortableTh>
                <SortableTh columnKey="subtemplates" sortConfig={sortConfig} onSort={handleSort}>subtemplate</SortableTh>
                <SortableTh columnKey="status" sortConfig={sortConfig} onSort={handleSort}>role_status</SortableTh>
                <SortableTh columnKey="requestable" sortConfig={sortConfig} onSort={handleSort}>requestable</SortableTh>
                <SortableTh columnKey="matchedAccessProfile" sortConfig={sortConfig} onSort={handleSort}>matched_access_profile</SortableTh>
                <SortableTh columnKey="entitlementType" sortConfig={sortConfig} onSort={handleSort}>entitlement_type</SortableTh>
                <SortableTh columnKey="instructions" sortConfig={sortConfig} onSort={handleSort}>entitlement_value</SortableTh>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {rowsToRender.map((row) => (
                (() => {
                  const entitlementText = row.instructions || row.entitlements || '';
                  const parsedFromEntitlement = parseTemplateAndSubtemplate(entitlementText);
                  const templateDisplay = row.templates || parsedFromEntitlement.template || '';
                  const subtemplateDisplay = row.subtemplates || parsedFromEntitlement.subtemplate || '';
                  return (
                    <tr key={row.id}>
                      <td>{row.sailpointRole}</td>
                      <td className="text-cell">{row.description || '—'}</td>
                      <td className="text-cell">{templateDisplay || '—'}</td>
                      <td className="text-cell">{subtemplateDisplay || '—'}</td>
                      <td>{row.status || 'Active'}</td>
                      <td>{row.requestable || '—'}</td>
                      <td>{row.matchedAccessProfile || '—'}</td>
                      <td>{row.entitlementType || '—'}</td>
                      <td className="text-cell">{entitlementText || '—'}</td>
                      <td>
                        <button className="btn-edit" onClick={() => handleEdit(row)}>Edit</button>
                        <button className="btn-delete" onClick={() => handleDelete(row)}>Delete</button>
                      </td>
                    </tr>
                  );
                })()
              ))}
            </tbody>
          </table>
        )}
      </div>
      {importPreview && (
        <ImportPreviewDialog
          rows={importPreview.rows}
          columns={importPreview.columns}
          existingData={importPreview.existingData}
          matchKey={importPreview.matchKey}
          onConfirm={(mode) => { setImportPreview(null); importPreview.onConfirm(mode); }}
          onCancel={() => { setImportPreview(null); setIsImporting(false); if (fileInputRef.current) fileInputRef.current.value = ''; }}
          enableImportMode
          defaultImportMode="merge"
        />
      )}
    </div>
  );
};

export default SailpointRoles;
