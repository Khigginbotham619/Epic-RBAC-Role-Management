import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  getJobCodes,
  saveJobCodes,
  getDepartments,
  saveDepartments,
  getBlueprints,
  saveBlueprints,
  getSailpointRoles,
  saveSailpointRoles,
  getTemplateLinks,
  saveTemplateLinks,
  addAuditLogsBatch,
} from '../utils/storage';
import {
  REFERENCE_TABLE_DEFS,
  findReferenceTableBlanks,
  applyReferenceTableFills,
} from '../utils/referenceTableBlanks';
import { useToast } from '../context/ToastContext';
import './ReferenceTableBlanks.css';

const VIEW_FOR_TABLE = {
  jobCodes: 'jobCodes',
  departments: 'departments',
  blueprints: 'blueprints',
  sailpointRoles: 'sailpointRoles',
  templateLinks: 'templateLinks',
};

const AUDIT_ENTITY_FOR_TABLE = {
  jobCodes: 'JOB_CODE',
  departments: 'DEPARTMENT',
  blueprints: 'BLUEPRINT',
  sailpointRoles: 'SAILPOINT_ROLE',
  templateLinks: 'TEMPLATE_LINK',
};

const ReferenceTableBlanks = ({ setCurrentView }) => {
  const { showToast } = useToast();
  const [tables, setTables] = useState(null);
  const [loading, setLoading] = useState(true);
  const [busyTableKey, setBusyTableKey] = useState(null);

  const reload = useCallback(async () => {
    setLoading(true);
    try {
      const [jobCodes, departments, blueprints, sailpointRoles, templateLinks] = await Promise.all([
        getJobCodes(),
        getDepartments(),
        getBlueprints(),
        getSailpointRoles(),
        getTemplateLinks(),
      ]);
      setTables({
        jobCodes: Array.isArray(jobCodes) ? jobCodes : [],
        departments: Array.isArray(departments) ? departments : [],
        blueprints: Array.isArray(blueprints) ? blueprints : [],
        sailpointRoles: Array.isArray(sailpointRoles) ? sailpointRoles : [],
        templateLinks: Array.isArray(templateLinks) ? templateLinks : [],
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    reload();
  }, [reload]);

  const sections = useMemo(() => (tables ? findReferenceTableBlanks(tables) : []), [tables]);
  const totalBlanks = sections.reduce((acc, sec) => acc + sec.blanks.length, 0);
  const totalProposable = sections.reduce(
    (acc, sec) => acc + sec.blanks.reduce(
      (a, b) => a + b.blanks.filter((bf) => !!bf.proposedFill).length,
      0,
    ),
    0,
  );

  const saveTableByKey = async (key, rows) => {
    switch (key) {
      case 'jobCodes':
        return saveJobCodes(rows);
      case 'departments':
        return saveDepartments(rows);
      case 'blueprints':
        return saveBlueprints(rows);
      case 'sailpointRoles':
        return saveSailpointRoles(rows);
      case 'templateLinks':
        return saveTemplateLinks(rows);
      default:
        return null;
    }
  };

  const applyFills = async ({ def, blanks, selected }) => {
    const tableRows = tables?.[def.key] || [];
    const result = applyReferenceTableFills(tableRows, blanks, selected);
    if (result.appliedCount === 0) {
      alert('No fills to apply (no proposable values in selection).');
      return;
    }
    setBusyTableKey(def.key);
    try {
      const auditEntries = [];
      const entityType = AUDIT_ENTITY_FOR_TABLE[def.key] || def.key.toUpperCase();
      for (const row of result.updatedRows) {
        if (row && row.id && result.changedRowIds.has(row.id)) {
          auditEntries.push({
            entityType,
            action: 'UPDATE',
            entityData: row,
            oldData: result.oldByRowId.get(row.id),
          });
        }
      }
      await saveTableByKey(def.key, result.updatedRows);
      if (auditEntries.length > 0) await addAuditLogsBatch(auditEntries);
      showToast(`Filled ${result.appliedCount} blank field(s) in ${def.label}.`);
      await reload();
    } catch (err) {
      alert(err?.message || 'Failed to save fills.');
    } finally {
      setBusyTableKey(null);
    }
  };

  const handleApplyAllForTable = async ({ def, blanks }) => {
    const total = blanks.reduce(
      (acc, b) => acc + b.blanks.filter((bf) => !!bf.proposedFill).length,
      0,
    );
    if (total === 0) {
      alert('No proposable fills in this table.');
      return;
    }
    if (!window.confirm(`Fill ${total} blank field(s) in ${def.label}?`)) return;
    await applyFills({ def, blanks });
  };

  const handleApplyRow = async ({ def, blanks, rowEntry }) => {
    const proposable = rowEntry.blanks.filter((b) => !!b.proposedFill);
    if (proposable.length === 0) {
      alert('No proposable fills for this row.');
      return;
    }
    const selected = new Set(proposable.map((b) => `${rowEntry.row.id}|${b.field}`));
    await applyFills({ def, blanks, selected });
  };

  if (loading) {
    return (
      <div className="ref-blanks">
        <div className="ref-blanks-header">
          <h2>Reference-Table Blank Sweeper</h2>
        </div>
        <p style={{ padding: '2rem', textAlign: 'center', color: '#64748b' }}>Loading reference tables…</p>
      </div>
    );
  }

  return (
    <div className="ref-blanks">
      <div className="ref-blanks-header">
        <h2>Reference-Table Blank Sweeper</h2>
        <p className="ref-blanks-desc">
          Rows in the reference tables (Job Codes, Departments, Blueprints, SailPoint Roles,
          Template Links) that are missing required fields. Fields with a proposed fill can be
          applied here; the rest deep-link to the source-of-truth tab for manual entry.
        </p>
      </div>

      <div className="ref-blanks-actions">
        <button
          type="button"
          className="ref-blanks-btn ref-blanks-btn-secondary"
          onClick={reload}
          disabled={!!busyTableKey}
        >
          Reload
        </button>
        <span className="ref-blanks-counter">
          {totalBlanks} row{totalBlanks === 1 ? '' : 's'} with blanks across {REFERENCE_TABLE_DEFS.length} reference tables
          {totalProposable > 0 && ` · ${totalProposable} auto-fillable`}
        </span>
      </div>

      <div className="ref-blanks-body">
        {sections.map(({ def, blanks }) => {
          const proposableCount = blanks.reduce(
            (acc, b) => acc + b.blanks.filter((bf) => !!bf.proposedFill).length,
            0,
          );
          const tableBusy = busyTableKey === def.key;
          return (
            <div key={def.key} className="ref-blanks-section">
              <div className="ref-blanks-section-head">
                <span className="ref-blanks-section-title">{def.label}</span>
                <span className="ref-blanks-section-count">
                  {blanks.length} row{blanks.length === 1 ? '' : 's'} with blanks
                  {proposableCount > 0 && ` · ${proposableCount} fillable`}
                </span>
                {proposableCount > 0 && (
                  <button
                    type="button"
                    className="ref-blanks-btn"
                    onClick={() => handleApplyAllForTable({ def, blanks })}
                    disabled={tableBusy}
                    style={{ marginRight: '0.5rem' }}
                  >
                    {tableBusy ? 'Saving…' : `Fill ${proposableCount} blank${proposableCount === 1 ? '' : 's'}`}
                  </button>
                )}
                {setCurrentView && VIEW_FOR_TABLE[def.key] && (
                  <button
                    type="button"
                    className="ref-blanks-jumplink"
                    onClick={() => setCurrentView(VIEW_FOR_TABLE[def.key])}
                  >
                    Open {def.label} →
                  </button>
                )}
              </div>
              {blanks.length === 0 ? (
                <p className="ref-blanks-empty-section">No blanks - this table looks complete.</p>
              ) : (
                <table className="ref-blanks-table">
                  <thead>
                    <tr>
                      <th>{def.idLabel}</th>
                      <th>Missing</th>
                      <th style={{ width: 110 }} />
                    </tr>
                  </thead>
                  <tbody>
                    {blanks.map((b) => {
                      const rowProposable = b.blanks.filter((bf) => !!bf.proposedFill);
                      return (
                        <tr key={b.id || b.keyValue}>
                          <td>{b.keyValue || '—'}</td>
                          <td>
                            <ul className="ref-blanks-missing-list">
                              {b.blanks.map((mf) => (
                                <li key={mf.field}>
                                  <span className="ref-blanks-missing-label">{mf.label}</span>
                                  {mf.proposedFill ? (
                                    <>
                                      <span className="ref-blanks-missing-proposal">
                                        → "{mf.proposedFill}"
                                      </span>
                                      {mf.proposeFillSource && (
                                        <span className="ref-blanks-missing-source">
                                          (from {mf.proposeFillSource})
                                        </span>
                                      )}
                                    </>
                                  ) : null}
                                </li>
                              ))}
                            </ul>
                          </td>
                          <td>
                            {rowProposable.length > 0 ? (
                              <button
                                type="button"
                                className="ref-blanks-row-btn"
                                onClick={() => handleApplyRow({ def, blanks, rowEntry: b })}
                                disabled={tableBusy}
                              >
                                Fill ({rowProposable.length})
                              </button>
                            ) : null}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ReferenceTableBlanks;
