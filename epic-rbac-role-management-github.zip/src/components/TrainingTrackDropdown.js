import React, { useState, useRef, useEffect, useMemo } from 'react';
import './TrainingTrackDropdown.css';

// Sentinel for "Other (free text)" selected but no custom text yet. Uses zero-width space so user-typed "__other__" is preserved.
export const TRAINING_TRACK_OTHER = '\u200B__other__';

export function trainingTrackSelectValue(currentValue, trackNames) {
  if (!currentValue || !String(currentValue).trim()) return '';
  return trackNames.includes(String(currentValue).trim()) ? String(currentValue).trim() : TRAINING_TRACK_OTHER;
}

export default function TrainingTrackDropdown({ id, value, options, onChange, onAddNew, placeholder = 'Select...' }) {
  const [open, setOpen] = useState(false);
  const [showAddNew, setShowAddNew] = useState(false);
  const [newTrackName, setNewTrackName] = useState('');
  const [filter, setFilter] = useState('');
  const addInputRef = useRef(null);
  const filterInputRef = useRef(null);
  const containerRef = useRef(null);

  const sortedOptions = useMemo(() => {
    const list = Array.isArray(options) ? [...options] : [];
    return list.sort((a, b) => {
      const na = (a.trackName || '').trim().toLowerCase();
      const nb = (b.trackName || '').trim().toLowerCase();
      return na.localeCompare(nb);
    });
  }, [options]);

  const filteredOptions = useMemo(() => {
    const term = (filter || '').trim().toLowerCase();
    if (!term) return sortedOptions;
    return sortedOptions.filter((t) => (t.trackName || '').trim().toLowerCase().includes(term));
  }, [sortedOptions, filter]);

  const trackNames = sortedOptions.map((t) => (t.trackName || '').trim()).filter(Boolean);
  const selectVal = trainingTrackSelectValue(value, trackNames);
  const isCustomValue = selectVal === TRAINING_TRACK_OTHER || (value && !trackNames.includes(String(value).trim()));
  const displayText = selectVal === '' ? placeholder : selectVal === TRAINING_TRACK_OTHER ? 'Other (free text)' : selectVal;

  useEffect(() => {
    if (!open) return;
    setFilter('');
    const handleClickOutside = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
        setShowAddNew(false);
        setNewTrackName('');
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [open]);

  useEffect(() => {
    if (open && !showAddNew && filterInputRef.current && !isCustomValue) {
      filterInputRef.current.focus();
    }
  }, [open, showAddNew, isCustomValue]);

  useEffect(() => {
    if (showAddNew && addInputRef.current) addInputRef.current.focus();
  }, [showAddNew]);

  const handleSelect = (val) => {
    onChange(val);
    setOpen(false);
    setShowAddNew(false);
    setNewTrackName('');
    setFilter('');
  };

  const handleAddNew = () => {
    const name = (newTrackName || '').trim();
    if (!name || typeof onAddNew !== 'function') return;
    onAddNew(name);
    onChange(name);
    setNewTrackName('');
    setShowAddNew(false);
    setOpen(false);
  };

  return (
    <div className="training-track-dropdown" ref={containerRef}>
      <div
        role="combobox"
        aria-haspopup="listbox"
        aria-expanded={open}
        className={`training-track-dropdown-trigger${open ? ' training-track-dropdown-trigger-open' : ''}`}
      >
        {isCustomValue ? (
          <input
            type="text"
            id={id}
            className="training-track-dropdown-input"
            value={value === TRAINING_TRACK_OTHER ? '' : value}
            onChange={(e) => onChange(e.target.value)}
            placeholder="Type or select..."
            onClick={(e) => e.stopPropagation()}
          />
        ) : (
          <button
            type="button"
            id={id}
            className="training-track-dropdown-trigger-btn"
            onClick={() => setOpen((o) => !o)}
          >
            <span className="training-track-dropdown-value">{displayText}</span>
          </button>
        )}
        <span className="training-track-dropdown-arrow" onClick={() => setOpen((o) => !o)} role="button" tabIndex={-1} aria-label="Open list">▼</span>
      </div>
      {open && (
        <ul className="training-track-dropdown-list" role="listbox">
          <li className="training-track-dropdown-filter-row" onClick={(e) => e.stopPropagation()}>
            <input
              ref={filterInputRef}
              type="text"
              className="training-track-dropdown-filter-input"
              placeholder="Type to find..."
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              onKeyDown={(e) => e.stopPropagation()}
            />
          </li>
          <li role="option" onClick={() => handleSelect('')}>
            {placeholder}
          </li>
          {filteredOptions.map((t) => (
            <li key={t.id} role="option" onClick={() => handleSelect(t.trackName || '')}>
              {t.trackName || ''}
            </li>
          ))}
          {filteredOptions.length === 0 && filter.trim() && (
            <li className="training-track-dropdown-no-results">No matches</li>
          )}
          <li role="option" onClick={() => handleSelect(TRAINING_TRACK_OTHER)}>
            Other (free text)
          </li>
          {typeof onAddNew === 'function' && (
            <li className="training-track-dropdown-add-new" role="option">
              {!showAddNew ? (
                <button type="button" className="training-track-add-new-trigger" onClick={(e) => { e.stopPropagation(); setShowAddNew(true); }}>
                  Add new...
                </button>
              ) : (
                <div className="training-track-add-new-form" onClick={(e) => e.stopPropagation()}>
                  <input
                    ref={addInputRef}
                    type="text"
                    value={newTrackName}
                    onChange={(e) => setNewTrackName(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') handleAddNew(); if (e.key === 'Escape') { setShowAddNew(false); setNewTrackName(''); } }}
                    placeholder="New training track name"
                  />
                  <button type="button" className="training-track-add-btn" onClick={handleAddNew}>Add</button>
                </div>
              )}
            </li>
          )}
        </ul>
      )}
    </div>
  );
}
