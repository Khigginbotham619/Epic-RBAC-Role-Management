import React, { useState, useEffect, useRef } from 'react';
import { normalizeJobCode } from '../utils/jobCodeUtils';
import './JobCodeForm.css';

const validateJobCode = (value) => {
  const code = normalizeJobCode(value || '');
  if (!code) return 'Job code is required.';
  if (code.length !== 4) return 'Job code must be exactly 4 characters (e.g. 0123).';
  return '';
};

const validateJobTitle = (value) => {
  if (!value || !String(value).trim()) return 'Job title is required.';
  return '';
};

const JobCodeForm = ({ jobCode, existingJobCodes = [], onSubmit, onCancel }) => {
  const firstInputRef = useRef(null);
  const [formData, setFormData] = useState({
    jobCode: '',
    jobTitle: '',
    currentStatus: 'Active',
  });
  const [errors, setErrors] = useState({ jobCode: '', jobTitle: '' });
  const [touched, setTouched] = useState({ jobCode: false, jobTitle: false });

  const duplicateWarning = (() => {
    const code = normalizeJobCode(formData.jobCode || '');
    if (!code || code.length !== 4) return null;
    const list = Array.isArray(existingJobCodes) ? existingJobCodes : [];
    const match = list.find(
      (jc) => jc && normalizeJobCode(jc.jobCode || '') === code && (!jobCode || jc.id !== jobCode.id)
    );
    return match ? 'This job code already exists.' : null;
  })();

  useEffect(() => {
    if (jobCode) {
      setFormData({
        jobCode: normalizeJobCode(jobCode.jobCode || '') || '',
        jobTitle: jobCode.jobTitle || '',
        currentStatus: jobCode.currentStatus || 'Active',
      });
      setErrors({ jobCode: '', jobTitle: '' });
      setTouched({ jobCode: false, jobTitle: false });
    }
  }, [jobCode]);

  // Focus first field when form is shown so users can start typing immediately
  useEffect(() => {
    const t = setTimeout(() => firstInputRef.current?.focus(), 0);
    return () => clearTimeout(t);
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    if (touched[name]) {
      const fn = name === 'jobCode' ? validateJobCode : name === 'jobTitle' ? validateJobTitle : () => '';
      setErrors((prev) => ({ ...prev, [name]: fn(value) }));
    }
  };

  const handleBlur = (e) => {
    const { name, value } = e.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    const fn = name === 'jobCode' ? validateJobCode : name === 'jobTitle' ? validateJobTitle : () => '';
    setErrors((prev) => ({ ...prev, [name]: fn(value) }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const jobCodeErr = validateJobCode(formData.jobCode);
    const jobTitleErr = validateJobTitle(formData.jobTitle);
    setErrors({ jobCode: jobCodeErr, jobTitle: jobTitleErr });
    setTouched({ jobCode: true, jobTitle: true });
    if (jobCodeErr || jobTitleErr) return;
    if (duplicateWarning && !window.confirm(`${duplicateWarning}\n\nDo you want to continue anyway?`)) return;
    onSubmit(formData);
  };

  return (
    <div className="job-code-form-container">
      <div className="job-code-form">
        <h2>{jobCode ? 'Edit Job Code' : 'Add New Job Code'}</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="jobCode">Job Code *</label>
            <input
              ref={firstInputRef}
              type="text"
              id="jobCode"
              name="jobCode"
              value={formData.jobCode}
              onChange={handleChange}
              onBlur={handleBlur}
              maxLength={4}
              placeholder="4 characters (e.g. 0123)"
              required
              className={errors.jobCode ? 'input-error' : duplicateWarning ? 'input-warning' : ''}
              aria-invalid={!!errors.jobCode}
              aria-describedby={errors.jobCode ? 'jobCode-error' : undefined}
            />
            {errors.jobCode && (
              <span id="jobCode-error" className="form-error" role="alert">
                {errors.jobCode}
              </span>
            )}
            {!errors.jobCode && duplicateWarning && (
              <span className="form-warning" role="status">
                {duplicateWarning}
              </span>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="jobTitle">Job Title *</label>
            <input
              type="text"
              id="jobTitle"
              name="jobTitle"
              value={formData.jobTitle}
              onChange={handleChange}
              onBlur={handleBlur}
              required
              className={errors.jobTitle ? 'input-error' : ''}
              aria-invalid={!!errors.jobTitle}
              aria-describedby={errors.jobTitle ? 'jobTitle-error' : undefined}
            />
            {errors.jobTitle && (
              <span id="jobTitle-error" className="form-error" role="alert">
                {errors.jobTitle}
              </span>
            )}
          </div>

          <div className="form-group">
            <label htmlFor="currentStatus">Current Status</label>
            <select
              id="currentStatus"
              name="currentStatus"
              value={formData.currentStatus}
              onChange={handleChange}
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>

          <div className="form-actions">
            <button type="button" className="btn-cancel" onClick={onCancel}>
              Cancel
            </button>
            <button type="submit" className="btn-submit">
              {jobCode ? 'Update Job Code' : 'Create Job Code'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default JobCodeForm;
