import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useDebounce } from '../utils/useDebounce';
import { getJobCategories, saveJobCategories, addJobCategoryAuditLog, addAuditLog, addAuditLogsBatch, generateId, getRoles, saveRoles, mergeRoles, getBlueprints, getTemplateLinks, getSailpointRoles } from '../utils/storage';
import {
  formatSailpointRoleRequestableDisplay,
  getNonRequestableSailpointRoleWarning,
  isNonRequestableSailpointCatalogRow,
  findSailpointCatalogRowByName,
  matchesSailpointRequestableFilter,
} from '../utils/sailpointRequestable';
import {
  buildRbacCodeCountByJobCategoryName,
  countRbacCodesForJobCategoryName,
} from '../utils/jobCategoryRbacCounts';
import {
  applyJobCategoryChangesToRoles,
  countRolesForCategories,
} from '../utils/jobCategoryRoleSync';
import { notifyRolesUpdated } from '../utils/rbacRolesRefresh';
import { normalizeRoleId, findRoleById } from '../utils/roleIdUtils';
import {
  findActiveRolesAssignedToCategory,
  findRolesAssignedToCategory,
  buildRoleReassignmentPlan,
} from '../utils/jobCategoryReassignment';
import { exportToCSV } from '../utils/csvExport';
import { importFromCSV } from '../utils/csvImport';
import { importFromExcel } from '../utils/excelImport';
import { sanitizeCellText } from '../utils/textSanitize';
import { useResizableColumns } from '../utils/useResizableColumns';
import JobCategoryForm from './JobCategoryForm';
import JobCategoryReassignDialog from './JobCategoryReassignDialog';
import FindReplaceDialog from './FindReplaceDialog';
import TableContextMenu from './TableContextMenu';
import ImportPreviewDialog from './ImportPreviewDialog';
import { useToast } from '../context/ToastContext';
import {
  dedupeTemplateListTokens,
  formatCommaSeparatedTemplateNamesUpper,
  formatTemplateNameTitleCase,
  normalizeSubtemplateCommaList,
  syncJobCategoryLinkableFromTemplateLinks,
  syncJobCategorySubtemplatesFromTemplateLinks,
} from '../utils/templateLinkRoleMatch';
import { normalizeSearchInput } from '../utils/searchInput';
import { buildLastEditStamp } from '../utils/lastEditStamp';
import { isCategoryEditedInLast24Hours } from '../utils/jobCategoryRoleSync';
import JobCategoryRoleSyncButton from './JobCategoryRoleSyncButton';
import { SYNC_SCOPE_ALL } from '../utils/jobCategoryRoleSync';
import './JobCategories.css';

const JOB_CAT_COL_WIDTHS_KEY = 'rbac_jobcat_table_col_widths_v1';
const JOB_CAT_DEFAULT_COL_WIDTHS = {
  __checkbox__: 40,
  jobCategoryId: 140,
  jobCategoryName: 200,
  organizationJobCategoryScope: 220,
  description: 220,
  owningApplication: 140,
  impactedApplications: 180,
  owningWorkgroup: 140,
  otherInterestedWorkgroups: 180,
  needEMP: 90,
  needSER: 90,
  linkableTemplateId: 160,
  linkableTemplateName: 240,
  subtemplatesId: 160,
  subtemplatesName: 240,
  blueprintId: 280,
  trainingTrack1: 140,
  trainingTrack2: 140,
  trainingTrack3: 140,
  trainingTrack4: 140,
  trainingTrack5: 140,
  trainingTrack6: 140,
  preLiveDayInTheLifeActivity: 180,
  postLiveDayInTheLifeActivity: 180,
  userSettingsLab: 140,
  sailpointRole: 180,
  status: 100,
  lastEditDateReasonInitials: 260,
  rbacCodeCount: 100,
  sailpointRequestable: 120,
  __actions__: 260,
};

// Template/subtemplate display: dedupe tokens; names use splitOnSpaces=false so multi-word phrases stay intact.
function templateSubtemplateOneLine(value, splitOnSpaces = true) {
  return dedupeTemplateListTokens(value, splitOnSpaces);
}

function isNullFilterToken(value) {
  const normalized = String(value || '').trim().toLowerCase();
  return normalized === 'null' || normalized === 'blank' || normalized === 'empty';
}

const SCOPE_FILTER_DEFAULT = 'In Scope for Organization';

const CAT_BULK_FIELDS = [
  { key: 'jobCategoryName', label: 'Job Category Name' },
  { key: 'organizationJobCategoryScope', label: 'Organization Job Category Scope' },
  { key: 'description', label: 'Description' },
  { key: 'owningApplication', label: 'Owning Application' },
  { key: 'impactedApplications', label: 'Impacted Application(s)' },
  { key: 'owningWorkgroup', label: 'Owning Workgroup' },
  { key: 'otherInterestedWorkgroups', label: 'Other Interested Workgroup(s)' },
  { key: 'needEMP', label: 'Need EMP?', type: 'select', options: ['Yes', 'No'] },
  { key: 'needSER', label: 'Need SER?', type: 'select', options: ['Yes', 'No'] },
  { key: 'linkableTemplateId', label: 'Linkable Template ID' },
  { key: 'linkableTemplateName', label: 'Template Description' },
  { key: 'subtemplatesId', label: 'Subtemplate ID' },
  { key: 'subtemplatesName', label: 'Subtemplate Description' },
  { key: 'blueprintId', label: 'Blueprint ID' },
  { key: 'blueprintName', label: 'Blueprint Name' },
  { key: 'trainingTrack1', label: 'Training Track 1' },
  { key: 'trainingTrack2', label: 'Training Track 2' },
  { key: 'trainingTrack3', label: 'Training Track 3' },
  { key: 'trainingTrack4', label: 'Training Track 4' },
  { key: 'trainingTrack5', label: 'Training Track 5' },
  { key: 'trainingTrack6', label: 'Training Track 6' },
  { key: 'preLiveDayInTheLifeActivity', label: 'Pre-live Day-in-the-Life Activity' },
  { key: 'postLiveDayInTheLifeActivity', label: 'Post-live Day-in-the-Life Activity' },
  { key: 'userSettingsLab', label: 'User Settings Lab' },
  { key: 'sailpointRole', label: 'Sailpoint Role' },
  { key: 'sailpointRoleReview', label: 'Sailpoint Review', type: 'select', options: ['Review'] },
  { key: 'status', label: 'Status', type: 'select', options: ['Active', 'Inactive'] },
];

const CatBulkUpdateDialog = ({ selectedCount, onApply, onClose }) => {
  const [field, setField] = useState('');
  const [value, setValue] = useState('');
  const fieldDef = CAT_BULK_FIELDS.find((f) => f.key === field);
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!field) { alert('Please select a field.'); return; }
    if (!window.confirm(`Set "${fieldDef?.label || field}" to "${value}" on ${selectedCount} category(ies)?`)) return;
    onApply(field, value);
  };
  return (
    <div className="find-replace-overlay" onClick={onClose}>
      <div className="find-replace-dialog" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 440 }}>
        <div className="find-replace-header">
          <h3>Bulk Update ({selectedCount} selected)</h3>
          <button type="button" className="find-replace-close" onClick={onClose}>&times;</button>
        </div>
        <form onSubmit={handleSubmit} style={{ padding: '1rem 1.25rem' }}>
          <div style={{ marginBottom: '0.75rem' }}>
            <label style={{ display: 'block', marginBottom: '0.25rem', fontWeight: 500, fontSize: '0.9rem' }}>Field</label>
            <select value={field} onChange={(e) => { setField(e.target.value); setValue(''); }} style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1' }}>
              <option value="">Select field...</option>
              {CAT_BULK_FIELDS.map((f) => <option key={f.key} value={f.key}>{f.label}</option>)}
            </select>
          </div>
          {field && (
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', marginBottom: '0.25rem', fontWeight: 500, fontSize: '0.9rem' }}>New Value</label>
              {fieldDef?.type === 'select' ? (
                <select value={value} onChange={(e) => setValue(e.target.value)} style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1' }} autoFocus>
                  <option value="">— (clear) —</option>
                  {fieldDef.options.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              ) : (
                <input type="text" value={value} onChange={(e) => setValue(e.target.value)} style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1', boxSizing: 'border-box' }} autoFocus placeholder="Enter new value (leave empty to clear)" />
              )}
            </div>
          )}
          <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
            <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn-primary" disabled={!field}>Apply</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const CAT_EDITABLE_FIELDS = [
  'jobCategoryId', 'jobCategoryName', 'organizationJobCategoryScope', 'description',
  'owningApplication', 'impactedApplications', 'owningWorkgroup', 'otherInterestedWorkgroups',
  'needEMP', 'needSER',
  'linkableTemplateId', 'linkableTemplateName', 'subtemplatesId', 'subtemplatesName',
  'blueprintId',
  'trainingTrack1', 'trainingTrack2', 'trainingTrack3', 'trainingTrack4', 'trainingTrack5', 'trainingTrack6',
  'preLiveDayInTheLifeActivity', 'postLiveDayInTheLifeActivity', 'userSettingsLab', 'sailpointRole',
  'status'
];

const JobCategories = ({ allowBulkActions = false, canAccessAdvanced = false, canSyncRoles = false }) => {
  const { showToast } = useToast();
  const [categories, setCategories] = useState([]);
  const [allRoles, setAllRoles] = useState([]);
  const [sailpointCatalog, setSailpointCatalog] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounce(searchTerm, 300);
  const [statusFilter, setStatusFilter] = useState('Active'); // 'All', 'Active', 'Inactive'
  const [scopeFilter, setScopeFilter] = useState(SCOPE_FILTER_DEFAULT); // 'All' or 'In Scope for Organization'
  const [recentlyEditedFilter, setRecentlyEditedFilter] = useState(false);
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  const [selectedRows, setSelectedRows] = useState(new Set());
  const [showAdvancedSearch, setShowAdvancedSearch] = useState(false);
  const [advancedFilters, setAdvancedFilters] = useState({});
  const debouncedAdvancedFilters = useDebounce(advancedFilters, 300);
  const [savedPresets, setSavedPresets] = useState([]);
  const [isImporting, setIsImporting] = useState(false);
  const [editingCategory, setEditingCategory] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [showFindReplace, setShowFindReplace] = useState(false);
  const [showBulkUpdate, setShowBulkUpdate] = useState(false);
  const [editingCell, setEditingCell] = useState(null);
  const [isDirty, setIsDirty] = useState(false);
  const [contextMenu, setContextMenu] = useState(null);
  const [importPreview, setImportPreview] = useState(null);
  const [reassignDialog, setReassignDialog] = useState(null); // { category, affectedRoles, allAffectedRoles }
  const [reassignBusy, setReassignBusy] = useState(false);
  const [pendingEditInactivation, setPendingEditInactivation] = useState(null); // { oldCategory, editedCategory, sourceCategoryName }
  const undoRef = useRef(null);
  const [canUndo, setCanUndo] = useState(false);
  const fileInputRef = useRef(null);
  const handleSaveRef = useRef(() => {});
  const { getWidth: getColWidth, startResize } = useResizableColumns(JOB_CAT_COL_WIDTHS_KEY);

  const colW = useCallback((key) => getColWidth(key, JOB_CAT_DEFAULT_COL_WIDTHS[key] ?? 160), [getColWidth]);
  const renderResizableTh = useCallback(
    (key, inner, thProps = {}) => {
      const widthNow = colW(key);
      const min = key === '__actions__' ? 200 : 80;
      const max = 900;
      return (
        <th {...thProps} className={`${thProps.className || ''} th-resizable`.trim()}>
          <div className="th-content">{inner}</div>
          {key !== '__checkbox__' && (
            <div
              className="col-resizer"
              role="separator"
              aria-orientation="vertical"
              onMouseDown={(e) => startResize(key, e, widthNow, min, max)}
              onClick={(e) => e.stopPropagation()}
            />
          )}
        </th>
      );
    },
    [colW, startResize]
  );

  const jobCatColumnKeys = useMemo(() => {
    const keys = [];
    if (allowBulkActions) keys.push('__checkbox__');
    keys.push(
      'jobCategoryId',
      'jobCategoryName',
      'organizationJobCategoryScope',
      'description',
      'owningApplication',
      'impactedApplications',
      'owningWorkgroup',
      'otherInterestedWorkgroups',
      'needEMP',
      'needSER',
      'linkableTemplateId',
      'linkableTemplateName',
      'subtemplatesId',
      'subtemplatesName',
      'blueprintId',
      'trainingTrack1',
      'trainingTrack2',
      'trainingTrack3',
      'trainingTrack4',
      'trainingTrack5',
      'trainingTrack6',
      'preLiveDayInTheLifeActivity',
      'postLiveDayInTheLifeActivity',
      'userSettingsLab',
      'sailpointRole',
      'status',
      'lastEditDateReasonInitials',
      'rbacCodeCount',
      'sailpointRequestable',
      '__actions__'
    );
    return keys;
  }, [allowBulkActions]);

  const loadRoleCounts = useCallback(async () => {
    try {
      const rows = await getRoles({ fresh: true });
      setAllRoles(Array.isArray(rows) ? rows : []);
    } catch (err) {
      console.error('Failed to load roles for category counts:', err);
    }
  }, []);

  const loadCategories = useCallback(async () => {
    try {
      const loadedCategories = await getJobCategories({ fresh: true });
      setCategories(Array.isArray(loadedCategories) ? loadedCategories : []);
    } catch (err) {
      console.error('Failed to load job categories:', err);
      showToast(err?.message || 'Failed to load job categories from server.', 'error');
    }
  }, [showToast]);

  useEffect(() => {
    loadCategories();
    loadRoleCounts();
    getSailpointRoles().then((rows) => {
      setSailpointCatalog(Array.isArray(rows) ? rows : []);
    });
  }, [loadCategories, loadRoleCounts]);

  const rbacCodeCountByCategoryName = useMemo(
    () => buildRbacCodeCountByJobCategoryName(allRoles),
    [allRoles]
  );

  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'h') {
        e.preventDefault();
        setShowFindReplace(true);
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 's' && canAccessAdvanced) {
        e.preventDefault();
        handleSaveRef.current();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [canAccessAdvanced]);

  useEffect(() => {
    if (!canAccessAdvanced || !isDirty) return;
    const handler = (e) => { e.preventDefault(); };
    window.addEventListener('beforeunload', handler);
    return () => window.removeEventListener('beforeunload', handler);
  }, [canAccessAdvanced, isDirty]);

  const handleSaveCategories = async () => {
    try {
      await saveJobCategories(categories);
      setIsDirty(false);
      showToast('Categories saved');
    } catch (err) {
      alert(err?.message || 'Failed to save.');
    }
  };
  handleSaveRef.current = handleSaveCategories;

  const snapshotForUndo = useCallback((description) => {
    undoRef.current = { data: [...categories], description };
    setCanUndo(true);
  }, [categories]);

  const handleUndo = async () => {
    if (!undoRef.current) return;
    const { data: prevData, description } = undoRef.current;
    if (!window.confirm(`Undo "${description}"?`)) return;
    setCategories(prevData);
    try {
      await saveJobCategories(prevData);
      undoRef.current = null;
      setCanUndo(false);
      loadCategories();
      showToast(`Undone: ${description}`);
    } catch (err) {
      alert(err?.message || 'Undo failed.');
    }
  };

  const updateCategoryField = async (categoryId, field, value) => {
    const category = categories.find((c) => c.id === categoryId);
    if (!category) return;
    const sanitized = typeof value === 'string' ? sanitizeCellText(value) : value;
    if (field === 'sailpointRole' && String(sanitized || '').trim()) {
      const warning = getNonRequestableSailpointRoleWarning(sanitized, sailpointCatalog);
      if (
        warning &&
        !window.confirm(
          `${warning}\n\nSave this Sailpoint role on the job category anyway?`
        )
      ) {
        return;
      }
    }
    snapshotForUndo(`Edit ${category.jobCategoryName || categoryId} → ${field}`);
    const oldData = { ...category };

    let updated = {
      ...category,
      lastEditDateReasonInitials: getLastEditValue(`Edited: ${field}`),
    };

    if (field === 'linkableTemplateId' || field === 'linkableTemplateName') {
      try {
        const tls = await getTemplateLinks();
        const links = Array.isArray(tls) ? tls : [];
        if (field === 'linkableTemplateId') {
          const synced = syncJobCategoryLinkableFromTemplateLinks(
            links,
            sanitized,
            category.linkableTemplateName || '',
            'id'
          );
          updated.linkableTemplateId = normalizeSubtemplateCommaList(synced.linkableTemplateId);
          updated.linkableTemplateName = normalizeSubtemplateCommaList(
            formatCommaSeparatedTemplateNamesUpper(
              synced.linkableTemplateName || category.linkableTemplateName || ''
            )
          );
        } else {
          const normalizedIn = normalizeSubtemplateCommaList(sanitized);
          const formattedForSync = formatCommaSeparatedTemplateNamesUpper(normalizedIn);
          const synced = syncJobCategoryLinkableFromTemplateLinks(
            links,
            category.linkableTemplateId || '',
            formattedForSync,
            'name'
          );
          updated.linkableTemplateId = normalizeSubtemplateCommaList(
            synced.linkableTemplateId || category.linkableTemplateId || ''
          );
          updated.linkableTemplateName = normalizeSubtemplateCommaList(
            formatCommaSeparatedTemplateNamesUpper(synced.linkableTemplateName || formattedForSync)
          );
        }
      } catch (err) {
        alert(err?.message || 'Failed to resolve template fields from Template Links.');
        return;
      }
    } else if (field === 'subtemplatesId' || field === 'subtemplatesName') {
      try {
        const tls = await getTemplateLinks();
        const links = Array.isArray(tls) ? tls : [];
        if (field === 'subtemplatesId') {
          const synced = syncJobCategorySubtemplatesFromTemplateLinks(
            links,
            sanitized,
            category.subtemplatesName || '',
            'id'
          );
          updated.subtemplatesId = normalizeSubtemplateCommaList(synced.subtemplatesId);
          updated.subtemplatesName = normalizeSubtemplateCommaList(
            formatCommaSeparatedTemplateNamesUpper(
              synced.subtemplatesName || category.subtemplatesName || ''
            )
          );
        } else {
          const normalizedIn = normalizeSubtemplateCommaList(sanitized);
          const formattedForSync = formatCommaSeparatedTemplateNamesUpper(normalizedIn);
          const synced = syncJobCategorySubtemplatesFromTemplateLinks(
            links,
            category.subtemplatesId || '',
            formattedForSync,
            'name'
          );
          updated.subtemplatesId = normalizeSubtemplateCommaList(
            synced.subtemplatesId || category.subtemplatesId || ''
          );
          updated.subtemplatesName = normalizeSubtemplateCommaList(
            formatCommaSeparatedTemplateNamesUpper(synced.subtemplatesName || formattedForSync)
          );
        }
      } catch (err) {
        alert(err?.message || 'Failed to resolve subtemplate fields from Template Links.');
        return;
      }
    } else {
      updated[field] = sanitized;
    }
    const updatedCategories = categories.map((c) => (c.id === categoryId ? updated : c));
    setCategories(updatedCategories);
    setIsDirty(true);
    try {
      const saveResult = await saveJobCategories(updatedCategories);
      await addJobCategoryAuditLog('UPDATE', updated, oldData);
      setEditingCell(null);
      await propagateCategoryChangesToRoles([updated], {
        saveResult,
        previousNamesByCategoryId:
          field === 'jobCategoryName' ? { [categoryId]: oldData.jobCategoryName } : {},
      });
    } catch (err) {
      alert(err?.message || 'Failed to save. Check the server and try again.');
    }
  };

  const handleDuplicateCategory = async (category) => {
    snapshotForUndo(`Duplicate category ${category.jobCategoryName || category.id}`);
    const clone = {
      ...category,
      id: generateId(),
      lastEditDateReasonInitials: getLastEditValue('Duplicated category'),
    };
    const updated = [...categories];
    const idx = updated.findIndex((c) => c.id === category.id);
    updated.splice(idx + 1, 0, clone);
    setCategories(updated);
    setIsDirty(true);
    try {
      await saveJobCategories(updated);
      await addJobCategoryAuditLog('CREATE', clone);
      showToast(`Duplicated category ${category.jobCategoryName || ''}`);
    } catch (err) {
      alert(err?.message || 'Duplicate failed.');
    }
  };

  const handleCopyRow = (category) => {
    const fields = CAT_EDITABLE_FIELDS;
    const values = fields.map((f) => (category[f] ?? '').toString().replace(/\t/g, ' '));
    const header = fields.join('\t');
    const row = values.join('\t');
    navigator.clipboard.writeText(`${header}\n${row}`).then(
      () => showToast('Row copied to clipboard'),
      () => alert('Failed to copy to clipboard')
    );
  };

  // Memoize filtered categories to prevent unnecessary recalculations and memory issues
  const filteredCategories = useMemo(() => {
    let filtered = categories;

    // Apply status filter
    if (statusFilter !== 'All') {
      filtered = filtered.filter((category) => (category.status || 'Active') === statusFilter);
    }

    // Apply organization job category scope filter (default: In Scope for Organization)
    if (scopeFilter !== 'All') {
      filtered = filtered.filter(
        (category) => (category.organizationJobCategoryScope || '').trim() === scopeFilter
      );
    }

    if (recentlyEditedFilter) {
      filtered = filtered.filter(isCategoryEditedInLast24Hours);
    }

    const requestableFilter = debouncedAdvancedFilters.sailpointRequestable || 'All';
    if (requestableFilter !== 'All') {
      filtered = filtered.filter((category) =>
        matchesSailpointRequestableFilter(
          category.sailpointRole,
          sailpointCatalog,
          requestableFilter
        )
      );
    }

    // Apply advanced filters (using debounced value)
    Object.keys(debouncedAdvancedFilters).forEach((field) => {
      if (field === 'sailpointRequestable') return;
      const filterValue = debouncedAdvancedFilters[field];
      if (filterValue && filterValue.trim()) {
        const term = filterValue.toLowerCase();
        const useNullFilter = isNullFilterToken(term);
        filtered = filtered.filter((category) => {
          if (field === 'blueprintId') {
            if (useNullFilter) {
              const blueprintId = category.blueprintId;
              const blueprintName = category.blueprintName;
              return (
                (blueprintId == null || String(blueprintId).trim() === '') &&
                (blueprintName == null || String(blueprintName).trim() === '')
              );
            }
            const combined = [category.blueprintId, category.blueprintName].filter(Boolean).join(' ').toLowerCase();
            return combined.includes(term);
          }
          const value = category[field];
          if (useNullFilter) return value == null || String(value).trim() === '';
          return value && value.toString().toLowerCase().includes(term);
        });
      }
    });

    // Apply search term filter (if no advanced filters, using debounced value)
    if (debouncedSearchTerm.trim() && Object.keys(debouncedAdvancedFilters).length === 0) {
      const term = debouncedSearchTerm.trim().toLowerCase();
      filtered = filtered.filter((category) =>
        Object.values(category).some((value) =>
          value && value.toString().toLowerCase().includes(term)
        )
      );
    }

    // Apply sorting
    if (sortConfig.key) {
      filtered = [...filtered].sort((a, b) => {
        if (sortConfig.key === 'rbacCodeCount') {
          const aCount = countRbacCodesForJobCategoryName(
            rbacCodeCountByCategoryName,
            a.jobCategoryName
          );
          const bCount = countRbacCodesForJobCategoryName(
            rbacCodeCountByCategoryName,
            b.jobCategoryName
          );
          return sortConfig.direction === 'asc' ? aCount - bCount : bCount - aCount;
        }
        if (sortConfig.key === 'sailpointRequestable') {
          const aVal = formatSailpointRoleRequestableDisplay(a.sailpointRole, sailpointCatalog);
          const bVal = formatSailpointRoleRequestableDisplay(b.sailpointRole, sailpointCatalog);
          if (sortConfig.direction === 'asc') {
            return aVal.localeCompare(bVal);
          }
          return bVal.localeCompare(aVal);
        }
        const aValue = a[sortConfig.key] || '';
        const bValue = b[sortConfig.key] || '';
        if (sortConfig.direction === 'asc') {
          return aValue.toString().localeCompare(bValue.toString());
        }
        return bValue.toString().localeCompare(aValue.toString());
      });
    }

    return filtered;
  }, [
    categories,
    debouncedSearchTerm,
    statusFilter,
    scopeFilter,
    recentlyEditedFilter,
    debouncedAdvancedFilters,
    sortConfig,
    rbacCodeCountByCategoryName,
    sailpointCatalog,
  ]);

  const MAX_RENDERED_ROWS = 400;
  const categoriesToRender = useMemo(() => {
    if (filteredCategories.length <= MAX_RENDERED_ROWS) return filteredCategories;
    return filteredCategories.slice(0, MAX_RENDERED_ROWS);
  }, [filteredCategories]);

  const handleSort = (key) => {
    setSortConfig((prev) => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc',
    }));
  };

  const clearFilters = () => {
    setSearchTerm('');
    setStatusFilter('All');
    setScopeFilter('All');
    setRecentlyEditedFilter(false);
    setAdvancedFilters({});
    setShowAdvancedSearch(false);
    setSelectedRows(new Set());
  };

  const saveFilterPreset = () => {
    const presetName = window.prompt('Enter a name for this filter preset:');
    if (!presetName) return;

    const preset = {
      id: Date.now().toString(),
      name: presetName,
      searchTerm,
      statusFilter,
      scopeFilter,
      advancedFilters: { ...advancedFilters },
    };

    const presets = JSON.parse(localStorage.getItem('jobcat_filter_presets') || '[]');
    presets.push(preset);
    localStorage.setItem('jobcat_filter_presets', JSON.stringify(presets));
    setSavedPresets(presets);
    showToast('Filter preset saved!');
  };

  const loadFilterPreset = (preset) => {
    setSearchTerm(normalizeSearchInput(preset.searchTerm || ''));
    setStatusFilter(preset.statusFilter || 'All');
    setScopeFilter(preset.scopeFilter ?? SCOPE_FILTER_DEFAULT);
    const presetAdvanced = { ...(preset.advancedFilters || {}) };
    if (
      preset.requestableFilter &&
      preset.requestableFilter !== 'All' &&
      !presetAdvanced.sailpointRequestable
    ) {
      presetAdvanced.sailpointRequestable = preset.requestableFilter;
    }
    setAdvancedFilters(presetAdvanced);
    if (Object.keys(presetAdvanced).length > 0) {
      setShowAdvancedSearch(true);
    }
  };

  const deleteFilterPreset = (presetId) => {
    if (window.confirm('Delete this filter preset?')) {
      const presets = savedPresets.filter(p => p.id !== presetId);
      localStorage.setItem('jobcat_filter_presets', JSON.stringify(presets));
      setSavedPresets(presets);
    }
  };

  useEffect(() => {
    const presets = JSON.parse(localStorage.getItem('jobcat_filter_presets') || '[]');
    setSavedPresets(presets);
  }, []);

  const handleAdd = () => {
    setEditingCategory(null);
    setShowForm(true);
  };

  const handleEdit = (category) => {
    setEditingCategory(category);
    setShowForm(true);
  };

  const handleDelete = async (category) => {
    if (window.confirm('Are you sure you want to delete this job category?')) {
      snapshotForUndo(`Delete category ${category.jobCategoryName || category.id}`);
      const prevCategories = categories;
      const updatedCategories = categories.filter((c) => c.id !== category.id);
      setCategories(updatedCategories);
      try {
        await saveJobCategories(updatedCategories);
        await addJobCategoryAuditLog('DELETE', category, category);
        loadCategories();
      } catch (err) {
        setCategories(prevCategories);
        await loadCategories();
        alert(err?.message || 'Failed to delete category. Check the server and try again.');
      }
    }
  };

  const propagateCategoryChangesToRoles = async (changedCategories, options = {}) => {
    if (!changedCategories?.length && options.saveResult?.rolesUpdated == null) return;
    const previousNamesByCategoryId = options.previousNamesByCategoryId || {};
    const serverRolesUpdated = options.saveResult?.rolesUpdated;
    const rolePropagationError = options.saveResult?.rolePropagationError;

    try {
      if (rolePropagationError) {
        showToast(
          `Job category saved, but updating linked roles failed: ${rolePropagationError}`,
          'error'
        );
      }
      // Server propagates on POST /api/job-categories; refresh UI when we have a count.
      if (typeof serverRolesUpdated === 'number') {
        if (serverRolesUpdated > 0) {
          const roles = await getRoles({ fresh: true });
          setAllRoles(roles);
          notifyRolesUpdated(roles);
          showToast(`Updated ${serverRolesUpdated} linked role(s) from job category changes`);
          return;
        }
        if (!changedCategories?.length || options.warnWhenNoRoleChanges === false) return;
        const [roles, allCategories] = await Promise.all([
          getRoles({ fresh: true }),
          getJobCategories({ fresh: true }),
        ]);
        const assignedCount = countRolesForCategories(roles, changedCategories, allCategories);
        if (assignedCount > 0) {
          showToast(
            `Job category saved. ${assignedCount} linked role(s) already matched — no role field changes were needed.`,
            'info'
          );
        }
        return;
      }

      // Fallback for older servers without server-side propagation.
      const [roles, bps, tls, allCategories] = await Promise.all([
        getRoles({ fresh: true }),
        getBlueprints(),
        getTemplateLinks(),
        getJobCategories({ fresh: true }),
      ]);
      if (!roles || roles.length === 0) return;
      const templateLinks = Array.isArray(tls) ? tls : [];
      const editStamp = getLastEditValue('Synced from Job Category update');
      const { updatedRoles, affectedIds } = applyJobCategoryChangesToRoles(roles, changedCategories, {
        jobCategories: allCategories,
        blueprints: bps || [],
        templateLinks,
        previousNamesByCategoryId,
      });
      if (affectedIds.size > 0) {
        const isAffected = (role) => affectedIds.has(String(role.id ?? '').trim());
        const stampedRoles = updatedRoles.map((role) =>
          isAffected(role)
            ? { ...role, lastEditChangeControlDateReason: editStamp }
            : role
        );
        const rolePatches = stampedRoles.filter((role) => {
          if (!isAffected(role)) return false;
          const old = roles.find((r) => String(r.id) === String(role.id));
          return old && JSON.stringify(old) !== JSON.stringify(role);
        });
        if (rolePatches.length > 0) await mergeRoles(rolePatches);
        setAllRoles(stampedRoles);
        for (const role of stampedRoles) {
          if (!isAffected(role)) continue;
          const old = roles.find((r) => String(r.id) === String(role.id));
          if (old) await addAuditLog('UPDATE', role, old);
        }
        notifyRolesUpdated(stampedRoles);
        const affectedCodes = stampedRoles
          .filter((r) => isAffected(r))
          .map((r) => r.rbacCode || r.id)
          .sort();
        const preview = affectedCodes.length <= 10
          ? affectedCodes.join(', ')
          : `${affectedCodes.slice(0, 10).join(', ')} … and ${affectedCodes.length - 10} more`;
        showToast(`Updated ${affectedCodes.length} role(s): ${preview}`);
        return;
      }
      const assignedCount = countRolesForCategories(roles, changedCategories, allCategories);
      if (assignedCount > 0 && options.warnWhenNoRoleChanges !== false) {
        showToast(
          `Job category saved. ${assignedCount} linked role(s) already matched — no role field changes were needed.`,
          'info'
        );
      }
    } catch (err) {
      console.error('Failed to propagate category changes to roles:', err);
      showToast(err?.message || 'Job category saved, but updating linked roles failed.', 'error');
      throw err;
    }
  };

  // Persist a category status flip + audit + toast. Shared by direct toggle and post-reassignment flow.
  const persistCategoryStatusChange = async (category, newStatus, { undoLabel, toastMessage, categoryOverride } = {}) => {
    if (undoLabel) snapshotForUndo(undoLabel);
    const existing = categories.find((c) => c.id === category.id) || category;
    const oldData = { ...existing };
    const updated = { ...(categoryOverride || category), status: newStatus };
    const updatedCategories = categories.map((c) => (c.id === category.id ? updated : c));
    setCategories(updatedCategories);
    await saveJobCategories(updatedCategories);
    await addJobCategoryAuditLog('UPDATE', updated, oldData);
    loadCategories();
    if (toastMessage !== null) {
      showToast(toastMessage || `Category set to ${newStatus}`);
    }
    return updated;
  };

  const handleToggleStatus = async (category) => {
    const currentStatus = (category.status || 'Active').trim();
    const newStatus = currentStatus === 'Inactive' ? 'Active' : 'Inactive';
    // When moving Active -> Inactive, check for assigned active RBAC roles and offer reassignment.
    if (newStatus === 'Inactive') {
      try {
        const roles = await getRoles({ fresh: true });
        const activeAffected = findActiveRolesAssignedToCategory(roles, category.jobCategoryName);
        const allAffected = findRolesAssignedToCategory(roles, category.jobCategoryName);
        if (allAffected.length > 0) {
          setReassignDialog({
            category,
            sourceCategoryName: category.jobCategoryName,
            affectedRoles: activeAffected,
            allAffectedRoles: allAffected,
          });
          setPendingEditInactivation(null);
          return;
        }
      } catch (err) {
        console.error('Failed to load roles for reassignment check:', err);
      }
    }
    await persistCategoryStatusChange(category, newStatus, {
      undoLabel: `Toggle status ${category.jobCategoryName || category.id}`,
    });
  };

  const handleReassignCancel = () => {
    if (reassignBusy) return;
    if (pendingEditInactivation?.editedCategory) {
      setEditingCategory(pendingEditInactivation.editedCategory);
      setShowForm(true);
    }
    setPendingEditInactivation(null);
    setReassignDialog(null);
  };

  const handleReassignInactivateOnly = async () => {
    if (!reassignDialog || reassignBusy) return;
    const { category } = reassignDialog;
    const editedOverride = pendingEditInactivation?.editedCategory?.id === category.id
      ? pendingEditInactivation.editedCategory
      : null;
    setReassignBusy(true);
    try {
      await persistCategoryStatusChange(category, 'Inactive', {
        undoLabel: `Inactivate ${category.jobCategoryName || category.id} (no reassignment)`,
        toastMessage: `Inactivated ${category.jobCategoryName || category.id}. Assigned roles were left unchanged.`,
        categoryOverride: editedOverride,
      });
      setPendingEditInactivation(null);
      setReassignDialog(null);
    } catch (err) {
      console.error('Inactivate failed:', err);
      alert(err?.message || 'Inactivate failed.');
    } finally {
      setReassignBusy(false);
    }
  };

  const handleReassignConfirm = async (targetCategory, { includeInactive = false } = {}) => {
    if (!reassignDialog || !targetCategory || reassignBusy) return;
    const { category } = reassignDialog;
    const sourceCategoryName = reassignDialog.sourceCategoryName || category.jobCategoryName;
    const editedOverride = pendingEditInactivation?.editedCategory?.id === category.id
      ? pendingEditInactivation.editedCategory
      : null;
    setReassignBusy(true);
    try {
      const [roles, bps, tls] = await Promise.all([
        getRoles({ fresh: true }),
        getBlueprints(),
        getTemplateLinks(),
      ]);
      const editStamp = getLastEditValue(`Reassigned from job category "${sourceCategoryName}" -> "${targetCategory.jobCategoryName}"`);
      const { updatedRoles, affectedRoleIds, oldByRoleId } = buildRoleReassignmentPlan({
        roles: roles || [],
        fromCategoryName: sourceCategoryName,
        toCategory: targetCategory,
        blueprints: bps || [],
        templateLinks: Array.isArray(tls) ? tls : [],
        editStamp,
        includeInactive,
      });
      if (affectedRoleIds.size === 0) {
        // Nothing to reassign - fall through to plain inactivation.
        await persistCategoryStatusChange(category, 'Inactive', {
          undoLabel: `Inactivate ${category.jobCategoryName || category.id}`,
          toastMessage: `No matching roles found to reassign. Category inactivated.`,
          categoryOverride: editedOverride,
        });
        setPendingEditInactivation(null);
        setReassignDialog(null);
        return;
      }
      snapshotForUndo(`Reassign ${affectedRoleIds.size} role(s) and inactivate ${category.jobCategoryName || category.id}`);
      const isAffectedId = (id) => affectedRoleIds.has(normalizeRoleId(id));
      const rolePatches = updatedRoles.filter((role) => {
        if (!isAffectedId(role.id)) return false;
        const old = oldByRoleId.get(normalizeRoleId(role.id)) || findRoleById(roles, role.id);
        return old && JSON.stringify(old) !== JSON.stringify(role);
      });
      if (rolePatches.length > 0) await mergeRoles(rolePatches);
      const refreshedRoles = await getRoles({ fresh: true });
      setAllRoles(refreshedRoles);
      notifyRolesUpdated(refreshedRoles);
      for (const role of rolePatches) {
        const old = oldByRoleId.get(normalizeRoleId(role.id));
        try {
          await addAuditLog('UPDATE', role, old);
        } catch (err) {
          console.error('Failed to add role audit log during reassignment:', err);
        }
      }
      await persistCategoryStatusChange(category, 'Inactive', {
        toastMessage: `Reassigned ${affectedRoleIds.size} role(s) to "${targetCategory.jobCategoryName}" and inactivated "${category.jobCategoryName}".`,
        categoryOverride: editedOverride,
      });
      setPendingEditInactivation(null);
      setReassignDialog(null);
    } catch (err) {
      console.error('Role reassignment failed:', err);
      alert(err?.message || 'Reassignment failed. The category was not inactivated.');
    } finally {
      setReassignBusy(false);
    }
  };

  const handleInactivateConnectedRolesAndCategory = async () => {
    if (!reassignDialog || reassignBusy) return;
    const { category, allAffectedRoles = [] } = reassignDialog;
    const sourceCategoryName = reassignDialog.sourceCategoryName || category.jobCategoryName;
    const editedOverride = pendingEditInactivation?.editedCategory?.id === category.id
      ? pendingEditInactivation.editedCategory
      : null;
    const total = allAffectedRoles.length;
    if (total === 0) {
      await handleReassignInactivateOnly();
      return;
    }
    const activeCount = allAffectedRoles.filter((r) => (r.status || 'Active') !== 'Inactive').length;
    if (
      !window.confirm(
        `This will set ${total} connected role(s) to Inactive for "${category.jobCategoryName}".\n` +
          `(${activeCount} active, ${total - activeCount} inactive)\n\nContinue?`
      )
    ) {
      return;
    }
    setReassignBusy(true);
    try {
      const roles = await getRoles({ fresh: true });
      const toInactivate = findRolesAssignedToCategory(roles, sourceCategoryName);
      if (toInactivate.length === 0) {
        await persistCategoryStatusChange(category, 'Inactive', {
          undoLabel: `Inactivate ${category.jobCategoryName || category.id}`,
          toastMessage: `No connected roles found. Category inactivated.`,
          categoryOverride: editedOverride,
        });
        setPendingEditInactivation(null);
        setReassignDialog(null);
        return;
      }
      const targetIds = new Set(toInactivate.map((r) => String(r.id)));
      const roleEditStamp = getLastEditValue(`Set inactive via category inactivation "${category.jobCategoryName}"`);
      const oldByRoleId = new Map(toInactivate.map((r) => [r.id, r]));
      const rolePatches = toInactivate.map((r) => ({
        ...r,
        status: 'Inactive',
        lastEditChangeControlDateReason: roleEditStamp,
      }));
      snapshotForUndo(`Inactivate ${toInactivate.length} connected role(s) and inactivate ${category.jobCategoryName || category.id}`);
      await mergeRoles(rolePatches);
      const refreshedRoles = await getRoles({ fresh: true });
      setAllRoles(refreshedRoles);
      notifyRolesUpdated(refreshedRoles);
      await addAuditLogsBatch(rolePatches
        .map((role) => ({
          entityType: 'ROLE',
          action: 'UPDATE',
          entityData: role,
          oldData: oldByRoleId.get(role.id) || null,
        })));
      await persistCategoryStatusChange(category, 'Inactive', {
        toastMessage: `Set ${toInactivate.length} connected role(s) to Inactive and inactivated "${category.jobCategoryName}".`,
        categoryOverride: editedOverride,
      });
      setPendingEditInactivation(null);
      setReassignDialog(null);
    } catch (err) {
      console.error('Inactivate connected roles + category failed:', err);
      alert(err?.message || 'Failed to inactivate connected roles and category.');
    } finally {
      setReassignBusy(false);
    }
  };

  const handleFormSubmit = async (categoryData) => {
    if (
      editingCategory &&
      (editingCategory.status || 'Active').trim() !== 'Inactive' &&
      (categoryData.status || 'Active').trim() === 'Inactive'
    ) {
      try {
        const roles = await getRoles({ fresh: true });
        const sourceCategoryName = editingCategory.jobCategoryName;
        const activeAffected = findActiveRolesAssignedToCategory(roles, sourceCategoryName);
        const allAffected = findRolesAssignedToCategory(roles, sourceCategoryName);
        if (allAffected.length > 0) {
          const editedCategory = { ...categoryData, id: editingCategory.id };
          setPendingEditInactivation({ oldCategory: editingCategory, editedCategory, sourceCategoryName });
          setReassignDialog({
            category: editedCategory,
            sourceCategoryName,
            affectedRoles: activeAffected,
            allAffectedRoles: allAffected,
          });
          setShowForm(false);
          return;
        }
      } catch (err) {
        console.error('Failed to load roles for edit-form inactivation check:', err);
      }
    }
    snapshotForUndo(editingCategory ? `Edit category ${editingCategory.jobCategoryName || editingCategory.id}` : 'Create new category');
    try {
      if (editingCategory) {
        // Update existing category
        const oldData = { ...editingCategory };
        const updatedCategory = { ...categoryData, id: editingCategory.id };
        const updatedCategories = categories.map((c) =>
          c.id === editingCategory.id ? updatedCategory : c
        );
        setCategories(updatedCategories);
        const saveResult = await saveJobCategories(updatedCategories);
        await addJobCategoryAuditLog('UPDATE', updatedCategory, oldData);

        const categoryName = (updatedCategory.jobCategoryName || '').trim();
        if (categoryName) {
          try {
            await propagateCategoryChangesToRoles([updatedCategory], {
              saveResult,
              previousNamesByCategoryId: {
                [editingCategory.id]: editingCategory.jobCategoryName,
              },
            });
          } catch (err) {
            console.error('Failed to update roles with job category:', err);
            showToast('Job category saved, but updating linked roles failed.', 'error');
          }
        }
        showToast(`Updated category ${updatedCategory.jobCategoryName || ''}`);
      } else {
        // Create new category
        const newCategory = { ...categoryData, id: generateId() };
        const updatedCategories = [...categories, newCategory];
        setCategories(updatedCategories);
        await saveJobCategories(updatedCategories);
        await addJobCategoryAuditLog('CREATE', newCategory);
        showToast(`Created category ${newCategory.jobCategoryName || ''}`);
      }
      setShowForm(false);
      setEditingCategory(null);
      loadRoleCounts();
    } catch (err) {
      console.error('Failed to save job category:', err);
      alert(err?.message || 'Failed to save job category. Check the server and try again.');
    }
  };

  const handleExport = () => {
    // Map field names to CSV header names
    const fieldToHeaderMap = {
      'jobCategoryId': 'Job Category ID',
      'jobCategoryName': 'Job Category Name',
      'organizationJobCategoryScope': 'Organization Job Category Scope',
      'description': 'Description',
      'owningApplication': 'Owning Application',
      'impactedApplications': 'Impacted Application(s)',
      'owningWorkgroup': 'Owning Workgroup',
      'otherInterestedWorkgroups': 'Other Interested Workgroup(s)',
      'needEMP': 'Need EMP?',
      'needSER': 'Need SER?',
      'linkableTemplateId': 'Linkable Template ID',
      'linkableTemplateName': 'Template Description',
      'subtemplatesId': 'Subtemplate ID',
      'subtemplatesName': 'Subtemplate Description',
      'blueprintId': 'Blueprint ID',
      'blueprintName': 'Blueprint Name',
      'trainingTrack1': 'Training Track 1',
      'trainingTrack2': 'Training Track 2',
      'trainingTrack3': 'Training Track 3',
      'trainingTrack4': 'Training Track 4',
      'trainingTrack5': 'Training Track 5',
      'trainingTrack6': 'Training Track 6',
      'preLiveDayInTheLifeActivity': 'Pre-live Day-in-the-Life Activity',
      'postLiveDayInTheLifeActivity': 'Post-live Day-in-the-Life Activity',
      'userSettingsLab': 'User Settings Lab',
      'sailpointRole': 'Sailpoint Role',
      'sailpointRoleReview': 'Sailpoint Review',
      'status': 'Status',
      'lastEditDateReasonInitials': 'Last Edit Date/Reason/Initials',
      rbacCodeCount: 'RBAC Codes',
      sailpointRequestable: 'Sailpoint Requestable',
    };

    const fieldNames = Object.keys(fieldToHeaderMap);
    const csvHeaders = Object.values(fieldToHeaderMap);

    // Export filtered results only
    const exportData = filteredCategories.map((category) => {
      const row = {};
      fieldNames.forEach((fieldName) => {
        row[fieldToHeaderMap[fieldName]] = category[fieldName] || '';
      });
      row['RBAC Codes'] = countRbacCodesForJobCategoryName(
        rbacCodeCountByCategoryName,
        category.jobCategoryName
      );
      row['Sailpoint Requestable'] = formatSailpointRoleRequestableDisplay(
        category.sailpointRole,
        sailpointCatalog
      );
      return row;
    });

    const count = exportData.length;
    if (count >= 500) {
      showToast('Preparing export…');
      setTimeout(() => {
        try {
          exportToCSV(exportData, 'job_categories.csv', csvHeaders);
          showToast(`Exported ${count} categor${count === 1 ? 'y' : 'ies'}`);
        } catch (e) {
          showToast('Export failed');
        }
      }, 0);
    } else {
      exportToCSV(exportData, 'job_categories.csv', csvHeaders);
      showToast(`Exported ${count} categor${count === 1 ? 'y' : 'ies'}`);
    }
  };

  const getLastEditValue = (detail) => buildLastEditStamp(detail);

  const handleBulkStatusChange = () => {
    if (selectedRows.size === 0) {
      alert('Please select categories to change status');
      return;
    }

    const newStatus = window.prompt('Enter new status (Active/Inactive):');
    if (!newStatus || (newStatus !== 'Active' && newStatus !== 'Inactive')) {
      alert('Invalid status. Must be "Active" or "Inactive"');
      return;
    }

    (async () => {
      snapshotForUndo(`Bulk status ${selectedRows.size} category(ies) → ${newStatus}`);
      const lastEditValue = getLastEditValue('Bulk status change');
      const updatedCategories = categories.map(category => {
        if (selectedRows.has(category.id)) {
          return { ...category, status: newStatus, lastEditDateReasonInitials: lastEditValue };
        }
        return category;
      });

      const updatedCount = selectedRows.size;
      for (const category of categories) {
        if (selectedRows.has(category.id)) {
          const oldData = { ...category };
          const updated = updatedCategories.find((c) => c.id === category.id);
          await addJobCategoryAuditLog('UPDATE', updated, oldData);
        }
      }

      setCategories(updatedCategories);
      await saveJobCategories(updatedCategories);
      setSelectedRows(new Set());
      loadCategories();
      showToast(`Updated ${updatedCount} category(ies) to ${newStatus}`);
    })();
  };

  const handleRowSelect = (categoryId, e) => {
    e.stopPropagation();
    setSelectedRows(prev => {
      const newSet = new Set(prev);
      if (newSet.has(categoryId)) {
        newSet.delete(categoryId);
      } else {
        newSet.add(categoryId);
      }
      return newSet;
    });
  };

  // Select-all applies only to visible (capped) rows so bulk actions don't affect hidden rows
  const allVisibleSelected =
    categoriesToRender.length > 0 && categoriesToRender.every((c) => selectedRows.has(c.id));

  const handleSelectAll = () => {
    if (allVisibleSelected) {
      setSelectedRows(new Set());
    } else {
      setSelectedRows(new Set(categoriesToRender.map((c) => c.id)));
    }
  };

  const handleDeleteSelected = async () => {
    if (selectedRows.size === 0) return;
    if (!window.confirm(`Delete ${selectedRows.size} selected category(ies)?`)) return;
    snapshotForUndo(`Bulk delete ${selectedRows.size} category(ies)`);
    const updated = categories.filter((c) => !selectedRows.has(c.id));
    setCategories(updated);
    try {
      await saveJobCategories(updated);
      for (const c of categories) {
        if (selectedRows.has(c.id)) await addJobCategoryAuditLog('DELETE', c, c);
      }
      const count = selectedRows.size;
      setSelectedRows(new Set());
      loadCategories();
      showToast(`Deleted ${count} category(ies).`);
    } catch (err) {
      alert(err?.message || 'Delete failed.');
    }
  };

  const handleBulkUpdate = async (field, value) => {
    if (selectedRows.size === 0) return;
    if (field === 'sailpointRole' && String(value || '').trim()) {
      const warning = getNonRequestableSailpointRoleWarning(value, sailpointCatalog);
      if (
        warning &&
        !window.confirm(
          `${warning}\n\nApply this Sailpoint role to ${selectedRows.size} selected categor${
            selectedRows.size === 1 ? 'y' : 'ies'
          } anyway?`
        )
      ) {
        return;
      }
    }
    snapshotForUndo(`Bulk update ${selectedRows.size} category(ies) → ${field}`);
    const prevData = categories;
    const lastEditValue = getLastEditValue(`Bulk update (categories): ${field}`);
    const updated = categories.map((c) => {
      if (!selectedRows.has(c.id)) return c;
      const patch = { [field]: value, lastEditDateReasonInitials: lastEditValue };
      if (field === 'sailpointRole' && String(value || '').trim()) {
        patch.sailpointRoleReview = '';
      }
      return { ...c, ...patch };
    });
    setCategories(updated);
    try {
      const saveResult = await saveJobCategories(updated);
      for (const c of updated) {
        if (selectedRows.has(c.id)) {
          const old = prevData.find((o) => o.id === c.id);
          if (old) await addJobCategoryAuditLog('UPDATE', c, old);
        }
      }
      const changedCats = updated.filter((c) => selectedRows.has(c.id));
      const previousNamesByCategoryId = {};
      if (field === 'jobCategoryName') {
        for (const id of selectedRows) {
          const old = prevData.find((c) => c.id === id);
          if (old?.jobCategoryName) previousNamesByCategoryId[id] = old.jobCategoryName;
        }
      }
      await propagateCategoryChangesToRoles(changedCats, { saveResult, previousNamesByCategoryId });
      const count = selectedRows.size;
      setSelectedRows(new Set());
      loadCategories();
      showToast(`Updated ${count} category(ies).`);
    } catch (err) {
      alert(err?.message || 'Update failed.');
    }
    setShowBulkUpdate(false);
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const name = (file.name || '').toLowerCase();
    const isCsv = name.endsWith('.csv');
    const isExcel = name.endsWith('.xlsx') || name.endsWith('.xls');
    if (!isCsv && !isExcel) {
      alert('Please select a CSV or Excel file (.csv, .xlsx, .xls)');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    // Map CSV/Excel header names to field names
    const headerMapping = {
      'Job Category ID': 'jobCategoryId',
      'Job Category Name': 'jobCategoryName',
      'job_category': 'jobCategoryName',
      'Organization Job Category Scope': 'organizationJobCategoryScope',
      'Description': 'description',
      'Owning Application': 'owningApplication',
      'Impacted Application(s)': 'impactedApplications',
      'Owning Workgroup': 'owningWorkgroup',
      'Other Interested Workgroup(s)': 'otherInterestedWorkgroups',
      'Need EMP?': 'needEMP',
      'Need SER?': 'needSER',
      'Linkable Template ID': 'linkableTemplateId',
      'Linkable Template Name': 'linkableTemplateName',
      'Template Description': 'linkableTemplateName',
      'Subtemplate ID': 'subtemplatesId',
      'Subtemplate Description': 'subtemplatesName',
      'Subtemplate description': 'subtemplatesName',
      'Subtemplate(s) ID': 'subtemplatesId',
      'Subtemplate(s) Name': 'subtemplatesName',
      'Blueprint ID': 'blueprintId',
      'Blueprint Name': 'blueprintName',
      'Training Track 1': 'trainingTrack1',
      'Training Track 2': 'trainingTrack2',
      'Training Track 3': 'trainingTrack3',
      'Training Track 4': 'trainingTrack4',
      'Training Track 5': 'trainingTrack5',
      'Training Track 6': 'trainingTrack6',
      'Pre-live Day-in-the-Life Activity': 'preLiveDayInTheLifeActivity',
      'Post-live Day-in-the-Life Activity': 'postLiveDayInTheLifeActivity',
      'User Settings Lab': 'userSettingsLab',
      'Sailpoint Role': 'sailpointRole',
      'sailpoint_role': 'sailpointRole',
      'Sailpoint Review': 'sailpointRoleReview',
      'sailpoint_role_review': 'sailpointRoleReview',
      'Status': 'status',
      'Last Edit Date/Reason/Initials': 'lastEditDateReasonInitials'
    };

    const runImport = (importedData, errors) => {
      if (errors && errors.length > 0) console.warn('Import warnings:', errors);
      const rawData = Array.isArray(importedData) ? importedData : [];
      const mappedData = rawData.map((row) => {
        const mappedRow = {};
        Object.keys(row).forEach((key) => {
          const mappedKey = headerMapping[key] || key;
          let value = row[key] || '';
          mappedRow[mappedKey] = String(value).replace(/\s+/g, ' ').trim();
        });
        return mappedRow;
      });

      if (!mappedData.length) {
        setIsImporting(false);
        alert('No valid data rows found.');
        if (fileInputRef.current) fileInputRef.current.value = '';
        return;
      }

      const runImport = async (importMode = 'merge') => {
        const shouldReplace = importMode === 'replace';
        snapshotForUndo(`Import ${mappedData.length} category(ies)`);
        try {
          let updatedCategories;
          if (shouldReplace) {
            updatedCategories = mappedData.map((row) => ({ ...row, id: generateId() }));
            const auditEntries = updatedCategories.map((cat) => ({
              entityType: 'JOB_CATEGORY',
              action: 'CREATE',
              entityData: cat,
            }));
            const saveResult = await saveJobCategories(updatedCategories);
            await addAuditLogsBatch(auditEntries);
            await propagateCategoryChangesToRoles(updatedCategories, {
              saveResult,
              warnWhenNoRoleChanges: false,
            });
          } else {
            const allCategories = await getJobCategories();
            const existingByName = {};
            allCategories.forEach((c) => {
              const name = (c.jobCategoryName || '').trim().toLowerCase();
              if (name) existingByName[name] = c;
            });
            const auditEntries = [];
            const newCategories = [];
            mappedData.forEach((row) => {
              const name = (row.jobCategoryName || '').trim().toLowerCase();
              if (name && existingByName[name]) {
                const prev = { ...existingByName[name] };
                Object.assign(existingByName[name], { ...row, id: existingByName[name].id });
                auditEntries.push({ entityType: 'JOB_CATEGORY', action: 'UPDATE', entityData: existingByName[name], previousData: prev });
              } else {
                const newCat = { ...row, id: generateId() };
                newCategories.push(newCat);
                auditEntries.push({ entityType: 'JOB_CATEGORY', action: 'CREATE', entityData: newCat });
              }
            });
            updatedCategories = [...allCategories, ...newCategories];
            const changedCats = auditEntries
              .filter((e) => e.action === 'UPDATE')
              .map((e) => e.entityData);
            const saveResult = await saveJobCategories(updatedCategories);
            await addAuditLogsBatch(auditEntries);
            await propagateCategoryChangesToRoles(
              changedCats.length > 0 ? changedCats : updatedCategories,
              { saveResult, warnWhenNoRoleChanges: false }
            );
          }
          setCategories(updatedCategories);
          loadCategories();
          showToast(`Successfully imported ${mappedData.length} category/categories!`);
        } finally {
          setIsImporting(false);
          if (fileInputRef.current) fileInputRef.current.value = '';
        }
      };

      (async () => {
        const existing = await getJobCategories();
        const previewCols = ['jobCategoryId', 'jobCategoryName', 'organizationJobCategoryScope', 'status'];
        setImportPreview({
          rows: mappedData,
          columns: previewCols,
          existingData: existing,
          matchKey: 'jobCategoryName',
          onConfirm: runImport
        });
      })();
    };

    const onError = (error) => {
      setIsImporting(false);
      alert(`Import failed: ${error}`);
      if (fileInputRef.current) fileInputRef.current.value = '';
    };

    setIsImporting(true);
    if (isCsv) {
      importFromCSV(file, (data) => runImport(data, []), onError);
    } else {
      importFromExcel(file, (data, errs) => runImport(data, errs), onError);
    }
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingCategory(null);
  };

  const jobCatColumnDefs = useMemo(() => [
    { key: 'jobCategoryId', label: 'Job Category ID' },
    { key: 'jobCategoryName', label: 'Job Category Name' },
    { key: 'organizationJobCategoryScope', label: 'Organization Job Category Scope' },
    { key: 'description', label: 'Description' },
    { key: 'owningApplication', label: 'Owning Application' },
    { key: 'impactedApplications', label: 'Impacted Application(s)' },
    { key: 'owningWorkgroup', label: 'Owning Workgroup' },
    { key: 'otherInterestedWorkgroups', label: 'Other Interested Workgroup(s)' },
    { key: 'needEMP', label: 'Need EMP?' },
    { key: 'needSER', label: 'Need SER?' },
    { key: 'linkableTemplateId', label: 'Linkable Template ID' },
    { key: 'linkableTemplateName', label: 'Template Description' },
    { key: 'subtemplatesId', label: 'Subtemplate ID' },
    { key: 'subtemplatesName', label: 'Subtemplate Description' },
    { key: 'blueprintId', label: 'Blueprint' },
    { key: 'trainingTrack1', label: 'Training Track 1' },
    { key: 'trainingTrack2', label: 'Training Track 2' },
    { key: 'trainingTrack3', label: 'Training Track 3' },
    { key: 'trainingTrack4', label: 'Training Track 4' },
    { key: 'trainingTrack5', label: 'Training Track 5' },
    { key: 'trainingTrack6', label: 'Training Track 6' },
    { key: 'preLiveDayInTheLifeActivity', label: 'Pre-live Day-in-the-Life Activity' },
    { key: 'postLiveDayInTheLifeActivity', label: 'Post-live Day-in-the-Life Activity' },
    { key: 'userSettingsLab', label: 'User Settings Lab' },
    { key: 'sailpointRole', label: 'Sailpoint Role' },
    { key: 'sailpointRoleReview', label: 'Sailpoint Review' },
    { key: 'status', label: 'Status' },
    { key: 'lastEditDateReasonInitials', label: 'Last Edit Date/Reason/Initials' },
    { key: 'rbacCodeCount', label: 'RBAC Codes' },
    { key: 'sailpointRequestable', label: 'Sailpoint Requestable' },
  ], []);

  const handleFindReplaceCategories = async (updatedCategories, matchCount) => {
    snapshotForUndo(`Find & Replace (${matchCount} match${matchCount !== 1 ? 'es' : ''})`);
    const prevCategories = categories;
    setCategories(updatedCategories);
    try {
      const saveResult = await saveJobCategories(updatedCategories);
      const prevById = new Map(prevCategories.map((c) => [c.id, c]));
      const changed = updatedCategories.filter((c) => {
        const old = prevById.get(c.id);
        return old && JSON.stringify(old) !== JSON.stringify(c);
      });
      for (const cat of changed) {
        const old = prevCategories.find((c) => c.id === cat.id);
        if (old) await addJobCategoryAuditLog('UPDATE', cat, old);
      }
      if (changed.length > 0) {
        const previousNamesByCategoryId = {};
        for (const cat of changed) {
          const old = prevCategories.find((c) => c.id === cat.id);
          if (old?.jobCategoryName && old.jobCategoryName !== cat.jobCategoryName) {
            previousNamesByCategoryId[cat.id] = old.jobCategoryName;
          }
        }
        await propagateCategoryChangesToRoles(changed, { saveResult, previousNamesByCategoryId });
      }
      loadCategories();
      showToast(`Replaced ${matchCount} match${matchCount !== 1 ? 'es' : ''} in ${changed.length} category(ies).`);
    } catch (err) {
      setCategories(prevCategories);
      await loadCategories();
      alert(err?.message || 'Replace failed. Check the server and try again.');
    }
    setShowFindReplace(false);
  };

  if (showForm) {
    return (
      <JobCategoryForm
        category={editingCategory}
        onSubmit={handleFormSubmit}
        onCancel={handleCancel}
      />
    );
  }

  return (
    <div className="job-categories">
      <div className="categories-header">
        <h2>Job Categories</h2>
        <div className="actions">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".csv,.xlsx,.xls"
            style={{ display: 'none' }}
          />
          <button className="btn-import" onClick={handleImportClick} title="Import job categories from CSV or Excel" disabled={isImporting}>
            {isImporting ? 'Importing…' : 'Import from CSV or Excel'}
          </button>
          {isImporting && <span className="import-status" role="status">Importing…</span>}
          <button className="btn-export" onClick={handleExport} title="Download filtered categories as CSV">
            Export to CSV
          </button>
          <button className="btn-add" onClick={handleAdd}>
            Add New Category
          </button>
          <button className="btn-export" onClick={() => setShowFindReplace(true)} title="Find & Replace across all categories (Ctrl+H)">
            Find &amp; Replace
          </button>
          {canSyncRoles && (
            <JobCategoryRoleSyncButton onSynced={(updatedRoles) => setAllRoles(updatedRoles)} />
          )}
          {canSyncRoles && canAccessAdvanced && (
            <JobCategoryRoleSyncButton
              scope={SYNC_SCOPE_ALL}
              onSynced={(updatedRoles) => setAllRoles(updatedRoles)}
            />
          )}
          {canUndo && (
            <button type="button" className="btn-secondary btn-undo" onClick={handleUndo} title={undoRef.current ? `Undo: ${undoRef.current.description}` : 'Undo'}>Undo</button>
          )}
          {allowBulkActions && selectedRows.size > 0 && (
            <button className="btn-export" onClick={handleBulkStatusChange} title="Bulk status change">
              Bulk Status ({selectedRows.size})
            </button>
          )}
          {allowBulkActions && (
            <>
              <button type="button" className="btn-secondary" onClick={() => { if (selectedRows.size === 0) { alert('Select rows first.'); return; } setShowBulkUpdate(true); }} disabled={selectedRows.size === 0}>Bulk Update ({selectedRows.size})</button>
              <button type="button" className="btn-secondary btn-danger-outline" onClick={handleDeleteSelected} disabled={selectedRows.size === 0}>Bulk Delete ({selectedRows.size})</button>
            </>
          )}
        </div>
      </div>

      <div className="search-container">
        <div style={{ display: 'flex', gap: '1rem', alignItems: 'center', flexWrap: 'wrap' }}>
          <input
            type="text"
            placeholder="Search all fields..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
            style={{ flex: 1, maxWidth: '400px' }}
            disabled={Object.keys(advancedFilters).length > 0}
          />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            style={{
              padding: '0.75rem',
              border: '1px solid #d1d5db',
              borderRadius: '4px',
              fontSize: '1rem',
              backgroundColor: 'white',
              cursor: 'pointer'
            }}
          >
            <option value="All">All Status</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
          <select
            value={scopeFilter}
            onChange={(e) => setScopeFilter(e.target.value)}
            title="Filter by Organization Job Category Scope"
            style={{
              padding: '0.75rem',
              border: '1px solid #d1d5db',
              borderRadius: '4px',
              fontSize: '1rem',
              backgroundColor: 'white',
              cursor: 'pointer'
            }}
          >
            <option value={SCOPE_FILTER_DEFAULT}>{SCOPE_FILTER_DEFAULT}</option>
            <option value="All">All Scopes</option>
          </select>
          <label className="recently-edited-filter" title="Show only categories edited in the last 24 hours" style={{ display: 'flex', alignItems: 'center', fontSize: '0.9rem', cursor: 'pointer', whiteSpace: 'nowrap' }}>
            <input
              type="checkbox"
              checked={recentlyEditedFilter}
              onChange={(e) => setRecentlyEditedFilter(e.target.checked)}
              style={{ marginRight: '0.35rem' }}
            />
            Recently edited
          </label>
          <button 
            className="btn-export" 
            onClick={() => setShowAdvancedSearch(!showAdvancedSearch)}
            style={{ padding: '0.35rem 0.7rem', fontSize: '0.85rem' }}
          >
            {showAdvancedSearch ? 'Hide' : 'Advanced'} Search
          </button>
          <button 
            className="btn-export" 
            onClick={clearFilters}
            style={{ padding: '0.35rem 0.7rem', fontSize: '0.85rem' }}
          >
            Clear Filters
          </button>
          <button 
            className="btn-export" 
            onClick={saveFilterPreset}
            style={{ padding: '0.35rem 0.7rem', fontSize: '0.85rem' }}
          >
            Save Preset
          </button>
          {savedPresets.length > 0 && (
            <>
              <select
                id="jobcat-preset-select"
                onChange={(e) => {
                  if (e.target.value) {
                    const preset = savedPresets.find(p => p.id === e.target.value);
                    if (preset) loadFilterPreset(preset);
                    e.target.value = '';
                  }
                }}
                style={{
                  padding: '0.5rem',
                  border: '1px solid #d1d5db',
                  borderRadius: '4px',
                  fontSize: '0.9rem',
                  backgroundColor: 'white',
                  cursor: 'pointer'
                }}
              >
                <option value="">Load Preset...</option>
                {[...savedPresets].sort((a, b) => (a.name || '').localeCompare(b.name || '')).map(preset => (
                  <option key={preset.id} value={preset.id}>{preset.name}</option>
                ))}
              </select>
              <button
                type="button"
                className="btn-export"
                style={{ padding: '0.35rem 0.7rem', fontSize: '0.85rem' }}
                title="Delete the preset selected in Load Preset"
                onClick={() => {
                  const select = document.getElementById('jobcat-preset-select');
                  const presetId = select?.value;
                  if (!presetId) {
                    alert('Choose a preset in Load Preset first, then click Delete Preset.');
                    return;
                  }
                  deleteFilterPreset(presetId);
                  if (select) select.value = '';
                }}
              >
                Delete Preset
              </button>
            </>
          )}
        </div>
        {showAdvancedSearch && (
          <div style={{ marginTop: '1rem', padding: '1rem', backgroundColor: '#f3f4f6', borderRadius: '4px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem' }}>
              <div>
                <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.9rem' }}>Job Category Name</label>
                <input
                  type="text"
                  value={advancedFilters.jobCategoryName || ''}
                  onChange={(e) => setAdvancedFilters({...advancedFilters, jobCategoryName: e.target.value})}
                  style={{ width: '100%', padding: '0.5rem' }}
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.9rem' }}>Description</label>
                <input
                  type="text"
                  value={advancedFilters.description || ''}
                  onChange={(e) => setAdvancedFilters({...advancedFilters, description: e.target.value})}
                  style={{ width: '100%', padding: '0.5rem' }}
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.9rem' }}>Blueprint</label>
                <input
                  type="text"
                  value={advancedFilters.blueprintId || ''}
                  onChange={(e) => setAdvancedFilters({...advancedFilters, blueprintId: e.target.value})}
                  style={{ width: '100%', padding: '0.5rem' }}
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.9rem' }}>Sailpoint Role</label>
                <input
                  type="text"
                  value={advancedFilters.sailpointRole || ''}
                  onChange={(e) => setAdvancedFilters({...advancedFilters, sailpointRole: e.target.value})}
                  style={{ width: '100%', padding: '0.5rem' }}
                  placeholder="Use blank/null/empty for missing"
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: '0.25rem', fontSize: '0.9rem' }}>
                  Sailpoint Requestable
                </label>
                <select
                  value={advancedFilters.sailpointRequestable || 'All'}
                  onChange={(e) => {
                    const val = e.target.value;
                    if (val === 'All') {
                      const { sailpointRequestable, ...rest } = advancedFilters;
                      setAdvancedFilters(rest);
                    } else {
                      setAdvancedFilters({ ...advancedFilters, sailpointRequestable: val });
                    }
                  }}
                  style={{ width: '100%', padding: '0.5rem' }}
                >
                  <option value="All">All</option>
                  <option value="Requestable">Requestable</option>
                  <option value="Non-requestable">Non-requestable</option>
                </select>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="table-container">
        {categories.length === 0 ? (
          <div className="empty-state" role="status">
            <p className="empty-state-message">No job categories yet</p>
            <p className="empty-state-hint">Add job categories to link to roles, or import from CSV/Excel.</p>
            <button type="button" className="btn-add empty-state-cta" onClick={handleAdd}>
              Add New Category
            </button>
          </div>
        ) : (
        <>
        {filteredCategories.length > MAX_RENDERED_ROWS && (
          <div className="table-cap-notice" role="status">
            Showing first {MAX_RENDERED_ROWS} of {filteredCategories.length} categories. Use search or filters to narrow.
          </div>
        )}
        <table className="categories-table categories-table--wrap">
          <colgroup>
            {jobCatColumnKeys.map((k) => (
              <col key={k} style={{ width: `${colW(k)}px` }} />
            ))}
          </colgroup>
          <thead>
            <tr>
              {allowBulkActions &&
                renderResizableTh(
                  '__checkbox__',
                  <input
                    type="checkbox"
                    checked={allVisibleSelected}
                    onChange={handleSelectAll}
                    onClick={(e) => e.stopPropagation()}
                  />,
                  { className: 'col-checkbox' }
                )}
              {renderResizableTh(
                'jobCategoryId',
                <>Job Category ID {sortConfig.key === 'jobCategoryId' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('jobCategoryId'), className: 'sortable' }
              )}
              {renderResizableTh(
                'jobCategoryName',
                <>Job Category Name {sortConfig.key === 'jobCategoryName' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('jobCategoryName'), className: 'sortable' }
              )}
              {renderResizableTh(
                'organizationJobCategoryScope',
                <>Organization Job Category Scope {sortConfig.key === 'organizationJobCategoryScope' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('organizationJobCategoryScope'), className: 'sortable' }
              )}
              {renderResizableTh(
                'description',
                <>Description {sortConfig.key === 'description' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('description'), className: 'sortable' }
              )}
              {renderResizableTh(
                'owningApplication',
                <>Owning Application {sortConfig.key === 'owningApplication' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('owningApplication'), className: 'sortable' }
              )}
              {renderResizableTh(
                'impactedApplications',
                <>Impacted Application(s) {sortConfig.key === 'impactedApplications' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('impactedApplications'), className: 'sortable' }
              )}
              {renderResizableTh(
                'owningWorkgroup',
                <>Owning Workgroup {sortConfig.key === 'owningWorkgroup' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('owningWorkgroup'), className: 'sortable' }
              )}
              {renderResizableTh(
                'otherInterestedWorkgroups',
                <>Other Interested Workgroup(s) {sortConfig.key === 'otherInterestedWorkgroups' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('otherInterestedWorkgroups'), className: 'sortable' }
              )}
              {renderResizableTh(
                'needEMP',
                <>Need EMP? {sortConfig.key === 'needEMP' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('needEMP'), className: 'sortable' }
              )}
              {renderResizableTh(
                'needSER',
                <>Need SER? {sortConfig.key === 'needSER' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('needSER'), className: 'sortable' }
              )}
              {renderResizableTh(
                'linkableTemplateId',
                <>Linkable Template ID {sortConfig.key === 'linkableTemplateId' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('linkableTemplateId'), className: 'sortable' }
              )}
              {renderResizableTh(
                'linkableTemplateName',
                <>Template Description {sortConfig.key === 'linkableTemplateName' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('linkableTemplateName'), className: 'sortable' }
              )}
              {renderResizableTh(
                'subtemplatesId',
                <>Subtemplate ID {sortConfig.key === 'subtemplatesId' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('subtemplatesId'), className: 'sortable' }
              )}
              {renderResizableTh(
                'subtemplatesName',
                <>Subtemplate Description {sortConfig.key === 'subtemplatesName' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('subtemplatesName'), className: 'sortable' }
              )}
              {renderResizableTh(
                'blueprintId',
                <>Blueprint {sortConfig.key === 'blueprintId' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('blueprintId'), className: 'sortable' }
              )}
              {renderResizableTh(
                'trainingTrack1',
                <>Training Track 1 {sortConfig.key === 'trainingTrack1' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('trainingTrack1'), className: 'sortable' }
              )}
              {renderResizableTh(
                'trainingTrack2',
                <>Training Track 2 {sortConfig.key === 'trainingTrack2' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('trainingTrack2'), className: 'sortable' }
              )}
              {renderResizableTh(
                'trainingTrack3',
                <>Training Track 3 {sortConfig.key === 'trainingTrack3' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('trainingTrack3'), className: 'sortable' }
              )}
              {renderResizableTh(
                'trainingTrack4',
                <>Training Track 4 {sortConfig.key === 'trainingTrack4' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('trainingTrack4'), className: 'sortable' }
              )}
              {renderResizableTh(
                'trainingTrack5',
                <>Training Track 5 {sortConfig.key === 'trainingTrack5' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('trainingTrack5'), className: 'sortable' }
              )}
              {renderResizableTh(
                'trainingTrack6',
                <>Training Track 6 {sortConfig.key === 'trainingTrack6' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('trainingTrack6'), className: 'sortable' }
              )}
              {renderResizableTh(
                'preLiveDayInTheLifeActivity',
                <>Pre-live Day-in-the-Life Activity {sortConfig.key === 'preLiveDayInTheLifeActivity' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('preLiveDayInTheLifeActivity'), className: 'sortable' }
              )}
              {renderResizableTh(
                'postLiveDayInTheLifeActivity',
                <>Post-live Day-in-the-Life Activity {sortConfig.key === 'postLiveDayInTheLifeActivity' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('postLiveDayInTheLifeActivity'), className: 'sortable' }
              )}
              {renderResizableTh(
                'userSettingsLab',
                <>User Settings Lab {sortConfig.key === 'userSettingsLab' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('userSettingsLab'), className: 'sortable' }
              )}
              {renderResizableTh(
                'sailpointRole',
                <>Sailpoint Role {sortConfig.key === 'sailpointRole' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('sailpointRole'), className: 'sortable' }
              )}
              {renderResizableTh(
                'status',
                <>Status {sortConfig.key === 'status' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('status'), className: 'sortable' }
              )}
              {renderResizableTh(
                'lastEditDateReasonInitials',
                <>Last Edit Date/Reason/Initials {sortConfig.key === 'lastEditDateReasonInitials' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('lastEditDateReasonInitials'), className: 'sortable' }
              )}
              {renderResizableTh(
                'rbacCodeCount',
                <>RBAC Codes {sortConfig.key === 'rbacCodeCount' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('rbacCodeCount'), className: 'sortable col-numeric' }
              )}
              {renderResizableTh(
                'sailpointRequestable',
                <>Sailpoint Requestable {sortConfig.key === 'sailpointRequestable' && (sortConfig.direction === 'asc' ? '↑' : '↓')}</>,
                { onClick: () => handleSort('sailpointRequestable'), className: 'sortable' }
              )}
              {renderResizableTh('__actions__', 'Actions', { className: 'col-actions' })}
            </tr>
          </thead>
          <tbody>
            {filteredCategories.length === 0 ? (
              <tr>
                <td colSpan={jobCatColumnKeys.length} className="no-data">
                  No categories found matching your search.
                </td>
              </tr>
            ) : (
              categoriesToRender.map((category) => {
                const isEditing = (field) =>
                  editingCell && editingCell.categoryId === category.id && editingCell.field === field;

                const tabToCell = (field, dir) => {
                  if (!canAccessAdvanced) return;
                  const idx = CAT_EDITABLE_FIELDS.indexOf(field);
                  const next = dir === 1 ? CAT_EDITABLE_FIELDS[idx + 1] : CAT_EDITABLE_FIELDS[idx - 1];
                  if (next) setEditingCell({ categoryId: category.id, field: next });
                  else setEditingCell(null);
                };

                const renderTextCell = (field, opts = {}) => {
                  const { isTextarea, displayTransform } = opts;
                  if (isEditing(field)) {
                    const val = category[field] || '';
                    const commitEdit = (v) => updateCategoryField(category.id, field, v);
                    if (isTextarea) {
                      return (
                        <textarea
                          className="inline-edit-input inline-edit-textarea"
                          rows={3}
                          defaultValue={val}
                          onBlur={(e) => commitEdit(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); commitEdit(e.target.value); }
                            if (e.key === 'Escape') setEditingCell(null);
                            if (e.key === 'Tab' && canAccessAdvanced) { e.preventDefault(); commitEdit(e.target.value); tabToCell(field, e.shiftKey ? -1 : 1); }
                          }}
                          onClick={(e) => e.stopPropagation()}
                          autoFocus
                        />
                      );
                    }
                    return (
                      <input
                        type="text"
                        className="inline-edit-input"
                        defaultValue={val}
                        onBlur={(e) => commitEdit(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') commitEdit(e.target.value);
                          if (e.key === 'Escape') setEditingCell(null);
                          if (e.key === 'Tab' && canAccessAdvanced) { e.preventDefault(); commitEdit(e.target.value); tabToCell(field, e.shiftKey ? -1 : 1); }
                        }}
                        onClick={(e) => e.stopPropagation()}
                        autoFocus
                      />
                    );
                  }
                  const raw = category[field] ?? '';
                  const display = displayTransform ? displayTransform(raw) : raw;
                  return (
                    <span
                      className="inline-edit-span"
                      onDoubleClick={(e) => { e.stopPropagation(); setEditingCell({ categoryId: category.id, field }); }}
                    >
                      {sanitizeCellText(display)}
                    </span>
                  );
                };

                const renderSelectCell = (field, options) => {
                  if (isEditing(field)) {
                    return (
                      <select
                        className="inline-edit-select"
                        defaultValue={category[field] || ''}
                        onChange={(e) => updateCategoryField(category.id, field, e.target.value)}
                        onBlur={() => setEditingCell(null)}
                        onKeyDown={(e) => {
                          if (e.key === 'Escape') setEditingCell(null);
                          if (e.key === 'Tab' && canAccessAdvanced) { e.preventDefault(); tabToCell(field, e.shiftKey ? -1 : 1); }
                        }}
                        onClick={(e) => e.stopPropagation()}
                        autoFocus
                      >
                        <option value="">—</option>
                        {options.map((o) => <option key={o} value={o}>{o}</option>)}
                      </select>
                    );
                  }
                  const displayVal =
                    field === 'sailpointRoleReview'
                      ? (category[field] === 'Review' ? 'Review' : '—')
                      : (category[field] || (field === 'status' ? 'Active' : ''));
                  return (
                    <span
                      className="inline-edit-span"
                      onDoubleClick={(e) => { e.stopPropagation(); setEditingCell({ categoryId: category.id, field }); }}
                    >
                      {sanitizeCellText(displayVal)}
                    </span>
                  );
                };

                const handleContextMenu = canAccessAdvanced ? (e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  setContextMenu({
                    x: e.clientX,
                    y: e.clientY,
                    actions: [
                      { label: 'Edit', onClick: () => handleEdit(category) },
                      { label: 'Duplicate', onClick: () => handleDuplicateCategory(category) },
                      { label: 'Delete', onClick: () => handleDelete(category) },
                      { label: 'Copy Row', onClick: () => handleCopyRow(category) },
                    ]
                  });
                } : undefined;
                return (
                <tr
                  key={category.id}
                  className={isCategoryEditedInLast24Hours(category) ? 'category-recently-edited' : ''}
                  onContextMenu={handleContextMenu}
                >
                  {allowBulkActions && (
                    <td className="col-checkbox" onClick={(e) => e.stopPropagation()}>
                      <input
                        type="checkbox"
                        checked={selectedRows.has(category.id)}
                        onChange={(e) => handleRowSelect(category.id, e)}
                      />
                    </td>
                  )}
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('jobCategoryId')}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('jobCategoryName')}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('organizationJobCategoryScope')}</td>
                  <td className="text-cell" onClick={(e) => e.stopPropagation()}>{renderTextCell('description', { isTextarea: true })}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('owningApplication')}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('impactedApplications')}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('owningWorkgroup')}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('otherInterestedWorkgroups')}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderSelectCell('needEMP', ['Yes', 'No'])}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderSelectCell('needSER', ['Yes', 'No'])}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('linkableTemplateId', { isTextarea: true, displayTransform: (v) => templateSubtemplateOneLine(v) })}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('linkableTemplateName', { isTextarea: true, displayTransform: (v) => formatTemplateNameTitleCase(templateSubtemplateOneLine(v, false)) })}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('subtemplatesId', { isTextarea: true, displayTransform: (v) => templateSubtemplateOneLine(v) })}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('subtemplatesName', { isTextarea: true, displayTransform: (v) => formatTemplateNameTitleCase(templateSubtemplateOneLine(v, false)) })}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('blueprintId', { displayTransform: () => [category.blueprintId, category.blueprintName].filter(Boolean).join(' – ') })}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('trainingTrack1')}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('trainingTrack2')}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('trainingTrack3')}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('trainingTrack4')}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('trainingTrack5')}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('trainingTrack6')}</td>
                  <td className="text-cell" onClick={(e) => e.stopPropagation()}>{renderTextCell('preLiveDayInTheLifeActivity', { isTextarea: true })}</td>
                  <td className="text-cell" onClick={(e) => e.stopPropagation()}>{renderTextCell('postLiveDayInTheLifeActivity', { isTextarea: true })}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('userSettingsLab')}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderTextCell('sailpointRole')}</td>
                  <td onClick={(e) => e.stopPropagation()}>{renderSelectCell('status', ['Active', 'Inactive'])}</td>
                  <td className="text-cell">{sanitizeCellText(category.lastEditDateReasonInitials)}</td>
                  <td className="col-numeric">
                    {countRbacCodesForJobCategoryName(
                      rbacCodeCountByCategoryName,
                      category.jobCategoryName
                    )}
                  </td>
                  <td
                    className={
                      isNonRequestableSailpointCatalogRow(
                        findSailpointCatalogRowByName(sailpointCatalog, category.sailpointRole)
                      )
                        ? 'sailpoint-non-requestable'
                        : undefined
                    }
                  >
                    {formatSailpointRoleRequestableDisplay(category.sailpointRole, sailpointCatalog)}
                  </td>
                  <td className="col-actions">
                    <button
                      className="btn-edit"
                      onClick={() => handleEdit(category)}
                    >
                      Edit
                    </button>
                    <button
                      type="button"
                      className={(category.status || 'Active').trim() === 'Inactive' ? 'btn-reactivate' : 'btn-inactivate'}
                      onClick={() => handleToggleStatus(category)}
                    >
                      {(category.status || 'Active').trim() === 'Inactive' ? 'Reactivate' : 'Inactivate'}
                    </button>
                    <button
                      className="btn-delete"
                      onClick={() => handleDelete(category)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
                );
              })
            )}
          </tbody>
        </table>
        </>
        )}
      </div>

      {showFindReplace && (
        <FindReplaceDialog
          columns={jobCatColumnDefs}
          data={categories}
          onReplace={handleFindReplaceCategories}
          onClose={() => setShowFindReplace(false)}
        />
      )}

      {reassignDialog && (
        <JobCategoryReassignDialog
          sourceCategory={reassignDialog.category}
          affectedRoles={reassignDialog.allAffectedRoles || reassignDialog.affectedRoles}
          candidateCategories={categories}
          onConfirm={handleReassignConfirm}
          onInactivateOnly={handleReassignInactivateOnly}
          onInactivateConnectedRoles={handleInactivateConnectedRolesAndCategory}
          onCancel={handleReassignCancel}
        />
      )}

      {showBulkUpdate && (
        <CatBulkUpdateDialog
          selectedCount={selectedRows.size}
          onApply={handleBulkUpdate}
          onClose={() => setShowBulkUpdate(false)}
        />
      )}

      {contextMenu && (
        <TableContextMenu
          x={contextMenu.x}
          y={contextMenu.y}
          actions={contextMenu.actions}
          onClose={() => setContextMenu(null)}
        />
      )}

      {importPreview && (
        <ImportPreviewDialog
          rows={importPreview.rows}
          columns={importPreview.columns}
          existingData={importPreview.existingData}
          matchKey={importPreview.matchKey}
          onConfirm={(mode) => { setImportPreview(null); importPreview.onConfirm(mode); }}
          onCancel={() => { setImportPreview(null); setIsImporting(false); if (fileInputRef.current) fileInputRef.current.value = ''; }}
          enableImportMode
          defaultImportMode="merge"
        />
      )}
    </div>
  );
};

export default JobCategories;
