import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import './FindReplaceDialog.css';

const FindReplaceDialog = ({ columns, data, onReplace, onClose }) => {
  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [selectedColumn, setSelectedColumn] = useState('__all__');
  const [caseSensitive, setCaseSensitive] = useState(false);
  const [wholeCell, setWholeCell] = useState(false);
  const [previewResults, setPreviewResults] = useState(null);
  const findInputRef = useRef(null);

  useEffect(() => {
    const t = setTimeout(() => findInputRef.current?.focus(), 50);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [onClose]);

  const searchableColumns = useMemo(() => {
    return columns.filter(
      (c) => c.key !== '__checkbox__' && c.key !== '__actions__' && c.key !== 'actions'
    );
  }, [columns]);

  const getMatches = useCallback(() => {
    const findNeedle = findText.trim();
    if (!findNeedle) return { matchCount: 0, rowCount: 0, rows: [] };
    const cols =
      selectedColumn === '__all__'
        ? searchableColumns.map((c) => c.key)
        : [selectedColumn];
    const needle = caseSensitive ? findNeedle : findNeedle.toLowerCase();
    let matchCount = 0;
    const rows = [];
    for (let i = 0; i < data.length; i++) {
      const row = data[i];
      let rowMatched = false;
      for (const col of cols) {
        const cellVal = String(row[col] ?? '');
        const haystack = caseSensitive ? cellVal : cellVal.toLowerCase();
        if (wholeCell) {
          if (haystack === needle) {
            matchCount++;
            rowMatched = true;
          }
        } else {
          let idx = 0;
          while ((idx = haystack.indexOf(needle, idx)) !== -1) {
            matchCount++;
            rowMatched = true;
            idx += needle.length;
          }
        }
      }
      if (rowMatched) rows.push(i);
    }
    return { matchCount, rowCount: rows.length, rows };
  }, [findText, selectedColumn, caseSensitive, wholeCell, data, searchableColumns]);

  const handleFind = () => {
    setPreviewResults(getMatches());
  };

  const handleReplaceAll = () => {
    if (!findText.trim()) return;
    const { matchCount } = getMatches();
    if (matchCount === 0) {
      setPreviewResults({ matchCount: 0, rowCount: 0, rows: [] });
      return;
    }
    const cols =
      selectedColumn === '__all__'
        ? searchableColumns.map((c) => c.key)
        : [selectedColumn];
    const needleRaw = findText.trim();
    const updated = data.map((row) => {
      let changed = false;
      const newRow = { ...row };
      for (const col of cols) {
        const cellVal = String(row[col] ?? '');
        let newVal;
        if (wholeCell) {
          const haystack = caseSensitive ? cellVal : cellVal.toLowerCase();
          const needle = caseSensitive ? needleRaw : needleRaw.toLowerCase();
          if (haystack === needle) {
            newVal = replaceText;
            changed = true;
          }
        } else if (caseSensitive) {
          newVal = cellVal.split(needleRaw).join(replaceText);
          if (newVal !== cellVal) changed = true;
        } else {
          const escaped = needleRaw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
          newVal = cellVal.replace(new RegExp(escaped, 'gi'), replaceText);
          if (newVal !== cellVal) changed = true;
        }
        if (changed && newVal !== undefined) newRow[col] = newVal;
      }
      return newRow;
    });
    onReplace(updated, matchCount);
    setPreviewResults(null);
    setFindText('');
    setReplaceText('');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleFind();
    }
  };

  return (
    <div className="fr-overlay" onClick={onClose}>
      <div className="fr-dialog" onClick={(e) => e.stopPropagation()}>
        <div className="fr-header">
          <h3>Find &amp; Replace</h3>
          <button type="button" className="fr-close" onClick={onClose} aria-label="Close">
            &times;
          </button>
        </div>

        <div className="fr-body">
          <div className="fr-field">
            <label htmlFor="fr-find">Find</label>
            <input
              ref={findInputRef}
              id="fr-find"
              type="text"
              value={findText}
              onChange={(e) => {
                setFindText(e.target.value);
                setPreviewResults(null);
              }}
              onKeyDown={handleKeyDown}
              placeholder="Text to find..."
              autoComplete="off"
            />
          </div>

          <div className="fr-field">
            <label htmlFor="fr-replace">Replace with</label>
            <input
              id="fr-replace"
              type="text"
              value={replaceText}
              onChange={(e) => setReplaceText(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Replacement text (leave empty to delete)"
              autoComplete="off"
            />
          </div>

          <div className="fr-field">
            <label htmlFor="fr-column">In column</label>
            <select
              id="fr-column"
              value={selectedColumn}
              onChange={(e) => { setSelectedColumn(e.target.value); setPreviewResults(null); }}
            >
              <option value="__all__">All columns</option>
              {searchableColumns.map((col) => (
                <option key={col.key} value={col.key}>
                  {col.label}
                </option>
              ))}
            </select>
          </div>

          <div className="fr-options">
            <label className="fr-checkbox">
              <input
                type="checkbox"
                checked={caseSensitive}
                onChange={(e) => { setCaseSensitive(e.target.checked); setPreviewResults(null); }}
              />
              Case sensitive
            </label>
            <label className="fr-checkbox">
              <input
                type="checkbox"
                checked={wholeCell}
                onChange={(e) => { setWholeCell(e.target.checked); setPreviewResults(null); }}
              />
              Match entire cell
            </label>
          </div>

          {previewResults && (
            <div className={`fr-preview ${previewResults.matchCount === 0 ? 'fr-preview-none' : ''}`}>
              {previewResults.matchCount === 0 ? (
                <span>No matches found.</span>
              ) : (
                <span>
                  <strong>{previewResults.matchCount}</strong> match{previewResults.matchCount !== 1 ? 'es' : ''} in{' '}
                  <strong>{previewResults.rowCount}</strong> row{previewResults.rowCount !== 1 ? 's' : ''}
                </span>
              )}
            </div>
          )}
        </div>

        <div className="fr-footer">
          <button type="button" className="fr-btn fr-btn-secondary" onClick={handleFind} disabled={!findText.trim()}>
            Find
          </button>
          <button type="button" className="fr-btn fr-btn-primary" onClick={handleReplaceAll} disabled={!findText.trim()}>
            Replace All
          </button>
        </div>
      </div>
    </div>
  );
};

export default FindReplaceDialog;
