import React, { useEffect, useMemo, useState } from 'react';
import {
  SYNC_RECENT_EDIT_DAYS,
  SYNC_SCOPE_ALL,
  buildDefaultRoleSyncSelection,
  buildRoleSyncSelectionKey,
  countSelectedRoleSyncUpdates,
  formatCategorySyncRowDisplay,
  formatCategorySyncRowLabel,
} from '../utils/jobCategoryRoleSync';
import './JobCategoryRoleSyncDialog.css';

function formatRoleCodes(codes) {
  if (!codes?.length) return '—';
  if (codes.length <= 8) return codes.join(', ');
  return `${codes.slice(0, 8).join(', ')} … +${codes.length - 8} more`;
}

function formatChangeValue(value) {
  const text = value == null ? '' : String(value).trim();
  return text || '(blank)';
}

function truncateValue(value, max = 80) {
  const text = formatChangeValue(value);
  if (text.length <= max) return text;
  return `${text.slice(0, max)}…`;
}

function CategoryLabel({ row }) {
  const { title, subtitle } = formatCategorySyncRowDisplay(row);
  return (
    <div className="jcrs-cat-label">
      <div className="jcrs-cat-label-title">{title}</div>
      {subtitle ? <div className="jcrs-cat-label-sub">{subtitle}</div> : null}
    </div>
  );
}

function RoleChangeBlock({ entry, selectedKeys, onToggleField, onToggleRole }) {
  const fieldKeys = entry.changes.map((change) => buildRoleSyncSelectionKey(entry.roleId, change.field));
  const allSelected = fieldKeys.length > 0 && fieldKeys.every((key) => selectedKeys.has(key));
  const someSelected = fieldKeys.some((key) => selectedKeys.has(key));

  return (
    <div className={`jcrs-role-block${someSelected ? '' : ' jcrs-role-block-dimmed'}`}>
      <div className="jcrs-role-title">
        <label className="jcrs-role-select">
          <input
            type="checkbox"
            checked={allSelected}
            ref={(el) => {
              if (el) el.indeterminate = someSelected && !allSelected;
            }}
            onChange={(e) => onToggleRole(entry.roleId, entry.changes.map((c) => c.field), e.target.checked)}
          />
          <span>{entry.rbacCode}</span>
        </label>
      </div>
      <table className="jcrs-change-table">
        <thead>
          <tr>
            <th className="jcrs-col-apply">Apply</th>
            <th>Field</th>
            <th>Current</th>
            <th>After sync</th>
          </tr>
        </thead>
        <tbody>
          {entry.changes.map((change) => {
            const key = buildRoleSyncSelectionKey(entry.roleId, change.field);
            const checked = selectedKeys.has(key);
            return (
              <tr key={change.field} className={checked ? '' : 'jcrs-change-row-off'}>
                <td className="jcrs-col-apply">
                  <input
                    type="checkbox"
                    checked={checked}
                    aria-label={`Apply ${change.label} for ${entry.rbacCode}`}
                    onChange={(e) => onToggleField(entry.roleId, change.field, e.target.checked)}
                  />
                </td>
                <td className="jcrs-change-field">{change.label}</td>
                <td className="jcrs-change-from" title={formatChangeValue(change.from)}>
                  {truncateValue(change.from)}
                </td>
                <td className="jcrs-change-to" title={formatChangeValue(change.to)}>
                  {truncateValue(change.to)}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function CategoryChangesSection({
  categoriesWithChanges,
  selectedKeys,
  onToggleField,
  onToggleRole,
  onToggleCategory,
  onSelectAll,
}) {
  return (
    <div className="jcrs-changes-section">
      <div className="jcrs-changes-toolbar">
        <h4 className="jcrs-changes-heading">Changes to apply</h4>
        <div className="jcrs-changes-actions">
          <button type="button" className="jcrs-link-btn" onClick={() => onSelectAll(true)}>
            Select all
          </button>
          <span className="jcrs-changes-actions-sep">·</span>
          <button type="button" className="jcrs-link-btn" onClick={() => onSelectAll(false)}>
            Deselect all
          </button>
        </div>
      </div>
      <p className="jcrs-changes-hint">Uncheck any field changes you do not want to apply.</p>
      {categoriesWithChanges.map((row, idx) => {
        const entries = row.roleEntries || [];
        const categoryKeys = entries.flatMap((entry) =>
          entry.changes.map((change) => buildRoleSyncSelectionKey(entry.roleId, change.field))
        );
        const allSelected = categoryKeys.length > 0 && categoryKeys.every((key) => selectedKeys.has(key));
        const someSelected = categoryKeys.some((key) => selectedKeys.has(key));
        const selectedFieldCount = categoryKeys.filter((key) => selectedKeys.has(key)).length;

        return (
          <details
            key={row.category?.id || row.category?.jobCategoryId || `changes-${idx}`}
            className="jcrs-cat-details"
            open={categoriesWithChanges.length <= 2}
          >
            <summary>
              <label
                className="jcrs-cat-select"
                onClick={(e) => e.stopPropagation()}
                onKeyDown={(e) => e.stopPropagation()}
              >
                <input
                  type="checkbox"
                  checked={allSelected}
                  ref={(el) => {
                    if (el) el.indeterminate = someSelected && !allSelected;
                  }}
                  aria-label={`Select all changes for ${row.displayName || row.categoryName}`}
                  onChange={(e) => onToggleCategory(entries, e.target.checked)}
                />
              </label>
              <span className="jcrs-cat-details-name">
                <CategoryLabel row={row} />
              </span>
              <span className="jcrs-cat-details-meta">
                {selectedFieldCount} of {categoryKeys.length} field
                {categoryKeys.length === 1 ? '' : 's'} selected
              </span>
            </summary>
            <div className="jcrs-cat-details-body">
              {entries.map((entry) => (
                <RoleChangeBlock
                  key={entry.roleId}
                  entry={entry}
                  selectedKeys={selectedKeys}
                  onToggleField={onToggleField}
                  onToggleRole={onToggleRole}
                />
              ))}
            </div>
          </details>
        );
      })}
    </div>
  );
}

const JobCategoryRoleSyncDialog = ({ plan, busy = false, onConfirm, onCancel }) => {
  const [selectedKeys, setSelectedKeys] = useState(() => buildDefaultRoleSyncSelection(plan));

  useEffect(() => {
    setSelectedKeys(buildDefaultRoleSyncSelection(plan));
  }, [plan]);

  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === 'Escape' && !busy) onCancel?.();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [onCancel, busy]);

  const {
    categorySummaries = [],
    roleUpdateCount = 0,
    recentCategoryCount = 0,
    categoriesScanned = 0,
    driftCategoryCount = 0,
    scope,
  } = plan || {};
  const syncAll = scope === SYNC_SCOPE_ALL;
  const categoriesWithChanges = categorySummaries.filter((row) => (row.roleEntries || []).length > 0);
  const summaryRows = syncAll
    ? categorySummaries.filter((row) => row.driftRoleCount > 0 || row.assignedRoleCount > 0)
    : categorySummaries;
  const nothingToScan = recentCategoryCount === 0;
  const alreadySynced = !nothingToScan && roleUpdateCount === 0;

  const selectedRoleCount = useMemo(() => countSelectedRoleSyncUpdates(selectedKeys), [selectedKeys]);
  const selectedChangeCount = selectedKeys.size;
  const canConfirm = selectedChangeCount > 0;

  const toggleField = (roleId, field, checked) => {
    const key = buildRoleSyncSelectionKey(roleId, field);
    setSelectedKeys((prev) => {
      const next = new Set(prev);
      if (checked) next.add(key);
      else next.delete(key);
      return next;
    });
  };

  const toggleRole = (roleId, fields, checked) => {
    setSelectedKeys((prev) => {
      const next = new Set(prev);
      for (const field of fields) {
        const key = buildRoleSyncSelectionKey(roleId, field);
        if (checked) next.add(key);
        else next.delete(key);
      }
      return next;
    });
  };

  const toggleCategory = (entries, checked) => {
    setSelectedKeys((prev) => {
      const next = new Set(prev);
      for (const entry of entries) {
        for (const change of entry.changes) {
          const key = buildRoleSyncSelectionKey(entry.roleId, change.field);
          if (checked) next.add(key);
          else next.delete(key);
        }
      }
      return next;
    });
  };

  const selectAll = (checked) => {
    setSelectedKeys(checked ? buildDefaultRoleSyncSelection(plan) : new Set());
  };

  return (
    <div className="jcrs-overlay" onClick={busy ? undefined : onCancel}>
      <div className="jcrs-dialog" onClick={(e) => e.stopPropagation()}>
        <div className="jcrs-header">
          <h3>{syncAll ? 'Sync All Roles with Job Categories' : 'Sync Roles from Job Categories'}</h3>
          <button type="button" className="jcrs-close" onClick={onCancel} disabled={busy} aria-label="Close">
            &times;
          </button>
        </div>

        <div className="jcrs-body">
          {nothingToScan ? (
            <p className="jcrs-lede">
              {syncAll
                ? 'No job categories with names were found. Nothing to sync.'
                : `No job categories were edited in the last ${SYNC_RECENT_EDIT_DAYS} days. Nothing to sync.`}
            </p>
          ) : (
            <>
              <p className="jcrs-lede">
                {syncAll ? (
                  <>
                    Scanned <strong>{categoriesScanned || recentCategoryCount}</strong> job categor
                    {(categoriesScanned || recentCategoryCount) === 1 ? 'y' : 'ies'} across the full category table.
                    {alreadySynced ? (
                      <> All linked RBAC roles already match their job categories.</>
                    ) : (
                      <>
                        {' '}
                        <strong>{driftCategoryCount}</strong> categor{driftCategoryCount === 1 ? 'y has' : 'ies have'}{' '}
                        drift; review <strong>{roleUpdateCount}</strong> pending role update
                        {roleUpdateCount === 1 ? '' : 's'} below, choose which changes to apply, then confirm.
                      </>
                    )}
                  </>
                ) : (
                  <>
                    <strong>{recentCategoryCount}</strong> job categor{recentCategoryCount === 1 ? 'y was' : 'ies were'}{' '}
                    edited in the last {SYNC_RECENT_EDIT_DAYS} days.
                    {alreadySynced ? (
                      <> All linked RBAC roles already match those categories.</>
                    ) : (
                      <>
                        {' '}
                        Review the <strong>{roleUpdateCount}</strong> pending role update
                        {roleUpdateCount === 1 ? '' : 's'} below, choose which field changes to apply, then confirm.
                      </>
                    )}
                  </>
                )}
              </p>

              <div className="jcrs-table-wrap">
                <table className="jcrs-table">
                  <thead>
                    <tr>
                      <th>Job Category</th>
                      <th>{syncAll ? 'Category Data' : 'Last Edited'}</th>
                      <th>Assigned Roles</th>
                      <th>Roles to Sync</th>
                    </tr>
                  </thead>
                  <tbody>
                    {summaryRows.map((row, idx) => (
                      <tr key={row.category?.id || row.category?.jobCategoryId || `cat-${idx}`}>
                        <td>
                          <CategoryLabel row={row} />
                        </td>
                        <td className="jcrs-muted">
                          {syncAll ? (row.assignedRoleCount > 0 ? 'Has assigned roles' : '—') : row.lastEdit || '—'}
                        </td>
                        <td>{row.assignedRoleCount ?? 0}</td>
                        <td>
                          {row.driftRoleCount > 0 ? (
                            <span className="jcrs-pending" title={row.roleCodes.join(', ')}>
                              {row.driftRoleCount} ({formatRoleCodes(row.roleCodes)})
                            </span>
                          ) : (
                            <span className="jcrs-ok">In sync</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {roleUpdateCount > 0 && (
                <CategoryChangesSection
                  categoriesWithChanges={categoriesWithChanges}
                  selectedKeys={selectedKeys}
                  onToggleField={toggleField}
                  onToggleRole={toggleRole}
                  onToggleCategory={toggleCategory}
                  onSelectAll={selectAll}
                />
              )}

              {roleUpdateCount > 0 && (
                <p className="jcrs-note">
                  Selected roles will get a last-edit stamp with reason &quot;Synced from Job Category update&quot;.
                </p>
              )}
            </>
          )}
        </div>

        <div className="jcrs-footer">
          <button type="button" className="btn-secondary" onClick={onCancel} disabled={busy}>
            Cancel
          </button>
          {!nothingToScan && roleUpdateCount > 0 && (
            <button
              type="button"
              className="btn-primary"
              onClick={() => onConfirm?.(selectedKeys)}
              disabled={busy || !canConfirm}
            >
              {busy
                ? 'Syncing…'
                : `Sync ${selectedRoleCount} Role${selectedRoleCount === 1 ? '' : 's'} (${selectedChangeCount} change${selectedChangeCount === 1 ? '' : 's'})`}
            </button>
          )}
          {!nothingToScan && alreadySynced && (
            <button type="button" className="btn-primary" onClick={onCancel}>
              Close
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default JobCategoryRoleSyncDialog;
