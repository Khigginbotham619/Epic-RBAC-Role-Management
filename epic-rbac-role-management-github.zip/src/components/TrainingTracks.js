import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { getTrainingTracks, saveTrainingTracks, generateId } from '../utils/storage';
import { importFromExcel } from '../utils/excelImport';
import { useToast } from '../context/ToastContext';
import SortableTh from './SortableTh';
import { sortRowsByKey, nextSortState } from '../utils/tableSort';
import ImportPreviewDialog from './ImportPreviewDialog';
import './TrainingTracks.css';

const TT_BULK_FIELDS = [
  { key: 'trackName', label: 'Training Track Name' },
];

const TtBulkUpdateDialog = ({ selectedCount, onApply, onClose }) => {
  const [field, setField] = useState('');
  const [value, setValue] = useState('');
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!field) { alert('Please select a field.'); return; }
    if (!window.confirm(`Set "Training Track Name" to "${value}" on ${selectedCount} track(s)?`)) return;
    onApply(field, value);
  };
  return (
    <div className="find-replace-overlay" onClick={onClose}>
      <div className="find-replace-dialog" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 420 }}>
        <div className="find-replace-header">
          <h3>Bulk Update ({selectedCount} selected)</h3>
          <button type="button" className="find-replace-close" onClick={onClose}>&times;</button>
        </div>
        <form onSubmit={handleSubmit} style={{ padding: '1rem 1.25rem' }}>
          <div style={{ marginBottom: '0.75rem' }}>
            <label style={{ display: 'block', marginBottom: '0.25rem', fontWeight: 500, fontSize: '0.9rem' }}>Field</label>
            <select value={field} onChange={(e) => { setField(e.target.value); setValue(''); }} style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1' }}>
              <option value="">Select field...</option>
              {TT_BULK_FIELDS.map((f) => <option key={f.key} value={f.key}>{f.label}</option>)}
            </select>
          </div>
          {field && (
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', marginBottom: '0.25rem', fontWeight: 500, fontSize: '0.9rem' }}>New Value</label>
              <input type="text" value={value} onChange={(e) => setValue(e.target.value)} style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1', boxSizing: 'border-box' }} autoFocus placeholder="Enter new value (leave empty to clear)" />
            </div>
          )}
          <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
            <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn-primary" disabled={!field}>Apply</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const TrainingTracks = ({ canEdit = false }) => {
  const { showToast } = useToast();
  const [tracks, setTracks] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isImporting, setIsImporting] = useState(false);
  const [editingTrack, setEditingTrack] = useState(null);
  const [editName, setEditName] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newTrackName, setNewTrackName] = useState('');
  const [selectedRows, setSelectedRows] = useState(new Set());
  const [showBulkUpdate, setShowBulkUpdate] = useState(false);
  const undoRef = useRef(null);
  const [canUndo, setCanUndo] = useState(false);
  const [importPreview, setImportPreview] = useState(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    loadTracks();
  }, []);

  const loadTracks = async () => {
    const loaded = await getTrainingTracks();
    setTracks(Array.isArray(loaded) ? loaded : []);
  };

  const snapshotForUndo = useCallback((description) => {
    undoRef.current = { data: [...tracks], description };
    setCanUndo(true);
  }, [tracks]);

  const handleUndo = async () => {
    if (!undoRef.current) return;
    const { data: prevData, description } = undoRef.current;
    if (!window.confirm(`Undo "${description}"?`)) return;
    setTracks(prevData);
    try {
      await saveTrainingTracks(prevData);
      undoRef.current = null;
      setCanUndo(false);
      loadTracks();
      showToast(`Undone: ${description}`);
    } catch (err) {
      alert(err?.message || 'Undo failed.');
    }
  };

  const handleRowSelect = (id) => {
    setSelectedRows((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const filteredTracks = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    if (!q) return tracks;
    return tracks.filter((t) => (t.trackName || '').toLowerCase().includes(q));
  }, [tracks, searchTerm]);

  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  const handleSort = useCallback((key) => {
    setSortConfig((prev) => nextSortState(prev, key));
  }, []);
  const displayTracks = useMemo(
    () => sortRowsByKey(filteredTracks, sortConfig.key, sortConfig.direction),
    [filteredTracks, sortConfig.key, sortConfig.direction]
  );

  const allVisibleSelected = displayTracks.length > 0 && displayTracks.every((t) => selectedRows.has(t.id));

  const handleSelectAll = () => {
    if (allVisibleSelected) {
      setSelectedRows((prev) => { const next = new Set(prev); displayTracks.forEach((t) => next.delete(t.id)); return next; });
    } else {
      setSelectedRows((prev) => { const next = new Set(prev); displayTracks.forEach((t) => next.add(t.id)); return next; });
    }
  };

  const handleDeleteSelected = async () => {
    if (!canEdit || selectedRows.size === 0) return;
    if (!window.confirm(`Delete ${selectedRows.size} selected training track(s)?`)) return;
    snapshotForUndo(`Bulk delete ${selectedRows.size} training track(s)`);
    const updated = tracks.filter((t) => !selectedRows.has(t.id));
    setTracks(updated);
    try {
      await saveTrainingTracks(updated);
      const count = selectedRows.size;
      setSelectedRows(new Set());
      loadTracks();
      showToast(`Deleted ${count} training track(s).`);
    } catch (err) {
      alert(err?.message || 'Delete failed.');
    }
  };

  const handleBulkUpdateApply = async (field, value) => {
    if (!canEdit || selectedRows.size === 0) return;
    snapshotForUndo(`Bulk update ${selectedRows.size} training track(s)`);
    const updated = tracks.map((t) => {
      if (!selectedRows.has(t.id)) return t;
      return { ...t, [field]: value };
    });
    setTracks(updated);
    try {
      await saveTrainingTracks(updated);
      const count = selectedRows.size;
      setSelectedRows(new Set());
      loadTracks();
      showToast(`Updated ${count} training track(s).`);
    } catch (err) {
      alert(err?.message || 'Update failed.');
    }
    setShowBulkUpdate(false);
  };

  const handleSaveEdit = async () => {
    if (!canEdit) return;
    const name = (editName || '').trim();
    if (!name || !editingTrack) return;
    snapshotForUndo(`Edit track ${editingTrack.trackName || editingTrack.id}`);
    const updated = tracks.map((t) =>
      t.id === editingTrack.id ? { ...t, trackName: name } : t
    );
    setTracks(updated);
    await saveTrainingTracks(updated);
    setEditingTrack(null);
    setEditName('');
    showToast('Training track updated.');
  };

  const handleAdd = async () => {
    if (!canEdit) return;
    const name = (newTrackName || '').trim();
    if (!name) return;
    snapshotForUndo('Add new training track');
    const newTrack = { id: generateId(), trackName: name };
    const updated = [...tracks, newTrack];
    setTracks(updated);
    await saveTrainingTracks(updated);
    setNewTrackName('');
    setShowAddForm(false);
    showToast('Training track added.');
  };

  const handleDelete = async (track) => {
    if (!canEdit) return;
    if (!window.confirm(`Delete "${track.trackName || track.id}"?`)) return;
    snapshotForUndo(`Delete track ${track.trackName || track.id}`);
    const updated = tracks.filter((t) => t.id !== track.id);
    setTracks(updated);
    await saveTrainingTracks(updated);
    setEditingTrack(null);
    showToast('Training track deleted.');
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e) => {
    if (!canEdit) return;
    const file = e.target.files?.[0];
    if (!file) return;
    const fileName = (file.name || '').toLowerCase();
    if (!fileName.endsWith('.xlsx') && !fileName.endsWith('.xls')) {
      alert('Please select an Excel file (.xlsx or .xls).');
      e.target.value = '';
      return;
    }
    setIsImporting(true);
    importFromExcel(
      file,
      (data, errs) => {
        const raw = Array.isArray(data) ? data : [];
        const existingNames = new Set((tracks || []).map((t) => (t.trackName || '').trim().toLowerCase()));
        const added = [];
        for (const row of raw) {
          const name = (row.trackName ?? row['Training tracks '] ?? row['Training tracks'] ?? row.name ?? (Array.isArray(row) ? row[0] : null));
          const str = name != null ? String(name).trim() : '';
          if (str && !existingNames.has(str.toLowerCase())) {
            existingNames.add(str.toLowerCase());
            added.push({ id: generateId(), trackName: str });
          }
        }
        if (added.length === 0) {
          setIsImporting(false);
          showToast('No new training tracks to add (all already exist).');
          e.target.value = '';
          return;
        }
        const commitImport = async () => {
          snapshotForUndo(`Import ${added.length} training track(s)`);
          const updated = [...(tracks || []), ...added];
          setTracks(updated);
          await saveTrainingTracks(updated);
          showToast(`Imported ${added.length} training track(s).`);
        };

        setImportPreview({
          rows: added,
          columns: ['trackName'],
          existingData: tracks || [],
          matchKey: 'trackName',
          onConfirm: async () => {
            try {
              await commitImport();
            } finally {
              setIsImporting(false);
              e.target.value = '';
            }
          },
        });
      },
      (err) => {
        setIsImporting(false);
        alert(`Import failed: ${err}`);
        e.target.value = '';
      }
    );
  };

  return (
    <div className="training-tracks">
      <div className="training-tracks-header">
        <h2>Training Tracks</h2>
        <p className="training-tracks-desc">Reference table for the Training Track dropdown when creating or editing roles. Only set users can edit.</p>
        {canEdit && (
          <div className="training-tracks-actions">
            <input
              type="file"
              ref={fileInputRef}
              accept=".xlsx,.xls"
              style={{ display: 'none' }}
              onChange={handleFileChange}
            />
            <button type="button" className="btn-import" onClick={handleImportClick} disabled={isImporting}>
              {isImporting ? 'Importing…' : 'Import from Excel'}
            </button>
            {isImporting && <span className="import-status" role="status">Importing…</span>}
            <button type="button" className="btn-add" onClick={() => setShowAddForm(true)}>
              Add Training Track
            </button>
            {canUndo && (
              <button type="button" className="btn-secondary btn-undo" onClick={handleUndo} title={undoRef.current ? `Undo: ${undoRef.current.description}` : 'Undo'}>Undo</button>
            )}
            <button type="button" className="btn-secondary" onClick={() => { if (selectedRows.size === 0) { alert('Select rows first.'); return; } setShowBulkUpdate(true); }} disabled={selectedRows.size === 0}>Bulk Update ({selectedRows.size})</button>
            <button type="button" className="btn-secondary btn-danger-outline" onClick={handleDeleteSelected} disabled={selectedRows.size === 0}>Bulk Delete ({selectedRows.size})</button>
          </div>
        )}
      </div>

      <div className="training-tracks-search">
        <input
          type="text"
          placeholder="Search training tracks..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="search-input"
        />
      </div>

      {canEdit && showAddForm && (
        <div className="training-tracks-add-form">
          <input
            type="text"
            placeholder="Training track name"
            value={newTrackName}
            onChange={(e) => setNewTrackName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAdd()}
            autoFocus
          />
          <button type="button" className="btn-add" onClick={handleAdd}>Save</button>
          <button type="button" className="btn-secondary" onClick={() => { setShowAddForm(false); setNewTrackName(''); }}>Cancel</button>
        </div>
      )}

      <div className="training-tracks-table-wrap">
        <table className="training-tracks-table">
          <thead>
            <tr>
              {canEdit && <th style={{ width: 36, textAlign: 'center' }}><input type="checkbox" checked={allVisibleSelected} onChange={handleSelectAll} title="Select all" /></th>}
              <SortableTh columnKey="trackName" sortConfig={sortConfig} onSort={handleSort}>Training Track</SortableTh>
              {canEdit && <th className="col-actions">Actions</th>}
            </tr>
          </thead>
          <tbody>
            {filteredTracks.length === 0 ? (
              <tr>
                <td colSpan={canEdit ? 3 : 1}>{canEdit ? 'No training tracks. Add one or import from Excel.' : 'No training tracks.'}</td>
              </tr>
            ) : (
              displayTracks.map((track) => (
                <tr key={track.id}>
                  {canEdit && <td style={{ textAlign: 'center' }}><input type="checkbox" checked={selectedRows.has(track.id)} onChange={() => handleRowSelect(track.id)} /></td>}
                  <td>
                    {canEdit && editingTrack?.id === track.id ? (
                      <input
                        type="text"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSaveEdit()}
                        autoFocus
                        className="inline-edit-input"
                      />
                    ) : (
                      <span>{track.trackName || ''}</span>
                    )}
                  </td>
                  {canEdit && (
                    <td className="col-actions">
                      {editingTrack?.id === track.id ? (
                        <>
                          <button type="button" className="btn-edit" onClick={handleSaveEdit}>Save</button>
                          <button type="button" className="btn-secondary" onClick={() => { setEditingTrack(null); setEditName(''); }}>Cancel</button>
                        </>
                      ) : (
                        <>
                          <button type="button" className="btn-edit" onClick={() => { setEditingTrack(track); setEditName(track.trackName || ''); }}>Edit</button>
                          <button type="button" className="btn-delete" onClick={() => handleDelete(track)}>Delete</button>
                        </>
                      )}
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      {canEdit && showBulkUpdate && (
        <TtBulkUpdateDialog selectedCount={selectedRows.size} onApply={handleBulkUpdateApply} onClose={() => setShowBulkUpdate(false)} />
      )}
      {importPreview && (
        <ImportPreviewDialog
          rows={importPreview.rows}
          columns={importPreview.columns}
          existingData={importPreview.existingData}
          matchKey={importPreview.matchKey}
          onConfirm={(mode) => { setImportPreview(null); importPreview.onConfirm(mode); }}
          onCancel={() => { setImportPreview(null); setIsImporting(false); if (fileInputRef.current) fileInputRef.current.value = ''; }}
        />
      )}
    </div>
  );
};

export default TrainingTracks;
