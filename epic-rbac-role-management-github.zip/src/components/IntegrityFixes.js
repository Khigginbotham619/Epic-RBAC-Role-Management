import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  getRoles,
  mergeRoles,
  getJobCategories,
  saveJobCategories,
  getTemplateLinks,
  getBlueprints,
  addAuditLogsBatch,
  addJobCategoryAuditLog,
} from '../utils/storage';
import {
  findIntegrityFixes,
  applyIntegrityFixes,
  INTEGRITY_FIX_CODE_LABEL,
  INTEGRITY_FIELD_LABELS,
} from '../utils/integrityFixes';
import { useToast } from '../context/ToastContext';
import { useDeferredScan } from '../utils/deferredScan';
import './IntegrityFixes.css';

const CODES = Object.keys(INTEGRITY_FIX_CODE_LABEL);

function s(v) {
  return v == null ? '' : String(v);
}

function renderDiff(before, after) {
  const allKeys = Array.from(new Set([...Object.keys(before || {}), ...Object.keys(after || {})]));
  const changes = allKeys.filter((k) => s(before?.[k]) !== s(after?.[k]));
  if (!changes.length) return <em className="ifix-muted">No field changes</em>;
  return changes.map((k) => {
    const b = s(before?.[k]);
    const a = s(after?.[k]);
    const label = INTEGRITY_FIELD_LABELS[k] || k;
    return (
      <div key={k} className="ifix-diff-row">
        <div className="ifix-diff-label">{label}</div>
        <div className="ifix-diff-values">
          {b ? <span className="ifix-was">{b}</span> : <em className="ifix-muted">(blank)</em>}
          <span className="ifix-diff-arrow" aria-hidden="true">
            →
          </span>
          {a ? <span className="ifix-now">{a}</span> : <em className="ifix-muted">(blank)</em>}
        </div>
      </div>
    );
  });
}

const IntegrityFixes = () => {
  const { showToast } = useToast();
  const [roles, setRoles] = useState([]);
  const [jobCategories, setJobCategories] = useState([]);
  const [templateLinks, setTemplateLinks] = useState([]);
  const [blueprints, setBlueprints] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [codeFilter, setCodeFilter] = useState('all');
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(() => new Set());

  const reload = useCallback(async () => {
    setLoading(true);
    try {
      const [r, c, tl, bp] = await Promise.all([
        getRoles(),
        getJobCategories(),
        getTemplateLinks(),
        getBlueprints(),
      ]);
      setRoles(Array.isArray(r) ? r : []);
      setJobCategories(Array.isArray(c) ? c : []);
      setTemplateLinks(Array.isArray(tl) ? tl : []);
      setBlueprints(Array.isArray(bp) ? bp : []);
      setSelected(new Set());
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    reload();
  }, [reload]);

  const { result: scanResult, scanning } = useDeferredScan(
    () => findIntegrityFixes({ roles, jobCategories, templateLinks, blueprints }),
    [loading, roles, jobCategories, templateLinks, blueprints],
    !loading,
  );
  const proposals = useMemo(() => scanResult || [], [scanResult]);

  const countsByCode = useMemo(() => {
    const counts = {};
    for (const c of CODES) counts[c] = 0;
    for (const p of proposals) counts[p.code] = (counts[p.code] || 0) + 1;
    return counts;
  }, [proposals]);

  const visibleProposals = useMemo(() => {
    const q = search.trim().toLowerCase();
    return proposals.filter((p) => {
      if (codeFilter !== 'all' && p.code !== codeFilter) return false;
      if (!q) return true;
      return [p.rbacCode, p.jobCategoryId, p.jobTitle, p.jobCategory, p.summary, p.description, ...(p.details || [])]
        .map((v) => (v == null ? '' : String(v).toLowerCase()))
        .some((v) => v.includes(q));
    });
  }, [proposals, codeFilter, search]);

  const toggleOne = (id) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const selectAllVisible = () => {
    setSelected((prev) => {
      const next = new Set(prev);
      for (const p of visibleProposals) next.add(p.id);
      return next;
    });
  };

  const clearAllVisible = () => {
    setSelected((prev) => {
      const next = new Set(prev);
      for (const p of visibleProposals) next.delete(p.id);
      return next;
    });
  };

  const handleApply = async () => {
    if (selected.size === 0) {
      alert('Select at least one fix.');
      return;
    }
    if (!window.confirm(`Apply ${selected.size} integrity fix(es)?`)) return;
    setBusy(true);
    try {
      const result = applyIntegrityFixes({
        roles,
        jobCategories,
        proposals,
        selectedIds: Array.from(selected),
        blueprints,
        templateLinks,
      });
      const auditEntries = [];
      for (const category of result.updatedJobCategories) {
        if (category && category.id && result.changedCategoryIds.has(category.id)) {
          await addJobCategoryAuditLog('UPDATE', category, result.oldByCategoryId.get(category.id));
        }
      }
      for (const role of result.updatedRoles) {
        if (role && role.id && result.changedRoleIds.has(role.id)) {
          auditEntries.push({
            entityType: 'ROLE',
            action: 'UPDATE',
            entityData: role,
            oldData: result.oldByRoleId.get(role.id),
          });
        }
      }
      if (result.changedCategoryIds.size > 0) {
        await saveJobCategories(result.updatedJobCategories);
      }
      const rolePatches = result.updatedRoles.filter(
        (role) => role?.id && result.changedRoleIds.has(role.id)
      );
      if (rolePatches.length > 0) await mergeRoles(rolePatches);
      if (auditEntries.length > 0) await addAuditLogsBatch(auditEntries);
      const parts = [];
      if (result.changedCategoryIds.size > 0) {
        parts.push(`${result.changedCategoryIds.size} job categor${result.changedCategoryIds.size === 1 ? 'y' : 'ies'}`);
      }
      if (result.changedRoleIds.size > 0) {
        parts.push(`${result.changedRoleIds.size} role${result.changedRoleIds.size === 1 ? '' : 's'}`);
      }
      showToast(`Applied fixes across ${parts.join(' and ') || '0 rows'}.`);
      await reload();
    } catch (err) {
      alert(err?.message || 'Failed to save fixes.');
    } finally {
      setBusy(false);
    }
  };

  if (loading) {
    return (
      <div className="ifix">
        <div className="ifix-header">
          <h2>Integrity Fixes</h2>
        </div>
        <p className="ifix-loading">Loading…</p>
      </div>
    );
  }

  return (
    <div className="ifix">
      <div className="ifix-header">
        <h2>Integrity Fixes</h2>
        <p className="ifix-desc">
          Integrity proposals are evaluated at the <strong>job category</strong> level first
          (Need EMP?, templates, SailPoint, blueprints). Applying a category fix updates the
          category and propagates to all roles assigned to it. Role rows cover role-specific SER
          cleanup and roles that drifted from their job category. Only <strong>active</strong> job
          categories are scanned; inactive categories and roles assigned to them are excluded, along
          with placeholder categories (SHELL, EMP SHELL ONLY, wait-for-role, etc.).
        </p>
        {scanning && <p className="ifix-loading">Scanning roles and job categories…</p>}
      </div>

      <div className="ifix-actions">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Filter by RBAC code, job category, category ID, etc..."
          style={{ minWidth: 240 }}
        />
        <select value={codeFilter} onChange={(e) => setCodeFilter(e.target.value)}>
          <option value="all">All issues ({proposals.length})</option>
          {CODES.map((c) => (
            <option key={c} value={c}>
              {INTEGRITY_FIX_CODE_LABEL[c]} ({countsByCode[c]})
            </option>
          ))}
        </select>
        <button
          type="button"
          className="ifix-btn ifix-btn-secondary"
          onClick={selectAllVisible}
          disabled={visibleProposals.length === 0 || busy}
        >
          Select all shown
        </button>
        <button
          type="button"
          className="ifix-btn ifix-btn-secondary"
          onClick={clearAllVisible}
          disabled={visibleProposals.length === 0 || busy}
        >
          Clear shown
        </button>
        <button
          type="button"
          className="ifix-btn"
          onClick={handleApply}
          disabled={busy || selected.size === 0}
        >
          {busy ? 'Saving…' : `Apply ${selected.size} selected fix${selected.size === 1 ? '' : 'es'}`}
        </button>
        <span className="ifix-counter">
          {visibleProposals.length} of {proposals.length} proposals · {selected.size} selected
        </span>
      </div>

      {proposals.length === 0 ? (
        <p className="ifix-empty">No integrity issues detected. Your roles look clean.</p>
      ) : visibleProposals.length === 0 ? (
        <p className="ifix-empty">No proposals match the current filters.</p>
      ) : (
        <div className="ifix-table-wrap">
          <table className="ifix-table">
            <thead>
              <tr>
                <th style={{ width: 32 }} />
                <th>Issue</th>
                <th>Level</th>
                <th>RBAC / Cat ID</th>
                <th>Job Title</th>
                <th>Job Category</th>
                <th>What will change</th>
              </tr>
            </thead>
            <tbody>
              {visibleProposals.map((p) => (
                <tr key={p.id}>
                  <td>
                    <input
                      type="checkbox"
                      checked={selected.has(p.id)}
                      onChange={() => toggleOne(p.id)}
                      disabled={busy}
                      aria-label={`Select ${p.code} fix for ${p.level === 'category' ? p.jobCategory : p.rbacCode || p.roleId}`}
                    />
                  </td>
                  <td className="ifix-issue-cell">
                    <span className={`ifix-code ifix-code-${p.code}`}>
                      {INTEGRITY_FIX_CODE_LABEL[p.code] || p.code}
                    </span>
                    <p className="ifix-summary">{p.summary || p.description}</p>
                    {p.level === 'category' && p.affectedRoleCount > 0 && (
                      <p className="ifix-muted ifix-affected-roles">
                        Propagates to {p.affectedRoleCount} role{p.affectedRoleCount === 1 ? '' : 's'}
                      </p>
                    )}
                    {Array.isArray(p.details) && p.details.length > 0 && (
                      <ul className="ifix-details">
                        {p.details.map((line, idx) => (
                          <li key={`${p.id}-detail-${idx}`}>{line}</li>
                        ))}
                      </ul>
                    )}
                  </td>
                  <td>{p.level === 'category' ? 'Job category' : 'Role'}</td>
                  <td>{p.level === 'category' ? p.jobCategoryId || '—' : p.rbacCode || '—'}</td>
                  <td>{p.level === 'category' ? '—' : p.jobTitle || '—'}</td>
                  <td>{p.jobCategory || '—'}</td>
                  <td>
                    <div className="ifix-diff">{renderDiff(p.before, p.after)}</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default IntegrityFixes;
