import React, { useState, useEffect } from 'react';
import './DepartmentForm.css';

const SailpointRoleForm = ({ sailpointRole, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    sailpointRole: '',
    status: 'Active',
    templates: '',
    subtemplates: '',
    requestable: '',
    matchedAccessProfile: '',
    entitlementType: '',
    instructions: '',
  });

  useEffect(() => {
    if (sailpointRole) {
      setFormData({
        sailpointRole: sailpointRole.sailpointRole || '',
        status: sailpointRole.status || 'Active',
        templates: sailpointRole.templates || sailpointRole.description || '',
        subtemplates: sailpointRole.subtemplates || '',
        requestable: sailpointRole.requestable || '',
        matchedAccessProfile: sailpointRole.matchedAccessProfile || '',
        entitlementType: sailpointRole.entitlementType || '',
        instructions: sailpointRole.instructions || sailpointRole.entitlements || '',
      });
    }
  }, [sailpointRole]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <div className="department-form-container">
      <div className="department-form">
        <h2>{sailpointRole ? 'Edit Sailpoint Row' : 'Add New Sailpoint Row'}</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="sailpointRole">Role-ID *</label>
            <input
              type="text"
              id="sailpointRole"
              name="sailpointRole"
              value={formData.sailpointRole}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="status">Status</label>
            <select
              id="status"
              name="status"
              value={formData.status}
              onChange={handleChange}
            >
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>

          <div className="form-group">
            <label htmlFor="templates">Template</label>
            <textarea
              id="templates"
              name="templates"
              value={formData.templates}
              onChange={handleChange}
              rows="4"
            />
          </div>

          <div className="form-group">
            <label htmlFor="subtemplates">Subtemplate</label>
            <textarea
              id="subtemplates"
              name="subtemplates"
              value={formData.subtemplates}
              onChange={handleChange}
              rows="4"
            />
          </div>

          <div className="form-group">
            <label htmlFor="requestable">Requestable</label>
            <input
              type="text"
              id="requestable"
              name="requestable"
              value={formData.requestable}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label htmlFor="matchedAccessProfile">Matched Access Profile</label>
            <input
              type="text"
              id="matchedAccessProfile"
              name="matchedAccessProfile"
              value={formData.matchedAccessProfile}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label htmlFor="entitlementType">Entitlement Type</label>
            <input
              type="text"
              id="entitlementType"
              name="entitlementType"
              value={formData.entitlementType}
              onChange={handleChange}
            />
          </div>

          <div className="form-group">
            <label htmlFor="instructions">Instructions</label>
            <textarea
              id="instructions"
              name="instructions"
              value={formData.instructions}
              onChange={handleChange}
              rows="4"
            />
          </div>

          <div className="form-actions">
            <button type="button" className="btn-cancel" onClick={onCancel}>
              Cancel
            </button>
            <button type="submit" className="btn-submit">
              {sailpointRole ? 'Update Sailpoint Row' : 'Create Sailpoint Row'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SailpointRoleForm;
