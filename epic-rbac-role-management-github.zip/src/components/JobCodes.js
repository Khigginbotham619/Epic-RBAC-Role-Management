import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { useDebounce } from '../utils/useDebounce';
import { getJobCodes, saveJobCodes, appendJobCodes, addJobCodeAuditLog, addAuditLogsBatch, generateId } from '../utils/storage';
import { exportToCSV } from '../utils/csvExport';
import { importFromExcel } from '../utils/excelImport';
import { sanitizeCellText } from '../utils/textSanitize';
import { normalizeJobCode } from '../utils/jobCodeUtils';
import { useToast } from '../context/ToastContext';
import JobCodeForm from './JobCodeForm';
import ImportPreviewDialog from './ImportPreviewDialog';
import SortableTh from './SortableTh';
import { sortRowsByKey, nextSortState } from '../utils/tableSort';
import './JobCodes.css';

// Normalize imported row to job code shape. Works with any source (RBAC table export, standalone job code list, etc.)
const HEADER_ALIASES = {
  jobCode: ['job code', 'jobcode', 'job code/id', 'job code id', 'code', 'jobcodeid', 'job_code', 'jobcode/id'],
  jobTitle: ['job title', 'jobtitle', 'title', 'job_title', 'description'],
  currentStatus: ['current status', 'currentstatus', 'status', 'status code', 'status_code', 'active']
};

function normalizeImportedRow(row) {
  const get = (internalKey) => {
    const value = row[internalKey];
    if (value !== undefined && value !== null && String(value).trim() !== '') {
      return sanitizeCellText(value);
    }
    const aliases = HEADER_ALIASES[internalKey];
    for (const alias of aliases) {
      for (const key of Object.keys(row)) {
        if (key && String(key).toLowerCase().trim() === alias) {
          const v = row[key];
          if (v !== undefined && v !== null && String(v).trim() !== '') {
            return sanitizeCellText(v);
          }
        }
      }
    }
    return '';
  };
  let jobCode = get('jobCode');
  let jobTitle = get('jobTitle') || '';
  let currentStatus = get('currentStatus') || 'Active';
  // Fallback: no matching headers (e.g. headerless file or different column names) – use column order
  if (!jobCode && typeof row === 'object') {
    const values = Object.values(row).filter((v) => v !== undefined && v !== null && String(v).trim() !== '');
    if (values.length >= 1) {
      jobCode = sanitizeCellText(values[0]);
      jobTitle = values.length >= 2 ? sanitizeCellText(values[1]) : '';
      currentStatus = values.length >= 3 ? sanitizeCellText(values[2]) || 'Active' : 'Active';
    }
  }
  if (!jobCode) return null;
  jobCode = normalizeJobCode(jobCode);
  // Normalize status: #N/A or N/A -> Inactive (common in exports)
  const statusLower = (currentStatus || '').trim().toLowerCase();
  if (statusLower === '#n/a' || statusLower === 'n/a') {
    currentStatus = 'Inactive';
  }
  return { jobCode, jobTitle, currentStatus };
}

function processImportedData(importedData) {
  const mapped = [];
  for (const row of importedData) {
    const normalized = normalizeImportedRow(row);
    if (normalized) mapped.push(normalized);
  }
  return mapped;
}

// Parse CSV text into rows (array of string arrays)
function parseCSVRows(text) {
  const rows = [];
  let currentRow = [];
  let currentField = '';
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const nextChar = text[i + 1];
    if (char === '"') {
      if (inQuotes && nextChar === '"') {
        currentField += '"';
        i++;
      } else inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      currentRow.push(currentField);
      currentField = '';
    } else if ((char === '\n' || char === '\r') && !inQuotes) {
      if (char === '\r' && nextChar === '\n') i++;
      currentRow.push(currentField);
      if (currentRow.length > 0 && currentRow.some((f) => String(f).trim() !== '')) {
        rows.push([...currentRow]);
      }
      currentRow = [];
      currentField = '';
    } else {
      currentField += char;
    }
  }
  if (currentField !== '' || currentRow.length > 0) {
    currentRow.push(currentField);
    if (currentRow.length > 0 && currentRow.some((f) => String(f).trim() !== '')) {
      rows.push([...currentRow]);
    }
  }
  return rows;
}

// Job-code CSV import: works with or without header row; not restricted to RBAC table format
function readJobCodesCSV(file, onSuccess, onError) {
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      let text = e.target.result;
      if (!text || typeof text !== 'string') {
        onError('File is empty or invalid');
        return;
      }
      text = text.replace(/^\uFEFF/, '');
      if (!text.trim()) {
        onError('File is empty');
        return;
      }
      const rows = parseCSVRows(text);
      if (rows.length === 0) {
        onError('No rows found in file');
        return;
      }
      const data = [];
      const hasHeader = rows.length >= 2;
      const headers = hasHeader
        ? rows[0].map((h) => String(h || '').replace(/^\uFEFF/, '').trim())
        : ['Job Code', 'Job Title', 'Current Status'];
      const startIndex = hasHeader ? 1 : 0;
      for (let i = startIndex; i < rows.length; i++) {
        const row = rows[i];
        if (!row || row.length === 0 || row.every((c) => !c || String(c).trim() === '')) continue;
        const rowObj = {};
        headers.forEach((header, idx) => {
          const raw = row[idx] !== undefined && row[idx] !== null ? row[idx] : '';
          rowObj[header] = sanitizeCellText(raw);
        });
        data.push(rowObj);
      }
      if (data.length === 0) {
        onError('No valid data rows found');
        return;
      }
      onSuccess(data);
    } catch (err) {
      onError(err.message || 'Failed to parse CSV');
    }
  };
  reader.onerror = () => onError('Error reading file');
  reader.readAsText(file, 'UTF-8');
}

const JC_BULK_FIELDS = [
  { key: 'jobCode', label: 'Job Code' },
  { key: 'jobTitle', label: 'Job Title' },
  { key: 'currentStatus', label: 'Current Status', type: 'select', options: ['Active', 'Inactive'] },
];

const JcBulkUpdateDialog = ({ selectedCount, onApply, onClose }) => {
  const [field, setField] = useState('');
  const [value, setValue] = useState('');
  const fieldDef = JC_BULK_FIELDS.find((f) => f.key === field);
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!field) { alert('Please select a field.'); return; }
    if (!window.confirm(`Set "${fieldDef?.label || field}" to "${value}" on ${selectedCount} job code(s)?`)) return;
    onApply(field, value);
  };
  return (
    <div className="find-replace-overlay" onClick={onClose}>
      <div className="find-replace-dialog" onClick={(e) => e.stopPropagation()} style={{ maxWidth: 420 }}>
        <div className="find-replace-header">
          <h3>Bulk Update ({selectedCount} selected)</h3>
          <button type="button" className="find-replace-close" onClick={onClose}>&times;</button>
        </div>
        <form onSubmit={handleSubmit} style={{ padding: '1rem 1.25rem' }}>
          <div style={{ marginBottom: '0.75rem' }}>
            <label style={{ display: 'block', marginBottom: '0.25rem', fontWeight: 500, fontSize: '0.9rem' }}>Field</label>
            <select value={field} onChange={(e) => { setField(e.target.value); setValue(''); }} style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1' }}>
              <option value="">Select field...</option>
              {JC_BULK_FIELDS.map((f) => <option key={f.key} value={f.key}>{f.label}</option>)}
            </select>
          </div>
          {field && (
            <div style={{ marginBottom: '1rem' }}>
              <label style={{ display: 'block', marginBottom: '0.25rem', fontWeight: 500, fontSize: '0.9rem' }}>New Value</label>
              {fieldDef?.type === 'select' ? (
                <select value={value} onChange={(e) => setValue(e.target.value)} style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1' }} autoFocus>
                  <option value="">— (clear) —</option>
                  {fieldDef.options.map((o) => <option key={o} value={o}>{o}</option>)}
                </select>
              ) : (
                <input type="text" value={value} onChange={(e) => setValue(e.target.value)} style={{ width: '100%', padding: '0.5rem', borderRadius: 4, border: '1px solid #cbd5e1', boxSizing: 'border-box' }} autoFocus placeholder="Enter new value (leave empty to clear)" />
              )}
            </div>
          )}
          <div style={{ display: 'flex', gap: '0.5rem', justifyContent: 'flex-end' }}>
            <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn-primary" disabled={!field}>Apply</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const JobCodes = () => {
  const { showToast } = useToast();
  const [jobCodes, setJobCodes] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounce(searchTerm, 300);
  const [isImporting, setIsImporting] = useState(false);
  const [editingJobCode, setEditingJobCode] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [selectedRows, setSelectedRows] = useState(new Set());
  const [showBulkUpdate, setShowBulkUpdate] = useState(false);
  const undoRef = useRef(null);
  const [canUndo, setCanUndo] = useState(false);
  const [importPreview, setImportPreview] = useState(null);
  const fileInputRef = useRef(null);

  const filteredJobCodes = useMemo(() => {
    if (!debouncedSearchTerm.trim()) return jobCodes;
    const term = debouncedSearchTerm.trim().toLowerCase();
    return jobCodes.filter((jc) =>
      Object.values(jc).some((v) => v && String(v).toLowerCase().includes(term))
    );
  }, [jobCodes, debouncedSearchTerm]);

  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  const handleSort = useCallback((key) => {
    setSortConfig((prev) => nextSortState(prev, key));
  }, []);
  const displayJobCodes = useMemo(
    () => sortRowsByKey(filteredJobCodes, sortConfig.key, sortConfig.direction),
    [filteredJobCodes, sortConfig.key, sortConfig.direction]
  );

  useEffect(() => {
    loadJobCodes();
  }, []);

  const loadJobCodes = async () => {
    const loadedJobCodes = await getJobCodes();
    setJobCodes(loadedJobCodes);
  };

  const snapshotForUndo = useCallback((description) => {
    undoRef.current = { data: [...jobCodes], description };
    setCanUndo(true);
  }, [jobCodes]);

  const handleUndo = async () => {
    if (!undoRef.current) return;
    const { data: prevData, description } = undoRef.current;
    if (!window.confirm(`Undo "${description}"?`)) return;
    setJobCodes(prevData);
    try {
      await saveJobCodes(prevData);
      undoRef.current = null;
      setCanUndo(false);
      loadJobCodes();
      showToast(`Undone: ${description}`);
    } catch (err) {
      alert(err?.message || 'Undo failed.');
    }
  };

  const handleRowSelect = (id) => {
    setSelectedRows((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const allVisibleSelected = displayJobCodes.length > 0 && displayJobCodes.every((j) => selectedRows.has(j.id));

  const handleSelectAll = () => {
    if (allVisibleSelected) {
      setSelectedRows((prev) => { const next = new Set(prev); displayJobCodes.forEach((j) => next.delete(j.id)); return next; });
    } else {
      setSelectedRows((prev) => { const next = new Set(prev); displayJobCodes.forEach((j) => next.add(j.id)); return next; });
    }
  };

  const handleDeleteSelected = async () => {
    if (selectedRows.size === 0) return;
    if (!window.confirm(`Delete ${selectedRows.size} selected job code(s)?`)) return;
    snapshotForUndo(`Bulk delete ${selectedRows.size} job code(s)`);
    const updated = jobCodes.filter((j) => !selectedRows.has(j.id));
    try {
      await saveJobCodes(updated);
      for (const j of jobCodes) {
        if (selectedRows.has(j.id)) await addJobCodeAuditLog('DELETE', j, j);
      }
      const count = selectedRows.size;
      setSelectedRows(new Set());
      loadJobCodes();
      showToast(`Deleted ${count} job code(s).`);
    } catch (err) {
      alert(err?.message || 'Delete failed.');
    }
  };

  const handleBulkUpdate = async (field, value) => {
    if (selectedRows.size === 0) return;
    snapshotForUndo(`Bulk update ${selectedRows.size} job code(s) → ${field}`);
    const prevData = jobCodes;
    const updated = jobCodes.map((j) => {
      if (!selectedRows.has(j.id)) return j;
      return { ...j, [field]: value };
    });
    try {
      await saveJobCodes(updated);
      for (const j of updated) {
        if (selectedRows.has(j.id)) {
          const old = prevData.find((o) => o.id === j.id);
          if (old) await addJobCodeAuditLog('UPDATE', j, old);
        }
      }
      const count = selectedRows.size;
      setSelectedRows(new Set());
      loadJobCodes();
      showToast(`Updated ${count} job code(s).`);
    } catch (err) {
      alert(err?.message || 'Update failed.');
    }
    setShowBulkUpdate(false);
  };

  const handleAdd = () => {
    setEditingJobCode(null);
    setShowForm(true);
  };

  const handleEdit = (jobCode) => {
    setEditingJobCode(jobCode);
    setShowForm(true);
  };

  const handleDelete = async (jobCode) => {
    if (window.confirm('Are you sure you want to delete this job code?')) {
      snapshotForUndo(`Delete job code ${jobCode.jobCode || jobCode.id}`);
      const allJobCodes = await getJobCodes();
      const updatedJobCodes = allJobCodes.filter((j) => j.id !== jobCode.id);
      await saveJobCodes(updatedJobCodes);
      await addJobCodeAuditLog('DELETE', jobCode, jobCode);
      loadJobCodes();
    }
  };

  const handleFormSubmit = async (jobCodeData) => {
    snapshotForUndo(editingJobCode ? `Edit job code ${editingJobCode.jobCode || editingJobCode.id}` : 'Create new job code');
    const normalized = { ...jobCodeData, jobCode: normalizeJobCode(jobCodeData.jobCode || '') };
    if (editingJobCode) {
      const allJobCodes = await getJobCodes();
      const oldData = { ...editingJobCode };
      const updatedJobCodes = allJobCodes.map((j) =>
        j.id === editingJobCode.id ? { ...normalized, id: editingJobCode.id } : j
      );
      await saveJobCodes(updatedJobCodes);
      await addJobCodeAuditLog('UPDATE', { ...normalized, id: editingJobCode.id }, oldData);
    } else {
      // Append-only: never POST a full replacement list (avoids wiping when fetch/cache is empty/stale)
      const newJobCode = { ...normalized, id: generateId() };
      const result = await appendJobCodes([newJobCode]);
      if (!result || result.added === 0) {
        alert('Could not add job code. It may already exist, or the server request failed.');
        return;
      }
      await addJobCodeAuditLog('CREATE', newJobCode);
    }
    setShowForm(false);
    setEditingJobCode(null);
    loadJobCodes();
  };

  const handleExport = () => {
    const fieldToHeaderMap = {
      'jobCode': 'Job Code',
      'jobTitle': 'Job Title',
      'currentStatus': 'Current Status'
    };

    const fieldNames = Object.keys(fieldToHeaderMap);
    const csvHeaders = Object.values(fieldToHeaderMap);

    const exportData = jobCodes.map(jc => {
      const row = {};
      fieldNames.forEach(fieldName => {
        const val = fieldName === 'jobCode' ? normalizeJobCode(jc[fieldName] || '') : (jc[fieldName] || '');
        row[fieldToHeaderMap[fieldName]] = val;
      });
      return row;
    });

    const count = exportData.length;
    if (count >= 500) {
      showToast('Preparing export…');
      setTimeout(() => {
        try {
          exportToCSV(exportData, 'job_codes.csv', csvHeaders);
          showToast(`Exported ${count} job code(s)`);
        } catch (e) {
          showToast('Export failed');
        }
      }, 0);
    } else {
      exportToCSV(exportData, 'job_codes.csv', csvHeaders);
      showToast(`Exported ${count} job code(s)`);
    }
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const runImport = (importedData) => {
    const rawData = Array.isArray(importedData) ? importedData : (importedData && importedData[0] !== undefined ? [importedData] : []);
    const mappedData = processImportedData(rawData);

    if (!mappedData.length) {
      setIsImporting(false);
      alert('No valid job codes found. File should have at least a "Job Code" column (and optionally "Job Title", "Current Status").');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    const commitImport = async (importMode = 'merge') => {
      const shouldReplace = importMode === 'replace';
        snapshotForUndo(`Import ${mappedData.length} job code(s)`);
      try {
        let finalData;
        if (shouldReplace) {
          finalData = mappedData.map(row => ({ ...row, id: generateId() }));
          const auditEntries = finalData.map((code) => ({
            entityType: 'JOB_CODE',
            action: 'CREATE',
            entityData: code,
          }));
          await Promise.all([addAuditLogsBatch(auditEntries), saveJobCodes(finalData)]);
        } else {
          const allJobCodes = await getJobCodes();
          const existingByKey = {};
          allJobCodes.forEach((j) => {
            const key = (j.jobCode || '').trim().toLowerCase();
            if (key) existingByKey[key] = j;
          });
          const auditEntries = [];
          const newCodes = [];
          mappedData.forEach((row) => {
            const key = (row.jobCode || '').trim().toLowerCase();
            if (key && existingByKey[key]) {
              const prev = { ...existingByKey[key] };
              Object.assign(existingByKey[key], { ...row, id: existingByKey[key].id });
              auditEntries.push({ entityType: 'JOB_CODE', action: 'UPDATE', entityData: existingByKey[key], previousData: prev });
            } else {
              const newCode = { ...row, id: generateId() };
              newCodes.push(newCode);
              auditEntries.push({ entityType: 'JOB_CODE', action: 'CREATE', entityData: newCode });
            }
          });
          finalData = [...allJobCodes, ...newCodes];
          await Promise.all([addAuditLogsBatch(auditEntries), saveJobCodes(finalData)]);
        }
        loadJobCodes();
        showToast(`Successfully imported ${mappedData.length} job code(s)!`);
      } finally {
        setIsImporting(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };

    (async () => {
      const existing = await getJobCodes();
      setImportPreview({
        rows: mappedData,
        columns: ['jobCode', 'jobTitle', 'currentStatus'],
        existingData: existing,
        matchKey: 'jobCode',
        onConfirm: commitImport,
      });
    })();
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const name = (file.name || '').toLowerCase();
    const isCsv = name.endsWith('.csv');
    const isExcel = name.endsWith('.xlsx') || name.endsWith('.xls');

    if (!isCsv && !isExcel) {
      alert('Please select a CSV or Excel file (.csv, .xlsx, .xls)');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    const onError = (error) => {
      setIsImporting(false);
      alert(`Import failed: ${error}`);
      if (fileInputRef.current) fileInputRef.current.value = '';
    };

    setIsImporting(true);
    if (isCsv) {
      readJobCodesCSV(file, (data) => runImport(data), onError);
    } else {
      importFromExcel(
        file,
        (data) => runImport(data),
        onError
      );
    }
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingJobCode(null);
  };

  if (showForm) {
    return (
      <JobCodeForm
        jobCode={editingJobCode}
        existingJobCodes={jobCodes}
        onSubmit={handleFormSubmit}
        onCancel={handleCancel}
      />
    );
  }

  return (
    <div className="job-codes">
      <div className="job-codes-header">
        <h2>Job Codes</h2>
        <div className="actions">
          <div className="search-container">
            <input
              type="text"
              className="search-input"
              placeholder="Search job codes, titles, status..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              aria-label="Search job codes"
            />
          </div>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".csv,.xlsx,.xls"
            style={{ display: 'none' }}
          />
          <button className="btn-import" onClick={handleImportClick} title="Import job codes from CSV or Excel" disabled={isImporting}>
            {isImporting ? 'Importing…' : 'Import from CSV or Excel'}
          </button>
          {isImporting && <span className="import-status" role="status">Importing…</span>}
          <button className="btn-export" onClick={handleExport} title="Download job codes as CSV">
            Export to CSV
          </button>
          <button className="btn-add" onClick={handleAdd} title="Create a new job code (4 characters)">
            Add New Job Code
          </button>
          {canUndo && (
            <button type="button" className="btn-secondary btn-undo" onClick={handleUndo} title={undoRef.current ? `Undo: ${undoRef.current.description}` : 'Undo'}>Undo</button>
          )}
          <button type="button" className="btn-secondary" onClick={() => { if (selectedRows.size === 0) { alert('Select rows first.'); return; } setShowBulkUpdate(true); }} disabled={selectedRows.size === 0}>Bulk Update ({selectedRows.size})</button>
          <button type="button" className="btn-secondary btn-danger-outline" onClick={handleDeleteSelected} disabled={selectedRows.size === 0}>Bulk Delete ({selectedRows.size})</button>
        </div>
      </div>

      <div className="table-container">
        <table className="job-codes-table">
          <thead>
            <tr>
              <th style={{ width: 36, textAlign: 'center' }}><input type="checkbox" checked={allVisibleSelected} onChange={handleSelectAll} title="Select all" /></th>
              <SortableTh columnKey="jobCode" sortConfig={sortConfig} onSort={handleSort}>Job Code</SortableTh>
              <SortableTh columnKey="jobTitle" sortConfig={sortConfig} onSort={handleSort}>Job Title</SortableTh>
              <SortableTh columnKey="currentStatus" sortConfig={sortConfig} onSort={handleSort}>Current Status</SortableTh>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {displayJobCodes.map((jobCode) => (
              <tr key={jobCode.id}>
                <td style={{ textAlign: 'center' }}><input type="checkbox" checked={selectedRows.has(jobCode.id)} onChange={() => handleRowSelect(jobCode.id)} /></td>
                <td>{sanitizeCellText(normalizeJobCode(jobCode.jobCode))}</td>
                <td>{sanitizeCellText(jobCode.jobTitle)}</td>
                <td>{sanitizeCellText(jobCode.currentStatus)}</td>
                <td>
                  <button
                    className="btn-edit"
                    onClick={() => handleEdit(jobCode)}
                  >
                    Edit
                  </button>
                  <button
                    className="btn-delete"
                    onClick={() => handleDelete(jobCode)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {showBulkUpdate && (
        <JcBulkUpdateDialog selectedCount={selectedRows.size} onApply={handleBulkUpdate} onClose={() => setShowBulkUpdate(false)} />
      )}
      {importPreview && (
        <ImportPreviewDialog
          rows={importPreview.rows}
          columns={importPreview.columns}
          existingData={importPreview.existingData}
          matchKey={importPreview.matchKey}
          onConfirm={(mode) => { setImportPreview(null); importPreview.onConfirm(mode); }}
          onCancel={() => { setImportPreview(null); setIsImporting(false); if (fileInputRef.current) fileInputRef.current.value = ''; }}
          enableImportMode
          defaultImportMode="merge"
        />
      )}
    </div>
  );
};

export default JobCodes;
