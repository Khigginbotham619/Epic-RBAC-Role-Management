import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { getRoles, mergeRoles, patchRole, addAuditLog, getJobCategories, getJobCodes, getDepartments, getBlueprints, getTemplateLinks, getCurrentAuditUser } from '../utils/storage';
import { getBlanksForRole } from '../utils/fillBlanks';
import { isShellRbacRole } from '../utils/spExport';
import { normalizeJobCode } from '../utils/jobCodeUtils';
import { sanitizeRow } from '../utils/textSanitize';
import { useToast } from '../context/ToastContext';
import { useDeferredScan } from '../utils/deferredScan';
import SortableTh from './SortableTh';
import { sortRowsByKey, nextSortState } from '../utils/tableSort';
import './FindBlanks.css';

// Fields we autofill but do not prompt for in Find Blanks tab (sub templates and training tracks can be left blank)
const FILL_BLANKS_SKIP_FIELDS = new Set([
  'trainingTrack', 'trainingTrack2', 'trainingTrack3', 'trainingTrack4', 'trainingTrack5', 'trainingTrack6',
  'subtemplateId', 'subtemplateDescription'
]);

// True when computeFillUpdates proposed an actual value (not an empty string)
// to write into the blank field. Find Blanks should only surface rows that
// actually have something to fill.
const hasFillValue = (v) => v != null && String(v).trim() !== '';

const FIELD_LABELS = {
  deptCodeId: 'Dept Code/ID',
  jobCodeId: 'Job Code/ID',
  department: 'Department',
  jobTitle: 'Job Title',
  jobCategory: 'Job Category',
  blueprintName: 'Blueprint Name',
  linkedRoleTemplateId: 'Linked Role Template ID',
  linkedRoleTemplateName: 'Linked Role Template Name',
  templateDisplayTitle: 'Template Display Title',
  subtemplateId: 'Subtemplate ID',
  subtemplateDescription: 'Subtemplate Description',
  empNeeded: 'EMP Needed',
  slaNeeded: 'SER Needed',
  slaBlueprintId: 'SER Blueprint ID',
};

const FindBlanks = () => {
  const { showToast } = useToast();
  const [roles, setRoles] = useState([]);
  const [jobCategories, setJobCategories] = useState([]);
  const [jobCodes, setJobCodes] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [blueprints, setBlueprints] = useState([]);
  const [templateLinks, setTemplateLinks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filling, setFilling] = useState(false);

  const getLastEditValue = () => {
    const now = new Date();
    const dateTimeString = now.toLocaleString('en-US', {
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true
    });
    return `${dateTimeString} - ${getCurrentAuditUser()}`;
  };

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const [r, cats, codes, depts, bps, tls] = await Promise.all([
          getRoles(),
          getJobCategories(),
          getJobCodes(),
          getDepartments(),
          getBlueprints(),
          getTemplateLinks()
        ]);
        setRoles((Array.isArray(r) ? r : []).map(sanitizeRow));
        setJobCategories(Array.isArray(cats) ? cats : []);
        setJobCodes(Array.isArray(codes) ? codes : []);
        setDepartments(Array.isArray(depts) ? depts : []);
        setBlueprints(Array.isArray(bps) ? bps : []);
        setTemplateLinks(Array.isArray(tls) ? tls : []);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const context = useMemo(() => ({
    roles,
    jobCategories,
    jobCodes,
    departments,
    blueprints,
    templateLinks,
    getLastEditValue
  }), [roles, jobCategories, jobCodes, departments, blueprints, templateLinks]);

  const { result: scanResult, scanning } = useDeferredScan(
    () =>
      roles
        .filter((role) => !isShellRbacRole(role, jobCategories))
        .map((role) => {
          const { filledRole, changes } = getBlanksForRole(role, context);
          const promptableChanges = Object.fromEntries(
            Object.entries(changes).filter(
              ([k, v]) => !FILL_BLANKS_SKIP_FIELDS.has(k) && hasFillValue(v),
            )
          );
          return { role, filledRole, changes: promptableChanges };
        })
        .filter(({ changes }) => Object.keys(changes).length > 0),
    [loading, roles, context, jobCategories],
    !loading,
  );
  const rowsWithBlanks = useMemo(() => scanResult || [], [scanResult]);

  const getFindBlanksCell = useCallback((item, key) => {
    if (key === 'rbacCode') return item.role?.rbacCode ?? '';
    if (key === 'deptCodeId') return item.role?.deptCodeId ?? '';
    if (key === 'jobCodeId') return item.role?.jobCodeId ?? '';
    if (key === 'blanks') {
      return Object.entries(item.changes || {})
        .map(([f, v]) => `${f}:${v}`)
        .join(' ');
    }
    return '';
  }, []);

  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  const handleSort = useCallback((key) => {
    setSortConfig((prev) => nextSortState(prev, key));
  }, []);
  const displayBlankRows = useMemo(
    () => sortRowsByKey(rowsWithBlanks, sortConfig.key, sortConfig.direction, getFindBlanksCell),
    [rowsWithBlanks, sortConfig.key, sortConfig.direction, getFindBlanksCell]
  );

  const handleFillOne = async (row) => {
    const { role, filledRole } = row;
    setFilling(true);
    try {
      const updatedRoles = roles.map((r) => (r.id === role.id ? filledRole : r));
      setRoles(updatedRoles);
      await patchRole(filledRole);
      await addAuditLog('UPDATE', filledRole, role);
      const r = await getRoles({ fresh: true });
      setRoles((Array.isArray(r) ? r : []).map(sanitizeRow));
    } catch (err) {
      alert(err?.message || 'Failed to save.');
    } finally {
      setFilling(false);
    }
  };

  const handleFillAll = async () => {
    if (rowsWithBlanks.length === 0) {
      alert('No blanks to fill.');
      return;
    }
    if (!window.confirm(`Fill blanks in ${rowsWithBlanks.length} role(s)?`)) return;
    setFilling(true);
    try {
      const updatedRoles = roles.map((r) => {
        const row = rowsWithBlanks.find((x) => x.role.id === r.id);
        return row ? row.filledRole : r;
      });
      const prevRoles = roles;
      setRoles(updatedRoles);
      const patches = updatedRoles.filter(
        (r, i) => JSON.stringify(r) !== JSON.stringify(prevRoles[i])
      );
      if (patches.length > 0) await mergeRoles(patches);
      for (let i = 0; i < prevRoles.length; i++) {
        if (JSON.stringify(prevRoles[i]) !== JSON.stringify(updatedRoles[i])) {
          await addAuditLog('UPDATE', updatedRoles[i], prevRoles[i]);
        }
      }
      const r = await getRoles({ fresh: true });
      setRoles((Array.isArray(r) ? r : []).map(sanitizeRow));
      showToast(`Filled blanks in ${rowsWithBlanks.length} role(s).`);
    } catch (err) {
      alert(err?.message || 'Failed to save.');
    } finally {
      setFilling(false);
    }
  };

  if (loading) {
    return (
      <div className="find-blanks">
        <div className="find-blanks-header">
          <h2>Find Blanks</h2>
        </div>
        <p className="find-blanks-loading">Loading roles and reference data…</p>
      </div>
    );
  }

  return (
    <div className="find-blanks">
      <div className="find-blanks-header">
        <h2>Find Blanks</h2>
        <p className="find-blanks-desc">
          Roles with blank fields that can be filled from Job Codes, Departments, Blueprints, or Job Categories.
        </p>
        {scanning && <p className="find-blanks-loading">Scanning roles for fillable blanks…</p>}
        {!scanning && rowsWithBlanks.length > 0 && (
          <button
            type="button"
            className="find-blanks-btn-fill-all"
            onClick={handleFillAll}
            disabled={filling}
          >
            {filling ? 'Saving…' : `Fill all blanks (${rowsWithBlanks.length} roles)`}
          </button>
        )}
      </div>

      {scanning ? (
        <p className="find-blanks-empty">Scanning…</p>
      ) : rowsWithBlanks.length === 0 ? (
        <p className="find-blanks-empty">No roles with fillable blanks found.</p>
      ) : (
        <div className="find-blanks-table-wrap">
          <table className="find-blanks-table">
            <thead>
              <tr>
                <SortableTh columnKey="rbacCode" sortConfig={sortConfig} onSort={handleSort}>RBAC Code</SortableTh>
                <SortableTh columnKey="deptCodeId" sortConfig={sortConfig} onSort={handleSort}>Dept ID</SortableTh>
                <SortableTh columnKey="jobCodeId" sortConfig={sortConfig} onSort={handleSort}>Job Code</SortableTh>
                <SortableTh columnKey="blanks" sortConfig={sortConfig} onSort={handleSort}>Blanks (field → value to fill)</SortableTh>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {displayBlankRows.map(({ role, filledRole, changes }) => (
                <tr key={role.id}>
                  <td>{role.rbacCode || '—'}</td>
                  <td>{role.deptCodeId || '—'}</td>
                  <td>{role.jobCodeId ? normalizeJobCode(role.jobCodeId) : '—'}</td>
                  <td className="find-blanks-blobs">
                    <ul>
                      {Object.entries(changes).map(([field, value]) => (
                        <li key={field}>
                          <strong>{FIELD_LABELS[field] || field}</strong> → {String(value).slice(0, 60)}{value && String(value).length > 60 ? '…' : ''}
                        </li>
                      ))}
                    </ul>
                  </td>
                  <td>
                    <button
                      type="button"
                      className="find-blanks-btn-fill-one"
                      onClick={() => handleFillOne({ role, filledRole, changes })}
                      disabled={filling}
                    >
                      Fill this role
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default FindBlanks;
