import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useDebounce } from '../utils/useDebounce';
import { getRoles, getJobCategories, getSPExportTable, saveSPExportTable } from '../utils/storage';
import { buildExportForSPRows } from '../utils/spExport';
import { exportToCSV } from '../utils/csvExport';
import SortableTh from './SortableTh';
import { sortRowsByKey, nextSortState } from '../utils/tableSort';
import { useToast } from '../context/ToastContext';
import './Departments.css';

const MAX_RENDERED_ROWS = 1500;

const SPExportTable = () => {
  const { showToast } = useToast();
  const [rows, setRows] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounce(searchTerm, 300);
  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });

  const loadRows = useCallback(async () => {
    const persisted = await getSPExportTable();
    if (persisted.length > 0) {
      setRows(persisted);
      return;
    }
    const [roles, jobCategories] = await Promise.all([getRoles(), getJobCategories()]);
    const publishableRoles = (Array.isArray(roles) ? roles : []).filter(
      (r) => String(r.publishToSailpoint || '').trim().toLowerCase() === 'yes'
    );
    const rebuiltRows = buildExportForSPRows(publishableRoles, jobCategories);
    setRows(rebuiltRows);
    await saveSPExportTable(rebuiltRows);
  }, []);

  const rebuildRows = useCallback(async () => {
    const [roles, jobCategories] = await Promise.all([getRoles(), getJobCategories()]);
    const publishableRoles = (Array.isArray(roles) ? roles : []).filter(
      (r) => String(r.publishToSailpoint || '').trim().toLowerCase() === 'yes'
    );
    const rebuiltRows = buildExportForSPRows(publishableRoles, jobCategories);
    setRows(rebuiltRows);
    const ok = await saveSPExportTable(rebuiltRows);
    if (ok) {
      showToast(`Refreshed and saved ${rebuiltRows.length} row(s).`);
    } else {
      showToast(`Refreshed ${rebuiltRows.length} row(s), but save failed.`);
    }
  }, [showToast]);

  useEffect(() => {
    loadRows();
  }, [loadRows]);

  const filteredRows = useMemo(() => {
    if (!debouncedSearchTerm.trim()) return rows;
    const term = debouncedSearchTerm.trim().toLowerCase();
    return rows.filter((row) =>
      Object.values(row).some((v) => String(v || '').toLowerCase().includes(term))
    );
  }, [rows, debouncedSearchTerm]);

  const handleSort = useCallback((key) => {
    setSortConfig((prev) => nextSortState(prev, key));
  }, []);

  const displayRows = useMemo(
    () => sortRowsByKey(filteredRows, sortConfig.key, sortConfig.direction),
    [filteredRows, sortConfig.key, sortConfig.direction]
  );
  const rowsToRender = useMemo(
    () => (displayRows.length <= MAX_RENDERED_ROWS ? displayRows : displayRows.slice(0, MAX_RENDERED_ROWS)),
    [displayRows]
  );

  const handleExport = () => {
    const headers = ['RBAC Code', 'Template', 'SER Needed', 'SER Blueprint ID', 'Affiliate'];
    const exportData = displayRows.map((r) => ({
      'RBAC Code': r.rbacCode || '',
      Template: r.template || '',
      'SER Needed': r.serNeeded || '',
      'SER Blueprint ID': r.serBlueprintId || '',
      Affiliate: r.affiliate || '',
    }));
    exportToCSV(exportData, 'rbac_export_for_sp_preview.csv', headers);
    showToast(`Exported ${exportData.length} row(s)`);
  };

  return (
    <div className="departments">
      <div className="departments-header">
        <h2>SP Export Table</h2>
        <div className="actions">
          <div className="search-container">
            <input
              type="text"
              className="search-input"
              placeholder="Search SP export rows..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              aria-label="Search SP export rows"
            />
          </div>
          <button className="btn-export" onClick={handleExport}>
            Export to CSV
          </button>
          <button className="btn-import" onClick={rebuildRows}>
            Refresh
          </button>
        </div>
      </div>
      <div className="table-container">
        {displayRows.length > MAX_RENDERED_ROWS && (
          <p className="admin-muted" style={{ padding: '0.5rem 0.75rem' }}>
            Showing first {MAX_RENDERED_ROWS.toLocaleString()} of {displayRows.length.toLocaleString()} rows.
            Narrow search to see the rest.
          </p>
        )}
        <table className="departments-table">
          <thead>
            <tr>
              <SortableTh columnKey="rbacCode" sortConfig={sortConfig} onSort={handleSort}>RBAC Code</SortableTh>
              <SortableTh columnKey="template" sortConfig={sortConfig} onSort={handleSort}>Template</SortableTh>
              <SortableTh columnKey="serNeeded" sortConfig={sortConfig} onSort={handleSort}>SER Needed</SortableTh>
              <SortableTh columnKey="serBlueprintId" sortConfig={sortConfig} onSort={handleSort}>SER Blueprint ID</SortableTh>
              <SortableTh columnKey="affiliate" sortConfig={sortConfig} onSort={handleSort}>Affiliate</SortableTh>
            </tr>
          </thead>
          <tbody>
            {displayRows.length === 0 ? (
              <tr>
                <td colSpan={5}>No rows.</td>
              </tr>
            ) : (
              rowsToRender.map((row, idx) => (
                <tr key={`${row.rbacCode || 'row'}-${idx}`}>
                  <td>{row.rbacCode || '—'}</td>
                  <td className="text-cell">{row.template || '—'}</td>
                  <td>{row.serNeeded || '—'}</td>
                  <td>{row.serBlueprintId || '—'}</td>
                  <td>{row.affiliate || '—'}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SPExportTable;
