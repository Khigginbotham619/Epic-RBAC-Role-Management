import React, { useState, useRef, useEffect, useMemo } from 'react';
import './BlueprintDropdown.css';

// Sentinel for "Other (free text)" selected but no custom text yet. Uses zero-width space so user-typed "__other__" is preserved.
export const BLUEPRINT_OTHER = '\u200B__other__';

export default function BlueprintDropdown({ id, value, options, onChange, onAddNew, allowFreeText = false, placeholder = 'Select blueprint...' }) {
  const [open, setOpen] = useState(false);
  const [showAddNew, setShowAddNew] = useState(false);
  const [newBlueprintId, setNewBlueprintId] = useState('');
  const [newBlueprintName, setNewBlueprintName] = useState('');
  const [filter, setFilter] = useState('');
  const filterInputRef = useRef(null);
  const containerRef = useRef(null);
  const firstAddInputRef = useRef(null);

  const sortedOptions = useMemo(() => {
    const list = Array.isArray(options) ? [...options] : [];
    return list.sort((a, b) => {
      const na = (a.blueprintId || '').trim().toLowerCase();
      const nb = (b.blueprintId || '').trim().toLowerCase();
      return na.localeCompare(nb);
    });
  }, [options]);

  const filteredOptions = useMemo(() => {
    const term = (filter || '').trim().toLowerCase();
    if (!term) return sortedOptions;
    return sortedOptions.filter((b) => {
      const id = (b.blueprintId || '').trim().toLowerCase();
      const name = (b.blueprintName || '').trim().toLowerCase();
      return id.includes(term) || name.includes(term);
    });
  }, [sortedOptions, filter]);

  const selectedBlueprint = useMemo(() => {
    const v = (value || '').toString().trim();
    if (!v || v === BLUEPRINT_OTHER) return null;
    return sortedOptions.find((b) => (b.blueprintId || '').toString().trim() === v) || null;
  }, [value, sortedOptions]);

  const isFreeText = allowFreeText && (value === BLUEPRINT_OTHER || (value && !sortedOptions.some((b) => (b.blueprintId || '').toString().trim() === String(value).trim())));

  const displayText = selectedBlueprint
    ? [selectedBlueprint.blueprintId, selectedBlueprint.blueprintName].filter(Boolean).join(' – ') || selectedBlueprint.blueprintId
    : value === BLUEPRINT_OTHER ? 'Other (free text)' : (value && allowFreeText ? value : placeholder);

  useEffect(() => {
    if (!open) return;
    setFilter('');
    const handleClickOutside = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
        setShowAddNew(false);
        setNewBlueprintId('');
        setNewBlueprintName('');
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [open]);

  useEffect(() => {
    if (open && !showAddNew && filterInputRef.current && !isFreeText) {
      filterInputRef.current.focus();
    }
  }, [open, showAddNew, isFreeText]);

  useEffect(() => {
    if (showAddNew && firstAddInputRef.current) firstAddInputRef.current.focus();
  }, [showAddNew]);

  const handleSelect = (blueprint) => {
    onChange(blueprint);
    setOpen(false);
    setShowAddNew(false);
    setNewBlueprintId('');
    setNewBlueprintName('');
    setFilter('');
  };

  const handleAddNew = async () => {
    const blueprintId = (newBlueprintId || '').trim();
    const blueprintName = (newBlueprintName || '').trim();
    if (!blueprintId || typeof onAddNew !== 'function') return;
    await onAddNew({ blueprintId, blueprintName });
    setNewBlueprintId('');
    setNewBlueprintName('');
    setShowAddNew(false);
    setOpen(false);
  };

  return (
    <div className="blueprint-dropdown" ref={containerRef}>
      <div
        role="combobox"
        aria-haspopup="listbox"
        aria-expanded={open}
        className={`blueprint-dropdown-trigger${open ? ' blueprint-dropdown-trigger-open' : ''}`}
      >
        {isFreeText ? (
          <input
            type="text"
            id={id}
            className="blueprint-dropdown-input"
            value={value === BLUEPRINT_OTHER ? '' : value}
            onChange={(e) => onChange({ blueprintId: e.target.value, blueprintName: e.target.value })}
            placeholder="Type or select..."
            onClick={(e) => e.stopPropagation()}
          />
        ) : (
          <button
            type="button"
            id={id}
            className="blueprint-dropdown-trigger-btn"
            onClick={() => setOpen((o) => !o)}
          >
            <span className="blueprint-dropdown-value">{displayText}</span>
          </button>
        )}
        <span className="blueprint-dropdown-arrow" onClick={() => setOpen((o) => !o)} role="button" tabIndex={-1} aria-label="Open list">▼</span>
      </div>
      {open && (
        <ul className="blueprint-dropdown-list" role="listbox">
          <li className="blueprint-dropdown-filter-row" onClick={(e) => e.stopPropagation()}>
            <input
              ref={filterInputRef}
              type="text"
              className="blueprint-dropdown-filter-input"
              placeholder="Type to find..."
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              onKeyDown={(e) => e.stopPropagation()}
            />
          </li>
          <li role="option" onClick={() => handleSelect(null)}>
            {placeholder}
          </li>
          {filteredOptions.map((b) => (
            <li key={b.id} role="option" onClick={() => handleSelect({ blueprintId: (b.blueprintId || '').trim(), blueprintName: (b.blueprintName || '').trim() })}>
              {[b.blueprintId, b.blueprintName].filter(Boolean).join(' – ') || b.blueprintId}
            </li>
          ))}
          {filteredOptions.length === 0 && filter.trim() && (
            <li className="blueprint-dropdown-no-results">No matches</li>
          )}
          {allowFreeText && (
            <li role="option" onClick={() => handleSelect({ blueprintId: BLUEPRINT_OTHER, blueprintName: '' })}>
              Other (free text)
            </li>
          )}
          {typeof onAddNew === 'function' && (
            <li className="blueprint-dropdown-add-new" role="option">
              {!showAddNew ? (
                <button type="button" className="blueprint-add-new-trigger" onClick={(e) => { e.stopPropagation(); setShowAddNew(true); }}>
                  Add new...
                </button>
              ) : (
                <div className="blueprint-add-new-form" onClick={(e) => e.stopPropagation()}>
                  <input
                    ref={firstAddInputRef}
                    type="text"
                    value={newBlueprintId}
                    onChange={(e) => setNewBlueprintId(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleAddNew(); } if (e.key === 'Escape') { setShowAddNew(false); setNewBlueprintId(''); setNewBlueprintName(''); } }}
                    placeholder="Blueprint ID"
                  />
                  <input
                    type="text"
                    value={newBlueprintName}
                    onChange={(e) => setNewBlueprintName(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleAddNew(); } if (e.key === 'Escape') { setShowAddNew(false); setNewBlueprintId(''); setNewBlueprintName(''); } }}
                    placeholder="Blueprint Name"
                  />
                  <button type="button" className="blueprint-add-btn" onClick={handleAddNew}>Add</button>
                </div>
              )}
            </li>
          )}
        </ul>
      )}
    </div>
  );
}
