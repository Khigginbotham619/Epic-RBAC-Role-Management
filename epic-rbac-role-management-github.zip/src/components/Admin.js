import React, { useState, useEffect } from 'react';
import {
  getRoles,
  saveRoles,
  saveRolesBatch,
  getJobCategories,
  getJobCodes,
  getDepartments,
  getBlueprints,
  getTrainingTracks,
  getTemplateLinks,
  getSailpointRoles,
  saveJobCategories,
  saveJobCodes,
  saveDepartments,
  saveBlueprints,
  saveTrainingTracks,
  invalidateCache,
  RESTORE_TIMEOUT_MS,
} from '../utils/storage';
import { normalizeJobCode } from '../utils/jobCodeUtils';
import {
  reportRolesWithInactiveTemplateLinks,
  reportJobCategoriesLinkedToInactiveTemplates,
  reportSailpointRolesAttachedToInactiveTemplates,
  reportRolesWithOrphanTemplateRefs,
  reportJobCategorySailpointIssues,
  reportRolesWithInactiveJobCategory,
  reportRolesConnectedToInactive,
  reportJobCategoriesMissingBlueprintWhenSer,
  reportJobCategoriesWithNoRoles,
  reportRolesSailpointDriftFromCategory,
  reportJobCategorySailpointReconciliation,
  reportJobCategoryMergeClusters,
  reportJobCategoriesLinkedToNonRequestableSailpoint,
  reportDuplicateSailpointRolesOnJobCategories,
  downloadCsv,
  downloadXlsx,
} from '../utils/adminReports';
import { useToast } from '../context/ToastContext';
import './Admin.css';

const PRESET_STORAGE_KEY = 'rbac_filter_presets';
const PENDING_PRESET_KEY = 'rbac_pending_preset_id';
const EDIT_SELECTED_KEY = 'adminEditSelected';
const SELECTED_IDS_KEY = 'rbac_selected_role_ids';
const CURRENT_FILTERS_KEY = 'rbac_current_filters';

const Admin = ({ setCurrentView, allowBulkActions = false }) => {
  const { showToast } = useToast();
  const [savedPresets, setSavedPresets] = useState([]);
  const [reportsLoading, setReportsLoading] = useState(false);
  const [reports, setReports] = useState(null);
  const [reportsLoadedAt, setReportsLoadedAt] = useState(null);

  useEffect(() => {
    const presets = JSON.parse(localStorage.getItem(PRESET_STORAGE_KEY) || '[]');
    setSavedPresets(presets);
  }, []);

  const handleEditSelected = () => {
    const ids = JSON.parse(sessionStorage.getItem(SELECTED_IDS_KEY) || '[]');
    if (!ids.length) {
      alert('No rows selected. Go to Roles Management, select one or more rows, then try again.');
      return;
    }
    sessionStorage.setItem(EDIT_SELECTED_KEY, '1');
    setCurrentView('roles');
  };

  const handleReload = () => {
    invalidateCache('roles');
    showToast('Cache cleared. Go to Roles Management to see the latest data.');
  };

  const handleLoadPreset = (e) => {
    const presetId = e.target.value;
    if (!presetId) return;
    sessionStorage.setItem(PENDING_PRESET_KEY, presetId);
    setCurrentView('roles');
    e.target.value = '';
  };

  const handleSavePreset = () => {
    const raw = sessionStorage.getItem(CURRENT_FILTERS_KEY);
    if (!raw) {
      alert('No current filters. Go to Roles Management and set search/filters first.');
      return;
    }
    const presetName = window.prompt('Enter a name for this filter preset:');
    if (!presetName) return;
    try {
      const filters = JSON.parse(raw);
      const preset = {
        id: Date.now().toString(),
        name: presetName,
        searchTerm: filters.searchTerm || '',
        statusFilter: filters.statusFilter || 'All',
        recentlyEditedFilter: !!filters.recentlyEditedFilter,
        newIn24hFilter: !!filters.newIn24hFilter,
        advancedFilters: filters.advancedFilters || {},
      };
      const presets = JSON.parse(localStorage.getItem(PRESET_STORAGE_KEY) || '[]');
      presets.push(preset);
      localStorage.setItem(PRESET_STORAGE_KEY, JSON.stringify(presets));
      setSavedPresets(presets);
      alert('Filter preset saved!');
    } catch (e) {
      alert('Could not read current filters. Set filters on Roles Management first.');
    }
  };

  const handleBackup = async () => {
    try {
      const allData = {
        roles: await getRoles(),
        jobCategories: await getJobCategories(),
        jobCodes: await getJobCodes(),
        departments: await getDepartments(),
        blueprints: await getBlueprints(),
        trainingTracks: await getTrainingTracks(),
        exportDate: new Date().toISOString(),
      };
      const dataStr = JSON.stringify(allData, null, 2);
      const blob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `rbac_backup_${new Date().toISOString().split('T')[0]}.json`;
      link.click();
      URL.revokeObjectURL(url);
      showToast('Backup created successfully!');
    } catch (err) {
      alert(err?.message || 'Backup failed.');
    }
  };

  const handleRestore = () => {
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.json';
    fileInput.onchange = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const raw = JSON.parse(event.target.result);
          // Support backup as object { roles, jobCategories, ... } or legacy single array as roles
          const data = Array.isArray(raw) ? { roles: raw } : raw;
          if (!data || typeof data !== 'object') {
            alert('Invalid backup file: expected a JSON object or array.');
            return;
          }
          if (!window.confirm('This will replace ALL current data. Continue?')) return;
          (async () => {
            try {
              const restoreOpts = {
                timeoutMs: RESTORE_TIMEOUT_MS,
                force: true,
                allowShrink: true,
              };
              // Audit history is intentionally not restored; only data (roles, job categories, etc.) is restored.
              if (data.roles != null) {
                const roles = Array.isArray(data.roles) ? data.roles : [];
                const BATCH_SIZE = 50;
                if (roles.length <= BATCH_SIZE) {
                  await saveRoles(roles, restoreOpts);
                } else {
                  await saveRolesBatch(roles.slice(0, BATCH_SIZE), true, { ...restoreOpts, destructiveReplaceConfirmed: true });
                  for (let i = BATCH_SIZE; i < roles.length; i += BATCH_SIZE) {
                    await saveRolesBatch(roles.slice(i, i + BATCH_SIZE), false, restoreOpts);
                  }
                }
              }
              if (data.jobCategories != null) {
                await saveJobCategories(Array.isArray(data.jobCategories) ? data.jobCategories : [], restoreOpts);
              }
              if (data.jobCodes != null) {
                const ok = await saveJobCodes(Array.isArray(data.jobCodes) ? data.jobCodes : [], restoreOpts);
                if (!ok) throw new Error('Failed to restore job codes.');
              }
              if (data.departments != null) {
                const ok = await saveDepartments(Array.isArray(data.departments) ? data.departments : [], restoreOpts);
                if (!ok) throw new Error('Failed to restore departments.');
              }
              if (data.blueprints != null) {
                const ok = await saveBlueprints(Array.isArray(data.blueprints) ? data.blueprints : [], restoreOpts);
                if (!ok) throw new Error('Failed to restore blueprints.');
              }
              if (data.trainingTracks != null) {
                const ok = await saveTrainingTracks(Array.isArray(data.trainingTracks) ? data.trainingTracks : [], restoreOpts);
                if (!ok) throw new Error('Failed to restore training tracks.');
              }
              invalidateCache('roles');
              invalidateCache('job-categories');
              invalidateCache('job-codes');
              invalidateCache('departments');
              invalidateCache('blueprints');
              invalidateCache('training-tracks');
              alert('Data restored successfully! Go to Roles Management to see the data.');
            } catch (err) {
              alert(err?.message || 'Restore failed. Check the server and try again.');
            }
          })();
        } catch (error) {
          alert(`Error restoring data: ${error.message}`);
        }
      };
      reader.readAsText(file);
    };
    fileInput.click();
  };

  const checkDuplicates = async () => {
    const roles = await getRoles();
    const rbacCodes = {};
    const duplicates = [];
    roles.forEach((role) => {
      if (!role.rbacCode) return;
      if (!rbacCodes[role.rbacCode]) rbacCodes[role.rbacCode] = [];
      rbacCodes[role.rbacCode].push(role);
    });
    Object.keys(rbacCodes).forEach((code) => {
      if (rbacCodes[code].length > 1) {
        duplicates.push({ rbacCode: code, count: rbacCodes[code].length, roles: rbacCodes[code] });
      }
    });
    if (duplicates.length > 0) {
      const message = duplicates
        .map((d) => `RBAC Code "${d.rbacCode}": ${d.count} occurrences`)
        .join('\n');
      alert(`Found ${duplicates.length} duplicate RBAC code(s):\n\n${message}`);
    } else {
      showToast('No duplicate RBAC codes found.');
    }
  };

  const generateValidationReport = async () => {
    const [roles, jobCategories, departments, jobCodes] = await Promise.all([
      getRoles(),
      getJobCategories(),
      getDepartments(),
      getJobCodes(),
    ]);
    const issues = [];
    roles.forEach((role) => {
      if (!role.rbacCode) issues.push({ type: 'Missing RBAC Code', role });
      if (!role.jobTitle) issues.push({ type: 'Missing Job Title', role });
      if (role.jobCategory) {
        const category = jobCategories.find((c) => c.jobCategoryName === role.jobCategory);
        if (!category) issues.push({ type: 'Invalid Job Category', role, detail: role.jobCategory });
      }
      if (role.deptCodeId) {
        const dept = departments.find((d) => d.deptId === role.deptCodeId);
        if (!dept) issues.push({ type: 'Invalid Department Code', role, detail: role.deptCodeId });
      }
      if (role.jobCodeId) {
        const code = normalizeJobCode(role.jobCodeId);
        const jobCode = jobCodes.find((j) => normalizeJobCode(j.jobCode) === code);
        if (!jobCode) issues.push({ type: 'Invalid Job Code', role, detail: role.jobCodeId });
      }
    });
    if (issues.length === 0) {
      alert('No validation issues found!');
      return;
    }
    const report = issues
      .map(
        (issue) =>
          `${issue.type}: RBAC Code ${issue.role.rbacCode || 'N/A'}${issue.detail ? ` (${issue.detail})` : ''}`
      )
      .join('\n');
    alert(`Found ${issues.length} validation issue(s):\n\n${report}`);
  };

  const cleanupData = async () => {
    const actions = window.prompt(
      'Select cleanup action:\n' +
        '1 - Remove roles with missing RBAC codes\n' +
        '2 - Remove duplicate RBAC codes (keep first)\n' +
        '3 - Fix invalid references\n' +
        '4 - Remove inactive roles older than 90 days'
    );
    if (!actions) return;

    let roles = await getRoles();
    let cleaned = [...roles];
    let removed = 0;

    if (actions.includes('1')) {
      const before = cleaned.length;
      cleaned = cleaned.filter((r) => r.rbacCode && r.rbacCode.trim());
      removed += before - cleaned.length;
    }

    if (actions.includes('2')) {
      const seen = new Set();
      cleaned = cleaned.filter((r) => {
        if (!r.rbacCode) return true;
        if (seen.has(r.rbacCode)) {
          removed++;
          return false;
        }
        seen.add(r.rbacCode);
        return true;
      });
    }

    if (actions.includes('3')) {
      const jobCategories = await getJobCategories();
      cleaned = cleaned.map((r) => {
        const copy = { ...r };
        if (copy.jobCategory) {
          const category = jobCategories.find((c) => c.jobCategoryName === copy.jobCategory);
          if (!category) copy.jobCategory = '';
        }
        return copy;
      });
    }

    if (actions.includes('4')) {
      const cutoff = new Date();
      cutoff.setDate(cutoff.getDate() - 90);
      const before = cleaned.length;
      cleaned = cleaned.filter((r) => {
        if (r.status === 'Inactive' && r.lastEditChangeControlDateReason) {
          const editDate = new Date(r.lastEditChangeControlDateReason);
          return editDate > cutoff;
        }
        return true;
      });
      removed += before - cleaned.length;
    }

    if (removed > 0 || actions.includes('3')) {
      if (window.confirm(`This will modify ${removed} role(s). Continue?`)) {
        try {
          await saveRoles(cleaned, { force: true, allowShrink: true });
          invalidateCache('roles');
          showToast('Cleanup complete.');
        } catch (err) {
          alert(err?.message || 'Cleanup failed.');
        }
      }
    }
  };

  const runDataQualityReports = async () => {
    setReportsLoading(true);
    try {
      const [roles, jobCategories, templateLinks, sailpointRoles, jobCodes] = await Promise.all([
        getRoles(),
        getJobCategories(),
        getTemplateLinks(),
        getSailpointRoles(),
        getJobCodes(),
      ]);
      setReports({
        rolesInactiveConnections: reportRolesConnectedToInactive(
          roles,
          jobCategories,
          templateLinks,
          jobCodes,
          sailpointRoles
        ),
        inactiveTpl: reportRolesWithInactiveTemplateLinks(roles, templateLinks),
        inactiveCategoryTpl: reportJobCategoriesLinkedToInactiveTemplates(jobCategories, templateLinks),
        sailpointInactiveTpl: reportSailpointRolesAttachedToInactiveTemplates(sailpointRoles, templateLinks),
        orphanTpl: reportRolesWithOrphanTemplateRefs(roles, templateLinks),
        sailpointCat: reportJobCategorySailpointIssues(jobCategories, sailpointRoles),
        inactiveJcat: reportRolesWithInactiveJobCategory(roles, jobCategories),
        missingBp: reportJobCategoriesMissingBlueprintWhenSer(jobCategories),
        jobCategoriesNoRoles: reportJobCategoriesWithNoRoles(roles, jobCategories),
        sailpointDrift: reportRolesSailpointDriftFromCategory(roles, jobCategories),
        sailpointReconciliation: reportJobCategorySailpointReconciliation(jobCategories, sailpointRoles),
        mergeClusters: reportJobCategoryMergeClusters(jobCategories),
        nonRequestableSailpoint: reportJobCategoriesLinkedToNonRequestableSailpoint(
          jobCategories,
          sailpointRoles,
          roles
        ),
        duplicateSailpointOnCategories: reportDuplicateSailpointRolesOnJobCategories(
          jobCategories,
          sailpointRoles,
          roles
        ),
        sailpointCatalog: sailpointRoles,
      });
      setReportsLoadedAt(new Date());
      showToast('Data quality reports refreshed.');
    } catch (err) {
      alert(err?.message || 'Failed to load reports.');
    } finally {
      setReportsLoading(false);
    }
  };

  const csvStamp = () => new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-');

  const exportRolesInactiveConnectionsCsv = () => {
    if (!reports?.rolesInactiveConnections?.length) return;
    const headers = [
      'RBAC',
      'Role status',
      'Job category',
      'Connection type',
      'Detail',
      'Inactive status',
      'Field',
    ];
    const rows = [];
    for (const { role, issues } of reports.rolesInactiveConnections) {
      for (const issue of issues) {
        rows.push([
          role.rbacCode || '',
          role.status || 'Active',
          role.jobCategory || '',
          issue.connectionType,
          issue.detail,
          issue.status,
          issue.field || '',
        ]);
      }
    }
    downloadCsv(`admin_report_roles_connected_to_inactive_${csvStamp()}.csv`, headers, rows);
  };

  const exportInactiveTplCsv = () => {
    if (!reports?.inactiveTpl?.length) return;
    const headers = ['rbac_code', 'role_status', 'job_category', 'match_field', 'token', 'template_link_status', 'record_type'];
    const rows = [];
    for (const { role, hits } of reports.inactiveTpl) {
      for (const h of hits) {
        rows.push([
          role.rbacCode,
          role.status || 'Active',
          role.jobCategory || '',
          h.field,
          h.token,
          h.linkStatus,
          h.recordType,
        ]);
      }
    }
    downloadCsv(`admin_report_inactive_template_links_${csvStamp()}.csv`, headers, rows);
    showToast(`Exported ${rows.length} row(s).`);
  };

  const exportOrphanTplCsv = () => {
    if (!reports?.orphanTpl?.length) return;
    const headers = ['rbac_code', 'role_status', 'job_category', 'orphan_field', 'orphan_token'];
    const rows = [];
    for (const { role, orphans } of reports.orphanTpl) {
      for (const o of orphans) {
        rows.push([role.rbacCode, role.status || 'Active', role.jobCategory || '', o.field, o.token]);
      }
    }
    downloadCsv(`admin_report_orphan_template_refs_${csvStamp()}.csv`, headers, rows);
    showToast(`Exported ${rows.length} row(s).`);
  };

  const exportInactiveCategoryTplCsv = () => {
    if (!reports?.inactiveCategoryTpl?.length) return;
    const headers = ['job_category_id', 'job_category_name', 'category_status', 'match_field', 'token', 'template_link_status', 'record_type'];
    const rows = [];
    for (const { category, hits } of reports.inactiveCategoryTpl) {
      for (const h of hits) {
        rows.push([
          category.jobCategoryId || '',
          category.jobCategoryName || '',
          category.status || 'Active',
          h.field,
          h.token,
          h.linkStatus,
          h.recordType,
        ]);
      }
    }
    downloadCsv(`admin_report_job_categories_inactive_template_links_${csvStamp()}.csv`, headers, rows);
    showToast(`Exported ${rows.length} row(s).`);
  };

  const exportSailpointInactiveTplCsv = () => {
    if (!reports?.sailpointInactiveTpl?.length) return;
    const headers = [
      'sailpoint_role',
      'sailpoint_status',
      'requestable',
      'match_field',
      'token',
      'template_link_status',
      'record_type',
    ];
    const rows = [];
    for (const { sailpointRoleRow, hits } of reports.sailpointInactiveTpl) {
      for (const h of hits) {
        rows.push([
          sailpointRoleRow.sailpointRole || '',
          sailpointRoleRow.status || 'Active',
          sailpointRoleRow.requestable || '',
          h.field,
          h.token,
          h.linkStatus,
          h.recordType,
        ]);
      }
    }
    downloadCsv(`admin_report_sailpoint_roles_inactive_template_links_${csvStamp()}.csv`, headers, rows);
    showToast(`Exported ${rows.length} row(s).`);
  };

  const exportSailpointCatCsv = () => {
    if (!reports?.sailpointCat?.length) return;
    const headers = ['job_category_id', 'job_category_name', 'category_status', 'issue_codes', 'issue_labels', 'sailpoint_role_value'];
    const rows = reports.sailpointCat.map(({ category, issues }) => [
      category.jobCategoryId,
      category.jobCategoryName,
      category.status || 'Active',
      issues.map((i) => i.code).join('; '),
      issues.map((i) => i.label).join('; '),
      category.sailpointRole || '',
    ]);
    downloadCsv(`admin_report_job_category_sailpoint_${csvStamp()}.csv`, headers, rows);
    showToast(`Exported ${rows.length} row(s).`);
  };

  const exportInactiveJcatCsv = () => {
    if (!reports?.inactiveJcat?.length) return;
    const headers = ['rbac_code', 'role_status', 'job_category_name', 'job_category_id', 'category_status'];
    const rows = reports.inactiveJcat.map(({ role, category }) => [
      role.rbacCode,
      role.status || 'Active',
      category.jobCategoryName,
      category.jobCategoryId,
      category.status || 'Active',
    ]);
    downloadCsv(`admin_report_roles_inactive_job_category_${csvStamp()}.csv`, headers, rows);
    showToast(`Exported ${rows.length} row(s).`);
  };

  const exportMissingBpCsv = () => {
    if (!reports?.missingBp?.length) return;
    const headers = ['job_category_id', 'job_category_name', 'need_ser', 'blueprint_id', 'blueprint_name'];
    const rows = reports.missingBp.map((c) => [
      c.jobCategoryId,
      c.jobCategoryName,
      c.needSER,
      c.blueprintId || '',
      c.blueprintName || '',
    ]);
    downloadCsv(`admin_report_job_category_ser_no_blueprint_${csvStamp()}.csv`, headers, rows);
    showToast(`Exported ${rows.length} row(s).`);
  };

  const exportJobCategoriesNoRolesCsv = () => {
    if (!reports?.jobCategoriesNoRoles?.length) return;
    const headers = [
      'job_category_id',
      'job_category_name',
      'organization_job_category_scope',
      'category_status',
    ];
    const rows = reports.jobCategoriesNoRoles.map((c) => [
      c.jobCategoryId,
      c.jobCategoryName,
      c.organizationJobCategoryScope || '',
      c.status || 'Active',
    ]);
    downloadCsv(`admin_report_job_categories_no_rbac_roles_${csvStamp()}.csv`, headers, rows);
    showToast(`Exported ${rows.length} row(s).`);
  };

  const exportSailpointDriftCsv = () => {
    if (!reports?.sailpointDrift?.length) return;
    const headers = ['rbac_code', 'job_category', 'sailpoint_on_category', 'sailpoint_on_role'];
    const rows = reports.sailpointDrift.map(({ role, categorySailpoint, roleSailpoint }) => [
      role.rbacCode,
      role.jobCategory || '',
      categorySailpoint,
      roleSailpoint,
    ]);
    downloadCsv(`admin_report_role_sailpoint_drift_from_category_${csvStamp()}.csv`, headers, rows);
    showToast(`Exported ${rows.length} row(s).`);
  };

  const exportSailpointReconPrimaryCsv = () => {
    const rowsSrc = reports?.sailpointReconciliation?.rbacNotInSailpoint || [];
    if (!rowsSrc.length) return;
    const headers = [
      'job_category_id',
      'job_category_name',
      'category_status',
      'rbac_sailpoint_value',
      'scenario',
      'recommended_action',
      'top_sailpoint_candidate',
      'candidate_score',
      'duplicate_mismatch_count',
      'review_reason',
      'top_candidate_reason_codes',
    ];
    const rows = rowsSrc.map((r) => [
      r.category.jobCategoryId || '',
      r.category.jobCategoryName || '',
      r.category.status || 'Active',
      r.sourceRole || '',
      r.scenario,
      r.recommendedAction,
      r.candidates?.[0]?.sailpointRole || '',
      r.candidates?.[0]?.score != null ? r.candidates[0].score.toFixed(4) : '',
      r.duplicateCount || 1,
      r.reviewReason || '',
      (r.candidates?.[0]?.reasonCodes || []).join(';'),
    ]);
    downloadCsv(`admin_report_rbac_not_in_sailpoint_${csvStamp()}.csv`, headers, rows);
    showToast(`Exported ${rows.length} row(s).`);
  };

  const exportSailpointReconManualReviewCsv = () => {
    const rowsSrc = reports?.sailpointReconciliation?.rbacNotInSailpoint || [];
    if (!rowsSrc.length) return;
    const headers = [
      'jobCategoryId',
      'jobCategoryName',
      'currentSailpointValue',
      'scenario',
      'reviewReason',
      'suggestedCandidate1',
      'score1',
      'reasonCodes1',
      'reasonLabels1',
      'suggestedCandidate2',
      'score2',
      'reasonCodes2',
      'reasonLabels2',
      'suggestedCandidate3',
      'score3',
      'reasonCodes3',
      'reasonLabels3',
    ];
    const candCols = (c) => {
      if (!c) return ['', '', '', ''];
      return [
        c.sailpointRole,
        c.score != null ? String(c.score) : '',
        (c.reasonCodes || []).join('|'),
        (c.reasonLabels || []).join(' | '),
      ];
    };
    const rows = rowsSrc.map((r) => {
      const c = r.candidates || [];
      return [
        r.category.jobCategoryId || '',
        r.category.jobCategoryName || '',
        r.sourceRole || '',
        r.scenario || '',
        r.reviewReason || '',
        ...candCols(c[0]),
        ...candCols(c[1]),
        ...candCols(c[2]),
      ];
    });
    downloadCsv(`job-category-sailpoint-manual-review_${csvStamp()}.csv`, headers, rows);
    showToast(`Exported ${rows.length} manual-review row(s).`);
  };

  const exportSailpointReconSecondaryCsv = () => {
    const rowsSrc = reports?.sailpointReconciliation?.sailpointNotInRbac || [];
    if (!rowsSrc.length) return;
    const headers = ['sailpoint_role', 'requestable', 'recommended_action'];
    const rows = rowsSrc.map((r) => [r.sailpointRole, r.requestable || '', r.recommendedAction]);
    downloadCsv(`admin_report_sailpoint_not_in_rbac_${csvStamp()}.csv`, headers, rows);
    showToast(`Exported ${rows.length} row(s).`);
  };

  const exportNonRequestableSailpointXlsx = async () => {
    if (!reports?.nonRequestableSailpoint?.length) return;

    const reportHeaders = [
      'jobCategoryId',
      'jobCategoryName',
      'categoryStatus',
      'organizationScope',
      'rbacCodeCount',
      'sailpointRole',
      'requestable',
      'jobCategoryTemplateIds',
      'jobCategorySubtemplateIds',
      'sailpointTemplate',
      'sailpointSubtemplate',
      'templateMatch',
      'suggestedActiveSailpointRole',
      'suggestedReassignJobCategory',
    ];
    const reportRows = reports.nonRequestableSailpoint.map((r) => [
      r.category.jobCategoryId || '',
      r.category.jobCategoryName || '',
      r.categoryStatus || '',
      r.organizationScope || '',
      r.rbacCodeCount ?? 0,
      r.sailpointRole || '',
      r.requestable || '',
      r.jobCategoryTemplateIds || '',
      r.jobCategorySubtemplateIds || '',
      r.sailpointTemplate || '',
      r.sailpointSubtemplate || '',
      r.templateMatch ? 'Yes' : 'No',
      r.suggestedActiveSailpointRole || '',
      r.suggestedReassignJobCategory || '',
    ]);

    const requestableHeaders = [
      'sailpointRole',
      'status',
      'templates',
      'subtemplates',
      'requestable',
      'matchedAccessProfile',
      'entitlementType',
    ];
    const requestableRows = (reports.sailpointCatalog || [])
      .filter(
        (r) =>
          String(r?.requestable || '').trim().toUpperCase() === 'TRUE' &&
          String(r?.status || 'Active').trim().toLowerCase() !== 'inactive'
      )
      .sort((a, b) =>
        String(a.sailpointRole || '').localeCompare(String(b.sailpointRole || ''), undefined, {
          sensitivity: 'base',
        })
      )
      .map((r) => [
        r.sailpointRole || '',
        r.status || 'Active',
        r.templates || '',
        r.subtemplates || '',
        r.requestable || '',
        r.matchedAccessProfile || '',
        r.entitlementType || '',
      ]);

    try {
      await downloadXlsx(
        `job-categories-linked-to-non-requestable-sailpoint-with-templates_${csvStamp()}.xlsx`,
        [
          {
            name: 'Non-requestable categories',
            headers: reportHeaders,
            rows: reportRows,
          },
          {
            name: 'Requestable Sailpoint Roles',
            headers: requestableHeaders,
            rows: requestableRows,
          },
        ]
      );
      showToast(
        `Exported ${reportRows.length} category row(s) and ${requestableRows.length} requestable role(s).`
      );
    } catch (err) {
      alert(err?.message || 'Excel export failed.');
    }
  };

  const exportDuplicateSailpointOnCategoriesCsv = () => {
    if (!reports?.duplicateSailpointOnCategories?.length) return;
    const headers = [
      'sailpoint_role',
      'category_count',
      'requestable',
      'catalog_status',
      'rbac_code_count',
      'job_category_ids',
      'job_category_names',
      'category_statuses',
      'organization_scopes',
    ];
    const rows = reports.duplicateSailpointOnCategories.map((r) => [
      r.sailpointRole || '',
      r.categoryCount ?? 0,
      r.requestable || '',
      r.catalogStatus || '',
      r.rbacCodeCount ?? 0,
      r.jobCategoryIds || '',
      r.jobCategoryNames || '',
      r.categoryStatuses || '',
      r.organizationScopes || '',
    ]);
    downloadCsv(`admin_report_duplicate_sailpoint_on_job_categories_${csvStamp()}.csv`, headers, rows);
    showToast(`Exported ${rows.length} duplicate Sailpoint role group(s).`);
  };

  const exportMergeClustersCsv = () => {
    if (!reports?.mergeClusters?.length) return;
    const headers = [
      'cluster_index',
      'reason_codes',
      'reason_labels',
      'suggested_job_category_name',
      'other_names_in_cluster',
      'category_count',
      'job_category_ids',
      'job_category_names',
      'statuses',
    ];
    const rows = reports.mergeClusters.map((cl, i) => [
      i + 1,
      cl.reasons.join('; '),
      cl.reasonLabels.join('; '),
      cl.suggestedJobCategoryName,
      cl.alternateJobCategoryNames || '',
      cl.categories.length,
      cl.categories.map((c) => c.jobCategoryId || '').join('; '),
      cl.categories.map((c) => c.jobCategoryName || '').join('; '),
      cl.categories.map((c) => c.status || 'Active').join('; '),
    ]);
    downloadCsv(`admin_report_job_category_merge_candidates_${csvStamp()}.csv`, headers, rows);
    showToast(`Exported ${rows.length} cluster(s).`);
  };

  return (
    <div className="admin-page">
      <h2>Admin</h2>
      <div className="admin-actions">
        <section className="admin-section">
          <h3>Roles</h3>
          <p className="admin-section-desc">Edit selected role (after selecting rows on Roles Management) or clear cache to reload data.</p>
          <div className="admin-buttons">
            {allowBulkActions && (
              <button type="button" className="btn-secondary" onClick={handleEditSelected}>
                Edit Selected
              </button>
            )}
            <button type="button" className="btn-secondary" onClick={handleReload}>
              Reload
            </button>
          </div>
        </section>
        <section className="admin-section">
          <h3>Saved presets</h3>
          <p className="admin-section-desc">Save or load filter presets (search and filters from Roles Management).</p>
          <div className="admin-buttons">
            <button type="button" className="btn-secondary" onClick={handleSavePreset} title="Save current Roles filters as preset">
              Saved
            </button>
            {savedPresets.length > 0 ? (
              <select className="preset-select" onChange={handleLoadPreset}>
                <option value="">Load preset...</option>
                {[...savedPresets].sort((a, b) => (a.name || '').localeCompare(b.name || '')).map((preset) => (
                  <option key={preset.id} value={preset.id}>
                    {preset.name}
                  </option>
                ))}
              </select>
            ) : (
              <span className="admin-muted">No saved filter presets.</span>
            )}
          </div>
        </section>
        <section className="admin-section">
          <h3>Backup &amp; Restore</h3>
          <p className="admin-section-desc">Download a full backup (JSON) or restore from a previous backup file.</p>
          <div className="admin-buttons">
            <button type="button" className="btn-export" onClick={handleBackup} title="Backup all data">
              Backup
            </button>
            <button type="button" className="btn-import" onClick={handleRestore} title="Restore from backup">
              Restore
            </button>
          </div>
        </section>
        <section className="admin-section">
          <h3>Data tools</h3>
          <p className="admin-section-desc">Check for duplicate RBAC codes, run validation, or run cleanup (remove blanks, duplicates, etc.).</p>
          <div className="admin-buttons">
            <button type="button" className="btn-export" onClick={checkDuplicates} title="Check for duplicate RBAC codes">
              Check Duplicates
            </button>
            <button type="button" className="btn-export" onClick={generateValidationReport} title="Generate validation report">
              Validation Report
            </button>
            <button type="button" className="btn-export" onClick={cleanupData} title="Data cleanup utilities">
              Cleanup
            </button>
          </div>
        </section>

        <section className="admin-section">
          <h3>Data quality reports</h3>
          <p className="admin-section-desc">
            Cross-check RBAC roles against Templates/Subtemplates (User Record Status), job categories against the Sailpoint
            catalog, and a few consistency rules. Job category rows that are inactive or{' '}
            <strong>Not in Scope for Organization</strong> are omitted from every category-based report except{' '}
            <em>RBAC codes linked to an inactive job category</em>. Run to load fresh data; export any table as CSV.
          </p>
          <div className="admin-reports-toolbar">
            <button
              type="button"
              className="btn-primary-reports"
              onClick={runDataQualityReports}
              disabled={reportsLoading}
            >
              {reportsLoading ? 'Loading…' : reports ? 'Refresh reports' : 'Run reports'}
            </button>
            {reportsLoadedAt && (
              <span className="admin-muted">
                Last run: {reportsLoadedAt.toLocaleString()}
              </span>
            )}
          </div>

          {reports && (
            <>
              <div className="admin-report-block">
                <h4>
                  RBAC roles connected to inactive references
                  <span
                    className={`admin-report-count ${reports.rolesInactiveConnections?.length ? '' : 'is-zero'}`}
                  >
                    ({reports.rolesInactiveConnections?.length || 0} role
                    {(reports.rolesInactiveConnections?.length || 0) !== 1 ? 's' : ''})
                  </span>
                </h4>
                <p className="admin-report-desc">
                  Any RBAC role tied to an inactive job category, inactive Templates/Subtemplates row (on the role or
                  via its job category), inactive job code, or inactive SailPoint catalog role. Non-active template
                  link status includes Inactive and Pending.
                </p>
                <div className="admin-report-table-wrap">
                  <table className="admin-report-table">
                    <thead>
                      <tr>
                        <th>RBAC</th>
                        <th>Role status</th>
                        <th>Job category</th>
                        <th>Connection</th>
                        <th>Detail</th>
                        <th>Inactive status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(reports.rolesInactiveConnections?.length || 0) === 0 ? (
                        <tr><td colSpan={6} className="admin-muted">No rows.</td></tr>
                      ) : (
                        reports.rolesInactiveConnections.flatMap(({ role, issues }) =>
                          issues.map((issue, idx) => (
                            <tr key={`${role.id}-${issue.connectionType}-${issue.detail}-${idx}`}>
                              {idx === 0 ? (
                                <>
                                  <td rowSpan={issues.length}>{role.rbacCode || '—'}</td>
                                  <td rowSpan={issues.length}>{role.status || 'Active'}</td>
                                  <td rowSpan={issues.length}>{role.jobCategory || '—'}</td>
                                </>
                              ) : null}
                              <td>{issue.connectionType}</td>
                              <td className="admin-report-wrap">{issue.detail}</td>
                              <td>{issue.status}</td>
                            </tr>
                          ))
                        )
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="admin-report-actions">
                  <button
                    type="button"
                    className="btn-report-csv"
                    onClick={exportRolesInactiveConnectionsCsv}
                    disabled={!reports.rolesInactiveConnections?.length}
                  >
                    Download CSV
                  </button>
                </div>
              </div>

              <div className="admin-report-block">
                <h4>
                  Roles linked to non-active template rows
                  <span className={`admin-report-count ${reports.inactiveTpl.length ? '' : 'is-zero'}`}>
                    ({reports.inactiveTpl.length} role{reports.inactiveTpl.length !== 1 ? 's' : ''})
                  </span>
                </h4>
                <p className="admin-report-desc">
                  Linked Role Template ID/Name or Subtemplate ID matches a Templates/Subtemplates row where User Record
                  Status is not Active (e.g. Inactive or Pending).
                </p>
                <div className="admin-report-table-wrap">
                  <table className="admin-report-table">
                    <thead>
                      <tr>
                        <th>RBAC</th>
                        <th>Role status</th>
                        <th>Job category</th>
                        <th>Match</th>
                        <th>Link status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reports.inactiveTpl.length === 0 ? (
                        <tr><td colSpan={5} className="admin-muted">No rows.</td></tr>
                      ) : (
                        reports.inactiveTpl.flatMap(({ role, hits }) =>
                          hits.map((h, idx) => (
                            <tr key={`${role.id}-${h.field}-${h.token}-${idx}`}>
                              {idx === 0 ? (
                                <>
                                  <td rowSpan={hits.length}>{role.rbacCode || '—'}</td>
                                  <td rowSpan={hits.length}>{role.status || 'Active'}</td>
                                  <td rowSpan={hits.length}>{role.jobCategory || '—'}</td>
                                </>
                              ) : null}
                              <td>
                                {h.field}: <code>{h.token}</code> ({h.recordType})
                              </td>
                              <td>{h.linkStatus}</td>
                            </tr>
                          ))
                        )
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="admin-report-actions">
                  <button type="button" className="btn-report-csv" onClick={exportInactiveTplCsv} disabled={!reports.inactiveTpl.length}>
                    Download CSV
                  </button>
                </div>
              </div>

              <div className="admin-report-block">
                <h4>
                  Template references with no Templates/Subtemplates row
                  <span className={`admin-report-count ${reports.orphanTpl.length ? '' : 'is-zero'}`}>
                    ({reports.orphanTpl.length} role{reports.orphanTpl.length !== 1 ? 's' : ''})
                  </span>
                </h4>
                <p className="admin-report-desc">
                  Role has a linked template ID, template name, or subtemplate ID token that does not appear on any link row
                  (any status). Typos or missing imports often show up here.
                </p>
                <div className="admin-report-table-wrap">
                  <table className="admin-report-table">
                    <thead>
                      <tr>
                        <th>RBAC</th>
                        <th>Job category</th>
                        <th>Missing reference</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reports.orphanTpl.length === 0 ? (
                        <tr><td colSpan={3} className="admin-muted">No rows.</td></tr>
                      ) : (
                        reports.orphanTpl.flatMap(({ role, orphans }) =>
                          orphans.map((o, idx) => (
                            <tr key={`${role.id}-orphan-${o.field}-${o.token}-${idx}`}>
                              {idx === 0 ? (
                                <>
                                  <td rowSpan={orphans.length}>{role.rbacCode || '—'}</td>
                                  <td rowSpan={orphans.length}>{role.jobCategory || '—'}</td>
                                </>
                              ) : null}
                              <td>
                                {o.field}: <code>{o.token}</code>
                              </td>
                            </tr>
                          ))
                        )
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="admin-report-actions">
                  <button type="button" className="btn-report-csv" onClick={exportOrphanTplCsv} disabled={!reports.orphanTpl.length}>
                    Download CSV
                  </button>
                </div>
              </div>

              <div className="admin-report-block">
                <h4>
                  Job categories linked to non-active template rows
                  <span className={`admin-report-count ${reports.inactiveCategoryTpl.length ? '' : 'is-zero'}`}>
                    ({reports.inactiveCategoryTpl.length} categor{reports.inactiveCategoryTpl.length !== 1 ? 'ies' : 'y'})
                  </span>
                </h4>
                <p className="admin-report-desc">
                  Active, in-scope job categories where Linkable Template ID/Name or Subtemplate ID resolves to a
                  Templates/Subtemplates row whose User Record Status is not Active.
                </p>
                <div className="admin-report-table-wrap">
                  <table className="admin-report-table">
                    <thead>
                      <tr>
                        <th>Category ID</th>
                        <th>Category Name</th>
                        <th>Category status</th>
                        <th>Match</th>
                        <th>Link status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reports.inactiveCategoryTpl.length === 0 ? (
                        <tr><td colSpan={5} className="admin-muted">No rows.</td></tr>
                      ) : (
                        reports.inactiveCategoryTpl.flatMap(({ category, hits }) =>
                          hits.map((h, idx) => (
                            <tr key={`${category.id}-${h.field}-${h.token}-${idx}`}>
                              {idx === 0 ? (
                                <>
                                  <td rowSpan={hits.length}>{category.jobCategoryId || '—'}</td>
                                  <td rowSpan={hits.length}>{category.jobCategoryName || '—'}</td>
                                  <td rowSpan={hits.length}>{category.status || 'Active'}</td>
                                </>
                              ) : null}
                              <td>
                                {h.field}: <code>{h.token}</code> ({h.recordType})
                              </td>
                              <td>{h.linkStatus}</td>
                            </tr>
                          ))
                        )
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="admin-report-actions">
                  <button type="button" className="btn-report-csv" onClick={exportInactiveCategoryTplCsv} disabled={!reports.inactiveCategoryTpl.length}>
                    Download CSV
                  </button>
                </div>
              </div>

              <div className="admin-report-block">
                <h4>
                  SailPoint roles attached to non-active template rows
                  <span className={`admin-report-count ${reports.sailpointInactiveTpl.length ? '' : 'is-zero'}`}>
                    ({reports.sailpointInactiveTpl.length} role{reports.sailpointInactiveTpl.length !== 1 ? 's' : ''})
                  </span>
                </h4>
                <p className="admin-report-desc">
                  SailPoint catalog roles where <code>templates</code> or <code>subtemplates</code> tokens resolve to
                  Templates/Subtemplates rows whose User Record Status is not Active.
                </p>
                <div className="admin-report-table-wrap">
                  <table className="admin-report-table">
                    <thead>
                      <tr>
                        <th>SailPoint role</th>
                        <th>SailPoint status</th>
                        <th>Requestable</th>
                        <th>Match</th>
                        <th>Link status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reports.sailpointInactiveTpl.length === 0 ? (
                        <tr><td colSpan={5} className="admin-muted">No rows.</td></tr>
                      ) : (
                        reports.sailpointInactiveTpl.flatMap(({ sailpointRoleRow, hits }) =>
                          hits.map((h, idx) => (
                            <tr key={`${sailpointRoleRow.id || sailpointRoleRow.sailpointRole}-${h.field}-${h.token}-${idx}`}>
                              {idx === 0 ? (
                                <>
                                  <td rowSpan={hits.length}>{sailpointRoleRow.sailpointRole || '—'}</td>
                                  <td rowSpan={hits.length}>{sailpointRoleRow.status || 'Active'}</td>
                                  <td rowSpan={hits.length}>{sailpointRoleRow.requestable || '—'}</td>
                                </>
                              ) : null}
                              <td>
                                {h.field}: <code>{h.token}</code> ({h.recordType})
                              </td>
                              <td>{h.linkStatus}</td>
                            </tr>
                          ))
                        )
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="admin-report-actions">
                  <button
                    type="button"
                    className="btn-report-csv"
                    onClick={exportSailpointInactiveTplCsv}
                    disabled={!reports.sailpointInactiveTpl.length}
                  >
                    Download CSV
                  </button>
                </div>
              </div>

              <div className="admin-report-block">
                <h4>
                  SailPoint reconciliation checklist report
                  <span className={`admin-report-count ${(reports.sailpointReconciliation?.rbacNotInSailpoint?.length || 0) ? '' : 'is-zero'}`}>
                    ({reports.sailpointReconciliation?.rbacNotInSailpoint?.length || 0} RBAC mismatch{(reports.sailpointReconciliation?.rbacNotInSailpoint?.length || 0) !== 1 ? 'es' : ''})
                  </span>
                </h4>
                <p className="admin-report-desc">
                  Uses two source datasets (RBAC Job Categories + SailPoint Roles), normalizes values (trim/case), and finds:
                  <strong> RBAC values not in SailPoint</strong> (primary) and <strong>SailPoint values not in RBAC</strong> (secondary).
                  Primary rows are categorized to support actioning: inactivate duplicate/erroneous entries or map slight name variations.
                </p>
                <div className="admin-report-table-wrap">
                  <table className="admin-report-table">
                    <thead>
                      <tr>
                        <th>Job Category ID</th>
                        <th>Job Category Name</th>
                        <th>RBAC SailPoint Value</th>
                        <th>Scenario</th>
                        <th>Review reason</th>
                        <th>Recommended Action</th>
                        <th>Top Match Candidate</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(reports.sailpointReconciliation?.rbacNotInSailpoint?.length || 0) === 0 ? (
                        <tr><td colSpan={7} className="admin-muted">No RBAC→SailPoint mismatches.</td></tr>
                      ) : (
                        reports.sailpointReconciliation.rbacNotInSailpoint.map((r) => (
                          <tr key={r.category.id}>
                            <td>{r.category.jobCategoryId || '—'}</td>
                            <td>{r.category.jobCategoryName || '—'}</td>
                            <td>{r.sourceRole || '—'}</td>
                            <td>{String(r.scenario || '').split('_').join(' ')}</td>
                            <td className="admin-report-wrap">{r.reviewReason || '—'}</td>
                            <td>{r.recommendedAction}</td>
                            <td>
                              {r.candidates?.[0]
                                ? `${r.candidates[0].sailpointRole} (${r.candidates[0].score.toFixed(4)})${(r.candidates[0].reasonCodes || []).length ? ` — ${r.candidates[0].reasonCodes.join(', ')}` : ''}`
                                : '—'}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="admin-report-actions">
                  <button
                    type="button"
                    className="btn-report-csv"
                    onClick={exportSailpointReconPrimaryCsv}
                    disabled={!(reports.sailpointReconciliation?.rbacNotInSailpoint?.length)}
                  >
                    Download RBAC→SailPoint CSV
                  </button>
                  <button
                    type="button"
                    className="btn-report-csv"
                    onClick={exportSailpointReconManualReviewCsv}
                    disabled={!(reports.sailpointReconciliation?.rbacNotInSailpoint?.length)}
                    title="Top 3 candidates with scores, machine-readable reason codes, and reviewer-oriented review text"
                  >
                    Download manual-review CSV (candidates + reasons)
                  </button>
                </div>
                <div className="admin-report-table-wrap">
                  <table className="admin-report-table">
                    <thead>
                      <tr>
                        <th>SailPoint role not in RBAC</th>
                        <th>Requestable</th>
                        <th>Recommended Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(reports.sailpointReconciliation?.sailpointNotInRbac?.length || 0) === 0 ? (
                        <tr><td colSpan={3} className="admin-muted">No SailPoint→RBAC mismatches.</td></tr>
                      ) : (
                        reports.sailpointReconciliation.sailpointNotInRbac.map((r) => (
                          <tr key={r.sailpointRole}>
                            <td>{r.sailpointRole}</td>
                            <td>{r.requestable || '—'}</td>
                            <td>{r.recommendedAction}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="admin-report-actions">
                  <button
                    type="button"
                    className="btn-report-csv"
                    onClick={exportSailpointReconSecondaryCsv}
                    disabled={!(reports.sailpointReconciliation?.sailpointNotInRbac?.length)}
                  >
                    Download SailPoint→RBAC CSV
                  </button>
                </div>
              </div>

              <div className="admin-report-block">
                <h4>
                  Job categories linked to non-requestable Sailpoint role (with templates)
                  <span className={`admin-report-count ${reports.nonRequestableSailpoint.length ? '' : 'is-zero'}`}>
                    ({reports.nonRequestableSailpoint.length} categor
                    {reports.nonRequestableSailpoint.length !== 1 ? 'ies' : 'y'})
                  </span>
                </h4>
                <p className="admin-report-desc">
                  Job categories (any status or organization scope) whose assigned Sailpoint role exists in the Sailpoint Roles
                  catalog but is marked <strong>requestable = FALSE</strong>. <strong>Category status</strong> and{' '}
                  <strong>Scope</strong> show whether the category is active/inactive and in or out of organization scope.{' '}
                  <strong>RBAC codes</strong> is the count of RBAC roles linked to that category name (not a list). Template /
                  subtemplate IDs are compared side-by-side; <strong>templateMatch</strong> is Yes when every category template
                  (and subtemplate, if any) appears on the catalog row and vice versa. The <strong>Suggested active
                  replacement</strong> column proposes the closest <em>requestable</em> Sailpoint role using shared specialty
                  tokens (IDF-weighted) with template / subtemplate overlap as a tiebreaker; blank means no acceptable candidate
                  was found and a manual mapping is needed. <strong>Suggested reassign category</strong> is an active job category
                  with a requestable SailPoint role where templates, subtemplates, and training tracks best match — use it when
                  moving RBAC roles off this category.
                </p>
                <div className="admin-report-table-wrap">
                  <table className="admin-report-table">
                    <thead>
                      <tr>
                        <th>Job Category ID</th>
                        <th>Job Category Name</th>
                        <th>Category status</th>
                        <th>Scope</th>
                        <th>RBAC codes</th>
                        <th>Sailpoint role (non-requestable)</th>
                        <th>Category templates</th>
                        <th>Category subtemplates</th>
                        <th>Sailpoint template</th>
                        <th>Sailpoint subtemplate</th>
                        <th>Template match</th>
                        <th>Suggested active replacement</th>
                        <th>Suggested reassign category</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reports.nonRequestableSailpoint.length === 0 ? (
                        <tr><td colSpan={13} className="admin-muted">No rows.</td></tr>
                      ) : (
                        reports.nonRequestableSailpoint.map((r) => (
                          <tr key={r.category.id}>
                            <td>{r.category.jobCategoryId || '—'}</td>
                            <td>{r.category.jobCategoryName || '—'}</td>
                            <td>{r.categoryStatus || '—'}</td>
                            <td>{r.organizationScope || '—'}</td>
                            <td>{r.rbacCodeCount ?? 0}</td>
                            <td>{r.sailpointRole || '—'}</td>
                            <td><code>{r.jobCategoryTemplateIds || '—'}</code></td>
                            <td><code>{r.jobCategorySubtemplateIds || '—'}</code></td>
                            <td><code>{r.sailpointTemplate || '—'}</code></td>
                            <td><code>{r.sailpointSubtemplate || '—'}</code></td>
                            <td>{r.templateMatch ? 'Yes' : 'No'}</td>
                            <td>{r.suggestedActiveSailpointRole || <span className="admin-muted">No confident match</span>}</td>
                            <td>{r.suggestedReassignJobCategory || <span className="admin-muted">No confident match</span>}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="admin-report-actions">
                  <button
                    type="button"
                    className="btn-report-csv"
                    onClick={exportNonRequestableSailpointXlsx}
                    disabled={!reports.nonRequestableSailpoint.length}
                    title="Excel workbook: tab 1 = this report; tab 2 = all requestable Sailpoint roles"
                  >
                    Download Excel (with requestable roles tab)
                  </button>
                </div>
              </div>

              <div className="admin-report-block">
                <h4>
                  Job categories — Sailpoint gaps
                  <span className={`admin-report-count ${reports.sailpointCat.length ? '' : 'is-zero'}`}>
                    ({reports.sailpointCat.length} categor{reports.sailpointCat.length !== 1 ? 'ies' : 'y'})
                  </span>
                </h4>
                <p className="admin-report-desc">
                  Active category with blank Sailpoint role; Sailpoint value not in Sailpoint Roles catalog; or flagged for
                  Sailpoint review. One category may appear once with multiple issues listed.
                </p>
                <div className="admin-report-table-wrap">
                  <table className="admin-report-table">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Status</th>
                        <th>Issues</th>
                        <th>Sailpoint (value)</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reports.sailpointCat.length === 0 ? (
                        <tr><td colSpan={5} className="admin-muted">No rows.</td></tr>
                      ) : (
                        reports.sailpointCat.map(({ category, issues }) => (
                          <tr key={category.id}>
                            <td>{category.jobCategoryId || '—'}</td>
                            <td>{category.jobCategoryName || '—'}</td>
                            <td>{category.status || 'Active'}</td>
                            <td>{issues.map((i) => i.label).join('; ')}</td>
                            <td>{category.sailpointRole || '—'}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="admin-report-actions">
                  <button type="button" className="btn-report-csv" onClick={exportSailpointCatCsv} disabled={!reports.sailpointCat.length}>
                    Download CSV
                  </button>
                </div>
              </div>

              <div className="admin-report-block">
                <h4>
                  RBAC codes linked to an inactive job category
                  <span className={`admin-report-count ${reports.inactiveJcat.length ? '' : 'is-zero'}`}>
                    ({reports.inactiveJcat.length} role{reports.inactiveJcat.length !== 1 ? 's' : ''})
                  </span>
                </h4>
                <p className="admin-report-desc">
                  RBAC roles whose Job Category matches a category row with status Inactive (includes Active and Inactive
                  roles — see Role status column).
                </p>
                <div className="admin-report-table-wrap">
                  <table className="admin-report-table">
                    <thead>
                      <tr>
                        <th>RBAC</th>
                        <th>Role status</th>
                        <th>Job category</th>
                        <th>Category ID</th>
                        <th>Category status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reports.inactiveJcat.length === 0 ? (
                        <tr><td colSpan={5} className="admin-muted">No rows.</td></tr>
                      ) : (
                        reports.inactiveJcat.map(({ role, category }) => (
                          <tr key={role.id}>
                            <td>{role.rbacCode || '—'}</td>
                            <td>{role.status || 'Active'}</td>
                            <td>{category.jobCategoryName || '—'}</td>
                            <td>{category.jobCategoryId || '—'}</td>
                            <td>{category.status || 'Active'}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="admin-report-actions">
                  <button type="button" className="btn-report-csv" onClick={exportInactiveJcatCsv} disabled={!reports.inactiveJcat.length}>
                    Download CSV
                  </button>
                </div>
              </div>

              <div className="admin-report-block">
                <h4>
                  Active job categories — SER expected but no blueprint
                  <span className={`admin-report-count ${reports.missingBp.length ? '' : 'is-zero'}`}>
                    ({reports.missingBp.length} categor{reports.missingBp.length !== 1 ? 'ies' : 'y'})
                  </span>
                </h4>
                <p className="admin-report-desc">
                  Category is active, Need SER is not No, but Blueprint ID is empty.
                </p>
                <div className="admin-report-table-wrap">
                  <table className="admin-report-table">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Need SER</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reports.missingBp.length === 0 ? (
                        <tr><td colSpan={3} className="admin-muted">No rows.</td></tr>
                      ) : (
                        reports.missingBp.map((c) => (
                          <tr key={c.id}>
                            <td>{c.jobCategoryId || '—'}</td>
                            <td>{c.jobCategoryName || '—'}</td>
                            <td>{c.needSER || '—'}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="admin-report-actions">
                  <button type="button" className="btn-report-csv" onClick={exportMissingBpCsv} disabled={!reports.missingBp.length}>
                    Download CSV
                  </button>
                </div>
              </div>

              <div className="admin-report-block">
                <h4>
                  Job categories — no RBAC roles
                  <span className={`admin-report-count ${reports.jobCategoriesNoRoles.length ? '' : 'is-zero'}`}>
                    ({reports.jobCategoriesNoRoles.length} categor{reports.jobCategoriesNoRoles.length !== 1 ? 'ies' : 'y'})
                  </span>
                </h4>
                <p className="admin-report-desc">
                  Active, in-scope categories whose Job Category Name is not used on any RBAC role row (exact match to the role
                  Job Category field). Roles may be active or inactive; empty role Job Category does not count.
                </p>
                <div className="admin-report-table-wrap">
                  <table className="admin-report-table">
                    <thead>
                      <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Scope</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reports.jobCategoriesNoRoles.length === 0 ? (
                        <tr><td colSpan={4} className="admin-muted">No rows.</td></tr>
                      ) : (
                        reports.jobCategoriesNoRoles.map((c) => (
                          <tr key={c.id}>
                            <td>{c.jobCategoryId || '—'}</td>
                            <td>{c.jobCategoryName || '—'}</td>
                            <td>{c.organizationJobCategoryScope || '—'}</td>
                            <td>{c.status || 'Active'}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="admin-report-actions">
                  <button
                    type="button"
                    className="btn-report-csv"
                    onClick={exportJobCategoriesNoRolesCsv}
                    disabled={!reports.jobCategoriesNoRoles.length}
                  >
                    Download CSV
                  </button>
                </div>
              </div>

              <div className="admin-report-block">
                <h4>
                  Active roles — Sailpoint differs from job category
                  <span className={`admin-report-count ${reports.sailpointDrift.length ? '' : 'is-zero'}`}>
                    ({reports.sailpointDrift.length} role{reports.sailpointDrift.length !== 1 ? 's' : ''})
                  </span>
                </h4>
                <p className="admin-report-desc">
                  Job category has a Sailpoint role, but the role row is blank or uses a different name (case-insensitive
                  compare). Intentional overrides will appear here too.
                </p>
                <div className="admin-report-table-wrap">
                  <table className="admin-report-table">
                    <thead>
                      <tr>
                        <th>RBAC</th>
                        <th>Job category</th>
                        <th>Sailpoint on category</th>
                        <th>Sailpoint on role</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reports.sailpointDrift.length === 0 ? (
                        <tr><td colSpan={4} className="admin-muted">No rows.</td></tr>
                      ) : (
                        reports.sailpointDrift.map(({ role, categorySailpoint, roleSailpoint }) => (
                          <tr key={role.id}>
                            <td>{role.rbacCode || '—'}</td>
                            <td>{role.jobCategory || '—'}</td>
                            <td>{categorySailpoint}</td>
                            <td>{roleSailpoint}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="admin-report-actions">
                  <button type="button" className="btn-report-csv" onClick={exportSailpointDriftCsv} disabled={!reports.sailpointDrift.length}>
                    Download CSV
                  </button>
                </div>
              </div>

              <div className="admin-report-block">
                <h4>
                  Duplicate Sailpoint roles on job categories
                  <span
                    className={`admin-report-count ${
                      reports.duplicateSailpointOnCategories?.length ? '' : 'is-zero'
                    }`}
                  >
                    ({reports.duplicateSailpointOnCategories?.length || 0} Sailpoint role
                    {(reports.duplicateSailpointOnCategories?.length || 0) !== 1 ? 's' : ''})
                  </span>
                </h4>
                <p className="admin-report-desc">
                  Sailpoint roles assigned to more than one job category (match after normalizing spacing and case).
                  Review whether categories should use distinct Sailpoint roles or be merged.{' '}
                  <strong>RBAC codes</strong> is the total count of RBAC roles linked to all categories in the group.
                </p>
                <div className="admin-report-table-wrap">
                  <table className="admin-report-table">
                    <thead>
                      <tr>
                        <th>Sailpoint role</th>
                        <th># Categories</th>
                        <th>Requestable</th>
                        <th>RBAC codes</th>
                        <th>Job category IDs</th>
                        <th>Job category names</th>
                        <th>Category status</th>
                        <th>Scope</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(reports.duplicateSailpointOnCategories?.length || 0) === 0 ? (
                        <tr><td colSpan={8} className="admin-muted">No duplicate Sailpoint assignments.</td></tr>
                      ) : (
                        reports.duplicateSailpointOnCategories.map((r) => (
                          <tr key={r.sailpointRoleNorm || r.sailpointRole}>
                            <td>{r.sailpointRole || '—'}</td>
                            <td>{r.categoryCount ?? 0}</td>
                            <td>{r.requestable || '—'}</td>
                            <td>{r.rbacCodeCount ?? 0}</td>
                            <td className="text-cell" title={r.jobCategoryIds || ''}>
                              {r.jobCategoryIds || '—'}
                            </td>
                            <td className="text-cell" title={r.jobCategoryNames || ''}>
                              {r.jobCategoryNames || '—'}
                            </td>
                            <td title={r.categoryStatuses || ''}>{r.categoryStatuses || '—'}</td>
                            <td title={r.organizationScopes || ''}>{r.organizationScopes || '—'}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="admin-report-actions">
                  <button
                    type="button"
                    className="btn-report-csv"
                    onClick={exportDuplicateSailpointOnCategoriesCsv}
                    disabled={!(reports.duplicateSailpointOnCategories?.length)}
                  >
                    Download CSV
                  </button>
                </div>
              </div>

              <div className="admin-report-block">
                <h4>
                  Job categories — possible duplicates (merge candidates)
                  <span className={`admin-report-count ${reports.mergeClusters.length ? '' : 'is-zero'}`}>
                    ({reports.mergeClusters.length} cluster{reports.mergeClusters.length !== 1 ? 's' : ''})
                  </span>
                </h4>
                <p className="admin-report-desc">
                  Rows where every field matches after normalization (trim, collapse whitespace, case-insensitive text),
                  except <strong>job category name</strong>, <strong>description</strong>, and <strong>assigned Job Category
                  ID</strong> (duplicate rows often have different IDs). Storage row id and last-edit stamp are ignored. Only
                  clusters that have at least one value in <strong>blueprint</strong>, <strong>linkable template /
                  subtemplate</strong>, or <strong>training tracks</strong> are listed (avoids empty duplicates noise).
                  <strong>Suggested name</strong> picks a single label: most common spelling when names differ only by case;
                  otherwise an Active row if any, else lowest numeric Job Category ID. Update roles&apos; Job Category text
                  and delete or inactivate the extra category rows after review.
                </p>
                <div className="admin-report-table-wrap">
                  <table className="admin-report-table">
                    <thead>
                      <tr>
                        <th>#</th>
                        <th>Why</th>
                        <th>Suggested name</th>
                        <th>Other names</th>
                        <th>Count</th>
                        <th>Job category IDs</th>
                        <th>Names</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {reports.mergeClusters.length === 0 ? (
                        <tr><td colSpan={8} className="admin-muted">No merge candidates found.</td></tr>
                      ) : (
                        reports.mergeClusters.map((cl, idx) => (
                          <tr key={`${cl.categories[0]?.id}-${idx}`}>
                            <td>{idx + 1}</td>
                            <td title={cl.reasonLabels.join('\n')}>{cl.reasonLabels.join('; ')}</td>
                            <td><strong>{cl.suggestedJobCategoryName || '—'}</strong></td>
                            <td className="admin-muted" title={cl.alternateJobCategoryNames || ''}>
                              {cl.alternateJobCategoryNames || '—'}
                            </td>
                            <td>{cl.categories.length}</td>
                            <td title={cl.categories.map((c) => c.jobCategoryId || '—').join('; ')}>
                              {cl.categories.map((c) => c.jobCategoryId || '—').join('; ')}
                            </td>
                            <td title={cl.categories.map((c) => c.jobCategoryName || '—').join('; ')}>
                              {cl.categories.map((c) => c.jobCategoryName || '—').join('; ')}
                            </td>
                            <td>{cl.categories.map((c) => c.status || 'Active').join('; ')}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
                <div className="admin-report-actions">
                  <button
                    type="button"
                    className="btn-report-csv"
                    onClick={exportMergeClustersCsv}
                    disabled={!reports.mergeClusters.length}
                  >
                    Download CSV
                  </button>
                </div>
              </div>
            </>
          )}
        </section>
      </div>
    </div>
  );
};

export default Admin;
