import React from 'react';
import './SortableTh.css';

/**
 * Accessible sortable column header (matches sortConfig shape used in RolesList / JobCategories).
 */
export default function SortableTh({
  columnKey,
  sortConfig,
  onSort,
  children,
  className = '',
  scope = 'col',
  title,
  ...rest
}) {
  const active = sortConfig?.key === columnKey;
  const dir = sortConfig?.direction || 'asc';
  const ariaSort = active ? (dir === 'asc' ? 'ascending' : 'descending') : 'none';
  const labelText = typeof children === 'string' ? children : columnKey;
  return (
    <th
      scope={scope}
      aria-sort={ariaSort}
      className={`sortable-th ${active ? 'is-active' : ''} ${className}`.trim()}
      {...rest}
    >
      <button
        type="button"
        className="sortable-th__btn"
        onClick={() => onSort(columnKey)}
        title={title || `Sort by ${labelText}`}
      >
        <span className="sortable-th__label">{children}</span>
        {active && (
          <span className="sortable-th__indicator" aria-hidden>
            {dir === 'asc' ? ' ↑' : ' ↓'}
          </span>
        )}
      </button>
    </th>
  );
}
