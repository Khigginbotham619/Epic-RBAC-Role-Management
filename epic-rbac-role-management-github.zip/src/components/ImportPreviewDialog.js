import React, { useMemo, useState, useCallback } from 'react';
import SortableTh from './SortableTh';
import { sortRowsByKey, nextSortState } from '../utils/tableSort';
import './ImportPreviewDialog.css';

const STATUS_SORT_KEY = '__status__';

const MAX_PREVIEW_ROWS = 100;

const ImportPreviewDialog = ({
  rows,
  columns,
  existingData,
  matchKey,
  onConfirm,
  onCancel,
  enableImportMode = false,
  defaultImportMode = 'merge',
}) => {
  const [importMode, setImportMode] = useState(defaultImportMode === 'replace' ? 'replace' : 'merge');
  const preview = useMemo(() => {
    const existingByKey = {};
    if (existingData && matchKey) {
      existingData.forEach((item) => {
        const k = (item[matchKey] || '').trim().toLowerCase();
        if (k) existingByKey[k] = item;
      });
    }
    return rows.slice(0, MAX_PREVIEW_ROWS).map((row) => {
      const k = matchKey ? (row[matchKey] || '').trim().toLowerCase() : '';
      let status = 'new';
      if (k && existingByKey[k]) {
        const existing = existingByKey[k];
        const changed = columns.some((col) => (row[col] || '') !== (existing[col] || ''));
        status = changed ? 'update' : 'unchanged';
      }
      return { row, status };
    });
  }, [rows, columns, existingData, matchKey]);

  const mergeCounts = useMemo(() => {
    const c = { new: 0, update: 0, unchanged: 0 };
    preview.forEach((p) => c[p.status]++);
    return c;
  }, [preview]);
  const replaceCounts = useMemo(
    () => ({
      importRows: rows.length,
      replacedRows: Array.isArray(existingData) ? existingData.length : 0,
    }),
    [rows.length, existingData]
  );

  const getPreviewCell = useCallback(
    (p, key) => {
      if (key === STATUS_SORT_KEY) return p.status;
      return p.row[key];
    },
    []
  );

  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  const handleSort = useCallback((key) => {
    setSortConfig((prev) => nextSortState(prev, key));
  }, []);
  const sortedPreview = useMemo(
    () => sortRowsByKey(preview, sortConfig.key, sortConfig.direction, getPreviewCell),
    [preview, sortConfig.key, sortConfig.direction, getPreviewCell]
  );

  return (
    <div className="import-preview-overlay" onClick={onCancel}>
      <div className="import-preview-dialog" onClick={(e) => e.stopPropagation()}>
        <div className="import-preview-header">
          <h3>Import Preview</h3>
          <button type="button" className="import-preview-close" onClick={onCancel}>&times;</button>
        </div>
        {enableImportMode && (
          <div className="import-preview-mode">
            <span className="import-preview-mode-label">Import mode</span>
            <div className="import-preview-mode-controls">
              <label>
                <input
                  type="radio"
                  name="import-mode"
                  value="merge"
                  checked={importMode === 'merge'}
                  onChange={() => setImportMode('merge')}
                />
                Merge
              </label>
              <label>
                <input
                  type="radio"
                  name="import-mode"
                  value="replace"
                  checked={importMode === 'replace'}
                  onChange={() => setImportMode('replace')}
                />
                Replace
              </label>
            </div>
          </div>
        )}
        <div className="import-preview-summary">
          {enableImportMode && importMode === 'replace' ? (
            <>
              <span className="preview-badge preview-new">{replaceCounts.importRows} rows to import</span>
              <span className="preview-badge preview-update">{replaceCounts.replacedRows} existing rows replaced</span>
            </>
          ) : (
            <>
              <span className="preview-badge preview-new">{mergeCounts.new} new</span>
              <span className="preview-badge preview-update">{mergeCounts.update} update</span>
              <span className="preview-badge preview-unchanged">{mergeCounts.unchanged} unchanged</span>
            </>
          )}
          {rows.length > MAX_PREVIEW_ROWS && (
            <span className="preview-truncated">Showing {MAX_PREVIEW_ROWS} of {rows.length} rows</span>
          )}
        </div>
        <div className="import-preview-table-wrap">
          <table className="import-preview-table">
            <thead>
              <tr>
                <SortableTh columnKey={STATUS_SORT_KEY} sortConfig={sortConfig} onSort={handleSort}>Status</SortableTh>
                {columns.map((col) => (
                  <SortableTh key={col} columnKey={col} sortConfig={sortConfig} onSort={handleSort}>
                    {col}
                  </SortableTh>
                ))}
              </tr>
            </thead>
            <tbody>
              {sortedPreview.map((p, i) => (
                <tr key={i} className={`preview-row-${p.status}`}>
                  <td className="preview-status-cell">
                    {p.status === 'new' ? 'New' : p.status === 'update' ? 'Update' : 'No change'}
                  </td>
                  {columns.map((col) => (
                    <td key={col}>{String(p.row[col] ?? '').substring(0, 80)}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="import-preview-actions">
          <button type="button" className="btn-secondary" onClick={onCancel}>Cancel</button>
          <button type="button" className="btn-primary" onClick={() => onConfirm(importMode)}>
            Confirm {enableImportMode ? (importMode === 'replace' ? 'Replace' : 'Merge') : 'Import'} ({rows.length} rows)
          </button>
        </div>
      </div>
    </div>
  );
};

export default ImportPreviewDialog;
