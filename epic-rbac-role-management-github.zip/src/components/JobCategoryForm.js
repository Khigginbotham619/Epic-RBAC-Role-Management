import React, { useState, useEffect, useRef, useMemo } from 'react';
import { getJobCategories, getTrainingTracks, appendTrainingTracks, getBlueprints, getSailpointRoles, getTemplateLinks, appendBlueprints, appendTemplateLinks, addBlueprintAuditLog, addTemplateLinkAuditLog, generateId, getCurrentAuditUser, getRoles } from '../utils/storage';
import {
  suggestSailpointRolesForJobCategory,
  preparseTemplateLinkRows,
} from '../utils/sailpointCategorySuggestions';
import TrainingTrackDropdown, { TRAINING_TRACK_OTHER } from './TrainingTrackDropdown';
import BlueprintDropdown, { BLUEPRINT_OTHER } from './BlueprintDropdown';
import {
  formatCommaSeparatedTemplateNamesUpper,
  formatJobCategoryTemplateNameUpper,
  normalizeSubtemplateCommaList,
  syncJobCategoryLinkableFromTemplateLinks,
  syncJobCategorySubtemplatesFromTemplateLinks,
} from '../utils/templateLinkRoleMatch';
import { buildTemplateLinkRowsToAppendFromJobCategory } from '../utils/templateLinkAppend';
import {
  buildBlueprintsToAppend,
  buildTrainingTracksToAppend,
  jobCategoryTrainingTrackFieldValues,
} from '../utils/referenceTableAppend';
import { effectiveCategoryNeedSer } from '../utils/fillBlanks';
import { isJobCategoryExcludedFromOrgScope } from '../utils/jobCategoryScope';
import { getNonRequestableSailpointRoleWarning } from '../utils/sailpointRequestable';
import './JobCategoryForm.css';

/** Default scope for new categories (same as Job Categories list filter default). */
const DEFAULT_ORG_JOB_CAT_SCOPE = 'In Scope for Organization';

const TEMPLATE_TOUCH_FIELDS = ['linkableTemplateId', 'linkableTemplateName', 'subtemplatesId', 'subtemplatesName'];

const BLANK_JOB_CATEGORY_FORM = {
  jobCategoryId: '',
  jobCategoryName: '',
  organizationJobCategoryScope: DEFAULT_ORG_JOB_CAT_SCOPE,
  description: '',
  owningApplication: '',
  impactedApplications: '',
  owningWorkgroup: '',
  otherInterestedWorkgroups: '',
  needEMP: '',
  needSER: '',
  linkableTemplateId: '',
  linkableTemplateName: '',
  subtemplatesId: '',
  subtemplatesName: '',
  blueprintId: '',
  blueprintName: '',
  trainingTrack1: '',
  trainingTrack2: '',
  trainingTrack3: '',
  trainingTrack4: '',
  trainingTrack5: '',
  trainingTrack6: '',
  preLiveDayInTheLifeActivity: '',
  postLiveDayInTheLifeActivity: '',
  userSettingsLab: '',
  sailpointRole: '',
  sailpointRoleReview: '',
  lastEditDateReasonInitials: '',
  status: 'Active',
};

const JobCategoryForm = ({ category, onSubmit, onCancel }) => {
  const firstInputRef = useRef(null);
  const [trainingTracks, setTrainingTracks] = useState([]);
  const [blueprints, setBlueprints] = useState([]);
  const [sailpointRoles, setSailpointRoles] = useState([]);
  const [templateLinks, setTemplateLinks] = useState([]);
  const [formData, setFormData] = useState(BLANK_JOB_CATEGORY_FORM);

  useEffect(() => {
    if (category) {
      // Editing existing category - use existing data
      setFormData({
        jobCategoryId: category.jobCategoryId || '',
        jobCategoryName: category.jobCategoryName || '',
        organizationJobCategoryScope: category.organizationJobCategoryScope || '',
        description: category.description || '',
        owningApplication: category.owningApplication || '',
        impactedApplications: category.impactedApplications || '',
        owningWorkgroup: category.owningWorkgroup || '',
        otherInterestedWorkgroups: category.otherInterestedWorkgroups || '',
        needEMP: category.needEMP || '',
        needSER: category.needSER || '',
        linkableTemplateId: category.linkableTemplateId || '',
        linkableTemplateName: category.linkableTemplateName || '',
        subtemplatesId: category.subtemplatesId || '',
        subtemplatesName: category.subtemplatesName || '',
        blueprintId: category.blueprintId || '',
        blueprintName: category.blueprintName || '',
        trainingTrack1: category.trainingTrack1 || '',
        trainingTrack2: category.trainingTrack2 || '',
        trainingTrack3: category.trainingTrack3 || '',
        trainingTrack4: category.trainingTrack4 || '',
        trainingTrack5: category.trainingTrack5 || '',
        trainingTrack6: category.trainingTrack6 || '',
        preLiveDayInTheLifeActivity: category.preLiveDayInTheLifeActivity || '',
        postLiveDayInTheLifeActivity: category.postLiveDayInTheLifeActivity || '',
        userSettingsLab: category.userSettingsLab || '',
        sailpointRole: category.sailpointRole || '',
        sailpointRoleReview: category.sailpointRoleReview || '',
        lastEditDateReasonInitials: category.lastEditDateReasonInitials || '',
        status: category.status || 'Active',
      });
    } else {
      // New category - auto-populate next Job Category ID
      (async () => {
        const categories = await getJobCategories();
        let nextId = 1;
      
        if (categories && categories.length > 0) {
          // Find the highest numeric ID
          const numericIds = categories
            .map(cat => {
              const id = cat.jobCategoryId || '';
              // Extract numeric part from the ID
              const numericMatch = id.toString().match(/\d+/);
              return numericMatch ? parseInt(numericMatch[0], 10) : 0;
            })
            .filter(id => id > 0);
          
            if (numericIds.length > 0) {
            const maxId = Math.max(...numericIds);
            nextId = maxId + 1;
          }
        }
        
        setFormData({
          ...BLANK_JOB_CATEGORY_FORM,
          jobCategoryId: nextId.toString(),
        });
      })();
    }
  }, [category]);

  useEffect(() => {
    (async () => {
      const [tracks, bps, sailRoles, tls] = await Promise.all([
        getTrainingTracks(),
        getBlueprints(),
        getSailpointRoles(),
        getTemplateLinks(),
      ]);
      setTrainingTracks(Array.isArray(tracks) ? tracks : []);
      setBlueprints(Array.isArray(bps) ? bps : []);
      setSailpointRoles(Array.isArray(sailRoles) ? sailRoles : []);
      setTemplateLinks(Array.isArray(tls) ? tls : []);
    })();
  }, []);

  const preparsedTemplateRowsForSuggest = useMemo(
    () => preparseTemplateLinkRows(templateLinks),
    [templateLinks]
  );

  const sailpointRoleHint = useMemo(() => {
    const selectedRole = (formData.sailpointRole || '').trim().toLowerCase();
    if (!selectedRole) return '';
    const matches = (sailpointRoles || []).filter(
      (row) => (row.sailpointRole || '').trim().toLowerCase() === selectedRole
    );
    if (matches.length === 0) return '';
    const details = matches
      .map((row) => [row.description, row.entitlements].filter(Boolean).join(' | '))
      .filter(Boolean);
    return [...new Set(details)].join(' ; ');
  }, [formData, sailpointRoles]);

  const sailpointRoleNameSuggestions = useMemo(() => {
    if ((formData.sailpointRole || '').trim()) return [];
    if (isJobCategoryExcludedFromOrgScope(formData)) return [];
    return suggestSailpointRolesForJobCategory(
      formData.jobCategoryName,
      sailpointRoles,
      {
        linkableTemplateId: formData.linkableTemplateId,
        linkableTemplateName: formData.linkableTemplateName,
        subtemplatesId: formData.subtemplatesId,
        subtemplatesName: formData.subtemplatesName,
      },
      templateLinks,
      preparsedTemplateRowsForSuggest
    );
  }, [formData, sailpointRoles, templateLinks, preparsedTemplateRowsForSuggest]);

  const bestSailpointMatch =
    sailpointRoleNameSuggestions.length > 0 ? sailpointRoleNameSuggestions[0] : null;

  const nonRequestableSailpointWarning = useMemo(
    () => getNonRequestableSailpointRoleWarning(formData.sailpointRole, sailpointRoles),
    [formData, sailpointRoles]
  );

  const confirmNonRequestableSailpointIfNeeded = (roleName) => {
    const warning = getNonRequestableSailpointRoleWarning(roleName, sailpointRoles);
    if (!warning) return true;
    return window.confirm(`${warning}\n\nSave this job category anyway?`);
  };

  // Focus first field when form is shown so users can start typing immediately
  useEffect(() => {
    const t = setTimeout(() => firstInputRef.current?.focus(), 0);
    return () => clearTimeout(t);
  }, []);

  const [affectedRoles, setAffectedRoles] = useState([]);

  useEffect(() => {
    if (!category) { setAffectedRoles([]); return; }
    const catName = (category.jobCategoryName || '').trim();
    if (!catName) { setAffectedRoles([]); return; }
    let cancelled = false;
    getRoles().then((roles) => {
      if (cancelled) return;
      const matched = (roles || [])
        .filter((r) => (r.jobCategory || '').trim() === catName)
        .map((r) => r.rbacCode || r.id)
        .sort();
      setAffectedRoles(matched);
    });
    return () => { cancelled = true; };
  }, [category]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => {
      const next = { ...prev, [name]: value };
      if (name === 'sailpointRole' && (value || '').trim()) next.sailpointRoleReview = '';
      if (name === 'blueprintId' || name === 'blueprintName') {
        next.needSER = effectiveCategoryNeedSer(next);
      }
      if (TEMPLATE_TOUCH_FIELDS.includes(name)) {
        const v = (f) => (f === name ? value : prev[f]) || '';
        const hasTpl =
          String(v('linkableTemplateId')).trim() ||
          String(v('linkableTemplateName')).trim() ||
          String(v('subtemplatesId')).trim() ||
          String(v('subtemplatesName')).trim();
        if (hasTpl && !String(prev.needEMP || '').trim()) next.needEMP = 'Yes';
      }
      return next;
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const data = { ...formData };
    ['trainingTrack1', 'trainingTrack2', 'trainingTrack3', 'trainingTrack4', 'trainingTrack5', 'trainingTrack6'].forEach((f) => {
      if (data[f] === TRAINING_TRACK_OTHER) data[f] = '';
    });
    if (data.blueprintId === BLUEPRINT_OTHER) {
      data.blueprintId = '';
      data.blueprintName = '';
    }
    data.needSER = effectiveCategoryNeedSer(data);
    if ((data.sailpointRole || '').trim()) data.sailpointRoleReview = '';
    if (!confirmNonRequestableSailpointIfNeeded(data.sailpointRole)) return;
    // Auto-populate Last Edit Date/Reason/Initials (same format as Roles: date/time - audit user)
    const now = new Date();
    const dateTimeString = now.toLocaleString('en-US', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
    data.lastEditDateReasonInitials = `${dateTimeString} - ${getCurrentAuditUser()}`;

    const toTpl = buildTemplateLinkRowsToAppendFromJobCategory(templateLinks, data);
    const toBp = buildBlueprintsToAppend(blueprints, data.blueprintId, data.blueprintName);
    const toTr = buildTrainingTracksToAppend(trainingTracks, jobCategoryTrainingTrackFieldValues(data));

    if (toTpl.length === 0 && toBp.length === 0 && toTr.length === 0) {
      onSubmit(data);
      return;
    }

    (async () => {
      try {
        if (toTpl.length > 0) {
          const withIds = toTpl.map((r) => ({ ...r, id: generateId() }));
          const res = await appendTemplateLinks(withIds);
          if (res?.added > 0) {
            for (const row of withIds) {
              await addTemplateLinkAuditLog('CREATE', row);
            }
            setTemplateLinks(await getTemplateLinks());
          }
        }
        if (toBp.length > 0) {
          const withIds = toBp.map((b) => ({ ...b, id: generateId() }));
          const res = await appendBlueprints(withIds);
          if (res?.added > 0) {
            for (const row of withIds) {
              await addBlueprintAuditLog('CREATE', row);
            }
            setBlueprints(await getBlueprints());
          }
        }
        if (toTr.length > 0) {
          const withIds = toTr.map((t) => ({ ...t, id: generateId() }));
          await appendTrainingTracks(withIds);
          setTrainingTracks(await getTrainingTracks());
        }
      } catch (err) {
        console.error('Append reference tables failed:', err);
      }
      onSubmit(data);
    })();
  };

  return (
    <div className="category-form-container">
      <div className="category-form">
        <h2>{category ? 'Edit Job Category' : 'Add New Job Category'}</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="jobCategoryId">Job Category ID *</label>
              <input
                ref={firstInputRef}
                type="text"
                id="jobCategoryId"
                name="jobCategoryId"
                value={formData.jobCategoryId}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="jobCategoryName">Job Category Name *</label>
              <input
                type="text"
                id="jobCategoryName"
                name="jobCategoryName"
                value={formData.jobCategoryName}
                onChange={handleChange}
                required
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="organizationJobCategoryScope">Organization Job Category Scope</label>
              <input
                type="text"
                id="organizationJobCategoryScope"
                name="organizationJobCategoryScope"
                value={formData.organizationJobCategoryScope}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="description">Description</label>
            <textarea
              id="description"
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows="3"
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="owningApplication">Owning Application</label>
              <input
                type="text"
                id="owningApplication"
                name="owningApplication"
                value={formData.owningApplication}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label htmlFor="impactedApplications">Impacted Application(s)</label>
              <input
                type="text"
                id="impactedApplications"
                name="impactedApplications"
                value={formData.impactedApplications}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="owningWorkgroup">Owning Workgroup</label>
              <input
                type="text"
                id="owningWorkgroup"
                name="owningWorkgroup"
                value={formData.owningWorkgroup}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label htmlFor="otherInterestedWorkgroups">Other Interested Workgroup(s)</label>
              <input
                type="text"
                id="otherInterestedWorkgroups"
                name="otherInterestedWorkgroups"
                value={formData.otherInterestedWorkgroups}
                onChange={handleChange}
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="needEMP">Need EMP?</label>
              <select
                id="needEMP"
                name="needEMP"
                value={formData.needEMP}
                onChange={handleChange}
              >
                <option value="">Select...</option>
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select>
            </div>

            <div className="form-group">
              <label htmlFor="needSER">Need SER?</label>
              <select
                id="needSER"
                name="needSER"
                value={formData.needSER}
                onChange={handleChange}
              >
                <option value="">Select...</option>
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select>
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="linkableTemplateId">Linkable Template ID</label>
              <textarea
                id="linkableTemplateId"
                name="linkableTemplateId"
                rows={3}
                value={formData.linkableTemplateId}
                onChange={handleChange}
                onBlur={(e) => {
                  setFormData((prev) => {
                    const synced = syncJobCategoryLinkableFromTemplateLinks(
                      templateLinks,
                      e.target.value,
                      prev.linkableTemplateName,
                      'id'
                    );
                    return {
                      ...prev,
                      linkableTemplateId: normalizeSubtemplateCommaList(synced.linkableTemplateId),
                      linkableTemplateName: normalizeSubtemplateCommaList(
                        formatCommaSeparatedTemplateNamesUpper(
                          synced.linkableTemplateName || prev.linkableTemplateName
                        )
                      ),
                    };
                  });
                }}
                placeholder="One per line or comma/pipe separated; duplicates allowed"
              />
            </div>

            <div className="form-group">
              <label htmlFor="linkableTemplateName" title="Same field as Template Links → Template Display Title(s); commas separate two templates">
                Template Description
              </label>
              <textarea
                id="linkableTemplateName"
                name="linkableTemplateName"
                rows={3}
                value={formData.linkableTemplateName}
                onChange={handleChange}
                onBlur={(e) => {
                  const normalizedIn = normalizeSubtemplateCommaList(e.target.value);
                  const formattedForSync = formatCommaSeparatedTemplateNamesUpper(normalizedIn);
                  setFormData((prev) => {
                    const synced = syncJobCategoryLinkableFromTemplateLinks(
                      templateLinks,
                      prev.linkableTemplateId,
                      formattedForSync,
                      'name'
                    );
                    return {
                      ...prev,
                      linkableTemplateName: normalizeSubtemplateCommaList(
                        formatCommaSeparatedTemplateNamesUpper(
                          synced.linkableTemplateName || formattedForSync
                        )
                      ),
                      linkableTemplateId: normalizeSubtemplateCommaList(
                        synced.linkableTemplateId || prev.linkableTemplateId
                      ),
                    };
                  });
                }}
                placeholder="Template Display Title(s) from Templates/Subtemplates; comma separates two templates"
              />
            </div>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="subtemplatesId" title="Same field as Subtemplate ID in Templates/Subtemplates (subtemplate rows)">
                Subtemplate ID
              </label>
              <textarea
                id="subtemplatesId"
                name="subtemplatesId"
                rows={3}
                value={formData.subtemplatesId}
                onChange={handleChange}
                onBlur={(e) => {
                  setFormData((prev) => {
                    const synced = syncJobCategorySubtemplatesFromTemplateLinks(
                      templateLinks,
                      e.target.value,
                      prev.subtemplatesName,
                      'id'
                    );
                    const idOut = normalizeSubtemplateCommaList(synced.subtemplatesId);
                    const mergedNames = synced.subtemplatesName || prev.subtemplatesName || '';
                    const nameOut = normalizeSubtemplateCommaList(
                      formatCommaSeparatedTemplateNamesUpper(mergedNames)
                    );
                    return {
                      ...prev,
                      subtemplatesId: idOut,
                      subtemplatesName: nameOut || prev.subtemplatesName,
                    };
                  });
                }}
                placeholder="One per line or comma/pipe separated; duplicates allowed"
              />
            </div>

            <div className="form-group">
              <label htmlFor="subtemplatesName" title="Same as Subtemplate Description in Templates/Subtemplates; legacy CSV header Subtemplate(s) Name maps to this column">
                Subtemplate Description
              </label>
              <textarea
                id="subtemplatesName"
                name="subtemplatesName"
                rows={3}
                value={formData.subtemplatesName}
                onChange={handleChange}
                onBlur={(e) => {
                  const formatted = formatJobCategoryTemplateNameUpper(e.target.value);
                  const normalizedIn = normalizeSubtemplateCommaList(formatted);
                  setFormData((prev) => {
                    const synced = syncJobCategorySubtemplatesFromTemplateLinks(
                      templateLinks,
                      prev.subtemplatesId,
                      normalizedIn,
                      'name'
                    );
                    const mergedNames = synced.subtemplatesName || normalizedIn;
                    const idOut = normalizeSubtemplateCommaList(
                      synced.subtemplatesId || prev.subtemplatesId || ''
                    );
                    const nameOut = normalizeSubtemplateCommaList(
                      formatCommaSeparatedTemplateNamesUpper(mergedNames)
                    );
                    return {
                      ...prev,
                      subtemplatesName: nameOut,
                      subtemplatesId: idOut || prev.subtemplatesId,
                    };
                  });
                }}
                placeholder="One per line or comma/pipe separated; duplicates allowed"
              />
            </div>
          </div>

          <div className="form-row">
            {blueprints.length > 0 ? (
              <div className="form-group" style={{ flex: '1 1 100%' }}>
                <label htmlFor="blueprintId">Blueprint</label>
                <BlueprintDropdown
                  id="blueprintId"
                  value={formData.blueprintId}
                  options={blueprints}
                  placeholder="Select blueprint..."
                  onChange={(blueprint) => {
                    setFormData((prev) => {
                      const next = {
                        ...prev,
                        blueprintId: blueprint ? blueprint.blueprintId : '',
                        blueprintName: blueprint ? blueprint.blueprintName : '',
                      };
                      next.needSER = effectiveCategoryNeedSer(next);
                      return next;
                    });
                  }}
                  onAddNew={async ({ blueprintId, blueprintName }) => {
                    const newBlueprint = { id: generateId(), blueprintId, blueprintName };
                    await appendBlueprints([newBlueprint]);
                    await addBlueprintAuditLog('CREATE', newBlueprint);
                    const updated = await getBlueprints();
                    setBlueprints(updated || []);
                    setFormData((prev) => {
                      const next = {
                        ...prev,
                        blueprintId,
                        blueprintName,
                      };
                      next.needSER = effectiveCategoryNeedSer(next);
                      return next;
                    });
                  }}
                />
              </div>
            ) : (
              <>
                <div className="form-group">
                  <label htmlFor="blueprintId">Blueprint ID</label>
                  <input
                    type="text"
                    id="blueprintId"
                    name="blueprintId"
                    value={formData.blueprintId}
                    onChange={handleChange}
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="blueprintName">Blueprint Name</label>
                  <input
                    type="text"
                    id="blueprintName"
                    name="blueprintName"
                    value={formData.blueprintName}
                    onChange={handleChange}
                  />
                </div>
              </>
            )}
          </div>

          {(() => {
            const trackNames = (trainingTracks || []).map((t) => (t.trackName || '').trim()).filter(Boolean);
            const hasDropdown = trackNames.length > 0;
            const renderTrackField = (name, label) => {
              const value = formData[name] || '';
              const clearBtn = value ? (
                <button
                  type="button"
                  className="btn-clear-field"
                  onClick={() => setFormData((prev) => ({ ...prev, [name]: '' }))}
                  title={`Clear ${label}`}
                  aria-label={`Clear ${label}`}
                >
                  &times;
                </button>
              ) : null;
              return (
                <div className="form-group" key={name}>
                  <label htmlFor={name}>{label}</label>
                  <div className="field-with-clear">
                    {hasDropdown ? (
                      <TrainingTrackDropdown
                        id={name}
                        value={value}
                        options={trainingTracks}
                        onChange={(v) => setFormData((prev) => ({ ...prev, [name]: v }))}
                        onAddNew={async (newName) => {
                          const trackName = (newName || '').trim();
                          if (!trackName) return;
                          const id = generateId();
                          await appendTrainingTracks([{ id, trackName }]);
                          setTrainingTracks(await getTrainingTracks());
                        }}
                        placeholder="Select..."
                      />
                    ) : (
                      <input type="text" id={name} name={name} value={value} onChange={handleChange} />
                    )}
                    {clearBtn}
                  </div>
                </div>
              );
            };
            return (
              <>
                <div className="form-row">
                  {renderTrackField('trainingTrack1', 'Training Track 1')}
                  {renderTrackField('trainingTrack2', 'Training Track 2')}
                </div>
                <div className="form-row">
                  {renderTrackField('trainingTrack3', 'Training Track 3')}
                  {renderTrackField('trainingTrack4', 'Training Track 4')}
                </div>
                <div className="form-row">
                  {renderTrackField('trainingTrack5', 'Training Track 5')}
                  {renderTrackField('trainingTrack6', 'Training Track 6')}
                </div>
              </>
            );
          })()}

          <div className="form-group">
            <label htmlFor="preLiveDayInTheLifeActivity">Pre-live Day-in-the-Life Activity</label>
            <textarea
              id="preLiveDayInTheLifeActivity"
              name="preLiveDayInTheLifeActivity"
              value={formData.preLiveDayInTheLifeActivity}
              onChange={handleChange}
              rows="3"
            />
          </div>

          <div className="form-group">
            <label htmlFor="postLiveDayInTheLifeActivity">Post-live Day-in-the-Life Activity</label>
            <textarea
              id="postLiveDayInTheLifeActivity"
              name="postLiveDayInTheLifeActivity"
              value={formData.postLiveDayInTheLifeActivity}
              onChange={handleChange}
              rows="3"
            />
          </div>

          <div className="form-group">
            <label htmlFor="userSettingsLab">User Settings Lab</label>
            <input
              type="text"
              id="userSettingsLab"
              name="userSettingsLab"
              value={formData.userSettingsLab}
              onChange={handleChange}
            />
          </div>

          <div className="form-group sailpoint-role-form-group">
            <label htmlFor="sailpointRole">Sailpoint Role</label>
            <p className="form-hint form-hint--compact">
              Leave blank for ranked suggestions: category name (leading &quot;Epic Mosaic&quot; ignored), linkable
              template and subtemplate IDs/names, and matching Template Links rows. Pin a role in{' '}
              <code>sailpointCategoryPreferredRoles.json</code> (normalized key → full role name); save and refresh.
              Or type to search the catalog, or use <strong>Use best match</strong>.
            </p>
            <div className="sailpoint-role-input-row">
              <input
                type="text"
                id="sailpointRole"
                name="sailpointRole"
                className={`sailpoint-role-input-row__field${nonRequestableSailpointWarning ? ' input-warning' : ''}`}
                list="jobCategorySailpointRoleList"
                value={formData.sailpointRole}
                onChange={handleChange}
                placeholder="Search catalog, or pick a suggestion below"
                aria-describedby={
                  [
                    nonRequestableSailpointWarning ? 'sailpoint-non-requestable-warning' : '',
                    sailpointRoleNameSuggestions.length > 0 ? 'sailpoint-suggestions-region' : '',
                  ]
                    .filter(Boolean)
                    .join(' ') || undefined
                }
              />
              <div className="sailpoint-role-input-row__actions">
                {(formData.sailpointRole || '').trim() ? (
                  <button
                    type="button"
                    className="btn-sailpoint-secondary"
                    onClick={() => setFormData((prev) => ({ ...prev, sailpointRole: '' }))}
                  >
                    Clear
                  </button>
                ) : bestSailpointMatch ? (
                  <button
                    type="button"
                    className="btn-sailpoint-primary"
                    onClick={() =>
                      setFormData((prev) => ({
                        ...prev,
                        sailpointRole: String(bestSailpointMatch.sailpointRole || '').trim(),
                        sailpointRoleReview: '',
                      }))
                    }
                  >
                    Use best match
                  </button>
                ) : null}
              </div>
            </div>
            <datalist id="jobCategorySailpointRoleList">
              {sailpointRoles.map((row) => (
                <option key={row.id} value={row.sailpointRole}>
                  {row.sailpointRole}
                </option>
              ))}
            </datalist>
            {sailpointRoleNameSuggestions.length > 0 && (
              <div
                id="sailpoint-suggestions-region"
                className="sailpoint-role-suggestions"
                role="group"
                aria-label="Suggested Sailpoint roles from category name, templates, subtemplates, and Template Links"
              >
                <span className="sailpoint-role-suggestions-label">Suggestions (click to apply):</span>
                <div className="sailpoint-role-suggestions-list">
                  {sailpointRoleNameSuggestions.map((row) => (
                    <button
                      key={row.id}
                      type="button"
                      className="sailpoint-role-suggestion-btn"
                      onClick={() =>
                        setFormData((prev) => ({
                          ...prev,
                          sailpointRole: String(row.sailpointRole || '').trim(),
                          sailpointRoleReview: '',
                        }))
                      }
                    >
                      {row.sailpointRole}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {nonRequestableSailpointWarning && (
              <p id="sailpoint-non-requestable-warning" className="form-warning" role="alert">
                {nonRequestableSailpointWarning}
              </p>
            )}
            {sailpointRoleHint && (
              <small style={{ color: '#475569', fontSize: '0.85rem' }}>
                Linked templates/subtemplates: {sailpointRoleHint}
              </small>
            )}
            <label className="form-hint form-hint--compact" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginTop: '0.75rem' }}>
              <input
                type="checkbox"
                checked={formData.sailpointRoleReview === 'Review'}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    sailpointRoleReview: e.target.checked ? 'Review' : '',
                  }))
                }
              />
              Flag for Sailpoint review (no suitable catalog match yet)
            </label>
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="status">Status</label>
              <select
                id="status"
                name="status"
                value={formData.status}
                onChange={handleChange}
              >
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="lastEditDateReasonInitials">Last Edit Date/Reason/Initials</label>
            <textarea
              id="lastEditDateReasonInitials"
              name="lastEditDateReasonInitials"
              value={formData.lastEditDateReasonInitials}
              rows="3"
              readOnly
              style={{ backgroundColor: '#f5f5f5', cursor: 'not-allowed' }}
              title="This field is automatically populated on save"
            />
          </div>

          {category && affectedRoles.length > 0 && (
            <div className="affected-roles-notice">
              <strong>
                RBAC roles that will be updated for{' '}
                {(formData.jobCategoryName || category.jobCategoryName || '').trim() || '(unnamed category)'}
                {' '}({affectedRoles.length}):
              </strong>
              <div className="affected-roles-list">
                {affectedRoles.map((code) => (
                  <span key={code} className="affected-role-tag">{code}</span>
                ))}
              </div>
            </div>
          )}

          <div className="form-actions">
            <button type="button" className="btn-cancel" onClick={onCancel}>
              Cancel
            </button>
            <button type="submit" className="btn-submit">
              {category ? 'Update Category' : 'Create Category'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default JobCategoryForm;
