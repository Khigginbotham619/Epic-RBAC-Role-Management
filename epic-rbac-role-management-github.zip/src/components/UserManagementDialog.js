import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import SortableTh from './SortableTh';
import { sortRowsByKey, nextSortState } from '../utils/tableSort';
import './UserManagementDialog.css';

const UserManagementDialog = ({ users, currentUserId, onClose, onUsersChanged }) => {
  const [selected, setSelected] = useState(new Set());
  const [editingId, setEditingId] = useState(null);
  const [editValue, setEditValue] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const editRef = useRef(null);

  useEffect(() => {
    const handleKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [onClose]);

  useEffect(() => {
    if (editingId && editRef.current) editRef.current.focus();
  }, [editingId]);

  const [sortConfig, setSortConfig] = useState({ key: null, direction: 'asc' });
  const handleSort = useCallback((key) => {
    setSortConfig((prev) => nextSortState(prev, key));
  }, []);
  const sorted = useMemo(() => {
    const base = [...users];
    if (!sortConfig.key) {
      return base.sort((a, b) => (a.username || '').localeCompare(b.username || ''));
    }
    return sortRowsByKey(base, sortConfig.key, sortConfig.direction);
  }, [users, sortConfig.key, sortConfig.direction]);
  const isNotSetUser = (user) => {
    const username = (user?.username || '').trim().toLowerCase();
    return username === 'not set';
  };

  const toggleSelect = (id) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const toggleAll = () => {
    if (selected.size === sorted.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(sorted.map((u) => u.id)));
    }
  };

  const startEdit = (user) => {
    setEditingId(user.id);
    setEditValue(user.username);
    setError('');
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditValue('');
    setError('');
  };

  const saveEdit = async () => {
    const name = editValue.trim();
    if (!name) { setError('Username cannot be empty.'); return; }
    setBusy(true);
    setError('');
    try {
      const res = await fetch(`/api/users/${editingId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: name }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Failed to rename user');
      cancelEdit();
      onUsersChanged();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const handleDeleteSelected = async () => {
    if (selected.size === 0) return;
    const names = sorted.filter((u) => selected.has(u.id)).map((u) => u.username).join(', ');
    if (!window.confirm(`Delete ${selected.size} user(s)?\n\n${names}`)) return;
    setBusy(true);
    setError('');
    try {
      const res = await fetch('/api/users/batch-delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids: [...selected] }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Failed to delete users');
      setSelected(new Set());
      onUsersChanged();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="um-overlay" onClick={onClose}>
      <div className="um-dialog" onClick={(e) => e.stopPropagation()}>
        <div className="um-header">
          <h3>Manage Users</h3>
          <button type="button" className="um-close" onClick={onClose} aria-label="Close">&times;</button>
        </div>

        {error && <div className="um-error">{error}</div>}

        <div className="um-body">
          {sorted.length === 0 ? (
            <p className="um-empty">No users.</p>
          ) : (
            <table className="um-table">
              <thead>
                <tr>
                  <th className="um-col-check">
                    <input
                      type="checkbox"
                      checked={selected.size === sorted.length && sorted.length > 0}
                      onChange={toggleAll}
                      title="Select all"
                    />
                  </th>
                  <SortableTh columnKey="username" sortConfig={sortConfig} onSort={handleSort}>Username</SortableTh>
                  <th className="um-col-actions">Actions</th>
                </tr>
              </thead>
              <tbody>
                {sorted.map((u) => (
                  <tr key={u.id} className={u.id === currentUserId ? 'um-current' : ''}>
                    <td className="um-col-check">
                      <input
                        type="checkbox"
                        checked={selected.has(u.id)}
                        onChange={() => toggleSelect(u.id)}
                      />
                    </td>
                    <td>
                      {editingId === u.id ? (
                        <input
                          ref={editRef}
                          type="text"
                          className="um-edit-input"
                          value={editValue}
                          onChange={(e) => setEditValue(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') { e.preventDefault(); saveEdit(); }
                            if (e.key === 'Escape') cancelEdit();
                          }}
                          disabled={busy}
                        />
                      ) : (
                        <span className="um-username">
                          {u.username}
                          {u.id === currentUserId && <span className="um-badge">current</span>}
                        </span>
                      )}
                    </td>
                    <td className="um-col-actions">
                      {!isNotSetUser(u) && (
                        editingId === u.id ? (
                          <>
                            <button type="button" className="um-btn um-btn-save" onClick={saveEdit} disabled={busy}>Save</button>
                            <button type="button" className="um-btn um-btn-cancel" onClick={cancelEdit} disabled={busy}>Cancel</button>
                          </>
                        ) : (
                          <button type="button" className="um-btn um-btn-edit" onClick={() => startEdit(u)} disabled={busy}>Rename</button>
                        )
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="um-footer">
          <span className="um-selection-info">
            {selected.size > 0 ? `${selected.size} selected` : '\u00A0'}
          </span>
          <div className="um-footer-buttons">
            <button
              type="button"
              className="um-btn um-btn-delete"
              onClick={handleDeleteSelected}
              disabled={selected.size === 0 || busy}
            >
              Delete Selected ({selected.size})
            </button>
            <button type="button" className="um-btn um-btn-close" onClick={onClose}>
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserManagementDialog;
