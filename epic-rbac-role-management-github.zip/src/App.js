import React, { useState, useEffect } from 'react';
import './App.css';
import { ToastProvider } from './context/ToastContext';
import RolesList from './components/RolesList';
import AuditLog from './components/AuditLog';
import JobCategories from './components/JobCategories';
import JobCodes from './components/JobCodes';
import Departments from './components/Departments';
import SailpointRoles from './components/SailpointRoles';
import BlueprintList from './components/BlueprintList';
import TemplateLinks from './components/TemplateLinks';
import FindBlanks from './components/FindBlanks';
import FindSailpointMatches from './components/FindSailpointMatches';
import SPExportTable from './components/SPExportTable';
import TrainingTracks from './components/TrainingTracks';
import ReferenceTableBlanks from './components/ReferenceTableBlanks';
import IntegrityFixes from './components/IntegrityFixes';
import Admin from './components/Admin';
import UserManagementDialog from './components/UserManagementDialog';
import { setCurrentUserInStorage, removeCurrentUserFromStorage, getStoredCurrentUser } from './utils/storage';

const USER_CHANGE_PASSWORD = 'CHANGE_ME';

/** Main nav: grouped for scanability; `view` matches currentView / sessionStorage. */
const NAV_CORE = [
  { view: 'roles', label: 'Roles' },
  { view: 'jobCategories', label: 'Job Categories' },
];
const NAV_REFERENCE_DATA = [
  { view: 'jobCodes', label: 'Job Codes' },
  { view: 'departments', label: 'Departments' },
  { view: 'templateLinks', label: 'Templates/Subtemplates' },
  { view: 'blueprints', label: 'Blueprints' },
  { view: 'trainingTracks', label: 'Training Tracks' },
  { view: 'sailpointRoles', label: 'Sailpoint Roles' },
];
/** Restricted to admin. */
const NAV_SP_EXPORT = [{ view: 'spExportTable', label: 'SP Export Table' }];
const NAV_TOOLS = [
  { view: 'findBlanks', label: 'Find Blanks' },
  { view: 'findSailpointMatches', label: 'Sailpoint Match' },
  { view: 'integrityFixes', label: 'Integrity Fixes' },
  { view: 'referenceTableBlanks', label: 'Reference Blanks' },
];
const NAV_ADMIN = [{ view: 'admin', label: 'Admin' }];
const NAV_AUDIT = [{ view: 'audit', label: 'Audit Log' }];

function App() {
  const [currentView, setCurrentView] = useState(() => {
    try { return sessionStorage.getItem('rbac_currentView') || 'roles'; } catch (_) { return 'roles'; }
  });
  // Hydrate from storage immediately so refresh keeps the same tab (restricted views require user).
  const [user, setUser] = useState(() => {
    try {
      return getStoredCurrentUser();
    } catch (_) {
      return null;
    }
  });
  const [userList, setUserList] = useState([]);
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [pendingUserChangeValue, setPendingUserChangeValue] = useState(null);
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [showUserManagement, setShowUserManagement] = useState(false);

  useEffect(() => {
    try { sessionStorage.setItem('rbac_currentView', currentView); } catch (_) {}
  }, [currentView]);

  const fetchUsers = () => {
    fetch('/api/users')
      .then(res => res.ok ? res.json() : [])
      .then((list) => {
        const arr = Array.isArray(list) ? list : [];
        setUserList(arr);
        setUser((prev) => {
          if (!prev) return prev;
          const match = arr.find((u) => u.id === prev.id);
          if (!match) {
            removeCurrentUserFromStorage();
            return null;
          }
          if (match.username !== prev.username) {
            const updated = { ...prev, username: match.username };
            setCurrentUserInStorage(updated);
            return updated;
          }
          return prev;
        });
      })
      .catch(() => setUserList([]));
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  // When no user is selected, only Roles Management is available — stay on roles view
  useEffect(() => {
    if (!user && currentView !== 'roles') setCurrentView('roles');
  }, [user, currentView]);

  // Reference data, tools, admin, and SP Export are only for admin.
  const canAccessRestricted = user?.username === 'admin';
  useEffect(() => {
    if (!canAccessRestricted && ['jobCodes', 'departments', 'templateLinks', 'blueprints', 'findBlanks', 'findSailpointMatches', 'integrityFixes', 'referenceTableBlanks', 'trainingTracks', 'spExportTable', 'admin'].includes(currentView)) {
      setCurrentView('roles');
    }
  }, [canAccessRestricted, currentView]);

  const applyUserChangeValue = (value) => {
    if (value === '' || value === '__none__') {
      removeCurrentUserFromStorage();
      setUser(null);
      return;
    }
    if (value === '__add__') {
      const name = window.prompt('Enter username for audit:');
      if (!name || !name.trim()) return;
      fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: name.trim() }),
      })
        .then(async (res) => {
          const text = await res.text();
          let data;
          try {
            data = text ? JSON.parse(text) : {};
          } catch (_) {
            data = { error: res.statusText || 'Server error' };
          }
          if (!res.ok) {
            throw new Error(data.error || `Request failed (${res.status})`);
          }
          return data;
        })
        .then((data) => {
          if (data.user) {
            const userData = { id: data.user.id, username: data.user.username };
            setUserList(prev => [...prev, userData]);
            setCurrentUserInStorage(userData);
            setUser(userData);
          } else {
            alert(data.error || 'Failed to add user');
          }
        })
        .catch((err) => alert(err.message || 'Failed to add user. Check that the server is running.'));
      return;
    }
    const chosen = userList.find(u => u.id === value);
    if (chosen) {
      const userData = { id: chosen.id, username: chosen.username };
      setCurrentUserInStorage(userData);
      setUser(userData);
    }
  };

  const handleUserChange = (e) => {
    const value = e.target.value;
    setPendingUserChangeValue(value);
    setPasswordInput('');
    setPasswordError('');
    setShowPasswordDialog(true);
  };

  const handlePasswordSubmit = () => {
    if (passwordInput !== USER_CHANGE_PASSWORD) {
      setPasswordError('Incorrect password.');
      return;
    }
    setPasswordError('');
    setShowPasswordDialog(false);
    if (pendingUserChangeValue != null) {
      applyUserChangeValue(pendingUserChangeValue);
      setPendingUserChangeValue(null);
    }
    setPasswordInput('');
  };

  const handlePasswordDialogCancel = () => {
    setShowPasswordDialog(false);
    setPendingUserChangeValue(null);
    setPasswordInput('');
    setPasswordError('');
  };

  return (
    <ToastProvider>
    <div className="App">
      {showPasswordDialog && (
        <div className="password-dialog-overlay" onClick={handlePasswordDialogCancel}>
          <div className="password-dialog" onClick={(e) => e.stopPropagation()}>
            <p className="password-dialog-title">Enter password to change user</p>
            <input
              type="password"
              className="password-dialog-input"
              value={passwordInput}
              onChange={(e) => { setPasswordInput(e.target.value); setPasswordError(''); }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handlePasswordSubmit();
                if (e.key === 'Escape') handlePasswordDialogCancel();
              }}
              placeholder="Password"
              autoFocus
              aria-label="Password"
            />
            {passwordError && <p className="password-dialog-error">{passwordError}</p>}
            <div className="password-dialog-buttons">
              <button type="button" className="password-dialog-btn password-dialog-cancel" onClick={handlePasswordDialogCancel}>Cancel</button>
              <button type="button" className="password-dialog-btn password-dialog-submit" onClick={handlePasswordSubmit}>OK</button>
            </div>
          </div>
        </div>
      )}
      <header className="app-header">
        <div className="app-header-left">
          <h1>Epic RBAC Roles Management</h1>
          <div className="user-info">
            <select
              id="audit-user-select"
              className="audit-user-dropdown"
              value={user ? user.id : '__none__'}
              onChange={handleUserChange}
              aria-label="User for audit"
            >
              <option value="__none__">Not set</option>
              {userList.map(u => (
                <option key={u.id} value={u.id}>{u.username}</option>
              ))}
              <option value="__add__">➕ Add user...</option>
            </select>
            {user && (
              <button
                type="button"
                className="btn-delete-user"
                onClick={() => setShowUserManagement(true)}
              >
                Manage Users
              </button>
            )}
          </div>
        </div>
      </header>
      
      <nav className="app-nav" aria-label="Primary navigation">
        <div className="app-nav__group" aria-label="Core">
          {NAV_CORE.map(({ view, label }) => (
            <button
              key={view}
              type="button"
              className={currentView === view ? 'active' : ''}
              onClick={() => setCurrentView(view)}
            >
              {label}
            </button>
          ))}
        </div>
        {user && canAccessRestricted && (
          <div className="app-nav__group" aria-label="SailPoint export">
            {NAV_SP_EXPORT.map(({ view, label }) => (
              <button
                key={view}
                type="button"
                className={currentView === view ? 'active' : ''}
                onClick={() => setCurrentView(view)}
              >
                {label}
              </button>
            ))}
          </div>
        )}
        {user && (
          <div className="app-nav__group" aria-label="Reference data">
            {NAV_REFERENCE_DATA
              .filter(({ view }) => view === 'sailpointRoles')
              .map(({ view, label }) => (
                <button
                  key={view}
                  type="button"
                  className={currentView === view ? 'active' : ''}
                  onClick={() => setCurrentView(view)}
                >
                  {label}
                </button>
              ))}
          </div>
        )}
        {user && canAccessRestricted && (
          <>
            <div className="app-nav__group" aria-label="Reference data">
              {NAV_REFERENCE_DATA
                .filter(({ view }) => view !== 'sailpointRoles')
                .map(({ view, label }) => (
                <button
                  key={view}
                  type="button"
                  className={currentView === view ? 'active' : ''}
                  onClick={() => setCurrentView(view)}
                >
                  {label}
                </button>
              ))}
            </div>
            <div className="app-nav__group" aria-label="Tools">
              {NAV_TOOLS.map(({ view, label }) => (
                <button
                  key={view}
                  type="button"
                  className={currentView === view ? 'active' : ''}
                  onClick={() => setCurrentView(view)}
                >
                  {label}
                </button>
              ))}
            </div>
            <div className="app-nav__group" aria-label="Administration">
              {NAV_ADMIN.map(({ view, label }) => (
                <button
                  key={view}
                  type="button"
                  className={currentView === view ? 'active' : ''}
                  onClick={() => setCurrentView(view)}
                >
                  {label}
                </button>
              ))}
            </div>
          </>
        )}
        {user && (
          <div className="app-nav__group" aria-label="Audit">
            {NAV_AUDIT.map(({ view, label }) => (
              <button
                key={view}
                type="button"
                className={currentView === view ? 'active' : ''}
                onClick={() => setCurrentView(view)}
              >
                {label}
              </button>
            ))}
          </div>
        )}
      </nav>

      <main className="app-main">
        {currentView === 'roles' && (
          <RolesList
            allowBulkActions={!!user}
            canEditRoles={!!user}
            canSyncRoles={!!user}
            showSaveButton={canAccessRestricted}
          />
        )}
        {user && currentView === 'jobCategories' && (
          <JobCategories
            allowBulkActions={!!user}
            canAccessAdvanced={canAccessRestricted}
            canSyncRoles={!!user}
          />
        )}
        {user && canAccessRestricted && currentView === 'jobCodes' && <JobCodes />}
        {user && canAccessRestricted && currentView === 'departments' && <Departments />}
        {user && canAccessRestricted && currentView === 'templateLinks' && <TemplateLinks />}
        {user && currentView === 'sailpointRoles' && <SailpointRoles />}
        {user && canAccessRestricted && currentView === 'blueprints' && <BlueprintList />}
        {user && canAccessRestricted && currentView === 'findBlanks' && <FindBlanks />}
        {user && canAccessRestricted && currentView === 'findSailpointMatches' && <FindSailpointMatches />}
        {user && canAccessRestricted && currentView === 'integrityFixes' && <IntegrityFixes />}
        {user && canAccessRestricted && currentView === 'referenceTableBlanks' && <ReferenceTableBlanks setCurrentView={setCurrentView} />}
        {user && canAccessRestricted && currentView === 'trainingTracks' && <TrainingTracks canEdit={!!user} />}
        {user && canAccessRestricted && currentView === 'spExportTable' && <SPExportTable />}
        {user && canAccessRestricted && currentView === 'admin' && <Admin setCurrentView={setCurrentView} allowBulkActions={canAccessRestricted} />}
        {user && currentView === 'audit' && <AuditLog />}
      </main>

      {showUserManagement && (
        <UserManagementDialog
          users={userList}
          currentUserId={user?.id}
          onClose={() => setShowUserManagement(false)}
          onUsersChanged={fetchUsers}
        />
      )}
    </div>
    </ToastProvider>
  );
}

export default App;
