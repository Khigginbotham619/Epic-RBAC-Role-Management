import {
  applyCategoryUpdatesToRole,
  roleMatchesJobCategory,
} from './fillBlanks';

describe('applyCategoryUpdatesToRole', () => {
  const category = {
    jobCategoryName: 'Registered Nurse',
    linkableTemplateId: 'T100',
    linkableTemplateName: 'NURSE TEMPLATE DISPLAY',
    subtemplatesId: 'S1',
    subtemplatesName: 'Sub One',
    needEMP: 'Yes',
    needSER: 'No',
    blueprintId: 'BP1',
    blueprintName: 'Nurse Blueprint',
    trainingTrack1: 'Track A',
    sailpointRole: 'SP Nurse',
  };

  const blueprints = [{ blueprintId: 'BP1', blueprintName: 'Nurse Blueprint' }];

  it('syncs category-derived fields onto a matching role', () => {
    const role = {
      id: 'r1',
      jobCategory: 'Registered Nurse',
      linkedRoleTemplateId: 'OLD',
      empNeeded: 'No',
    };
    const updated = applyCategoryUpdatesToRole(role, category, blueprints, []);
    expect(updated.linkedRoleTemplateId).toBe('T100');
    expect(updated.linkedRoleTemplateName).toBe('NURSE TEMPLATE DISPLAY');
    expect(updated.templateDisplayTitle).toBeUndefined();
    expect(updated.empNeeded).toBe('Yes');
    expect(updated.slaNeeded).toBe('Yes');
    expect(updated.sailpointRole).toBe('SP Nurse');
    expect(updated.trainingTrack).toBe('Track A');
  });

  it('falls back to category template description when template links have no name', () => {
    const role = { id: 'r1', jobCategory: 'Registered Nurse', linkedRoleTemplateName: 'Old Name' };
    const cat = { ...category, linkableTemplateId: 'UNKNOWN' };
    const updated = applyCategoryUpdatesToRole(role, cat, [], []);
    expect(updated.linkedRoleTemplateName).toBe('NURSE TEMPLATE DISPLAY');
  });

  it('updates roles matched by the previous category name after a rename', () => {
    const role = {
      id: 'r1',
      jobCategory: 'Old Nurse Name',
      empNeeded: 'No',
    };
    const renamed = { ...category, jobCategoryName: 'Registered Nurse' };
    expect(roleMatchesJobCategory(role, renamed)).toBe(false);
    expect(
      roleMatchesJobCategory(role, renamed, { previousCategoryName: 'Old Nurse Name' })
    ).toBe(true);

    const updated = applyCategoryUpdatesToRole(role, renamed, blueprints, [], {
      previousCategoryName: 'Old Nurse Name',
    });
    expect(updated.jobCategory).toBe('Registered Nurse');
    expect(updated.empNeeded).toBe('Yes');
  });

  it('leaves unrelated roles unchanged', () => {
    const role = { id: 'r1', jobCategory: 'Physician', empNeeded: 'Yes' };
    const updated = applyCategoryUpdatesToRole(role, category, blueprints, []);
    expect(updated).toBe(role);
  });
});
