/**
 * Shared cell comparison for table column sorting (numeric when both parse as finite numbers).
 */
export function compareCellValues(a, b) {
  if (a == null && b == null) return 0;
  if (a == null || a === '') return 1;
  if (b == null || b === '') return -1;
  const sa = String(a).trim();
  const sb = String(b).trim();
  const na = Number(sa);
  const nb = Number(sb);
  if (
    sa !== '' &&
    sb !== '' &&
    !Number.isNaN(na) &&
    !Number.isNaN(nb) &&
    Number.isFinite(na) &&
    Number.isFinite(nb)
  ) {
    if (na !== nb) return na < nb ? -1 : 1;
    return 0;
  }
  return sa.localeCompare(sb, undefined, { numeric: true, sensitivity: 'base' });
}

/**
 * @param {Array} rows
 * @param {string|null} sortKey
 * @param {'asc'|'desc'} direction
 * @param {(row: object, key: string) => *} [getCellValue] default: row[key]
 */
export function sortRowsByKey(rows, sortKey, direction, getCellValue) {
  if (!sortKey || !Array.isArray(rows) || rows.length === 0) return rows;
  const mult = direction === 'desc' ? -1 : 1;
  const get =
    typeof getCellValue === 'function' ? getCellValue : (row, key) => row[key];
  return [...rows].sort(
    (r1, r2) => mult * compareCellValues(get(r1, sortKey), get(r2, sortKey))
  );
}

export function nextSortState(prev, key) {
  if (prev.key !== key) return { key, direction: 'asc' };
  return { key, direction: prev.direction === 'asc' ? 'desc' : 'asc' };
}
