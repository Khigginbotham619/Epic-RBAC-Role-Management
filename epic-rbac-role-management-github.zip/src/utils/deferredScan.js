import { useEffect, useState } from 'react';

/**
 * Run an expensive scan after the UI has painted (requestIdleCallback / setTimeout).
 * Keeps tab switches responsive when scanning thousands of roles.
 */
export function useDeferredScan(scanFn, deps, enabled = true) {
  const [result, setResult] = useState(null);
  const [scanning, setScanning] = useState(false);

  useEffect(() => {
    if (!enabled) {
      setResult(null);
      setScanning(false);
      return undefined;
    }

    setScanning(true);
    let cancelled = false;

    const run = () => {
      if (cancelled) return;
      setResult(scanFn());
      setScanning(false);
    };

    if (typeof window !== 'undefined' && typeof window.requestIdleCallback === 'function') {
      const id = window.requestIdleCallback(run, { timeout: 1500 });
      return () => {
        cancelled = true;
        window.cancelIdleCallback(id);
      };
    }

    const timerId = setTimeout(run, 0);
    return () => {
      cancelled = true;
      clearTimeout(timerId);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps -- scanFn + deps are the intentional trigger set
  }, deps);

  return { result, scanning };
}
