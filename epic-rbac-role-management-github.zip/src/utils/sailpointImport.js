import {
  applyTemplateFieldsFromEntitlement,
  parseTemplateAndSubtemplate,
} from './sailpointEntitlementParse.js';

export const SAILPOINT_IMPORT_HEADER_MAP = {
  'Sailpoint Role': 'sailpointRole',
  'Role-ID': 'sailpointRole',
  'role-id': 'sailpointRole',
  role_name: 'sailpointRole',
  sailpointRole: 'sailpointRole',
  sailpoint_role: 'sailpointRole',
  Status: 'status',
  status: 'status',
  role_status: 'status',
  job_category: 'description',
  Description: 'description',
  description: 'description',
  role_description: 'description',
  Templates: 'templates',
  templates: 'templates',
  template: 'templates',
  Template: 'templates',
  subtemplate: 'subtemplates',
  subtemplates: 'subtemplates',
  Subtemplate: 'subtemplates',
  Subtemplates: 'subtemplates',
  Entitlements: 'entitlements',
  entitlements: 'entitlements',
  entitlement_value: 'instructions',
  Instructions: 'instructions',
  instructions: 'instructions',
  requestable: 'requestable',
  matched_access_profile: 'matchedAccessProfile',
  entitlement_type: 'entitlementType',
  'Role Name': 'sailpointRole',
  'Template Display Name': 'description',
  'Template ID': 'templateId',
  'Subtemplate ID': 'subtemplateId',
};

function normalizeStatus(value) {
  const s = String(value || '').trim();
  if (!s) return 'Active';
  if (/^true$/i.test(s)) return 'Active';
  if (/^false$/i.test(s)) return 'Inactive';
  return s;
}

/** Map one raw CSV/Excel row to internal Sailpoint role fields. */
export function mapImportedSailpointRow(row) {
  const mapped = {};
  Object.keys(row || {}).forEach((key) => {
    const normalized = String(key).trim();
    const match = Object.keys(SAILPOINT_IMPORT_HEADER_MAP).find(
      (h) => h.toLowerCase() === normalized.toLowerCase()
    );
    const internalKey = match ? SAILPOINT_IMPORT_HEADER_MAP[match] : normalized;
    mapped[internalKey] = String(row[key] || '').replace(/\s+/g, ' ').trim();
  });

  if (!mapped.entitlements) {
    const entitlements = [mapped.templateId, mapped.subtemplateId]
      .map((v) => String(v || '').trim())
      .filter(Boolean)
      .join(' | ');
    mapped.entitlements = entitlements;
  }
  if (!mapped.templates) mapped.templates = '';
  if (!mapped.subtemplates) mapped.subtemplates = '';
  Object.assign(mapped, applyTemplateFieldsFromEntitlement(mapped));
  if (!mapped.templates && mapped.description && /template\s*id/i.test(mapped.description)) {
    const parsed = parseTemplateAndSubtemplate(mapped.description);
    if (parsed.template) mapped.templates = parsed.template;
    if (parsed.subtemplate) mapped.subtemplates = parsed.subtemplate;
  }
  if (!mapped.instructions) mapped.instructions = mapped.entitlements || '';
  if (!mapped.description) mapped.description = '';
  if (!mapped.entitlements) mapped.entitlements = mapped.instructions || '';
  mapped.status = normalizeStatus(mapped.status);
  if (!mapped.requestable) mapped.requestable = '';
  if (!mapped.matchedAccessProfile) mapped.matchedAccessProfile = '';
  if (!mapped.entitlementType) mapped.entitlementType = '';
  delete mapped.templateId;
  delete mapped.subtemplateId;
  return mapped;
}

export function mapImportedSailpointRows(rows) {
  return (Array.isArray(rows) ? rows : [])
    .map(mapImportedSailpointRow)
    .filter((r) => (r.sailpointRole || '').trim());
}
