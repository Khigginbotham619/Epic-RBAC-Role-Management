/**
 * Parse Epic Mosaic entitlement strings into template and subtemplate IDs.
 * Handles formats like:
 *   "... - Template ID T3041901 / Subtemplate ID STORG034"
 *   "... Template ID T2100301/ Subtemplate ID T74200 T15400"
 *   "...-Template TORG111-Subtemplate STORG130 ..."
 *   "... / No Subtemplate ID"
 */
export function parseTemplateAndSubtemplate(value) {
  const raw = String(value || '').trim();
  if (!raw) return { template: '', subtemplate: '' };

  const stripPrefixByDashRule = (input) => {
    const s = String(input || '').trim();
    if (!s) return '';
    const first = s.indexOf('-');
    if (first === -1) return s;
    const second = s.indexOf('-', first + 1);
    if (second !== -1) return s.slice(second + 1).trim();
    return s.slice(first + 1).trim();
  };

  const cleanSubtemplateValue = (val) => {
    return String(val || '')
      .replace(/\s+add\s+template\b.*$/i, '')
      .replace(/\s+needs\b.*$/i, '')
      .replace(/\s*\(.*$/, '')
      .trim();
  };

  const extractTemplateId = (text) => {
    const t = String(text || '').trim();
    if (!t) return '';
    if (/no\s*template\s*id/i.test(t)) return '';

    const inlineTemplate = t.match(
      /(?:^|[\s-])template\s+(?:id\s*)?[:\-]?\s*([A-Za-z0-9]+)(?=\s*-?\s*subtemplate\b|$)/i
    );
    if (inlineTemplate) return String(inlineTemplate[1] || '').trim();

    const stripped = stripPrefixByDashRule(t);

    const gluedId = stripped.match(/template\s*id\s*((?:T|ST|TORG)[A-Za-z0-9_-]+)/i);
    if (gluedId) return String(gluedId[1] || '').trim();

    const labeledId = stripped.match(/template\s*id\s*[:\-]?\s*([A-Za-z0-9_-]+)/i);
    if (labeledId) return String(labeledId[1] || '').trim();

    if (/^template\s*id\s*[:\-]?\s*$/i.test(stripped)) return '';

    const beforeSubLabel = stripped.match(/-\s*([A-Za-z0-9_-]+)\s*-\s*subtemplate\s*id\b/i);
    if (beforeSubLabel) return String(beforeSubLabel[1] || '').trim();

    return '';
  };

  const extractSubtemplateId = (text) => {
    const t = String(text || '').trim();
    if (!t) return '';
    if (/no\s*subtemplate/i.test(t) && !/subtemplate\s*id\s*[:\-]?\s*\S/i.test(t)) {
      return 'No Subtemplate';
    }

    const inlineSub = t.match(/(?:^|[\s-])subtemplate\s+(?:id\s*)?[:\-]?\s*(.+)$/i);
    if (inlineSub) {
      const epicIdPattern = /(?:^|\s|,)(ST[A-Za-z]*\d[A-Za-z0-9_-]*|T\d[A-Za-z0-9_-]*|TORG[A-Za-z0-9]+)/gi;
      const epicIds = [...String(inlineSub[1] || '').matchAll(epicIdPattern)].map((m) =>
        String(m[1] || '').trim()
      );
      if (epicIds.length) return epicIds.join(' ');
      const val = cleanSubtemplateValue(inlineSub[1]);
      if (!val || /^id\s*$/i.test(val)) return '';
      return val;
    }

    const stripped = stripPrefixByDashRule(t);
    const labeled = stripped.match(/subtemplate\s*id\s*[:\-]?\s*(.+)$/i);
    if (labeled) {
      const val = cleanSubtemplateValue(labeled[1]);
      if (!val) return '';
      return val;
    }

    if (/^subtemplate\s*id\s*[:\-]?\s*$/i.test(stripped)) return '';
    return '';
  };

  // Split on "/" before subtemplate section (flexible spacing; avoids Pre/Post in role names).
  const sepMatch = raw.match(/^(.*?)\s*\/\s*((?:subtemplate\b|no\s*subtemplate\b).*)$/i);
  if (sepMatch) {
    return {
      template: extractTemplateId(sepMatch[1]),
      subtemplate: extractSubtemplateId(sepMatch[2]),
    };
  }

  return {
    template: extractTemplateId(raw),
    subtemplate: extractSubtemplateId(raw),
  };
}

/** Apply parsed template/subtemplate fields onto a Sailpoint import row. */
export function applyTemplateFieldsFromEntitlement(row) {
  const mapped = { ...row };
  const source = String(mapped.instructions || mapped.entitlements || '').trim();
  if (!source) return mapped;

  const parsed = parseTemplateAndSubtemplate(source);
  if (parsed.template) mapped.templates = parsed.template;
  if (parsed.subtemplate) mapped.subtemplates = parsed.subtemplate;
  return mapped;
}
