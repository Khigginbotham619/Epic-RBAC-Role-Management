import {
  jobCategoryClinicianType,
  sailpointRowClinicianType,
  suggestSailpointRolesForJobCategory,
} from './sailpointCategorySuggestions';

describe('clinician type matching', () => {
  it('detects nurse practitioner and physician assistant on categories and roles', () => {
    expect(jobCategoryClinicianType('Nurse Practitioner - Burn Medicine')).toBe('nurse-practitioner');
    expect(jobCategoryClinicianType('NP - Allergy (Inpatient)')).toBe('nurse-practitioner');
    expect(jobCategoryClinicianType('Physician Assistant - ICU')).toBe('physician-assistant');
    expect(jobCategoryClinicianType('Physician - PICU (Inpatient)')).toBeNull();
    expect(sailpointRowClinicianType({ sailpointRole: 'Epic Mosaic NP - Burn (Inpatient)' })).toBe(
      'nurse-practitioner'
    );
    expect(
      sailpointRowClinicianType({ sailpointRole: 'Epic Mosaic Physician Assistant - ICU' })
    ).toBe('physician-assistant');
  });
});

describe('suggestSailpointRolesForJobCategory', () => {
  it('only suggests catalog rows marked requestable=TRUE', () => {
    const rows = [
      {
        sailpointRole: 'Epic Mosaic Nurse Ambulatory',
        requestable: 'TRUE',
        description: 'Template T100 ambulatory nursing',
      },
      {
        sailpointRole: 'Epic Mosaic Nurse Ambulatory Legacy',
        requestable: 'FALSE',
        description: 'Template T100 ambulatory nursing',
      },
      {
        sailpointRole: 'Epic Mosaic Nurse Ambulatory Unknown',
        requestable: '',
        description: 'Template T100 ambulatory nursing',
      },
    ];
    const suggestions = suggestSailpointRolesForJobCategory('Nurse Ambulatory', rows, {
      linkableTemplateId: 'T100',
      linkableTemplateName: 'Ambulatory',
    });
    const names = suggestions.map((r) => r.sailpointRole);
    expect(names).toContain('Epic Mosaic Nurse Ambulatory');
    expect(names).not.toContain('Epic Mosaic Nurse Ambulatory Legacy');
    expect(names).not.toContain('Epic Mosaic Nurse Ambulatory Unknown');
  });

  it('suggests only nurse practitioner roles for NP job categories', () => {
    const rows = [
      {
        sailpointRole: 'Epic Mosaic Nurse Practitioner - Burn Medicine',
        requestable: 'TRUE',
        description: 'Template T100 burn medicine',
      },
      {
        sailpointRole: 'Epic Mosaic Physician Assistant - Burn Medicine',
        requestable: 'TRUE',
        description: 'Template T100 burn medicine',
      },
    ];
    const suggestions = suggestSailpointRolesForJobCategory(
      'Nurse Practitioner - Burn Medicine (Inpatient)',
      rows,
      { linkableTemplateId: 'T100', linkableTemplateName: 'Burn' }
    );
    const names = suggestions.map((r) => r.sailpointRole);
    expect(names).toContain('Epic Mosaic Nurse Practitioner - Burn Medicine');
    expect(names).not.toContain('Epic Mosaic Physician Assistant - Burn Medicine');
  });

  it('suggests only physician assistant roles for PA job categories', () => {
    const rows = [
      {
        sailpointRole: 'Epic Mosaic Nurse Practitioner - ICU',
        requestable: 'TRUE',
        description: 'Template T100 icu',
      },
      {
        sailpointRole: 'Epic Mosaic Physician Assistant - ICU',
        requestable: 'TRUE',
        description: 'Template T100 icu',
      },
    ];
    const suggestions = suggestSailpointRolesForJobCategory('Physician Assistant - ICU', rows, {
      linkableTemplateId: 'T100',
      linkableTemplateName: 'ICU',
    });
    const names = suggestions.map((r) => r.sailpointRole);
    expect(names).toContain('Epic Mosaic Physician Assistant - ICU');
    expect(names).not.toContain('Epic Mosaic Nurse Practitioner - ICU');
  });
});
