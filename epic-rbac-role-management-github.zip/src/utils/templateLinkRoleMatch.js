/**
 * Match RBAC role linked template fields to Template Links (Linkable Template rows)
 * and resolve Template Display Title values from that table.
 *
 * Column alignment (same concept, different screens):
 * - Role **Linked Role Template ID** ↔ Template Links **Template ID(s)**
 * - Role **Linked Role Template Name** ↔ Template Links **Template Name(s)**
 * - Role **Template Display Title** ↔ Template Links **Template Display Title**
 * - Job category **linkableTemplateId** ↔ Template Links **Template ID(s)**
 * - Job category **linkableTemplateName** (Template Description) ↔ Template Links **Template Display Title**
 * - Job category **subtemplatesName** (Subtemplate Description) ↔ Template Links **Subtemplate Name**
 */

/** Keep in sync with TemplateLinks canonicalUserRecordType (Linkable vs Subtemplate). */
export function canonicalTemplateLinkRecordType(row) {
  const raw =
    row?.userRecordType ??
    row?.UserRecordType ??
    row?.user_record_type ??
    '';
  let v = String(raw).replace(/\u00a0/g, ' ').trim().toLowerCase().replace(/\s+/g, ' ');
  if (!v) return 'Linkable Template';
  if (v === 'subtemplate' || v === 'sub template' || v === 'sub-template') return 'Subtemplate';
  if (v === 'linkable template' || v === 'linkabletemplate') return 'Linkable Template';
  if (v.startsWith('subtemplate')) return 'Subtemplate';
  if (v.includes('linkable')) return 'Linkable Template';
  return 'Linkable Template';
}

function canonicalTemplateLinkStatus(value) {
  const raw = String(value ?? '').replace(/\u00a0/g, ' ').trim().toLowerCase();
  if (!raw) return 'Active';
  if (['active', 'a', 'yes', 'y', 'true', '1', 'enabled'].includes(raw)) return 'Active';
  if (['inactive', 'in active', 'i', 'no', 'n', 'false', '0', 'disabled', '#n/a', 'n/a'].includes(raw)) return 'Inactive';
  if (['pending', 'p', 'review', 'on hold', 'hold'].includes(raw)) return 'Pending';
  return 'Active';
}

/**
 * Same rules as Template Links screen `normalizeMultiTemplateInput`.
 * By default commas/newlines split tokens, but name fields preserve commas.
 * Keeps lookup strings aligned with what the template table stores after edit/save.
 */
function normalizeMultiTemplateInput(value, { splitCommas = true, uppercase = false } = {}) {
  if (value == null) return '';
  return String(value)
    .replace(/\r\n?/g, '\n')
    .replace(/\n+/g, '\n')
    .split('\n')
    .flatMap((line) => (splitCommas ? line.split(',') : [line]))
    .map((part) => part.trim().replace(/\s+/g, ' '))
    .filter(Boolean)
    .map((part) => (uppercase ? part.toUpperCase() : part))
    .join('\n');
}

/** Normalize driver/API variants (MSSQL / JSON) onto expected keys and stored field shape (matches Template Links UI). */
export function normalizeTemplateLinkRow(row) {
  if (!row || typeof row !== 'object') return row;
  const merged = {
    ...row,
    userRecordType: row.userRecordType ?? row.UserRecordType ?? row.user_record_type ?? '',
    templateId: row.templateId ?? row.TemplateId ?? row.template_id ?? '',
    templateName: row.templateName ?? row.TemplateName ?? row.template_name ?? '',
    templateDisplayTitle:
      row.templateDisplayTitle ?? row.TemplateDisplayTitle ?? row.template_display_title ?? '',
    subtemplateId: row.subtemplateId ?? row.SubtemplateId ?? row.subtemplate_id ?? '',
    subtemplateName: row.subtemplateName ?? row.SubtemplateName ?? row.subtemplate_name ?? '',
    primaryTemplateOwner:
      row.primaryTemplateOwner ?? row.PrimaryTemplateOwner ?? row.primary_template_owner ?? '',
    currentStatus: row.currentStatus ?? row.CurrentStatus ?? row.current_status ?? '',
  };

  const userRecordType = canonicalTemplateLinkRecordType(merged);
  let templateId = normalizeMultiTemplateInput(merged.templateId);
  let templateName = normalizeMultiTemplateInput(merged.templateName, { splitCommas: false, uppercase: true });
  let subtemplateId = normalizeMultiTemplateInput(merged.subtemplateId);
  let subtemplateName = normalizeMultiTemplateInput(merged.subtemplateName, { splitCommas: false, uppercase: true });

  if (userRecordType === 'Subtemplate') {
    if (!templateId && subtemplateId) templateId = subtemplateId;
    if (!templateName && subtemplateName) templateName = subtemplateName;
    subtemplateId = '';
    subtemplateName = '';
  }

  return {
    ...merged,
    userRecordType,
    templateId,
    templateName,
    primaryTemplateOwner: normalizeMultiTemplateInput(merged.primaryTemplateOwner),
    templateDisplayTitle: normalizeMultiTemplateInput(merged.templateDisplayTitle, { splitCommas: false, uppercase: true }),
    subtemplateId,
    subtemplateName,
    currentStatus: canonicalTemplateLinkStatus(merged.currentStatus),
  };
}

/** Drop null/undefined/holes so `canonicalTemplateLinkRecordType` is not applied to missing rows (which would look "linkable" and crash ID set helpers). */
function asNormalizedLinkRows(links) {
  return (links || [])
    .map(normalizeTemplateLinkRow)
    .filter((r) => r != null && typeof r === 'object');
}

/**
 * Normalize Template Links once for lookup (call before many `displayTitlesFromNormalizedLinks` calls).
 * @param {unknown[]} links
 * @returns {object[]}
 */
export function normalizeTemplateLinksForLookup(links) {
  return asNormalizedLinkRows(links);
}

/** Template IDs: same separators as elsewhere in app, including spaces (e.g. "T1 T2" or exports with spaces). */
export function splitTemplateIdTokens(value) {
  if (value == null || !String(value).trim()) return [];
  return String(value)
    .replace(/\r\n?/g, '\n')
    .split(/[\n,|;\s]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

/** Template names: do not split on spaces or commas (commas can be part of a single name). */
export function splitTemplateNameTokens(value) {
  if (value == null || !String(value).trim()) return [];
  return String(value)
    .replace(/\r\n?/g, '\n')
    .split(/[\n|;]+/)
    .map((s) => s.trim())
    .filter(Boolean);
}

/**
 * Subtemplate name slots on job categories: preserve empty segments when comma-separated ("A,,B") so IDs ↔ names stay aligned.
 */
export function splitSubtemplateNameSlotsForSync(value) {
  if (value == null || !String(value).trim()) return [];
  const raw = String(value).replace(/\r\n?/g, '\n').trim();
  if (raw.includes(',')) {
    return raw.split(',').map((t) => t.trim());
  }
  return splitTemplateNameTokens(raw);
}

/**
 * Template description slots on job categories (linkableTemplateName ↔ Template Display Title).
 * Commas separate two templates; commas inside a single title are preserved when no comma-list is used.
 */
export function splitLinkableTemplateDescriptionSlotsForSync(value) {
  if (value == null || !String(value).trim()) return [];
  const raw = String(value).replace(/\r\n?/g, '\n').trim();
  if (raw.includes(',')) {
    return raw.split(',').map((t) => t.trim());
  }
  return splitTemplateDisplayTitleSlots(raw);
}

function splitLinkRowSubtemplateNameSlots(row) {
  const raw = normalizeTemplateLinkRow(row)?.subtemplateName ?? '';
  if (!String(raw).trim()) return [];
  const s = String(raw).replace(/\r\n?/g, '\n').trim();
  if (s.includes(',')) {
    return s.split(',').map((t) => t.trim());
  }
  return splitTemplateNameTokens(s);
}

/** Display title slots: align with Template Links (newlines/pipes), not spaces or commas (commas may be part of title text). */
export function splitTemplateDisplayTitleSlots(value) {
  if (value == null || !String(value).trim()) return [];
  return String(value)
    .replace(/\r\n?/g, '\n')
    .split(/[\n|;]+/)
    .map((s) => s.trim().replace(/\s+/g, ' '))
    .filter(Boolean);
}

/**
 * Prefer Template Display Title slots aligned to Template ID(s) / Template Name(s); mirrors **Template Display Title** column only (no Template Name fallback).
 */
function resolvedDisplayTitleForSlot(link, idToken, nameToken) {
  if (!link) return '';
  const n = normalizeTemplateLinkRow(link);
  const idx = resolveTemplateLinkSlotIndex(n, idToken, nameToken);
  const titles = splitTemplateDisplayTitleSlots(n.templateDisplayTitle);
  if (idx >= 0) return (titles[idx] ?? titles[0] ?? '').trim();
  if (titles.length > 0) return titles[0].trim();
  return String(n.templateDisplayTitle || '').trim();
}

/** Template Name slot aligned to Template ID(s) / Template Name(s) on a link row. */
function resolvedTemplateNameForSlot(link, idToken, nameToken) {
  if (!link) return '';
  const n = normalizeTemplateLinkRow(link);
  const idx = resolveTemplateLinkSlotIndex(n, idToken, nameToken);
  const names = splitTemplateNameTokens(n.templateName);
  if (idx >= 0) return (names[idx] ?? names[0] ?? '').trim();
  if (names.length > 0) return names[0].trim();
  return String(n.templateName || '').trim();
}

function resolveTemplateLinkSlotIndex(normalizedLink, idToken, nameToken) {
  const n = normalizedLink;
  if (!n) return -1;
  let idx = -1;
  if (idToken) {
    const ids = splitTemplateIdTokens(n.templateId);
    idx = ids.findIndex((t) => t.trim().toLowerCase() === idToken.trim().toLowerCase());
  }
  if (idx < 0 && nameToken) {
    const namesForIdx = splitTemplateNameTokens(n.templateName);
    idx = namesForIdx.findIndex((t) => t.trim().toLowerCase() === nameToken.trim().toLowerCase());
  }
  return idx;
}

function linkRowDisplayTitleTokens(link) {
  if (!link || typeof link !== 'object') return [];
  const n = normalizeTemplateLinkRow(link);
  if (!n) return [];
  const segs = splitTemplateDisplayTitleSlots(n.templateDisplayTitle);
  if (segs.length > 0) return segs.map((s) => s.toLowerCase());
  const single = String(n.templateDisplayTitle || '').trim().toLowerCase();
  return single ? [single] : [];
}

function findLinkRowByTemplateDisplayTitle(linkable, titleToken) {
  if (!titleToken) return null;
  const want = titleToken.trim().toLowerCase();
  if (!want) return null;
  return (
    linkable.find((l) => {
      const tokens = linkRowDisplayTitleTokens(l);
      return tokens.includes(want);
    }) || null
  );
}

/** Template link "Template ID(s)" field may list multiple IDs like the role's Linked Role Template ID. */
function linkRowTemplateIdSet(link) {
  if (!link || typeof link !== 'object') return new Set();
  const n = normalizeTemplateLinkRow(link);
  if (!n) return new Set();
  const segs = splitTemplateIdTokens(n.templateId);
  return new Set(segs.map((s) => s.toLowerCase()));
}

function findLinkRowByLinkedTemplateId(linkable, idToken) {
  if (!idToken) return null;
  const want = idToken.trim().toLowerCase();
  if (!want) return null;
  return (
    linkable.find((l) => {
      const idSet = linkRowTemplateIdSet(l);
      return idSet.has(want);
    }) || null
  );
}

function linkRowTemplateNameTokens(link) {
  if (!link || typeof link !== 'object') return [];
  const n = normalizeTemplateLinkRow(link);
  if (!n) return [];
  const segs = splitTemplateNameTokens(n.templateName);
  if (segs.length > 0) return segs.map((s) => s.toLowerCase());
  const single = String(n.templateName || '').trim().toLowerCase();
  return single ? [single] : [];
}

function findLinkRowByTemplateName(linkable, nameToken) {
  if (!nameToken) return null;
  const want = nameToken.trim().toLowerCase();
  if (!want) return null;
  return (
    linkable.find((l) => {
      const tokens = linkRowTemplateNameTokens(l);
      return tokens.includes(want);
    }) || null
  );
}

/** Same resolution order as linear scan (Linkable ID → Linkable name → all ID → all name); first row wins per token. */
function findTemplateLinkRowFromIndex(index, id, name) {
  const idKey = id ? String(id).trim().toLowerCase() : '';
  const nameKey = name ? String(name).trim().toLowerCase() : '';
  let row = idKey ? index.idLinkable.get(idKey) : null;
  if (!row && nameKey) row = index.nameLinkable.get(nameKey);
  if (!row && idKey) row = index.idAll.get(idKey);
  if (!row && nameKey) row = index.nameAll.get(nameKey);
  return row || null;
}

/**
 * Build token→row maps once (iteration order matches linear `.find` first-match wins).
 * Use with {@link displayTitlesFromTemplateIndex} for bulk RBAC updates.
 * @param {object[]} normalizedLinks from {@link normalizeTemplateLinksForLookup}
 */
export function buildTemplateLookupIndex(normalizedLinks) {
  const idLinkable = new Map();
  const nameLinkable = new Map();
  const idAll = new Map();
  const nameAll = new Map();
  const rows = Array.isArray(normalizedLinks) ? normalizedLinks : [];
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    if (!r || typeof r !== 'object') continue;
    const isLinkable = canonicalTemplateLinkRecordType(r) === 'Linkable Template';
    for (const t of splitTemplateIdTokens(r.templateId)) {
      const k = t.trim().toLowerCase();
      if (!k) continue;
      if (!idAll.has(k)) idAll.set(k, r);
      if (isLinkable && !idLinkable.has(k)) idLinkable.set(k, r);
    }
    for (const tok of linkRowTemplateNameTokens(r)) {
      if (!tok) continue;
      if (!nameAll.has(tok)) nameAll.set(tok, r);
      if (isLinkable && !nameLinkable.has(tok)) nameLinkable.set(tok, r);
    }
  }
  return { idLinkable, nameLinkable, idAll, nameAll };
}

/**
 * Resolve Template Display Title from Template Links.
 * Join: role **Linked Role Template ID** ↔ link **Template ID(s)**, or name ↔ **Template Name(s)**.
 * Prefers **Linkable Template** rows, then any row (so mis-labeled **User Record Type** still matches).
 * Values come from the link row’s **Template Display Title** column only (blank in the table → blank on the role).
 *
 * @param {Array<{templateId?: string, templateName?: string, templateDisplayTitle?: string, userRecordType?: string}>} links
 * @param {string} linkedRoleTemplateId
 * @param {string} linkedRoleTemplateName
 * @returns {string} newline-separated display titles (aligned to slots)
 */
export function hasTemplateLookupInput(linkedRoleTemplateId, linkedRoleTemplateName) {
  return (
    splitTemplateIdTokens(linkedRoleTemplateId).length > 0 ||
    splitTemplateNameTokens(linkedRoleTemplateName).length > 0
  );
}

/**
 * Per-slot lookup using a pre-built index (O(slots), not O(slots × links)).
 * @returns {{ id: string, name: string, title: string }[]}
 */
function resolveTemplateLookupSlotsFromIndex(index, linkedRoleTemplateId, linkedRoleTemplateName) {
  const ids = splitTemplateIdTokens(linkedRoleTemplateId);
  const names = splitTemplateNameTokens(linkedRoleTemplateName);
  if (!ids.length && !names.length) return [];
  const slots = Math.max(ids.length, names.length, 1);
  const out = [];
  for (let i = 0; i < slots; i++) {
    const id = (ids[i] ?? (ids.length ? ids[0] : '')).trim();
    const name = (names[i] ?? (names.length ? names[0] : '')).trim();
    let title = '';
    if (id || name) {
      const row = findTemplateLinkRowFromIndex(index, id || '', name || '');
      title = row ? resolvedDisplayTitleForSlot(row, id || '', name || '') : '';
    }
    out.push({ id, name, title });
  }
  return out;
}

/** Newline-separated titles using a **pre-built** lookup index (bulk merges). */
export function displayTitlesFromTemplateIndex(index, linkedRoleTemplateId, linkedRoleTemplateName) {
  const slots = resolveTemplateLookupSlotsFromIndex(index, linkedRoleTemplateId, linkedRoleTemplateName);
  return slots.map((s) => s.title).filter(Boolean).join('\n');
}

/** Newline-separated titles from **pre-normalized** link rows (builds index once per call). */
export function displayTitlesFromNormalizedLinks(normalizedLinks, linkedRoleTemplateId, linkedRoleTemplateName) {
  const index = buildTemplateLookupIndex(normalizedLinks);
  return displayTitlesFromTemplateIndex(index, linkedRoleTemplateId, linkedRoleTemplateName);
}

/** Newline-separated resolved titles only (legacy / plain display). */
export function displayTitlesFromTemplateLinks(links, linkedRoleTemplateId, linkedRoleTemplateName) {
  return displayTitlesFromNormalizedLinks(asNormalizedLinkRows(links), linkedRoleTemplateId, linkedRoleTemplateName);
}

/** Alias for older imports; identical to {@link displayTitlesFromTemplateLinks}. */
export const rbacTemplateDisplayTitlesFromLinks = displayTitlesFromTemplateLinks;

/** Comma-separated Template Name(s) from Template Links for job-category template IDs (roles need names, not display titles). */
export function templateNamesFromTemplateLinks(links, linkableTemplateId) {
  const normalizedLinks = asNormalizedLinkRows(links);
  const linkable = normalizedLinks.filter(
    (r) => canonicalTemplateLinkRecordType(r) === 'Linkable Template'
  );
  const ids = splitTemplateIdTokens(linkableTemplateId);
  if (!ids.length) return '';
  const names = ids.map((id) => {
    const row = findLinkRowByLinkedTemplateId(linkable, id);
    return row ? resolvedTemplateNameForSlot(row, id, '') : '';
  });
  return names.map((p) => (p == null ? '' : String(p)).trim()).join(', ');
}

function linkRowSubtemplateIdSet(link) {
  if (!link || typeof link !== 'object') return new Set();
  const n = normalizeTemplateLinkRow(link);
  if (!n) return new Set();
  const segs = splitTemplateIdTokens(n.subtemplateId);
  return new Set(segs.map((s) => s.toLowerCase()));
}

function findLinkRowBySubtemplateId(linkable, idToken) {
  if (!idToken) return null;
  const want = idToken.trim().toLowerCase();
  if (!want) return null;
  return (
    linkable.find((l) => {
      const idSet = linkRowSubtemplateIdSet(l);
      return idSet.has(want);
    }) || null
  );
}

function linkRowSubtemplateNameTokens(link) {
  if (!link || typeof link !== 'object') return [];
  const n = normalizeTemplateLinkRow(link);
  if (!n) return [];
  const segs = splitTemplateNameTokens(n.subtemplateName);
  if (segs.length > 0) return segs.map((s) => s.toLowerCase());
  const single = String(n.subtemplateName || '').trim().toLowerCase();
  return single ? [single] : [];
}

function findLinkRowBySubtemplateName(linkable, nameToken) {
  if (!nameToken) return null;
  const want = nameToken.trim().toLowerCase();
  if (!want) return null;
  return (
    linkable.find((l) => {
      const tokens = linkRowSubtemplateNameTokens(l);
      return tokens.includes(want);
    }) || null
  );
}

/**
 * Sync role linked template ID ↔ Template Name(s) from Template Links (Linkable rows only).
 * @param {'id'|'name'} editedField
 */
export function syncRoleLinkedTemplateFromTemplateLinks(links, linkedRoleTemplateId, linkedRoleTemplateName, editedField) {
  const normalizedLinks = asNormalizedLinkRows(links);
  const linkable = normalizedLinks.filter(
    (r) => canonicalTemplateLinkRecordType(r) === 'Linkable Template'
  );
  const idsIn = splitTemplateIdTokens(linkedRoleTemplateId);
  const namesIn = splitTemplateNameTokens(linkedRoleTemplateName);
  if (editedField === 'id' && idsIn.length === 0) {
    return { linkedRoleTemplateId, linkedRoleTemplateName };
  }
  if (editedField === 'name' && namesIn.length === 0) {
    return { linkedRoleTemplateId, linkedRoleTemplateName };
  }
  const slots = editedField === 'id' ? Math.max(idsIn.length, 1) : Math.max(namesIn.length, 1);
  const outIds = [];
  const outNames = [];
  for (let i = 0; i < slots; i++) {
    const id = (idsIn[i] ?? '').trim();
    const name = (namesIn[i] ?? '').trim();
    if (editedField === 'id') {
      if (!id) {
        outIds.push('');
        outNames.push(name);
        continue;
      }
      const row = findLinkRowByLinkedTemplateId(linkable, id);
      outIds.push(id);
      const resolvedName = row ? resolvedTemplateNameForSlot(row, id, '') : '';
      outNames.push(resolvedName || name);
    } else {
      if (!name) {
        outIds.push(id);
        outNames.push('');
        continue;
      }
      const row = findLinkRowByTemplateName(linkable, name);
      const rowIds = splitTemplateIdTokens(row?.templateId);
      const rowNames = splitTemplateNameTokens(row?.templateName);
      let idx = row ? rowNames.findIndex((t) => t.toLowerCase() === name.toLowerCase()) : -1;
      if (idx < 0) idx = 0;
      outNames.push(name);
      const resolvedId = row ? (rowIds[idx] ?? rowIds[0] ?? '') : '';
      outIds.push(resolvedId || id);
    }
  }
  return {
    linkedRoleTemplateId: outIds.filter((x) => x !== '').join('\n'),
    linkedRoleTemplateName: outNames.filter((x) => x !== '').join('\n'),
  };
}

/**
 * Sync linkable template ID ↔ description from Template Links (Linkable rows only).
 * Job category **linkableTemplateName** stores Template Display Title(s); commas separate two templates.
 * @param {'id'|'name'} editedField - Which field the user just edited (blur source)
 */
export function syncJobCategoryLinkableFromTemplateLinks(links, linkableTemplateId, linkableTemplateName, editedField) {
  const normalizedLinks = asNormalizedLinkRows(links);
  const linkable = normalizedLinks.filter(
    (r) => canonicalTemplateLinkRecordType(r) === 'Linkable Template'
  );
  const idsIn = splitTemplateIdTokens(linkableTemplateId);
  const descriptionsIn = splitLinkableTemplateDescriptionSlotsForSync(linkableTemplateName);
  if (editedField === 'id' && idsIn.length === 0) {
    return { linkableTemplateId, linkableTemplateName };
  }
  if (editedField === 'name' && descriptionsIn.length === 0) {
    return { linkableTemplateId, linkableTemplateName };
  }
  const slots =
    editedField === 'id'
      ? Math.max(idsIn.length, descriptionsIn.length, 1)
      : Math.max(descriptionsIn.length, idsIn.length, 1);
  const outIds = [];
  const outDescriptions = [];
  const joinSlots = (parts) =>
    parts.map((p) => (p == null ? '' : String(p)).trim()).join(', ');
  for (let i = 0; i < slots; i++) {
    const id = (idsIn[i] ?? '').trim();
    const description = (descriptionsIn[i] ?? '').trim();
    if (editedField === 'id') {
      if (!id) {
        outIds.push('');
        outDescriptions.push(description);
        continue;
      }
      const row = findLinkRowByLinkedTemplateId(linkable, id);
      outIds.push(id);
      const resolvedDescription = row ? resolvedDisplayTitleForSlot(row, id, '') : '';
      outDescriptions.push(resolvedDescription || description);
    } else {
      if (!description) {
        outIds.push(id);
        outDescriptions.push('');
        continue;
      }
      const row = findLinkRowByTemplateDisplayTitle(linkable, description);
      const rowIds = splitTemplateIdTokens(row?.templateId);
      const rowDescriptions = splitTemplateDisplayTitleSlots(row?.templateDisplayTitle);
      let idx = row
        ? rowDescriptions.findIndex((t) => t.trim().toLowerCase() === description.toLowerCase())
        : -1;
      if (idx < 0) idx = 0;
      outDescriptions.push(description);
      const resolvedId = row ? (rowIds[idx] ?? rowIds[0] ?? '') : '';
      outIds.push(resolvedId || id);
    }
  }
  return {
    linkableTemplateId: joinSlots(outIds),
    linkableTemplateName: joinSlots(outDescriptions),
  };
}

/**
 * Sync subtemplate ID ↔ description on job category from Template Links linkable rows (subtemplate columns).
 */
export function syncJobCategorySubtemplatesFromTemplateLinks(links, subtemplatesId, subtemplatesName, editedField) {
  const normalizedLinks = asNormalizedLinkRows(links);
  const linkable = normalizedLinks.filter(
    (r) => canonicalTemplateLinkRecordType(r) === 'Linkable Template'
  );
  const idsIn = splitTemplateIdTokens(subtemplatesId);
  const namesIn = splitSubtemplateNameSlotsForSync(subtemplatesName);
  if (editedField === 'id' && idsIn.length === 0) {
    return { subtemplatesId, subtemplatesName };
  }
  if (editedField === 'name' && namesIn.length === 0) {
    return { subtemplatesId, subtemplatesName };
  }
  const slots = Math.max(idsIn.length, namesIn.length, 1);
  const outIds = [];
  const outNames = [];
  for (let i = 0; i < slots; i++) {
    const id = (idsIn[i] ?? '').trim();
    const name = (namesIn[i] ?? '').trim();
    if (editedField === 'id') {
      if (!id) {
        outIds.push('');
        outNames.push(name);
        continue;
      }
      const row = findLinkRowBySubtemplateId(linkable, id);
      const rowIds = splitTemplateIdTokens(row?.subtemplateId);
      const rowNames = splitLinkRowSubtemplateNameSlots(row);
      let idx = row ? rowIds.findIndex((t) => t.toLowerCase() === id.toLowerCase()) : -1;
      if (idx < 0) idx = 0;
      outIds.push(id);
      const resolvedName = row ? (rowNames[idx] ?? rowNames[0] ?? '') : '';
      outNames.push(resolvedName || name);
    } else {
      if (!name) {
        outIds.push(id);
        outNames.push('');
        continue;
      }
      const row = findLinkRowBySubtemplateName(linkable, name);
      const rowIds = splitTemplateIdTokens(row?.subtemplateId);
      const rowNames = splitLinkRowSubtemplateNameSlots(row);
      let idx = row ? rowNames.findIndex((t) => t.toLowerCase() === name.toLowerCase()) : -1;
      if (idx < 0) idx = 0;
      outNames.push(name);
      const resolvedId = row ? (rowIds[idx] ?? rowIds[0] ?? '') : '';
      outIds.push(resolvedId || id);
    }
  }
  const joinSlots = (parts) =>
    parts.map((p) => (p == null ? '' : String(p)).trim()).join(', ');
  return {
    subtemplatesId: joinSlots(outIds),
    subtemplatesName: joinSlots(outNames),
  };
}

/**
 * Normalize multi-value template/subtemplate cells: split on newlines/commas/pipes (and optionally spaces for IDs),
 * deduplicate case-insensitively, join with ", " — used for stored values and consistent display (no duplicate segments).
 */
export function dedupeTemplateListTokens(value, splitOnSpaces = true) {
  if (value == null || String(value).trim() === '') return '';
  const regex = splitOnSpaces ? /[\n,|;\s]+/ : /[\n,|;]+/;
  const parts = String(value)
    .split(regex)
    .map((p) => p.trim())
    .filter(Boolean);
  const seen = new Set();
  const unique = [];
  for (const p of parts) {
    const key = p.toUpperCase();
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(p);
  }
  return unique.join(', ');
}

/**
 * Normalize comma-separated subtemplate ID/name cells without dropping empty slots (keeps alignment with paired field).
 */
export function normalizeSubtemplateCommaList(value) {
  if (value == null || String(value).trim() === '') return '';
  return String(value)
    .replace(/\r\n?/g, '\n')
    .split(',')
    .map((s) => s.trim())
    .join(', ');
}

/**
 * Normalize template/subtemplate display text: uppercase and collapse excess spacing
 * while preserving separators (newlines, commas, pipes, semicolons).
 */
export function formatTemplateNameTitleCase(templateName) {
  if (!templateName) return '';
  return String(templateName)
    .split(/([,\n|;]+)/)
    .map((part) => (/^[,\n|;]+$/.test(part) ? part : part.trim().replace(/\s+/g, ' ').toUpperCase()))
    .join('')
    .replace(/\s*([,|;])\s*/g, '$1 ')
    .replace(/[ \t]*\n[ \t]*/g, '\n')
    .trim();
}

/**
 * @deprecated Use {@link formatTemplateNameTitleCase}. Kept as an alias for job category blur / imports.
 */
export function formatJobCategoryTemplateNameUpper(templateName) {
  return formatTemplateNameTitleCase(templateName);
}

/**
 * Apply {@link formatTemplateNameTitleCase} to each comma-separated slot (preserves empty slots).
 * Use for Subtemplate Description (job category subtemplatesName) so it matches Linkable Template Name formatting.
 */
export function formatCommaSeparatedTemplateNamesUpper(value) {
  if (!value || !String(value).trim()) return '';
  return String(value)
    .replace(/\r\n?/g, '\n')
    .split(',')
    .map((segment) => {
      const s = segment.trim();
      return s ? formatTemplateNameTitleCase(s) : '';
    })
    .join(', ');
}
