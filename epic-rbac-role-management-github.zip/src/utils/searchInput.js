/**
 * Strip leading and trailing whitespace (e.g. when loading a saved filter preset).
 * Do not use on every keystroke — that prevents spaces between words while typing.
 * Search UIs should keep raw state and use `.trim()` only when building the match string.
 */
export function normalizeSearchInput(value) {
  if (value == null) return '';
  return String(value).trim();
}
