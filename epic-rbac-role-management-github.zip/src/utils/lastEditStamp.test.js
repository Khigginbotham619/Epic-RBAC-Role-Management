import {
  parseLastEditTimestamp,
  isLastEditOnLocalCalendarDay,
  isBatchStyleLastEdit,
  isRoleBulkEditedToday,
} from './lastEditStamp';

describe('parseLastEditTimestamp', () => {
  it('parses en-US locale stamps used by buildLastEditStamp', () => {
    const d = parseLastEditTimestamp('06/08/2026, 9:12:00 AM - Guerriero, Elysha — Bulk update: Job Category');
    expect(d).not.toBeNull();
    expect(d.getHours()).toBe(9);
    expect(d.getMinutes()).toBe(12);
  });

  it('parses afternoon times from earlier the same day', () => {
    const d = parseLastEditTimestamp('06/08/2026, 8:30:15 AM - user — Synced from Job Category update');
    expect(d).not.toBeNull();
    expect(d.getHours()).toBe(8);
  });
});

describe('isRoleBulkEditedToday', () => {
  it('includes category sync stamps from today', () => {
    const stamp = `${new Date().toLocaleString('en-US', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    })} - testuser — Synced from Job Category update`;
    expect(isRoleBulkEditedToday({ lastEditChangeControlDateReason: stamp })).toBe(true);
  });

  it('includes direct role bulk update stamps from today', () => {
    const stamp = `${new Date().toLocaleString('en-US', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    })} - testuser — Bulk update: Job Category`;
    expect(isRoleBulkEditedToday({ lastEditChangeControlDateReason: stamp })).toBe(true);
  });

  it('excludes single-field inline edits', () => {
    const stamp = `${new Date().toLocaleString('en-US', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    })} - testuser — Edited: Department`;
    expect(isBatchStyleLastEdit(stamp)).toBe(false);
    expect(isRoleBulkEditedToday({ lastEditChangeControlDateReason: stamp })).toBe(false);
  });

  it('recognizes morning and afternoon stamps on the same local day', () => {
    const morning = new Date();
    morning.setHours(8, 15, 0, 0);
    const afternoon = new Date();
    afternoon.setHours(15, 45, 0, 0);
    const fmt = (d) =>
      d.toLocaleString('en-US', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      });
    expect(
      isLastEditOnLocalCalendarDay(`${fmt(morning)} - user — Bulk update: X`)
    ).toBe(true);
    expect(
      isLastEditOnLocalCalendarDay(`${fmt(afternoon)} - user — Bulk update: X`)
    ).toBe(true);
  });
});
