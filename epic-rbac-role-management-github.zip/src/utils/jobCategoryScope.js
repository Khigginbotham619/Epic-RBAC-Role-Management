/**
 * Organization Job Category Scope: free-text on each category.
 * When set to this value, the category is treated as outside org scope (see Job Categories list default filter).
 */
export const JOB_CATEGORY_SCOPE_NOT_IN_ORG = 'Not in Scope for Organization';

/** True when the category should not participate in Sailpoint catalog matching / suggestions. */
export function isJobCategoryExcludedFromOrgScope(categoryLike) {
  return String(categoryLike?.organizationJobCategoryScope ?? '').trim() === JOB_CATEGORY_SCOPE_NOT_IN_ORG;
}
