/** Canonical string form for RBAC role ids (handles numeric vs string from imports). */
export function normalizeRoleId(roleId) {
  return String(roleId ?? '').trim();
}

export function roleIdsEqual(a, b) {
  return normalizeRoleId(a) === normalizeRoleId(b);
}

export function findRoleById(roles, roleId) {
  const want = normalizeRoleId(roleId);
  return (roles || []).find((r) => normalizeRoleId(r.id) === want);
}

export function selectedRowsHasRole(selectedRows, roleId) {
  const want = normalizeRoleId(roleId);
  for (const id of selectedRows || []) {
    if (normalizeRoleId(id) === want) return true;
  }
  return false;
}
