// File-based storage utilities using server-side file storage
const API_BASE_URL = process.env.REACT_APP_API_URL || '/api';

const CURRENT_USER_KEY = 'currentUser';

function getStoredCurrentUserRaw() {
  try {
    return localStorage.getItem(CURRENT_USER_KEY) || sessionStorage.getItem(CURRENT_USER_KEY);
  } catch (_) {
    return null;
  }
}

// Current user for audit trail (from optional login; localStorage or sessionStorage)
export function getCurrentAuditUser() {
  try {
    const stored = getStoredCurrentUserRaw();
    if (!stored) return 'Not set';
    const user = JSON.parse(stored);
    return user?.username || user?.name || 'Not set';
  } catch (_) {
    return 'Not set';
  }
}

// Persist current user; use sessionStorage if localStorage quota exceeded
export function setCurrentUserInStorage(userData) {
  const value = JSON.stringify(userData);
  try {
    localStorage.setItem(CURRENT_USER_KEY, value);
    try {
      sessionStorage.removeItem(CURRENT_USER_KEY);
    } catch (_) {}
  } catch (e) {
    if (e && e.name === 'QuotaExceededError') {
      try {
        sessionStorage.setItem(CURRENT_USER_KEY, value);
      } catch (_) {}
    }
  }
}

export function removeCurrentUserFromStorage() {
  try {
    localStorage.removeItem(CURRENT_USER_KEY);
    sessionStorage.removeItem(CURRENT_USER_KEY);
  } catch (_) {}
}

export function getStoredCurrentUser() {
  try {
    const stored = getStoredCurrentUserRaw();
    if (!stored) return null;
    return JSON.parse(stored);
  } catch (_) {
    return null;
  }
}

// Default request timeout (ms) to avoid indefinite hangs and gateway timeouts
const API_TIMEOUT_MS = 90 * 1000;
// Longer timeout for restore and other bulk operations (10 min)
export const RESTORE_TIMEOUT_MS = 10 * 60 * 1000;

/** Role count from the last successful GET /roles (used to block stale full-array saves). */
let rolesCountAtLastFetch = null;

export function getRolesCountAtLastFetch() {
  return rolesCountAtLastFetch;
}

function setRolesCountAtLastFetch(count) {
  rolesCountAtLastFetch = typeof count === 'number' && count >= 0 ? count : null;
}

// Helper function to make API requests with optional timeout and extra headers
async function apiRequest(endpoint, method = 'GET', body = null, timeoutMs = API_TIMEOUT_MS, extraHeaders = {}) {
  const controller = new AbortController();
  const timeoutId = timeoutMs > 0 ? setTimeout(() => controller.abort(), timeoutMs) : null;
  try {
    const options = {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...extraHeaders,
      },
      signal: controller.signal,
    };
    if (body) {
      options.body = JSON.stringify(body);
    }
    const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
    if (timeoutId) clearTimeout(timeoutId);
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const msg = data?.error || data?.message || `HTTP ${response.status}`;
      throw new Error(msg);
    }
    return data;
  } catch (error) {
    if (timeoutId) clearTimeout(timeoutId);
    if (error.name === 'AbortError') {
      const err = new Error('Request timed out. Try a smaller operation or check the server.');
      err.name = 'AbortError';
      throw err;
    }
    console.error(`Error in API request to ${endpoint}:`, error);
    throw error;
  }
}

// In-memory cache for GET responses to avoid repeated network round-trips (e.g. when switching tabs).
// Invalidated when a mutation (save/append) runs for that resource. TTL 90s so data stays reasonably fresh.
const CACHE_TTL_MS = 3 * 60 * 1000;
const dataCache = new Map(); // key -> { value, ts }

function getCached(key) {
  const entry = dataCache.get(key);
  if (!entry) return undefined;
  if (Date.now() - entry.ts > CACHE_TTL_MS) {
    dataCache.delete(key);
    return undefined;
  }
  return entry.value;
}

function setCached(key, value) {
  dataCache.set(key, { value, ts: Date.now() });
}

function invalidateCache(key) {
  dataCache.delete(key);
}
export { invalidateCache };

export const getRoles = async (options = {}) => {
  if (!options.fresh) {
    const cached = getCached('roles');
    if (cached !== undefined) {
      setRolesCountAtLastFetch(cached.length);
      return cached;
    }
  } else {
    invalidateCache('roles');
  }
  try {
    const endpoint = options.fresh ? '/roles?fresh=true' : '/roles';
    const headers = options.fresh ? { 'X-Fresh-Read': 'true' } : {};
    const data = await apiRequest(endpoint, 'GET', null, API_TIMEOUT_MS, headers);
    const result = Array.isArray(data) ? data : [];
    setCached('roles', result);
    setRolesCountAtLastFetch(result.length);
    return result;
  } catch (error) {
    console.error('Error reading roles:', error);
    if (options.fresh) throw error;
    return [];
  }
};

function saveRolesHeaders(options = {}) {
  const headers = {};
  if (options.force) headers['X-Force-Save'] = 'true';
  if (options.allowShrink) headers['X-Allow-Role-Shrink'] = 'true';
  if (!options.force && rolesCountAtLastFetch != null) {
    headers['X-Expected-Role-Count'] = String(rolesCountAtLastFetch);
  }
  return headers;
}

export const saveRoles = async (roles, options = {}) => {
  const timeoutMs = options.timeoutMs ?? API_TIMEOUT_MS;
  const refresh = options.refreshFromDb !== false;
  try {
    await apiRequest('/roles', 'POST', roles, timeoutMs, saveRolesHeaders(options));
    if (refresh) {
      await getRoles({ fresh: true });
    } else {
      invalidateCache('roles');
    }
    return true;
  } catch (error) {
    console.error('Error saving roles:', error);
    throw error; // Rethrow so caller can show error.message
  }
};

/** Delete roles by id on the server (reads current DB, removes ids, saves). */
export const deleteRoles = async (ids, options = {}) => {
  const timeoutMs = options.timeoutMs ?? API_TIMEOUT_MS;
  const idList = Array.isArray(ids) ? ids.filter((id) => id != null && String(id).trim()) : [];
  if (idList.length === 0) return { deleted: 0 };
  try {
    const data = await apiRequest('/roles/delete', 'POST', { ids: idList }, timeoutMs);
    await getRoles({ fresh: true });
    return data;
  } catch (error) {
    console.error('Error deleting roles:', error);
    throw error;
  }
};

/** Sync every RBAC role from the full job category table (server-side). */
export const syncAllRolesFromCategories = async (options = {}) => {
  const timeoutMs = options.timeoutMs ?? API_TIMEOUT_MS;
  try {
    const data = await apiRequest('/roles/sync-from-categories', 'POST', {}, timeoutMs);
    if ((data?.applied ?? 0) > 0) invalidateCache('roles');
    return data;
  } catch (error) {
    console.error('Error syncing all roles from categories:', error);
    throw error;
  }
};

/** Patch one role by id (server read-merge-write). Prefer over saveRoles for single edits. */
export const patchRole = async (role, options = {}) => mergeRoles([role], options);

/** Merge role updates by id on the server (reads current roles, patches, saves). */
export const mergeRoles = async (updates, options = {}) => {
  const timeoutMs = options.timeoutMs ?? API_TIMEOUT_MS;
  const patches = Array.isArray(updates) ? updates : [];
  if (patches.length === 0) return { applied: 0 };
  try {
    const data = await apiRequest('/roles/merge', 'POST', patches, timeoutMs);
    const fromDb = await getRoles({ fresh: true });
    return { ...data, rolesFromDb: fromDb };
  } catch (error) {
    console.error('Error merging roles:', error);
    throw error;
  }
};

/** Save roles in batch: append or replace. Use for chunked CSV import or restore to avoid timeouts. */
export const saveRolesBatch = async (rolesChunk, replace = false, options = {}) => {
  const timeoutMs = options.timeoutMs ?? API_TIMEOUT_MS;
  const destructiveReplaceConfirmed = !!options.destructiveReplaceConfirmed;
  try {
    await apiRequest(
      '/roles/batch',
      'POST',
      { roles: rolesChunk, replace, destructiveReplaceConfirmed },
      timeoutMs,
      replace ? { 'X-Force-Save': 'true', 'X-Allow-Role-Shrink': 'true' } : {}
    );
    invalidateCache('roles');
    return true;
  } catch (error) {
    console.error('Error saving roles batch:', error);
    throw error;
  }
};

export const getAuditLogs = async () => {
  try {
    const data = await apiRequest('/audit');
    return Array.isArray(data) ? data : [];
  } catch (error) {
    console.error('Error reading audit logs:', error);
    return [];
  }
};

/**
 * Add multiple audit log entries in one API call. Use for bulk imports.
 * @param {Array<{entityType: string, action: string, entityData: object, oldData?: object}>} entries
 */
export const addAuditLogsBatch = async (entries) => {
  if (!Array.isArray(entries) || entries.length === 0) return true;
  try {
    const logs = await getAuditLogs();
    const user = getCurrentAuditUser();
    const baseTime = Date.now();
    for (let i = 0; i < entries.length; i++) {
      const { entityType, action, entityData, oldData = null } = entries[i];
      logs.unshift({
        id: `${baseTime + i}-${Math.random().toString(36).slice(2, 8)}`,
        timestamp: new Date(baseTime + i).toISOString(),
        user,
        action,
        entityType,
        entityId: entityData?.id ?? oldData?.id,
        newData: action !== 'DELETE' ? entityData : null,
        oldData,
      });
    }
    await apiRequest('/audit/replace', 'POST', logs);
    return true;
  } catch (error) {
    console.error('Error adding audit logs batch:', error);
    return false;
  }
};

export const addAuditLog = async (action, roleData, oldData = null) => {
  try {
    const newLog = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      user: getCurrentAuditUser(),
      action: action, // 'CREATE', 'UPDATE', 'DELETE'
      roleId: roleData.id || oldData?.id,
      newData: action !== 'DELETE' ? roleData : null,
      oldData: oldData,
    };
    await apiRequest('/audit', 'POST', newLog);
    return true;
  } catch (error) {
    console.error('Error adding audit log:', error);
    return false;
  }
};

export const generateId = () => {
  return Date.now().toString() + Math.random().toString(36).substr(2, 9);
};

// Job Categories storage functions
export const getJobCategories = async (options = {}) => {
  if (options.fresh) invalidateCache('job-categories');
  const cached = getCached('job-categories');
  if (cached !== undefined) return cached;
  try {
    const data = await apiRequest('/job-categories');
    const result = Array.isArray(data) ? data : [];
    setCached('job-categories', result);
    return result;
  } catch (error) {
    console.error('Error reading job categories:', error);
    if (options.fresh) throw error;
    return [];
  }
};

export const saveJobCategories = async (categories, options = {}) => {
  const timeoutMs = options.timeoutMs ?? API_TIMEOUT_MS;
  try {
    const data = await apiRequest('/job-categories', 'POST', categories, timeoutMs);
    setCached('job-categories', Array.isArray(categories) ? categories : []);
    const rolesUpdated = data?.rolesUpdated ?? 0;
    const rolePropagationError = data?.rolePropagationError ?? null;
    if (rolesUpdated > 0) invalidateCache('roles');
    return { success: true, rolesUpdated, rolePropagationError, ...data };
  } catch (error) {
    console.error('Error saving job categories:', error);
    throw error;
  }
};

export const addJobCategoryAuditLog = async (action, categoryData, oldData = null) => {
  try {
    const logs = await getAuditLogs();
    const newLog = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      user: getCurrentAuditUser(),
      action: action, // 'CREATE', 'UPDATE', 'DELETE'
      entityType: 'JOB_CATEGORY',
      entityId: categoryData.id || oldData?.id,
      newData: action !== 'DELETE' ? categoryData : null,
      oldData: oldData,
    };
    logs.unshift(newLog); // Add to beginning
    await apiRequest('/audit/replace', 'POST', logs);
    return true;
  } catch (error) {
    console.error('Error adding job category audit log:', error);
    return false;
  }
};

// Job Codes storage functions
export const getJobCodes = async () => {
  const cached = getCached('job-codes');
  if (cached !== undefined) return cached;
  try {
    const data = await apiRequest('/job-codes');
    const result = Array.isArray(data) ? data : [];
    setCached('job-codes', result);
    return result;
  } catch (error) {
    console.error('Error reading job codes:', error);
    return [];
  }
};

export const saveJobCodes = async (jobCodes, options = {}) => {
  const timeoutMs = options.timeoutMs ?? API_TIMEOUT_MS;
  try {
    await apiRequest('/job-codes', 'POST', jobCodes, timeoutMs);
    invalidateCache('job-codes');
    return true;
  } catch (error) {
    console.error('Error saving job codes:', error);
    return false;
  }
};

/** Append new job code(s) without removing existing ones (for RBAC edit). Use this when adding a job code from role edit. */
export const appendJobCodes = async (jobCodesToAdd) => {
  try {
    const arr = Array.isArray(jobCodesToAdd) ? jobCodesToAdd : [jobCodesToAdd];
    if (arr.length === 0) return { added: 0 };
    const result = await apiRequest('/job-codes/append', 'POST', arr);
    if (result && result.added > 0) invalidateCache('job-codes');
    return result || { added: 0 };
  } catch (error) {
    console.error('Error appending job codes:', error);
    return { added: 0 };
  }
};

export const addJobCodeAuditLog = async (action, jobCodeData, oldData = null) => {
  try {
    const logs = await getAuditLogs();
    const newLog = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      user: getCurrentAuditUser(),
      action: action,
      entityType: 'JOB_CODE',
      entityId: jobCodeData.id || oldData?.id,
      newData: action !== 'DELETE' ? jobCodeData : null,
      oldData: oldData,
    };
    logs.unshift(newLog);
    await apiRequest('/audit/replace', 'POST', logs);
    return true;
  } catch (error) {
    console.error('Error adding job code audit log:', error);
    return false;
  }
};

// Departments storage functions
export const getDepartments = async () => {
  const cached = getCached('departments');
  if (cached !== undefined) return cached;
  try {
    const data = await apiRequest('/departments');
    const result = Array.isArray(data) ? data : [];
    setCached('departments', result);
    return result;
  } catch (error) {
    console.error('Error reading departments:', error);
    return [];
  }
};

// Sailpoint Roles storage functions
export const getSailpointRoles = async () => {
  const cached = getCached('sailpoint-roles');
  if (cached !== undefined) return cached;
  try {
    const data = await apiRequest('/sailpoint-roles');
    const result = Array.isArray(data) ? data : [];
    setCached('sailpoint-roles', result);
    return result;
  } catch (error) {
    console.error('Error reading sailpoint roles:', error);
    return [];
  }
};

export const saveSailpointRoles = async (sailpointRoles, options = {}) => {
  const timeoutMs = options.timeoutMs ?? API_TIMEOUT_MS;
  try {
    await apiRequest('/sailpoint-roles', 'POST', sailpointRoles, timeoutMs);
    invalidateCache('sailpoint-roles');
    return true;
  } catch (error) {
    console.error('Error saving sailpoint roles:', error);
    return false;
  }
};

export const appendSailpointRoles = async (rolesToAdd) => {
  try {
    const arr = Array.isArray(rolesToAdd) ? rolesToAdd : [rolesToAdd];
    if (arr.length === 0) return { added: 0 };
    const result = await apiRequest('/sailpoint-roles/append', 'POST', arr);
    if (result && result.added > 0) invalidateCache('sailpoint-roles');
    return result || { added: 0 };
  } catch (error) {
    console.error('Error appending sailpoint roles:', error);
    return { added: 0 };
  }
};

export const addSailpointRoleAuditLog = async (action, sailpointRoleData, oldData = null) => {
  try {
    const logs = await getAuditLogs();
    const newLog = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      user: getCurrentAuditUser(),
      action: action,
      entityType: 'SAILPOINT_ROLE',
      entityId: sailpointRoleData.id || oldData?.id,
      newData: action !== 'DELETE' ? sailpointRoleData : null,
      oldData: oldData,
    };
    logs.unshift(newLog);
    await apiRequest('/audit/replace', 'POST', logs);
    return true;
  } catch (error) {
    console.error('Error adding sailpoint role audit log:', error);
    return false;
  }
};

export const saveDepartments = async (departments, options = {}) => {
  const timeoutMs = options.timeoutMs ?? API_TIMEOUT_MS;
  try {
    await apiRequest('/departments', 'POST', departments, timeoutMs);
    invalidateCache('departments');
    return true;
  } catch (error) {
    console.error('Error saving departments:', error);
    return false;
  }
};

/** Append new department(s) without removing existing (e.g. when adding from RBAC/role edit). */
export const appendDepartments = async (departmentsToAdd) => {
  try {
    const arr = Array.isArray(departmentsToAdd) ? departmentsToAdd : [departmentsToAdd];
    if (arr.length === 0) return { added: 0 };
    const result = await apiRequest('/departments/append', 'POST', arr);
    if (result && result.added > 0) invalidateCache('departments');
    return result || { added: 0 };
  } catch (error) {
    console.error('Error appending departments:', error);
    return { added: 0 };
  }
};

export const addDepartmentAuditLog = async (action, departmentData, oldData = null) => {
  try {
    const logs = await getAuditLogs();
    const newLog = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      user: getCurrentAuditUser(),
      action: action,
      entityType: 'DEPARTMENT',
      entityId: departmentData.id || oldData?.id,
      newData: action !== 'DELETE' ? departmentData : null,
      oldData: oldData,
    };
    logs.unshift(newLog);
    await apiRequest('/audit/replace', 'POST', logs);
    return true;
  } catch (error) {
    console.error('Error adding department audit log:', error);
    return false;
  }
};

// Blueprint storage functions
export const getBlueprints = async () => {
  const cached = getCached('blueprints');
  if (cached !== undefined) return cached;
  try {
    const data = await apiRequest('/blueprints');
    const result = Array.isArray(data) ? data : [];
    setCached('blueprints', result);
    return result;
  } catch (error) {
    console.error('Error reading blueprints:', error);
    return [];
  }
};

export const saveBlueprints = async (blueprints, options = {}) => {
  const timeoutMs = options.timeoutMs ?? API_TIMEOUT_MS;
  try {
    await apiRequest('/blueprints', 'POST', blueprints, timeoutMs);
    invalidateCache('blueprints');
    return true;
  } catch (error) {
    console.error('Error saving blueprints:', error);
    return false;
  }
};

/** Append new blueprint(s) without removing existing (e.g. when adding from RBAC/role edit). */
export const appendBlueprints = async (blueprintsToAdd) => {
  try {
    const arr = Array.isArray(blueprintsToAdd) ? blueprintsToAdd : [blueprintsToAdd];
    if (arr.length === 0) return { added: 0 };
    const result = await apiRequest('/blueprints/append', 'POST', arr);
    if (result && result.added > 0) invalidateCache('blueprints');
    return result || { added: 0 };
  } catch (error) {
    console.error('Error appending blueprints:', error);
    return { added: 0 };
  }
};

export const addBlueprintAuditLog = async (action, blueprintData, oldData = null) => {
  try {
    const logs = await getAuditLogs();
    const newLog = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      user: getCurrentAuditUser(),
      action: action,
      entityType: 'BLUEPRINT',
      entityId: blueprintData.id || oldData?.id,
      newData: action !== 'DELETE' ? blueprintData : null,
      oldData: oldData,
    };
    logs.unshift(newLog);
    await apiRequest('/audit/replace', 'POST', logs);
    return true;
  } catch (error) {
    console.error('Error adding blueprint audit log:', error);
    return false;
  }
};

// Template Links storage functions
export const getTemplateLinks = async () => {
  const cached = getCached('template-links');
  if (cached !== undefined) return cached;
  try {
    const data = await apiRequest('/template-links');
    const result = Array.isArray(data) ? data : [];
    setCached('template-links', result);
    return result;
  } catch (error) {
    console.error('Error reading template links:', error);
    return [];
  }
};

export const saveTemplateLinks = async (templateLinks, options = {}) => {
  const timeoutMs = options.timeoutMs ?? API_TIMEOUT_MS;
  try {
    await apiRequest('/template-links', 'POST', templateLinks, timeoutMs);
    invalidateCache('template-links');
    return true;
  } catch (error) {
    console.error('Error saving template links:', error);
    return false;
  }
};

/** Append new template link row(s) without replacing the table (e.g. from role / job category forms). */
export const appendTemplateLinks = async (rowsToAdd) => {
  try {
    const arr = Array.isArray(rowsToAdd) ? rowsToAdd : [rowsToAdd];
    if (arr.length === 0) return { added: 0 };
    const result = await apiRequest('/template-links/append', 'POST', arr);
    if (result && result.added > 0) invalidateCache('template-links');
    return result || { added: 0 };
  } catch (error) {
    console.error('Error appending template links:', error);
    return { added: 0 };
  }
};

export const addTemplateLinkAuditLog = async (action, templateLinkData, oldData = null) => {
  try {
    const logs = await getAuditLogs();
    const newLog = {
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
      user: getCurrentAuditUser(),
      action,
      entityType: 'TEMPLATE_LINK',
      entityId: templateLinkData.id || oldData?.id,
      newData: action !== 'DELETE' ? templateLinkData : null,
      oldData,
    };
    logs.unshift(newLog);
    await apiRequest('/audit/replace', 'POST', logs);
    return true;
  } catch (error) {
    console.error('Error adding template link audit log:', error);
    return false;
  }
};

// Training Tracks storage (reference table for role form dropdown, like job categories)
export const getTrainingTracks = async () => {
  const cached = getCached('training-tracks');
  if (cached !== undefined) return cached;
  try {
    const data = await apiRequest('/training-tracks');
    const result = Array.isArray(data) ? data : [];
    setCached('training-tracks', result);
    return result;
  } catch (error) {
    console.error('Error reading training tracks:', error);
    return [];
  }
};

export const saveTrainingTracks = async (tracks, options = {}) => {
  const timeoutMs = options.timeoutMs ?? API_TIMEOUT_MS;
  try {
    await apiRequest('/training-tracks', 'POST', tracks, timeoutMs);
    invalidateCache('training-tracks');
    return true;
  } catch (error) {
    console.error('Error saving training tracks:', error);
    return false;
  }
};

// SP Export Table storage functions
export const getSPExportTable = async () => {
  const cached = getCached('sp-export-table');
  if (cached !== undefined) return cached;
  try {
    const data = await apiRequest('/sp-export-table');
    const result = Array.isArray(data) ? data : [];
    setCached('sp-export-table', result);
    return result;
  } catch (error) {
    console.error('Error reading SP export table:', error);
    return [];
  }
};

export const saveSPExportTable = async (rows, options = {}) => {
  const timeoutMs = options.timeoutMs ?? API_TIMEOUT_MS;
  try {
    await apiRequest('/sp-export-table', 'POST', rows, timeoutMs);
    invalidateCache('sp-export-table');
    return true;
  } catch (error) {
    console.error('Error saving SP export table:', error);
    return false;
  }
};

/** Append training track row(s) without replacing the whole table (e.g. role / job category forms). */
export const appendTrainingTracks = async (tracksToAdd) => {
  try {
    const arr = Array.isArray(tracksToAdd) ? tracksToAdd : [tracksToAdd];
    if (arr.length === 0) return { added: 0 };
    const result = await apiRequest('/training-tracks/append', 'POST', arr);
    if (result && result.added > 0) invalidateCache('training-tracks');
    return result || { added: 0 };
  } catch (error) {
    console.error('Error appending training tracks:', error);
    return { added: 0 };
  }
};
