import { parseTemplateAndSubtemplate } from './sailpointEntitlementParse';

describe('parseTemplateAndSubtemplate', () => {
  it('parses standard Template ID / Subtemplate ID format', () => {
    const result = parseTemplateAndSubtemplate(
      'Epic SiteB Mosaic Inpatient Music Therapist - Template ID T3041901 / Subtemplate ID STORG034'
    );
    expect(result).toEqual({ template: 'T3041901', subtemplate: 'STORG034' });
  });

  it('parses No Subtemplate', () => {
    const result = parseTemplateAndSubtemplate(
      'Epic Mosaic Physician Builder (Outpatient and Inpatient) - Template ID T1590105 / No Subtemplate ID'
    );
    expect(result).toEqual({ template: 'T1590105', subtemplate: 'No Subtemplate' });
  });

  it('parses hyphenated subtemplate IDs', () => {
    const result = parseTemplateAndSubtemplate(
      'Epic Mosaic Advanced Practice Clinician - Behavioral Health (Inpatient) - Template ID T1590199 / Subtemplate ID T74200-T15400'
    );
    expect(result).toEqual({ template: 'T1590199', subtemplate: 'T74200-T15400' });
  });

  it('parses slash without space before subtemplate section', () => {
    const result = parseTemplateAndSubtemplate(
      'Epic Mosaic Advanced Practice Clinician Behavioral Health (Inpatient) Template ID T2100301/ Subtemplate ID T74200 T15400'
    );
    expect(result).toEqual({ template: 'T2100301', subtemplate: 'T74200 T15400' });
  });

  it('parses glued Template ID value', () => {
    const result = parseTemplateAndSubtemplate(
      'Epic Mosaic SiteA Cell Therapy Nurse Practitioner (NP) - Template IDT2100301 / Subtemplate ID STORG080'
    );
    expect(result).toEqual({ template: 'T2100301', subtemplate: 'STORG080' });
  });

  it('parses -Template / -Subtemplate shorthand', () => {
    const result = parseTemplateAndSubtemplate(
      'Epic Mosaic SiteA Databuilder-Template TORG111-Subtemplate STORG130 add template to PROD,POC and SUP'
    );
    expect(result).toEqual({ template: 'TORG111', subtemplate: 'STORG130' });
  });

  it('parses no template with subtemplate only', () => {
    const result = parseTemplateAndSubtemplate(
      'Epic Mosaic CDI - Physician Advisors - No Template ID / Subtemplate ID STORG019'
    );
    expect(result).toEqual({ template: '', subtemplate: 'STORG019' });
  });

  it('strips trailing notes from subtemplate value', () => {
    const result = parseTemplateAndSubtemplate(
      'Epic Mosaic Audiology Student Extern- Template ID T1590703 / Subtemplate ID Needs blueprint B40099'
    );
    expect(result.template).toBe('T1590703');
    expect(result.subtemplate).toBe('Needs blueprint B40099');
  });
});
