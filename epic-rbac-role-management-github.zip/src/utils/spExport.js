function parseIds(value) {
  if (!value) return [];
  return value
    .toString()
    .split(/[|,;\s]+/)
    .map((v) => v.trim())
    .filter((v) => v && v.toUpperCase() !== 'NA');
}

function formatTemplateTokens(tokens) {
  const arr = (tokens || []).filter(Boolean);
  if (arr.length === 0) return '';
  if (arr.length === 1) return arr[0];
  return arr.join('|');
}

function formatSubtemplateTokens(tokens) {
  const arr = (tokens || []).filter(Boolean);
  if (arr.length === 0) return '';
  if (arr.length === 1) return arr[0];
  return arr.join(',');
}

function norm(value) {
  return value == null ? '' : String(value).trim().toLowerCase();
}

export function roleHasListedTemplate(role, jobCategories = []) {
  if (parseIds(role?.linkedRoleTemplateId).length > 0) return true;
  if (parseIds(role?.subtemplateId).length > 0) return true;
  const jcName = (role?.jobCategory || '').toString().trim();
  if (!jcName) return false;
  const jc = (jobCategories || []).find((c) => {
    const name = (c?.jobCategoryName || '').toString().trim();
    return name && name.toLowerCase() === jcName.toLowerCase();
  });
  if (!jc) return false;
  return parseIds(jc.linkableTemplateId).length > 0 || parseIds(jc.subtemplatesId).length > 0;
}

function hasNoAccessText(value) {
  const s = norm(value);
  if (!s) return false;
  return (
    s.includes('no access') ||
    s.includes('wait for request') ||
    s.includes('manual build in lower environments and dc to prod') ||
    s.includes('admin position wait for it req') ||
    s.includes('build in all env') ||
    s.includes('school teacher (siteb)') ||
    s === 'nurse practitioner - anesthesia' ||
    s.includes('needs follow up- atat says epic admin/anlayst') ||
    s.includes('needs follow up- atat says epic admin/analyst') ||
    s.includes('ms-msha-045305')
  );
}

/**
 * True when the role carries a "No Access" marker in any of the fields the
 * SailPoint export inspects (template name, display title, job category,
 * subtemplate description). Exported so other utilities (e.g. Integrity Fixes)
 * can apply the same rule without duplicating the marker list.
 *
 * Roles with a linked template/subtemplate (on the role or job category) are
 * never classified as No Access — they export their template IDs instead.
 */
export function isNoAccessRbacRole(role, jobCategories = []) {
  if (!role) return false;
  if (roleHasListedTemplate(role, jobCategories)) return false;
  return [
    role.linkedRoleTemplateName,
    role.templateDisplayTitle,
    role.jobCategory,
    role.subtemplateDescription,
  ].some(hasNoAccessText);
}

/**
 * Compute the SailPoint export "Template" column for a single RBAC role.
 * Returns one of:
 *   - "Template|Template,Subtemplate,Subtemplate" (mapped to template/subtemplate IDs)
 *   - "No Access" when a row has a No-Access marker text
 *   - "SHELL" when the role has no template info and no job category template either
 *
 * Exported so other callers (e.g. Find Blanks) can detect SHELL rows without
 * re-implementing the rules.
 */
function buildTemplateColumn(templateIds, subtemplateIds) {
  const templatePart = formatTemplateTokens(templateIds);
  const subtemplatePart = formatSubtemplateTokens(subtemplateIds);
  if (templatePart && subtemplatePart) return `${templatePart},${subtemplatePart}`;
  return templatePart || subtemplatePart || '';
}

function jobCategoryForRole(role, jobCategories) {
  const jobCategoryName = (role?.jobCategory || '').toString().trim();
  if (!jobCategoryName) return null;
  return (Array.isArray(jobCategories) ? jobCategories : []).find((c) => {
    const name = (c?.jobCategoryName || '').toString().trim();
    return name && name.toLowerCase() === jobCategoryName.toLowerCase();
  });
}

function resolveTemplateIdsForRole(role, jobCategories = []) {
  let templates = parseIds(role?.linkedRoleTemplateId);
  let subtemplates = parseIds(role?.subtemplateId);
  const jc = jobCategoryForRole(role, jobCategories);
  if (jc) {
    const catTemplates = parseIds(jc.linkableTemplateId);
    const catSubtemplates = parseIds(jc.subtemplatesId);
    if (templates.length === 0 && catTemplates.length > 0) templates = catTemplates;
    if (subtemplates.length === 0 && catSubtemplates.length > 0) subtemplates = catSubtemplates;
  }
  return { templates, subtemplates };
}

export function computeRbacTemplateColumn(role, jobCategories = []) {
  if (isNoAccessRbacRole(role, jobCategories)) return 'No Access';

  const { templates, subtemplates } = resolveTemplateIdsForRole(role, jobCategories);
  const templateColumn = buildTemplateColumn(templates, subtemplates);
  return templateColumn || 'SHELL';
}

/**
 * True when the role's `jobCategory` column literally is "SHELL" (case-
 * insensitive, trimmed). Some imported rows carry "SHELL" as the job category
 * value to mark placeholder rows that shouldn't be treated as real RBAC rows.
 */
export function isShellJobCategory(value) {
  return norm(value) === 'shell';
}

/**
 * True when the role should be treated as a SHELL RBAC row. Two cases qualify:
 *   1. The role's `jobCategory` column is literally "SHELL".
 *   2. The role has no template, no subtemplate, and no job category mapping
 *      that supplies one (mirrors buildExportForSPRows' SHELL classification).
 *
 * Callers (e.g. Find Blanks) use this to skip placeholder rows entirely.
 */
export function isShellRbacRole(role, jobCategories = []) {
  if (!role) return false;
  if (isShellJobCategory(role.jobCategory)) return true;
  return computeRbacTemplateColumn(role, jobCategories) === 'SHELL';
}

/** Build Export for SP rows using the exact criteria used by CSV export. */
export function buildExportForSPRows(roles, jobCategories = []) {
  const input = Array.isArray(roles) ? roles : [];
  const out = [];
  input.forEach((role) => {
    const templateColumn = computeRbacTemplateColumn(role, jobCategories);

    // RBAC Code
    const rbacCode = role.rbacCode || '';

    // SER Needed - using slaNeeded field
    const serNeeded = role.slaNeeded || '';

    // SER Blueprint ID - just the ID; NA is left blank
    const rawSlaId = (role.slaBlueprintId || '').toString().trim();
    const serBlueprintId = rawSlaId.toUpperCase() === 'NA' ? '' : rawSlaId;

    // Affiliate - only export "yes" or blank
    const affiliate = String(role.affiliate || '').trim().toLowerCase() === 'yes' ? 'yes' : '';

    out.push({
      rbacCode,
      template: templateColumn,
      serNeeded,
      serBlueprintId,
      affiliate,
    });
  });
  return out;
}

// SP Export utility - exports roles in a specific format for SP
export const exportForSP = (roles, jobCategories = []) => {
  if (!roles || roles.length === 0) {
    alert('No data to export');
    return;
  }

  // Headers for SP export
  const headers = ['RBAC Code', 'Template', 'SER Needed', 'SER Blueprint ID', 'Affiliate'];

  // Create CSV content
  let csvContent = headers.join(',') + '\n';

  const exportRows = buildExportForSPRows(roles, jobCategories);

  if (exportRows.length === 0) {
    alert('No rows to export after applying SP exclusions.');
    return;
  }

  exportRows.forEach((row) => {
    const values = [
      row.rbacCode,
      row.template,
      row.serNeeded,
      row.serBlueprintId,
      row.affiliate,
    ];
    // Escape values that contain commas, quotes, or newlines
    const escapedRow = values.map((value) => {
      const strValue = value.toString();
      if (strValue.includes(',') || strValue.includes('"') || strValue.includes('\n')) {
        return `"${strValue.replace(/"/g, '""')}"`;
      }
      return strValue;
    });
    csvContent += escapedRow.join(',') + '\n';
  });

  // Create blob and download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);

  link.setAttribute('href', url);
  link.setAttribute('download', 'rbac_export_for_sp.csv');
  link.style.visibility = 'hidden';

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
