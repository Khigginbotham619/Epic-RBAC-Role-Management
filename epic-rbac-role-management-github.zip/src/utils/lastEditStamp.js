import { getCurrentAuditUser } from './storage';

/** Edit reasons that indicate batch work (bulk update, category sync, find/replace, etc.). */
export const BATCH_STYLE_LAST_EDIT_MARKERS = [
  'bulk update',
  'find & replace',
  'synced from job category update',
  'csv import',
];

/**
 * Parse the locale date/time prefix from a Last Edit stamp (roles or job categories).
 * @returns {Date|null}
 */
export function parseLastEditTimestamp(stamp) {
  const str = String(stamp || '').trim();
  if (!str) return null;
  const datePart = str.includes(' - ') ? str.split(' - ')[0]?.trim() : str;
  if (!datePart) return null;

  const match = datePart.match(
    /^(\d{1,2})\/(\d{1,2})\/(\d{4}),\s*(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)$/i
  );
  if (match) {
    let hour = parseInt(match[4], 10);
    const minute = parseInt(match[5], 10);
    const second = parseInt(match[6] || '0', 10);
    const ampm = match[7].toUpperCase();
    if (ampm === 'PM' && hour < 12) hour += 12;
    if (ampm === 'AM' && hour === 12) hour = 0;
    return new Date(
      parseInt(match[3], 10),
      parseInt(match[1], 10) - 1,
      parseInt(match[2], 10),
      hour,
      minute,
      second
    );
  }

  const d = new Date(datePart);
  return Number.isNaN(d.getTime()) ? null : d;
}

/** True when the parsed stamp falls on the same local calendar day as `when` (default: now). */
export function isLastEditOnLocalCalendarDay(stamp, when = new Date()) {
  const d = typeof stamp === 'string' || stamp == null ? parseLastEditTimestamp(stamp) : stamp;
  if (!d) return false;
  return (
    d.getFullYear() === when.getFullYear() &&
    d.getMonth() === when.getMonth() &&
    d.getDate() === when.getDate()
  );
}

/** True when the stamp detail indicates batch-style editing. */
export function isBatchStyleLastEdit(stamp) {
  const lower = String(stamp || '').trim().toLowerCase();
  return BATCH_STYLE_LAST_EDIT_MARKERS.some((marker) => lower.includes(marker));
}

/** Role last-edit stamp indicates batch work and the timestamp is today (local date). */
export function isRoleBulkEditedToday(role) {
  const stamp = role?.lastEditChangeControlDateReason;
  if (!isBatchStyleLastEdit(stamp)) return false;
  return isLastEditOnLocalCalendarDay(stamp);
}

/**
 * Builds the standard "Last Edit/Change Control Date/Reason" line: date, user, optional detail.
 * @param {string} [detail] - e.g. "New role", "Edited: Department", "Bulk update: Status"
 */
export function buildLastEditStamp(detail) {
  const now = new Date();
  const dateTimeString = now.toLocaleString('en-US', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });
  const user = getCurrentAuditUser();
  const base = `${dateTimeString} - ${user}`;
  const d = detail == null ? '' : String(detail).trim();
  if (!d) return base;
  return `${base} — ${d}`;
}
