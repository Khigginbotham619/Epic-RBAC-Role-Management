import { sanitizeCellText } from './textSanitize';

/** Header aliases — keep in sync with TemplateLinks.js HEADER_ALIASES. */
export const TEMPLATE_LINK_HEADER_ALIASES = {
  userRecordType: ['user record type', 'userrecordtype', 'record type', 'recordtype'],
  templateId: ['template id', 'template ids', 'template id(s)', 'templateid', 'template_id'],
  templateName: ['template name', 'template names', 'template name(s)', 'templatename', 'template_name'],
  primaryTemplateOwner: [
    'primary template owner',
    'primarytemplateowner',
    'primary_template_owner',
    'template primary owner',
    'templateprimaryowner',
    'primary owner',
    'primaryowner',
    'primary template owner(s)',
  ],
  templateDisplayTitle: [
    'template display title',
    'templatedisplaytitle',
    'template_display_title',
    'display title',
    'displaytitle',
    'template display title(s)',
    'template title display',
  ],
  subtemplateId: [
    'sub template id',
    'sub template ids',
    'subtemplate id',
    'subtemplate ids',
    'subtemplate id(s)',
    'subtemplateid',
    'subtemplate_id',
  ],
  subtemplateName: [
    'subtemplate description',
    'subtemplate descriptions',
    'subtemplate desc',
    'subtemplate name',
    'subtemplate names',
    'subtemplate name(s)',
    'subtemplatename',
    'subtemplate_name',
  ],
  currentStatus: [
    'user record status',
    'current status',
    'status',
    'currentstatus',
    'status code',
  ],
};

export function normalizeImportHeaderKey(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/\u00a0/g, ' ')
    .replace(/[^a-z0-9]/g, '');
}

/** Map a CSV/Excel header label to an internal field key (or null). */
export function resolveTemplateLinkImportHeaderKey(header) {
  const nk = normalizeImportHeaderKey(header);
  if (!nk) return null;
  for (const [internalKey, aliases] of Object.entries(TEMPLATE_LINK_HEADER_ALIASES)) {
    if (normalizeImportHeaderKey(internalKey) === nk) return internalKey;
    for (const alias of aliases) {
      if (normalizeImportHeaderKey(alias) === nk) return internalKey;
    }
  }
  return null;
}

function joinCells(parts) {
  return sanitizeCellText(parts.map((p) => (p == null ? '' : String(p))).join(','));
}

/** Decide whether extra CSV cells belong to template name or display title. */
function detectCommaSpill(row, ownerHi, overflow) {
  if (overflow <= 0 || ownerHi < 0) return { nameSpill: 0, displaySpill: 0 };
  const atOwner = String(row[ownerHi] ?? '').trim();
  const shiftedOwner = String(row[ownerHi + overflow] ?? '').trim();
  if (shiftedOwner && /@/.test(shiftedOwner) && !/@/.test(atOwner)) {
    return { nameSpill: overflow, displaySpill: 0 };
  }
  return { nameSpill: 0, displaySpill: overflow };
}

/**
 * Map a parsed CSV cell array onto header labels when unquoted commas created extra
 * columns. Template Name and Template Display Title keep embedded commas; trailing
 * columns stay right-aligned.
 */
export function mapCsvCellsToTemplateLinkRow(cells, headers) {
  const row = Array.isArray(cells) ? cells : [];
  const hdrs = Array.isArray(headers) ? headers : [];
  const keys = hdrs.map((h) => resolveTemplateLinkImportHeaderKey(h));
  const n = hdrs.length;

  if (n === 0) return {};

  if (row.length <= n) {
    const out = {};
    hdrs.forEach((header, idx) => {
      out[header] = sanitizeCellText(row[idx] ?? '');
    });
    return out;
  }

  const overflow = row.length - n;
  const nameHi = keys.indexOf('templateName');
  const ownerHi = keys.indexOf('primaryTemplateOwner');
  const displayHi = keys.indexOf('templateDisplayTitle');
  const subIdHi = keys.indexOf('subtemplateId');
  const { nameSpill, displaySpill } = detectCommaSpill(row, ownerHi, overflow);

  const out = {};
  let ci = 0;

  for (let hi = 0; hi < n; hi++) {
    if (ci >= row.length) {
      out[hdrs[hi]] = '';
      continue;
    }

    if (hi === nameHi && nameHi >= 0) {
      const ownerCellIdx = ownerHi >= 0 ? ownerHi + nameSpill : nameHi + 1;
      const end = Math.min(ownerCellIdx, row.length);
      out[hdrs[hi]] = joinCells(row.slice(ci, end));
      ci = end;
      continue;
    }

    if (hi === displayHi && displayHi >= 0) {
      if (displaySpill > 0) {
        const subCellIdx = subIdHi >= 0 ? subIdHi + displaySpill : displayHi + 1 + displaySpill;
        const end = Math.min(subCellIdx, row.length);
        out[hdrs[hi]] = joinCells(row.slice(ci, end));
        ci = end;
      } else {
        out[hdrs[hi]] = sanitizeCellText(row[ci] ?? '');
        ci += 1;
      }
      continue;
    }

    out[hdrs[hi]] = sanitizeCellText(row[ci] ?? '');
    ci += 1;
  }

  return out;
}

/** Pick aligned slot value; single-value lists repeat across expanded import rows. */
export function pickImportMultiSlot(values, index) {
  const list = Array.isArray(values) ? values : [];
  if (!list.length) return '';
  if (list.length === 1) return list[0];
  return list[index] ?? list[0] ?? '';
}
