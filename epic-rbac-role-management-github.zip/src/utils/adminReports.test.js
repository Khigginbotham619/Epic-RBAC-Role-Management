import {
  reportJobCategorySailpointReconciliation,
  reportJobCategoriesLinkedToNonRequestableSailpoint,
  reportDuplicateSailpointRolesOnJobCategories,
  reportJobCategoriesLinkedToInactiveTemplates,
  reportSailpointRolesAttachedToInactiveTemplates,
  reportRolesConnectedToInactive,
  reportRolesWithOrphanTemplateRefs,
  closestSailpointCandidates,
  scoreSailpointCandidateMatch,
  downloadXlsx,
  SAILPOINT_CANDIDATE_MIN_DISPLAY_SCORE,
  SAILPOINT_CANDIDATE_CONFIDENT_SCORE,
} from './adminReports';
import * as XLSX from 'xlsx';

describe('scoreSailpointCandidateMatch', () => {
  it('flags canonical equivalence (punctuation/spacing)', () => {
    const a = 'Epic Mosaic Clinician Builder - Notecraft';
    const b = 'Epic Mosaic Clinician Builder -Notecraft';
    const r = scoreSailpointCandidateMatch(a, b);
    expect(r.score).toBeGreaterThanOrEqual(0.99);
    expect(r.reasonCodes).toContain('CANON_EQUIV');
  });

  it('includes ordered reason signals for partial matches', () => {
    const r = scoreSailpointCandidateMatch(
      'Epic Mosaic Nurse Practitioner - Orthopaedic (Outpatient)',
      'Epic Mosaic Nurse Practitioner -  Orthopaedic (Outpatient)'
    );
    expect(r).not.toBeNull();
    expect(r.reasonCodes.length).toBeGreaterThan(0);
  });
});

describe('closestSailpointCandidates', () => {
  const catalog = [
    'Epic Mosaic Nurse Practitioner - Orthopaedic (Outpatient)',
    'Epic Mosaic Nurse Practitioner',
    'Epic Mosaic CMO',
  ];

  it('filters very weak matches when stronger ones exist', () => {
    const src = 'Epic Mosaic Nurse Practitioner - Orthopaedic (Outpatient)';
    const out = closestSailpointCandidates(src, catalog, 3);
    expect(out[0].sailpointRole).toContain('Orthopaedic');
    expect(out.every((c) => c.score >= SAILPOINT_CANDIDATE_MIN_DISPLAY_SCORE)).toBe(true);
  });
});

describe('reportJobCategorySailpointReconciliation', () => {
  const baseCat = (overrides) => ({
    id: overrides.id || 'c1',
    jobCategoryId: overrides.jobCategoryId || '1',
    jobCategoryName: overrides.jobCategoryName || 'Test Category',
    status: 'Active',
    organizationJobCategoryScope: 'In Scope',
    sailpointRole: overrides.sailpointRole,
    ...overrides,
  });

  it('does not flag RBAC value that matches catalog after normalization', () => {
    const jobCategories = [
      baseCat({
        id: 'a',
        jobCategoryId: '10',
        sailpointRole: 'Epic Mosaic Nurse Practitioner -  Orthopaedic (Outpatient)',
      }),
    ];
    const sailpoint = [{ sailpointRole: 'Epic Mosaic Nurse Practitioner - Orthopaedic (Outpatient)' }];
    const rep = reportJobCategorySailpointReconciliation(jobCategories, sailpoint);
    expect(rep.rbacNotInSailpoint).toHaveLength(0);
  });

  it('does not flag RBAC value that matches catalog after canonicalization', () => {
    const jobCategories = [
      baseCat({
        id: 'b',
        jobCategoryId: '11',
        sailpointRole: 'Epic Mosaic Clinician Builder -Notecraft',
      }),
    ];
    const sailpoint = [{ sailpointRole: 'Epic Mosaic Clinician Builder - Notecraft' }];
    const rep = reportJobCategorySailpointReconciliation(jobCategories, sailpoint);
    expect(rep.rbacNotInSailpoint).toHaveLength(0);
  });

  it('adds reviewReason and candidate reason codes for real mismatches', () => {
    const jobCategories = [
      baseCat({
        id: 'c',
        jobCategoryId: '99',
        sailpointRole: 'Epic Mosaic Senior Widget Engineer (TypoSuffix)',
      }),
    ];
    const sailpoint = [
      { sailpointRole: 'Epic Mosaic Senior Widget Engineer (Inpatient)' },
      { sailpointRole: 'Epic Mosaic Senior Widget Engineer (Outpatient)' },
    ];
    const rep = reportJobCategorySailpointReconciliation(jobCategories, sailpoint);
    expect(rep.rbacNotInSailpoint.length).toBe(1);
    const row = rep.rbacNotInSailpoint[0];
    expect(row.reviewReason).toBeTruthy();
    expect(row.candidates.length).toBeGreaterThan(0);
    expect(Array.isArray(row.candidates[0].reasonCodes)).toBe(true);
  });

  it('includes requestable on SailPoint roles not referenced in RBAC', () => {
    const jobCategories = [
      baseCat({ id: 'e', jobCategoryId: '20', sailpointRole: 'Epic Mosaic Mapped Role' }),
    ];
    const sailpoint = [
      { sailpointRole: 'Epic Mosaic Mapped Role', requestable: 'TRUE' },
      { sailpointRole: 'Epic Mosaic Unused Role', requestable: 'FALSE' },
    ];
    const rep = reportJobCategorySailpointReconciliation(jobCategories, sailpoint);
    expect(rep.sailpointNotInRbac).toHaveLength(1);
    expect(rep.sailpointNotInRbac[0]).toMatchObject({
      sailpointRole: 'Epic Mosaic Unused Role',
      requestable: 'FALSE',
    });
  });

  it('marks slight_name_variation when top score reaches confidence threshold', () => {
    const jobCategories = [
      baseCat({
        id: 'd',
        jobCategoryId: '12',
        sailpointRole: 'Epic Mosaic Senior Widget Engineer (Inpatient)x',
      }),
    ];
    const sailpoint = [{ sailpointRole: 'Epic Mosaic Senior Widget Engineer (Inpatient)' }];
    const rep = reportJobCategorySailpointReconciliation(jobCategories, sailpoint);
    expect(rep.rbacNotInSailpoint.length).toBe(1);
    const row = rep.rbacNotInSailpoint[0];
    expect(row.candidates[0].score).toBeGreaterThanOrEqual(SAILPOINT_CANDIDATE_CONFIDENT_SCORE);
    expect(row.scenario).toBe('slight_name_variation');
  });
});

describe('reportRolesConnectedToInactive', () => {
  it('aggregates inactive job category, template, job code, and SailPoint hits per role', () => {
    const roles = [
      {
        id: 'r1',
        rbacCode: 'RBAC1',
        status: 'Active',
        jobCategory: 'Old Cat',
        linkedRoleTemplateId: 'T1',
        jobCodeId: '9999',
        sailpointRole: 'Epic Old Role',
      },
    ];
    const jobCategories = [
      { jobCategoryName: 'Old Cat', status: 'Inactive', jobCategoryId: 'C1' },
      {
        jobCategoryName: 'Active Cat',
        status: 'Active',
        organizationJobCategoryScope: 'In Scope for Organization',
        linkableTemplateId: 'T2',
      },
    ];
    const templateLinks = [
      { templateId: 'T1', templateName: 'Alpha', currentStatus: 'Inactive' },
      { templateId: 'T2', templateName: 'Beta', currentStatus: 'Pending', userRecordType: 'Linkable Template' },
    ];
    const jobCodes = [{ jobCode: '9999', currentStatus: 'Inactive' }];
    const sailpoint = [{ sailpointRole: 'Epic Old Role', status: 'Inactive' }];

    const role2 = {
      id: 'r2',
      rbacCode: 'RBAC2',
      status: 'Active',
      jobCategory: 'Active Cat',
      linkedRoleTemplateId: '',
    };
    const out = reportRolesConnectedToInactive(
      [...roles, role2],
      jobCategories,
      templateLinks,
      jobCodes,
      sailpoint
    );

    expect(out).toHaveLength(2);
    const r1 = out.find((x) => x.role.id === 'r1');
    const types = r1.issues.map((i) => i.connectionType).sort();
    expect(types).toEqual(
      ['Job category', 'Job code', 'SailPoint role', 'Template link (on role)'].sort()
    );

    const r2 = out.find((x) => x.role.id === 'r2');
    expect(r2.issues.some((i) => i.connectionType === 'Job category template')).toBe(true);
  });
});

describe('reportJobCategoriesLinkedToNonRequestableSailpoint', () => {
  const cat = (overrides) => ({
    id: overrides.id,
    jobCategoryId: overrides.jobCategoryId,
    jobCategoryName: overrides.jobCategoryName,
    status: overrides.status || 'Active',
    organizationJobCategoryScope:
      overrides.organizationJobCategoryScope || 'In Scope for Organization',
    sailpointRole: overrides.sailpointRole || '',
    linkableTemplateId: overrides.linkableTemplateId || '',
    subtemplatesId: overrides.subtemplatesId || '',
  });

  const sp = (overrides) => ({
    sailpointRole: overrides.sailpointRole,
    status: overrides.status || 'Active',
    requestable: overrides.requestable,
    templates: overrides.templates || '',
    subtemplates: overrides.subtemplates || '',
  });

  it('returns only categories whose Sailpoint role is requestable=FALSE', () => {
    const categories = [
      cat({ id: 'a', jobCategoryId: '1', jobCategoryName: 'NP - Allergy (Inpatient)', sailpointRole: 'Epic Mosaic NP - Allergy (Inpatient)' }),
      cat({ id: 'b', jobCategoryId: '2', jobCategoryName: 'Active Role', sailpointRole: 'Epic Mosaic Active Role' }),
      cat({ id: 'c', jobCategoryId: '3', jobCategoryName: 'Inactive cat', status: 'Inactive', sailpointRole: 'Epic Mosaic NP - Allergy (Inpatient)' }),
      cat({ id: 'd', jobCategoryId: '4', jobCategoryName: 'No Sailpoint', sailpointRole: '' }),
    ];
    const sailpoint = [
      sp({ sailpointRole: 'Epic Mosaic NP - Allergy (Inpatient)', requestable: 'FALSE', templates: 'T2100301' }),
      sp({ sailpointRole: 'Epic Mosaic Active Role', requestable: 'TRUE', templates: 'T1' }),
      sp({ sailpointRole: 'Epic Mosaic Physician - Allergy (Inpatient)', requestable: 'TRUE', templates: 'T2100301' }),
    ];

    const out = reportJobCategoriesLinkedToNonRequestableSailpoint(categories, sailpoint);
    expect(out).toHaveLength(2);
    expect(out.map((r) => r.category.jobCategoryId).sort()).toEqual(['1', '3']);
    expect(out[0].requestable).toBe('FALSE');
  });

  it('includes category status, scope, and RBAC code count', () => {
    const categories = [
      cat({
        id: 'a',
        jobCategoryId: '10',
        jobCategoryName: 'NP - Allergy (Inpatient)',
        status: 'Inactive',
        organizationJobCategoryScope: 'Not in Scope for Organization',
        sailpointRole: 'Epic Mosaic NP - Allergy (Inpatient)',
      }),
    ];
    const sailpoint = [
      sp({ sailpointRole: 'Epic Mosaic NP - Allergy (Inpatient)', requestable: 'FALSE', templates: 'T2100301' }),
    ];
    const roles = [
      { rbacCode: 'RBAC1', jobCategory: 'NP - Allergy (Inpatient)' },
      { rbacCode: 'RBAC2', jobCategory: 'NP - Allergy (Inpatient)' },
      { rbacCode: 'RBAC3', jobCategory: 'Other Category' },
      { jobCategory: 'NP - Allergy (Inpatient)' },
    ];

    const out = reportJobCategoriesLinkedToNonRequestableSailpoint(categories, sailpoint, roles);
    expect(out).toHaveLength(1);
    expect(out[0].categoryStatus).toBe('Inactive');
    expect(out[0].organizationScope).toBe('Not in scope');
    expect(out[0].rbacCodeCount).toBe(2);
  });

  it('suggests an active replacement with shared specialty token', () => {
    const categories = [
      cat({
        id: 'a',
        jobCategoryId: '1',
        jobCategoryName: 'NP - Allergy (Inpatient)',
        sailpointRole: 'Epic Mosaic NP - Allergy (Inpatient)',
        linkableTemplateId: 'T2100301',
      }),
      cat({
        id: 'b',
        jobCategoryId: '2',
        jobCategoryName: 'Physician - Allergy (Inpatient)',
        sailpointRole: 'Epic Mosaic Physician - Allergy (Inpatient)',
        linkableTemplateId: 'T2100301',
      }),
    ];
    const sailpoint = [
      sp({ sailpointRole: 'Epic Mosaic NP - Allergy (Inpatient)', requestable: 'FALSE', templates: 'T2100301' }),
      sp({ sailpointRole: 'Epic Mosaic Physician - Allergy (Inpatient)', requestable: 'TRUE', templates: 'T2100301' }),
      sp({ sailpointRole: 'Epic Mosaic NP - Cardiology (Inpatient)', requestable: 'TRUE', templates: 'T2100301' }),
    ];

    const out = reportJobCategoriesLinkedToNonRequestableSailpoint(categories, sailpoint);
    expect(out).toHaveLength(1);
    expect(out[0].suggestedActiveSailpointRole).toBe(
      'Epic Mosaic Physician - Allergy (Inpatient)'
    );
    expect(out[0].suggestedReassignJobCategory).toBe('Physician - Allergy (Inpatient)');
  });

  it('leaves the suggestion blank when no active role shares the specialty token', () => {
    const categories = [
      cat({
        id: 'a',
        jobCategoryId: '1',
        jobCategoryName: 'Anesthetist',
        sailpointRole: 'Epic Mosaic Anesthetist',
        linkableTemplateId: 'T1120401',
      }),
    ];
    const sailpoint = [
      sp({ sailpointRole: 'Epic Mosaic Anesthetist', requestable: 'FALSE', templates: 'T1120401' }),
      sp({ sailpointRole: 'Epic Mosaic Surgeon', requestable: 'TRUE', templates: 'T1120401' }),
      sp({ sailpointRole: 'Epic Mosaic Nurse', requestable: 'TRUE', templates: 'T1120401' }),
    ];

    const out = reportJobCategoriesLinkedToNonRequestableSailpoint(categories, sailpoint);
    expect(out).toHaveLength(1);
    expect(out[0].suggestedActiveSailpointRole).toBe('');
  });

  it('does not suggest a candidate whose templates differ from the job category', () => {
    const categories = [
      cat({
        id: 'a',
        jobCategoryId: '1',
        jobCategoryName: 'NP - Burn (Inpatient)',
        sailpointRole: 'Epic Mosaic NP - Burn (Inpatient)',
        linkableTemplateId: 'T2100301',
      }),
    ];
    const sailpoint = [
      sp({ sailpointRole: 'Epic Mosaic NP - Burn (Inpatient)', requestable: 'FALSE', templates: 'T2100301' }),
      sp({ sailpointRole: 'Epic Mosaic Physician - Burn (Inpatient)', requestable: 'TRUE', templates: 'T1590199' }),
    ];

    const out = reportJobCategoriesLinkedToNonRequestableSailpoint(categories, sailpoint);
    expect(out).toHaveLength(1);
    expect(out[0].suggestedActiveSailpointRole).toBe('');
  });

  it('does not suggest a candidate whose subtemplates differ from the job category', () => {
    const categories = [
      cat({
        id: 'a',
        jobCategoryId: '1',
        jobCategoryName: 'NP - Bariatric (Inpatient)',
        sailpointRole: 'Epic Mosaic NP - Bariatric (Inpatient)',
        linkableTemplateId: 'T2100301',
        subtemplatesId: 'ST107001',
      }),
    ];
    const sailpoint = [
      sp({
        sailpointRole: 'Epic Mosaic NP - Bariatric (Inpatient)',
        requestable: 'FALSE',
        templates: 'T2100301',
        subtemplates: 'ST107001',
      }),
      sp({
        sailpointRole: 'Epic Mosaic NP - Bariatric Surgery (Inpatient)',
        requestable: 'TRUE',
        templates: 'T2100301',
        subtemplates: 'ST999999',
      }),
    ];

    const out = reportJobCategoriesLinkedToNonRequestableSailpoint(categories, sailpoint);
    expect(out).toHaveLength(1);
    expect(out[0].suggestedActiveSailpointRole).toBe('');
  });

  it('does not suggest a candidate when only one side has a subtemplate', () => {
    const categories = [
      cat({
        id: 'a',
        jobCategoryId: '1',
        jobCategoryName: 'NP - Surgery',
        sailpointRole: 'Epic Mosaic NP - Surgery',
        linkableTemplateId: 'T2100301',
        subtemplatesId: '',
      }),
    ];
    const sailpoint = [
      sp({ sailpointRole: 'Epic Mosaic NP - Surgery', requestable: 'FALSE', templates: 'T2100301' }),
      sp({
        sailpointRole: 'Epic Mosaic NP - Surgery (Inpatient)',
        requestable: 'TRUE',
        templates: 'T2100301',
        subtemplates: 'ST107001',
      }),
    ];

    const out = reportJobCategoriesLinkedToNonRequestableSailpoint(categories, sailpoint);
    expect(out).toHaveLength(1);
    expect(out[0].suggestedActiveSailpointRole).toBe('');
  });

  it('suggests a more-generic candidate when its name is a subset of the source and templates match', () => {
    const categories = [
      cat({
        id: 'a',
        jobCategoryId: '2',
        jobCategoryName: 'Nurse Practitioner - Anesthesia Outpatient/Clinic',
        sailpointRole: 'Epic Mosaic Nurse Practitioner - Anesthesia',
        linkableTemplateId: 'T2100301',
      }),
    ];
    const sailpoint = [
      sp({
        sailpointRole: 'Epic Mosaic Nurse Practitioner - Anesthesia',
        requestable: 'FALSE',
        templates: 'T2100301',
        subtemplates: 'No Subtemplate',
      }),
      sp({
        sailpointRole: 'Epic Mosaic Nurse Practitioner',
        requestable: 'TRUE',
        templates: 'T2100301',
        subtemplates: 'No Subtemplate',
      }),
      sp({
        sailpointRole: 'Epic Mosaic Nurse Practitioner - Cardiology',
        requestable: 'TRUE',
        templates: 'T2100301',
        subtemplates: 'No Subtemplate',
      }),
    ];

    const out = reportJobCategoriesLinkedToNonRequestableSailpoint(categories, sailpoint);
    expect(out).toHaveLength(1);
    expect(out[0].suggestedActiveSailpointRole).toBe('Epic Mosaic Nurse Practitioner');
  });

  it('prefers a specialty-matched candidate over a generic-subset candidate when both qualify', () => {
    const categories = [
      cat({
        id: 'a',
        jobCategoryId: '1',
        jobCategoryName: 'NP - Allergy (Inpatient)',
        sailpointRole: 'Epic Mosaic Nurse Practitioner - Allergy (Inpatient)',
        linkableTemplateId: 'T2100301',
      }),
    ];
    const sailpoint = [
      sp({
        sailpointRole: 'Epic Mosaic Nurse Practitioner - Allergy (Inpatient)',
        requestable: 'FALSE',
        templates: 'T2100301',
      }),
      sp({
        sailpointRole: 'Epic Mosaic Nurse Practitioner',
        requestable: 'TRUE',
        templates: 'T2100301',
      }),
      sp({
        sailpointRole: 'Epic Mosaic Physician - Allergy (Inpatient)',
        requestable: 'TRUE',
        templates: 'T2100301',
      }),
    ];

    const out = reportJobCategoriesLinkedToNonRequestableSailpoint(categories, sailpoint);
    expect(out).toHaveLength(1);
    expect(out[0].suggestedActiveSailpointRole).toBe(
      'Epic Mosaic Physician - Allergy (Inpatient)'
    );
  });

  it('suggests a candidate when both templates and subtemplates match exactly', () => {
    const categories = [
      cat({
        id: 'a',
        jobCategoryId: '1',
        jobCategoryName: 'NP - Behavioral Health (Outpatient)',
        sailpointRole: 'Epic Mosaic NP - Behavioral Health (Outpatient)',
        linkableTemplateId: 'T2100301',
        subtemplatesId: 'T74200 T15400',
      }),
    ];
    const sailpoint = [
      sp({
        sailpointRole: 'Epic Mosaic NP - Behavioral Health (Outpatient)',
        requestable: 'FALSE',
        templates: 'T2100301',
        subtemplates: 'T74200 T15400',
      }),
      sp({
        sailpointRole: 'Epic Mosaic Physician - Behavioral Health (Outpatient)',
        requestable: 'TRUE',
        templates: 'T2100301',
        subtemplates: 'T74200 T15400',
      }),
      sp({
        sailpointRole: 'Epic Mosaic Physician - Behavioral Health (Inpatient)',
        requestable: 'TRUE',
        templates: 'T2100301',
        subtemplates: 'T15400',
      }),
    ];

    const out = reportJobCategoriesLinkedToNonRequestableSailpoint(categories, sailpoint);
    expect(out).toHaveLength(1);
    expect(out[0].suggestedActiveSailpointRole).toBe(
      'Epic Mosaic Physician - Behavioral Health (Outpatient)'
    );
  });

  it('marks templateMatch=Yes when category and Sailpoint templates and subtemplates align', () => {
    const categories = [
      cat({
        id: 'a',
        jobCategoryId: '1',
        jobCategoryName: 'NP - Allergy (Inpatient)',
        sailpointRole: 'Epic Mosaic NP - Allergy (Inpatient)',
        linkableTemplateId: 'T2100301',
        subtemplatesId: 'ST10203',
      }),
      cat({
        id: 'b',
        jobCategoryId: '2',
        jobCategoryName: 'NP - Burn (Inpatient)',
        sailpointRole: 'Epic Mosaic NP - Burn (Inpatient)',
        linkableTemplateId: 'T2100301',
        subtemplatesId: 'ST10203',
      }),
    ];
    const sailpoint = [
      sp({
        sailpointRole: 'Epic Mosaic NP - Allergy (Inpatient)',
        requestable: 'FALSE',
        templates: 'T2100301',
        subtemplates: 'ST10203',
      }),
      sp({
        sailpointRole: 'Epic Mosaic NP - Burn (Inpatient)',
        requestable: 'FALSE',
        templates: 'T2100301',
        subtemplates: 'ST99999',
      }),
    ];

    const out = reportJobCategoriesLinkedToNonRequestableSailpoint(categories, sailpoint);
    const byId = Object.fromEntries(out.map((r) => [r.category.jobCategoryId, r]));
    expect(byId['1'].templateMatch).toBe(true);
    expect(byId['2'].templateMatch).toBe(false);
  });
});

describe('reportDuplicateSailpointRolesOnJobCategories', () => {
  const cat = (overrides) => ({
    id: overrides.id,
    jobCategoryId: overrides.jobCategoryId,
    jobCategoryName: overrides.jobCategoryName,
    status: overrides.status || 'Active',
    organizationJobCategoryScope:
      overrides.organizationJobCategoryScope || 'In Scope for Organization',
    sailpointRole: overrides.sailpointRole || '',
  });

  it('returns groups where the same Sailpoint role is on multiple categories', () => {
    const categories = [
      cat({ id: 'a', jobCategoryId: '1', jobCategoryName: 'NP Allergy', sailpointRole: 'Epic Mosaic NP - Allergy' }),
      cat({ id: 'b', jobCategoryId: '2', jobCategoryName: 'NP Allergy Copy', sailpointRole: 'Epic Mosaic NP - Allergy' }),
      cat({ id: 'c', jobCategoryId: '3', jobCategoryName: 'Unique', sailpointRole: 'Epic Mosaic Unique Role' }),
    ];
    const out = reportDuplicateSailpointRolesOnJobCategories(categories, [
      { sailpointRole: 'Epic Mosaic NP - Allergy', requestable: 'FALSE', status: 'Active' },
    ]);
    expect(out).toHaveLength(1);
    expect(out[0].categoryCount).toBe(2);
    expect(out[0].jobCategoryNames).toContain('NP Allergy');
    expect(out[0].requestable).toBe('FALSE');
  });

  it('groups roles that differ only by spacing or case', () => {
    const categories = [
      cat({ id: 'a', jobCategoryId: '10', jobCategoryName: 'Cat A', sailpointRole: 'Epic Mosaic  Role' }),
      cat({ id: 'b', jobCategoryId: '11', jobCategoryName: 'Cat B', sailpointRole: 'epic mosaic role' }),
    ];
    const out = reportDuplicateSailpointRolesOnJobCategories(categories, []);
    expect(out).toHaveLength(1);
    expect(out[0].categoryCount).toBe(2);
  });

  it('sums RBAC code counts across categories in a group', () => {
    const categories = [
      cat({ id: 'a', jobCategoryId: '1', jobCategoryName: 'Shared A', sailpointRole: 'Epic Shared' }),
      cat({ id: 'b', jobCategoryId: '2', jobCategoryName: 'Shared B', sailpointRole: 'Epic Shared' }),
    ];
    const roles = [
      { rbacCode: 'R1', jobCategory: 'Shared A' },
      { rbacCode: 'R2', jobCategory: 'Shared A' },
      { rbacCode: 'R3', jobCategory: 'Shared B' },
    ];
    const out = reportDuplicateSailpointRolesOnJobCategories(categories, [], roles);
    expect(out[0].rbacCodeCount).toBe(3);
  });
});

describe('reportJobCategoriesLinkedToInactiveTemplates', () => {
  it('returns active in-scope categories linked to non-active template rows', () => {
    const categories = [
      {
        id: 'c1',
        jobCategoryId: '1',
        jobCategoryName: 'Cat One',
        status: 'Active',
        organizationJobCategoryScope: 'In Scope',
        linkableTemplateId: 'T1',
        linkableTemplateName: 'Alpha',
        subtemplatesId: 'ST1',
      },
      {
        id: 'c2',
        jobCategoryId: '2',
        jobCategoryName: 'Cat Two',
        status: 'Active',
        organizationJobCategoryScope: 'In Scope',
        linkableTemplateId: 'T2',
      },
    ];
    const templateLinks = [
      { id: 'tl1', userRecordType: 'Linkable Template', templateId: 'T1', templateName: 'Alpha', currentStatus: 'Inactive' },
      { id: 'tl2', userRecordType: 'Linkable Template', templateId: 'T2', templateName: 'Beta', currentStatus: 'Active' },
      { id: 'tl3', userRecordType: 'Linkable Template', subtemplateId: 'ST1', currentStatus: 'Pending' },
    ];

    const out = reportJobCategoriesLinkedToInactiveTemplates(categories, templateLinks);
    expect(out).toHaveLength(1);
    expect(out[0].category.jobCategoryId).toBe('1');
    const fields = out[0].hits.map((h) => h.field);
    expect(fields).toContain('Linkable Template ID');
  });
});

describe('reportSailpointRolesAttachedToInactiveTemplates', () => {
  it('returns sailpoint rows whose template/subtemplate tokens match non-active template links', () => {
    const sailpointRows = [
      {
        id: 'sp1',
        sailpointRole: 'Epic Mosaic NP - Allergy (Inpatient)',
        status: 'Active',
        requestable: 'TRUE',
        templates: 'T1',
        subtemplates: 'ST1',
      },
      {
        id: 'sp2',
        sailpointRole: 'Epic Mosaic NP - Cardiology (Inpatient)',
        status: 'Active',
        requestable: 'TRUE',
        templates: 'T2',
        subtemplates: '',
      },
    ];
    const templateLinks = [
      { id: 'tl1', userRecordType: 'Linkable Template', templateId: 'T1', currentStatus: 'Inactive' },
      { id: 'tl2', userRecordType: 'Linkable Template', templateId: 'T2', currentStatus: 'Active' },
      { id: 'tl3', userRecordType: 'Linkable Template', subtemplateId: 'ST1', currentStatus: 'Pending' },
    ];

    const out = reportSailpointRolesAttachedToInactiveTemplates(sailpointRows, templateLinks);
    expect(out).toHaveLength(1);
    expect(out[0].sailpointRoleRow.id).toBe('sp1');
    expect(out[0].hits.map((h) => h.field)).toEqual(
      expect.arrayContaining(['Template ID', 'Subtemplate ID'])
    );
  });
});

describe('downloadXlsx', () => {
  const originalCreate = document.createElement;
  const originalCreateObjectUrl = global.URL.createObjectURL;
  const originalRevokeObjectUrl = global.URL.revokeObjectURL;

  beforeEach(() => {
    global.URL.createObjectURL = jest.fn(() => 'blob:mock');
    global.URL.revokeObjectURL = jest.fn();
  });

  afterEach(() => {
    document.createElement = originalCreate;
    global.URL.createObjectURL = originalCreateObjectUrl;
    global.URL.revokeObjectURL = originalRevokeObjectUrl;
  });

  function captureDownloadedBlob() {
    let captured = null;
    const realCreate = document.createElement.bind(document);
    document.createElement = (tag) => {
      const el = realCreate(tag);
      if (tag === 'a') {
        Object.defineProperty(el, 'href', {
          set(v) { /* ignore */ },
          get() { return ''; },
          configurable: true,
        });
        el.click = jest.fn();
      }
      return el;
    };
    const origBlob = global.Blob;
    global.Blob = function (parts, opts) {
      captured = { parts, opts };
      return new origBlob(parts, opts);
    };
    return {
      restore: () => { global.Blob = origBlob; },
      getCaptured: () => captured,
    };
  }

  it('writes both sheets with the given names and rows', async () => {
    const cap = captureDownloadedBlob();
    try {
      await downloadXlsx('test.xlsx', [
        {
          name: 'Report',
          headers: ['a', 'b'],
          rows: [['1', '2'], ['3', '4']],
        },
        {
          name: 'Requestable Sailpoint Roles',
          headers: ['sailpointRole', 'requestable'],
          rows: [['Epic Mosaic A', 'TRUE'], ['Epic Mosaic B', 'TRUE']],
        },
      ]);

      const buf = cap.getCaptured().parts[0];
      const wb = XLSX.read(buf, { type: 'array' });
      expect(wb.SheetNames).toEqual(['Report', 'Requestable Sailpoint Roles']);
      const sheet2 = XLSX.utils.sheet_to_json(wb.Sheets['Requestable Sailpoint Roles']);
      expect(sheet2).toHaveLength(2);
      expect(sheet2[0].sailpointRole).toBe('Epic Mosaic A');
      expect(sheet2[0].requestable).toBe('TRUE');
    } finally {
      cap.restore();
    }
  });

  it('truncates and de-duplicates sheet names to satisfy Excel limits', async () => {
    const cap = captureDownloadedBlob();
    try {
      const longName = 'A very long sheet name that exceeds the Excel 31 character limit';
      await downloadXlsx('test.xlsx', [
        { name: longName, headers: ['x'], rows: [['1']] },
        { name: longName, headers: ['x'], rows: [['2']] },
      ]);
      const wb = XLSX.read(cap.getCaptured().parts[0], { type: 'array' });
      expect(wb.SheetNames).toHaveLength(2);
      for (const n of wb.SheetNames) {
        expect(n.length).toBeLessThanOrEqual(31);
      }
      expect(wb.SheetNames[0]).not.toEqual(wb.SheetNames[1]);
    } finally {
      cap.restore();
    }
  });
});

describe('reportRolesWithOrphanTemplateRefs', () => {
  it('does not flag template name when the paired template ID exists in Template Links', () => {
    const links = [
      {
        templateId: 'T2100301',
        templateName: 'IP/OP ADVANCED PRACTICE PROVIDER (NP/PA) TEMPLATE',
        userRecordType: 'Linkable Template',
      },
    ];
    const roles = [
      {
        id: 'r1',
        rbacCode: 'WA-WALT-043140',
        jobCategory: 'Advanced Practice Clinician - Behavioral Health (Outpatient and Inpatient)',
        linkedRoleTemplateId: 'T2100301',
        linkedRoleTemplateName: 'IP/OP ADVANCED PRACTICE PROVIDER (NP/PA) TEMPLATE',
      },
    ];
    expect(reportRolesWithOrphanTemplateRefs(roles, links)).toEqual([]);
  });

  it('still flags template name when neither name nor paired ID is in Template Links', () => {
    const out = reportRolesWithOrphanTemplateRefs(
      [
        {
          id: 'r1',
          linkedRoleTemplateId: '',
          linkedRoleTemplateName: 'Missing Name',
        },
      ],
      [],
    );
    expect(out).toHaveLength(1);
    expect(out[0].orphans[0].field).toBe('Linked Role Template Name');
  });
});
