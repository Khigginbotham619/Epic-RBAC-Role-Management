/**
 * Reference-table blank sweeper.
 *
 * Mirrors the Find Blanks tab (which scans RBAC roles) for the reference
 * tables that feed it: Job Codes, Departments, Blueprints, SailPoint Roles,
 * and Template Links. Unlike Find Blanks for RBAC, we don't propose values —
 * the data sources required to derive these fields don't exist. Instead this
 * utility surfaces *which* rows of each reference table have blank required
 * fields so the admin can hop to the source-of-truth tab and fix them.
 *
 * All helpers are pure.
 */

function s(v) {
  return v == null ? '' : String(v).trim();
}

/** Returns true when value is blank (null, undefined, '', or whitespace-only). */
export function isBlank(v) {
  return s(v) === '';
}

/**
 * Propose a fill value for `templateDisplayTitle` on a Template Links row.
 * Order of preference:
 *   1. `subtemplateName` (labeled "Subtemplate Description" in the UI)
 *   2. `templateName`
 * Returns null when nothing usable is available.
 */
function proposeTemplateDisplayTitle(row) {
  const subDesc = s(row?.subtemplateName);
  if (subDesc) return subDesc;
  const tname = s(row?.templateName);
  if (tname) return tname;
  return null;
}

/**
 * The set of reference tables we scan. Each entry lists:
 *   - key          stable identifier used by the UI
 *   - label        human label rendered in the UI
 *   - idLabel      label for the "row id" column
 *   - idField      which field on each row is the natural key (rbac-facing id)
 *   - requiredFields  Array<{ field, label }>  fields that should not be blank
 *
 * status / currentStatus are intentionally not "required" since blank == Active
 * by convention in this codebase.
 */
export const REFERENCE_TABLE_DEFS = [
  {
    key: 'jobCodes',
    label: 'Job Codes',
    idLabel: 'Job Code',
    idField: 'jobCode',
    requiredFields: [{ field: 'jobTitle', label: 'Job Title' }],
  },
  {
    key: 'departments',
    label: 'Departments',
    idLabel: 'Dept ID',
    idField: 'deptId',
    requiredFields: [{ field: 'deptDescription', label: 'Dept Description' }],
  },
  {
    key: 'blueprints',
    label: 'Blueprints',
    idLabel: 'Blueprint ID',
    idField: 'blueprintId',
    requiredFields: [{ field: 'blueprintName', label: 'Blueprint Name' }],
  },
  {
    key: 'sailpointRoles',
    label: 'Sailpoint Roles',
    idLabel: 'SailPoint Role',
    idField: 'sailpointRole',
    requiredFields: [
      { field: 'templates', label: 'Templates' },
      { field: 'requestable', label: 'Requestable' },
      { field: 'status', label: 'Status' },
    ],
  },
  {
    key: 'templateLinks',
    label: 'Template Links',
    idLabel: 'Template ID',
    idField: 'templateId',
    requiredFields: [
      { field: 'templateName', label: 'Template Name' },
      {
        field: 'templateDisplayTitle',
        label: 'Template Display Title',
        proposeFill: proposeTemplateDisplayTitle,
        proposeFillSource: 'subtemplateName, then templateName',
      },
    ],
  },
];

/**
 * Find rows with at least one blank required field. Rows whose natural key
 * (idField) is itself blank are excluded - they're already broken in ways
 * this utility can't help with, and including them clutters the output.
 *
 * Each blank carries a `proposedFill` when the field's def declares a
 * `proposeFill(row)` helper and that helper returns a non-empty value.
 *
 * @returns {Array<{
 *   id: string,            row.id  (or fallback)
 *   keyValue: string,      row[idField]
 *   blanks: Array<{
 *     field: string,
 *     label: string,
 *     proposedFill: string | null,
 *     proposeFillSource: string | null,
 *   }>,
 *   row: object,
 * }>}
 */
export function findBlankRowsForTable(rows, def) {
  const out = [];
  for (const row of rows || []) {
    if (!row) continue;
    if (isBlank(row[def.idField])) continue;
    const blanks = [];
    for (const rf of def.requiredFields) {
      if (!isBlank(row[rf.field])) continue;
      const proposal = typeof rf.proposeFill === 'function' ? s(rf.proposeFill(row)) : '';
      blanks.push({
        field: rf.field,
        label: rf.label,
        proposedFill: proposal || null,
        proposeFillSource: rf.proposeFillSource || null,
      });
    }
    if (blanks.length === 0) continue;
    out.push({
      id: row.id || row[def.idField] || '',
      keyValue: s(row[def.idField]),
      blanks,
      row,
    });
  }
  out.sort((a, b) => a.keyValue.localeCompare(b.keyValue));
  return out;
}

/**
 * Apply the proposed fills for a table to a fresh rows array. The caller is
 * responsible for persisting the result and emitting audit entries.
 *
 * Only proposals that exist (`proposedFill` non-empty) are applied. By default
 * every available proposal is applied; pass `selectedRowFieldKeys` to limit
 * to a subset (set of strings `"${row.id}|${field}"`).
 *
 * @param {Array}  rows                  original table rows
 * @param {Array}  blanks                output of findBlankRowsForTable(rows, def)
 * @param {Set<string>} [selected]      optional subset of "id|field" keys
 * @returns {{
 *   updatedRows: Array,
 *   oldByRowId: Map<string, object>,
 *   changedRowIds: Set<string>,
 *   appliedCount: number,
 * }}
 */
export function applyReferenceTableFills(rows, blanks, selected) {
  const oldByRowId = new Map();
  const changedRowIds = new Set();
  let appliedCount = 0;

  const patchesByRowId = new Map();
  for (const entry of blanks || []) {
    if (!entry || !entry.row) continue;
    const rowId = entry.row.id;
    if (!rowId) continue;
    for (const b of entry.blanks) {
      if (!b.proposedFill) continue;
      const key = `${rowId}|${b.field}`;
      if (selected && !selected.has(key)) continue;
      if (!patchesByRowId.has(rowId)) patchesByRowId.set(rowId, {});
      patchesByRowId.get(rowId)[b.field] = b.proposedFill;
      appliedCount += 1;
    }
  }

  if (patchesByRowId.size === 0) {
    return { updatedRows: rows || [], oldByRowId, changedRowIds, appliedCount: 0 };
  }

  const updatedRows = (rows || []).map((row) => {
    if (!row || !row.id) return row;
    const patch = patchesByRowId.get(row.id);
    if (!patch) return row;
    oldByRowId.set(row.id, row);
    changedRowIds.add(row.id);
    return { ...row, ...patch };
  });

  return { updatedRows, oldByRowId, changedRowIds, appliedCount };
}

/**
 * Run findBlankRowsForTable across all reference tables. Tables with no
 * blanks are still represented (with empty arrays) so the UI can render
 * "no blanks" sections.
 *
 * @param {object} tables  { jobCodes, departments, blueprints, sailpointRoles, templateLinks }
 * @returns {Array<{ def, blanks }>}
 */
export function findReferenceTableBlanks(tables) {
  const t = tables || {};
  return REFERENCE_TABLE_DEFS.map((def) => ({
    def,
    blanks: findBlankRowsForTable(t[def.key] || [], def),
  }));
}
