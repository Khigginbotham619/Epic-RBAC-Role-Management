import { useCallback, useEffect, useRef, useState } from 'react';

function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

/**
 * Persisted column resizing helper.
 * - Stores widths in localStorage under `storageKey`
 * - Provides `startResize(colKey, mouseDownEvent, currentWidth, minWidth?, maxWidth?)`
 */
export function useResizableColumns(storageKey) {
  const [widths, setWidths] = useState(() => {
    try {
      const raw = localStorage.getItem(storageKey);
      const parsed = raw ? JSON.parse(raw) : {};
      return parsed && typeof parsed === 'object' ? parsed : {};
    } catch (_) {
      return {};
    }
  });

  const widthsRef = useRef(widths);
  useEffect(() => {
    widthsRef.current = widths;
  }, [widths]);

  const persist = useCallback(() => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(widthsRef.current || {}));
    } catch (_) {
      // ignore quota / blocked storage
    }
  }, [storageKey]);

  const getWidth = useCallback((colKey, fallbackPx) => {
    const v = widthsRef.current?.[colKey];
    const n = typeof v === 'number' ? v : Number(v);
    return Number.isFinite(n) && n > 0 ? n : fallbackPx;
  }, []);

  const startResize = useCallback(
    (colKey, e, currentWidth, minWidth = 80, maxWidth = 900) => {
      if (!colKey || !e) return;
      e.preventDefault();
      e.stopPropagation();

      const startX = e.clientX;
      const startW = Number(currentWidth) || 150;

      const onMove = (ev) => {
        const delta = ev.clientX - startX;
        const next = clamp(startW + delta, minWidth, maxWidth);
        setWidths((prev) => {
          const updated = { ...(prev || {}), [colKey]: next };
          widthsRef.current = updated;
          return updated;
        });
      };

      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
        persist();
      };

      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    },
    [persist]
  );

  return { widths, setWidths, getWidth, startResize };
}

