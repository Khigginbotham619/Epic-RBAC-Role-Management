/**
 * Detect server deploys (build id change) and refresh in-memory data so stale
 * browser tabs cannot overwrite production after a code promotion.
 */

const BUILD_ID_KEY = 'rbac_server_build_id';

let lastKnownBuildId = null;

export function getStoredBuildId() {
  try {
    return sessionStorage.getItem(BUILD_ID_KEY);
  } catch (_) {
    return null;
  }
}

function storeBuildId(buildId) {
  try {
    if (buildId) sessionStorage.setItem(BUILD_ID_KEY, buildId);
  } catch (_) {
    // noop
  }
}

/** Fetch /api/health buildId. Returns null when unavailable. */
export async function fetchServerBuildId() {
  try {
    const res = await fetch('/api/health');
    if (!res.ok) return null;
    const data = await res.json().catch(() => ({}));
    return data?.buildId ?? null;
  } catch (_) {
    return null;
  }
}

/**
 * @param {{ onBuildChanged?: () => void }} [options]
 * @returns {boolean} true when build id changed since last check
 */
export async function checkServerBuildChanged(options = {}) {
  const buildId = await fetchServerBuildId();
  if (!buildId) return false;

  const stored = getStoredBuildId();
  if (stored && stored !== buildId) {
    lastKnownBuildId = buildId;
    storeBuildId(buildId);
    options.onBuildChanged?.();
    return true;
  }

  if (!stored) {
    lastKnownBuildId = buildId;
    storeBuildId(buildId);
  } else {
    lastKnownBuildId = buildId;
  }
  return false;
}

/** Call on mount to record initial build without triggering refresh. */
export async function initServerBuildId() {
  const buildId = await fetchServerBuildId();
  if (buildId) {
    lastKnownBuildId = buildId;
    storeBuildId(buildId);
  }
}

export function subscribeBuildRefresh(onBuildChanged) {
  if (typeof window === 'undefined' || typeof document === 'undefined') return () => {};

  const runCheck = () => {
    if (document.visibilityState === 'visible') {
      checkServerBuildChanged({ onBuildChanged });
    }
  };

  window.addEventListener('focus', runCheck);
  document.addEventListener('visibilitychange', runCheck);
  return () => {
    window.removeEventListener('focus', runCheck);
    document.removeEventListener('visibilitychange', runCheck);
  };
}
