import { applyCategoryUpdatesToRole } from './fillBlanks';
import { normalizeRoleId } from './roleIdUtils';

/**
 * Helpers + a pure planner for reassigning RBAC roles when a Job Category is
 * inactivated. The planner does not mutate inputs and does not call storage;
 * callers persist the returned roles array + emit audit logs.
 */

const STATUS_INACTIVE = 'Inactive';

function s(v) {
  return v == null ? '' : String(v).trim();
}

function equalsCi(a, b) {
  return s(a).toLowerCase() === s(b).toLowerCase();
}

/** True when role.status is anything other than "Inactive" (blank counts as Active). */
export function isActiveRole(role) {
  if (!role) return false;
  return s(role.status || 'Active') !== STATUS_INACTIVE;
}

/** True when role.jobCategory (case-insensitive) matches categoryName. */
export function isRoleAssignedToCategory(role, categoryName) {
  if (!role) return false;
  return equalsCi(role.jobCategory, categoryName);
}

/** Active roles whose Job Category equals categoryName (case-insensitive). */
export function findActiveRolesAssignedToCategory(roles, categoryName) {
  if (!s(categoryName)) return [];
  return (roles || []).filter((r) => r && isActiveRole(r) && isRoleAssignedToCategory(r, categoryName));
}

/** All roles (active + inactive) whose Job Category equals categoryName. */
export function findRolesAssignedToCategory(roles, categoryName) {
  if (!s(categoryName)) return [];
  return (roles || []).filter((r) => r && isRoleAssignedToCategory(r, categoryName));
}

/**
 * Build an updated roles array where every role assigned to fromCategoryName
 * (filtered by includeInactive) is reassigned to toCategory and resynced via
 * applyCategoryUpdatesToRole.
 *
 * @param {object} args
 * @param {Array}  args.roles                 All roles.
 * @param {string} args.fromCategoryName      Source category name (the one being inactivated).
 * @param {object} args.toCategory            Target category object (must have jobCategoryName).
 * @param {Array}  [args.blueprints]          For blueprint name lookup.
 * @param {Array}  [args.templateLinks]       For template display title rebuild.
 * @param {string} [args.editStamp]           If provided, written to lastEditChangeControlDateReason.
 * @param {boolean}[args.includeInactive]     Reassign inactive roles too (default false).
 * @returns {{ updatedRoles: Array, affectedRoleIds: Set<string>, oldByRoleId: Map<string, object> }}
 */
export function buildRoleReassignmentPlan({
  roles,
  fromCategoryName,
  toCategory,
  blueprints = [],
  templateLinks = [],
  editStamp = '',
  includeInactive = false,
}) {
  const affectedRoleIds = new Set();
  const oldByRoleId = new Map();
  const fromName = s(fromCategoryName);
  const toName = s(toCategory && toCategory.jobCategoryName);
  if (!fromName || !toName) {
    return { updatedRoles: roles || [], affectedRoleIds, oldByRoleId };
  }
  if (equalsCi(fromName, toName)) {
    return { updatedRoles: roles || [], affectedRoleIds, oldByRoleId };
  }
  const fromLc = fromName.toLowerCase();
  const updatedRoles = (roles || []).map((role) => {
    if (!role || s(role.jobCategory).toLowerCase() !== fromLc) return role;
    if (!includeInactive && !isActiveRole(role)) return role;
    const old = { ...role };
    let next = { ...role, jobCategory: toName };
    next = applyCategoryUpdatesToRole(next, toCategory, blueprints || [], templateLinks || []);
    if (editStamp) next = { ...next, lastEditChangeControlDateReason: editStamp };
    const roleId = normalizeRoleId(role.id);
    affectedRoleIds.add(roleId);
    oldByRoleId.set(roleId, old);
    return next;
  });
  return { updatedRoles, affectedRoleIds, oldByRoleId };
}

const TRAINING_TRACK_FIELDS = [
  'trainingTrack1',
  'trainingTrack2',
  'trainingTrack3',
  'trainingTrack4',
  'trainingTrack5',
  'trainingTrack6',
];

/** Tokenize a comma/space/semicolon-delimited template-id string into a normalized lowercase set. */
function tokenizeIdSet(value) {
  return new Set(
    String(value || '')
      .split(/[\s,;/|]+/)
      .map((t) => t.trim().toLowerCase())
      .filter(Boolean),
  );
}

function setsEqual(a, b) {
  if (a.size !== b.size) return false;
  for (const t of a) if (!b.has(t)) return false;
  return true;
}

function setsIntersection(a, b) {
  const out = new Set();
  for (const t of a) if (b.has(t)) out.add(t);
  return out;
}

/** Collect distinct, trimmed, non-empty training track values from a category (case-preserving). */
function trainingTrackList(category) {
  const seen = new Set();
  const out = [];
  for (const f of TRAINING_TRACK_FIELDS) {
    const v = s(category && category[f]);
    if (!v) continue;
    const lc = v.toLowerCase();
    if (seen.has(lc)) continue;
    seen.add(lc);
    out.push(v);
  }
  return out;
}

/**
 * Score a single candidate category against the source. Returns
 * { score, reasons, signals } where:
 *   - score   - numeric (higher is better)
 *   - reasons - short human strings explaining why it matched
 *   - signals - { templateMatch, subtemplateMatch, sharedTrainingTracks }
 *
 * Scoring weights (chosen so a candidate sharing only training tracks can't
 * outrank a candidate sharing the template):
 *   3.0  template id set equal (after trim/case)
 *   2.5  subtemplate id set equal (or both empty when template matches)
 *   0.6  per shared training track value (case-insensitive)
 *   0.25 same owning workgroup
 *   0.15 same owning application
 *   0.10 same Need EMP / Need SER policy pair
 */
export function scoreReplacementCategory(sourceCategory, candidate) {
  const reasons = [];
  const signals = {
    templateMatch: false,
    subtemplateMatch: false,
    sharedTrainingTracks: [],
  };
  if (!sourceCategory || !candidate) return { score: 0, reasons, signals };

  const srcTpl = tokenizeIdSet(sourceCategory.linkableTemplateId);
  const candTpl = tokenizeIdSet(candidate.linkableTemplateId);
  const srcSub = tokenizeIdSet(sourceCategory.subtemplatesId);
  const candSub = tokenizeIdSet(candidate.subtemplatesId);
  let score = 0;

  if (srcTpl.size > 0 && setsEqual(srcTpl, candTpl)) {
    score += 3.0;
    signals.templateMatch = true;
    reasons.push(`Template ${[...srcTpl].join(' ')} matches`);
  } else if (srcTpl.size > 0 && candTpl.size > 0) {
    const inter = setsIntersection(srcTpl, candTpl);
    if (inter.size > 0) {
      score += 1.0 * inter.size;
      reasons.push(
        `${inter.size} template id${inter.size === 1 ? '' : 's'} in common (${[...inter].join(' ')})`,
      );
    }
  }

  if (setsEqual(srcSub, candSub)) {
    if (srcSub.size > 0) {
      score += 2.5;
      signals.subtemplateMatch = true;
      reasons.push(`Subtemplate ${[...srcSub].join(' ')} matches`);
    } else if (signals.templateMatch) {
      score += 0.5;
      signals.subtemplateMatch = true;
      reasons.push('Both have no subtemplate');
    }
  } else if (srcSub.size > 0 && candSub.size > 0) {
    const inter = setsIntersection(srcSub, candSub);
    if (inter.size > 0) {
      score += 0.75 * inter.size;
      reasons.push(
        `${inter.size} subtemplate id${inter.size === 1 ? '' : 's'} in common (${[...inter].join(' ')})`,
      );
    }
  }

  const srcTracks = trainingTrackList(sourceCategory);
  const candTracksLc = new Set(trainingTrackList(candidate).map((t) => t.toLowerCase()));
  const sharedTracks = srcTracks.filter((t) => candTracksLc.has(t.toLowerCase()));
  if (sharedTracks.length > 0) {
    score += 0.6 * sharedTracks.length;
    signals.sharedTrainingTracks = sharedTracks;
    reasons.push(
      `${sharedTracks.length} training track${sharedTracks.length === 1 ? '' : 's'} in common (${sharedTracks.join(', ')})`,
    );
  }

  if (equalsCi(candidate.owningWorkgroup, sourceCategory.owningWorkgroup) && s(sourceCategory.owningWorkgroup)) {
    score += 0.25;
    reasons.push(`Owning workgroup matches (${s(sourceCategory.owningWorkgroup)})`);
  }
  if (equalsCi(candidate.owningApplication, sourceCategory.owningApplication) && s(sourceCategory.owningApplication)) {
    score += 0.15;
    reasons.push(`Owning application matches (${s(sourceCategory.owningApplication)})`);
  }
  if (
    equalsCi(candidate.needEMP, sourceCategory.needEMP) &&
    equalsCi(candidate.needSER, sourceCategory.needSER) &&
    (s(sourceCategory.needEMP) || s(sourceCategory.needSER))
  ) {
    score += 0.1;
  }

  return { score, reasons, signals };
}

/**
 * True when the scoring result shares at least one of the three "primary"
 * signals the suggestion UI advertises: template match, subtemplate match,
 * or at least one shared training track. Bare ownership / EMP-SER overlap
 * is not enough on its own to count as a real replacement.
 */
function hasPrimaryReplacementSignal(scored) {
  if (!scored || !scored.signals) return false;
  const { templateMatch, subtemplateMatch, sharedTrainingTracks } = scored.signals;
  return Boolean(templateMatch || subtemplateMatch || (sharedTrainingTracks && sharedTrainingTracks.length > 0));
}

/**
 * Rank active in-scope candidate categories by how well they match the source
 * category's template, subtemplate, training tracks, and ownership. Returns
 * an array of `{ category, score, reasons, signals }` ordered by score desc.
 *
 * By default only candidates that share at least one of the primary signals
 * (template, subtemplate, or a training track) are returned, so the caller
 * only renders suggestions when a real replacement was found. Pass
 * `requirePrimarySignal: false` to include weaker ownership-only matches.
 *
 * @param {object} sourceCategory   Category being replaced.
 * @param {Array}  candidateCategories Pool to score (typically all categories).
 * @param {{ limit?: number, minScore?: number, requirePrimarySignal?: boolean }} [options]
 */
export function rankReplacementCategories(sourceCategory, candidateCategories, options = {}) {
  if (!sourceCategory) return [];
  const minScore = options.minScore ?? 0.01;
  const requirePrimarySignal = options.requirePrimarySignal !== false;
  const limit = options.limit ?? Infinity;
  const sourceName = s(sourceCategory.jobCategoryName).toLowerCase();
  const ranked = [];
  for (const c of candidateCategories || []) {
    if (!c) continue;
    if (s(c.status || 'Active') === STATUS_INACTIVE) continue;
    if (s(c.jobCategoryName).toLowerCase() === sourceName) continue;
    const r = scoreReplacementCategory(sourceCategory, c);
    if (r.score < minScore) continue;
    if (requirePrimarySignal && !hasPrimaryReplacementSignal(r)) continue;
    ranked.push({ category: c, score: r.score, reasons: r.reasons, signals: r.signals });
  }
  ranked.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    return s(a.category.jobCategoryName).localeCompare(s(b.category.jobCategoryName));
  });
  return Number.isFinite(limit) ? ranked.slice(0, limit) : ranked;
}

/**
 * Pick a single default replacement category for a category being inactivated.
 * Now a thin wrapper around rankReplacementCategories - returns the best
 * candidate or null when nothing scores above the threshold.
 */
export function suggestReplacementCategory(sourceCategory, candidateCategories) {
  const ranked = rankReplacementCategories(sourceCategory, candidateCategories, { limit: 1 });
  return ranked.length > 0 ? ranked[0].category : null;
}
