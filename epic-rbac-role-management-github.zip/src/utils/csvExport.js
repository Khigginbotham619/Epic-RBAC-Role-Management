// CSV export utility
export const exportToCSV = (data, filename = 'export.csv', customHeaders = null) => {
  if (!data || data.length === 0) {
    alert('No data to export');
    return;
  }

  // If custom headers provided, use them; otherwise auto-detect from first row
  let headers;
  if (customHeaders) {
    headers = customHeaders;
  } else {
    // Auto-detect headers from first data row (exclude 'id' field)
    headers = Object.keys(data[0]).filter(key => key !== 'id');
  }
  
  // Create CSV content
  let csvContent = headers.join(',') + '\n';
  
  data.forEach((row) => {
    const values = headers.map((header) => {
      const value = row[header] || '';
      // Escape commas and quotes in values
      if (value.toString().includes(',') || value.toString().includes('"') || value.toString().includes('\n')) {
        return `"${value.toString().replace(/"/g, '""')}"`;
      }
      return value;
    });
    csvContent += values.join(',') + '\n';
  });

  // Create blob and download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
