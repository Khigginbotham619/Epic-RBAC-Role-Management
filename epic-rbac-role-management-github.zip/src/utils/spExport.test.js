import {
  computeRbacTemplateColumn,
  isShellRbacRole,
  isShellJobCategory,
  isNoAccessRbacRole,
  buildExportForSPRows,
} from './spExport';

describe('computeRbacTemplateColumn', () => {
  it('uses role linkedRoleTemplateId when present', () => {
    expect(
      computeRbacTemplateColumn({ linkedRoleTemplateId: 'T2100301', subtemplateId: '' })
    ).toBe('T2100301');
  });

  it('joins templates with | and subtemplates with comma', () => {
    expect(
      computeRbacTemplateColumn({
        linkedRoleTemplateId: 'T1 T2',
        subtemplateId: 'ST1,ST2',
      })
    ).toBe('T1|T2,ST1,ST2');
  });

  it('falls back to job category template when role has none', () => {
    const role = { jobCategory: 'Burn Medicine NP' };
    const cats = [{ jobCategoryName: 'Burn Medicine NP', linkableTemplateId: 'T2100301' }];
    expect(computeRbacTemplateColumn(role, cats)).toBe('T2100301');
  });

  it('fills templates from job category when role only has subtemplates', () => {
    const role = { jobCategory: 'Burn Medicine NP', subtemplateId: 'ST1' };
    const cats = [
      {
        jobCategoryName: 'Burn Medicine NP',
        linkableTemplateId: 'T2100301',
        subtemplatesId: 'ST1',
      },
    ];
    expect(computeRbacTemplateColumn(role, cats)).toBe('T2100301,ST1');
  });

  it('formats job category templates and subtemplates separately', () => {
    const role = { jobCategory: 'Nurse Ambulatory' };
    const cats = [
      {
        jobCategoryName: 'Nurse Ambulatory',
        linkableTemplateId: 'T1 T2',
        subtemplatesId: 'ST1,ST2',
      },
    ];
    expect(computeRbacTemplateColumn(role, cats)).toBe('T1|T2,ST1,ST2');
  });

  it('returns "No Access" when the role has a no-access marker', () => {
    expect(
      computeRbacTemplateColumn({ linkedRoleTemplateName: 'No Access Role' })
    ).toBe('No Access');
  });

  it('returns "SHELL" when nothing maps to a template', () => {
    expect(computeRbacTemplateColumn({})).toBe('SHELL');
    expect(
      computeRbacTemplateColumn({ linkedRoleTemplateId: 'NA', subtemplateId: 'NA' })
    ).toBe('SHELL');
    expect(
      computeRbacTemplateColumn(
        { jobCategory: 'Missing Category' },
        [{ jobCategoryName: 'Other', linkableTemplateId: 'T1' }]
      )
    ).toBe('SHELL');
  });
});

describe('isShellJobCategory', () => {
  it('matches the literal SHELL value (case-insensitive, trimmed)', () => {
    expect(isShellJobCategory('SHELL')).toBe(true);
    expect(isShellJobCategory(' shell ')).toBe(true);
    expect(isShellJobCategory('Shell')).toBe(true);
  });

  it('does not match other values', () => {
    expect(isShellJobCategory('')).toBe(false);
    expect(isShellJobCategory(null)).toBe(false);
    expect(isShellJobCategory('SHELL Holder')).toBe(false);
    expect(isShellJobCategory('Burn Medicine NP')).toBe(false);
  });
});

describe('isShellRbacRole', () => {
  it('flags a role with no template, no subtemplate, no mapped job category', () => {
    expect(isShellRbacRole({ rbacCode: 'AAA' })).toBe(true);
  });

  it('flags a role whose jobCategory column is literally "SHELL"', () => {
    expect(isShellRbacRole({ jobCategory: 'SHELL' })).toBe(true);
    expect(isShellRbacRole({ jobCategory: 'shell' })).toBe(true);
    expect(isShellRbacRole({ jobCategory: ' SHELL ' })).toBe(true);
  });

  it('flags jobCategory="SHELL" even when the role has a template id', () => {
    expect(
      isShellRbacRole({ jobCategory: 'SHELL', linkedRoleTemplateId: 'T1' })
    ).toBe(true);
  });

  it('is false when the role has a linked template id', () => {
    expect(isShellRbacRole({ linkedRoleTemplateId: 'T1' })).toBe(false);
  });

  it('is false when the role inherits a template from its job category', () => {
    expect(
      isShellRbacRole(
        { jobCategory: 'NP - Burn' },
        [{ jobCategoryName: 'NP - Burn', linkableTemplateId: 'T2100301' }]
      )
    ).toBe(false);
  });

  it('is false for No-Access rows', () => {
    expect(isShellRbacRole({ linkedRoleTemplateName: 'No Access' })).toBe(false);
  });
});

describe('isNoAccessRbacRole', () => {
  it('flags rows with No-Access markers in any inspected field', () => {
    expect(isNoAccessRbacRole({ linkedRoleTemplateName: 'No Access' })).toBe(true);
    expect(isNoAccessRbacRole({ templateDisplayTitle: 'No Access Role' })).toBe(true);
    expect(isNoAccessRbacRole({ jobCategory: 'Wait for request' })).toBe(true);
    expect(
      isNoAccessRbacRole({ subtemplateDescription: 'Manual build in lower environments and DC to prod' }),
    ).toBe(true);
    expect(isNoAccessRbacRole({ jobCategory: 'Nurse Practitioner - Anesthesia' })).toBe(true);
  });

  it('does not treat real anesthesia inpatient/outpatient categories as No Access', () => {
    expect(
      isNoAccessRbacRole({
        rbacCode: 'CS-ANES-023140',
        jobCategory: 'Nurse Practitioner - Anesthesia Inpatient',
        linkedRoleTemplateId: 'T2100301',
        empNeeded: 'Yes',
      }),
    ).toBe(false);
    expect(isNoAccessRbacRole({ jobCategory: 'Nurse Practitioner - Anesthesia Outpatient/Clinic' })).toBe(
      false
    );
  });

  it('does not treat Sr Director - Revenue Cycle as No Access when a template is listed', () => {
    expect(
      isNoAccessRbacRole(
        {
          jobCategory: 'Sr Director - Revenue Cycle',
          linkedRoleTemplateId: 'T2100301',
        },
        [{ jobCategoryName: 'Sr Director - Revenue Cycle', linkableTemplateId: 'T2100301' }],
      ),
    ).toBe(false);
    expect(
      computeRbacTemplateColumn(
        { jobCategory: 'Sr Director - Revenue Cycle', linkedRoleTemplateId: 'T2100301' },
        [{ jobCategoryName: 'Sr Director - Revenue Cycle', linkableTemplateId: 'T2100301' }],
      ),
    ).toBe('T2100301');
  });

  it('does not treat revenue cycle job category alone as No Access', () => {
    expect(isNoAccessRbacRole({ jobCategory: 'Sr Director - Revenue Cycle' })).toBe(false);
  });

  it('is false for normal rows', () => {
    expect(isNoAccessRbacRole({ linkedRoleTemplateId: 'T1', jobCategory: 'NP - Burn' })).toBe(false);
    expect(isNoAccessRbacRole({})).toBe(false);
    expect(isNoAccessRbacRole(null)).toBe(false);
  });
});

describe('buildExportForSPRows', () => {
  it('still emits SHELL for unmapped roles after refactor', () => {
    const rows = buildExportForSPRows([
      { rbacCode: 'A', linkedRoleTemplateId: 'T1' },
      { rbacCode: 'B' },
    ]);
    expect(rows).toEqual([
      { rbacCode: 'A', template: 'T1', serNeeded: '', serBlueprintId: '', affiliate: '' },
      { rbacCode: 'B', template: 'SHELL', serNeeded: '', serBlueprintId: '', affiliate: '' },
    ]);
  });
});
