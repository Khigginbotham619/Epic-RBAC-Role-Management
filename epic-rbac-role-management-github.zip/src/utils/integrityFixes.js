import {
  splitTemplateNameTokens,
  splitTemplateDisplayTitleSlots,
  normalizeTemplateLinkRow,
  canonicalTemplateLinkRecordType,
} from './templateLinkRoleMatch';
import { isNoAccessRbacRole, isShellJobCategory, isShellRbacRole, roleHasListedTemplate } from './spExport';
import {
  applyCategoryUpdatesToRole,
  categoryHasBlueprint,
  categoryHasBlueprintReference,
} from './fillBlanks';
import { blueprintNameForId, buildBlueprintIndex, blueprintExistsInTable, resolveBlueprintReplacement } from './referenceTableAppend';

/**
 * Integrity fixers for RBAC roles.
 *
 * Each detector returns proposals describing a single field-level cleanup
 * (e.g. replace orphan blueprint from the Blueprints table, strip an orphan template token). The
 * applier rebuilds the role from a list of selected proposals and produces
 * an audit batch.
 *
 * Designed to be paired with a UI that previews proposals as checkboxes and
 * applies the user's selection in one batch save. Pure - never mutates input
 * and never calls storage.
 *
 * Multiple templates (and parallel name slots) use comma separation on roles and
 * job categories — not spaces. A single template name may still contain commas
 * when only one template ID is present.
 */

function s(v) {
  return v == null ? '' : String(v).trim();
}

/** Roles and job categories with status Inactive are excluded from integrity scanning. */
export function isActiveIntegrityRecord(record) {
  return s(record?.status || 'Active') !== 'Inactive';
}

/** Job categories skipped by integrity scanning (case-insensitive exact name). */
export const INTEGRITY_EXCLUDED_JOB_CATEGORY_NAMES = [
  'SHELL',
  'EMP SHELL ONLY',
  'unknown-wait for role request',
  'Wait for role req',
];

function normalizeIntegrityJobCategoryName(value) {
  return s(value).toLowerCase().replace(/\s+/g, ' ');
}

const INTEGRITY_EXCLUDED_JOB_CATEGORY_KEYS = new Set(
  INTEGRITY_EXCLUDED_JOB_CATEGORY_NAMES.map(normalizeIntegrityJobCategoryName)
);

/** True when the job category name is excluded from integrity fixes. */
export function isExcludedIntegrityJobCategory(value) {
  const key = normalizeIntegrityJobCategoryName(value);
  if (!key) return false;
  if (INTEGRITY_EXCLUDED_JOB_CATEGORY_KEYS.has(key)) return true;
  return isShellJobCategory(value);
}

/** Active, non-placeholder job categories used for integrity scans and reference data. */
export function isEligibleIntegrityJobCategory(category) {
  return (
    !!category &&
    isActiveIntegrityRecord(category) &&
    !isExcludedIntegrityJobCategory(category?.jobCategoryName)
  );
}

/** True when the role's job category is active, or no matching category row exists. */
function roleIsOnEligibleIntegrityJobCategory(role, jobCategories) {
  const key = s(role?.jobCategory).toLowerCase();
  if (!key) return true;
  const matches = (jobCategories || []).filter(
    (c) => s(c?.jobCategoryName).toLowerCase() === key
  );
  if (!matches.length) return true;
  return matches.some(isEligibleIntegrityJobCategory);
}

/** Human-readable RBAC field labels for Integrity Fixes UI. */
export const INTEGRITY_FIELD_LABELS = {
  slaNeeded: 'SER Needed',
  slaBlueprintId: 'SER Blueprint ID',
  blueprintName: 'Blueprint Name',
  empNeeded: 'EMP Needed',
  needEMP: 'Need EMP?',
  needSER: 'Need SER?',
  linkedRoleTemplateId: 'Linked Role Template ID',
  linkedRoleTemplateName: 'Linked Role Template Name',
  linkableTemplateId: 'Linkable Template ID',
  linkableTemplateName: 'Template Description',
  subtemplateId: 'Subtemplate ID',
  subtemplatesId: 'Subtemplate ID',
  subtemplatesName: 'Subtemplate Description',
  blueprintId: 'Blueprint ID',
  sailpointRole: 'SailPoint Role',
  templateDisplayTitle: 'Template Display Title',
  subtemplateDescription: 'Subtemplate Description',
};

const ROLE_CATEGORY_DERIVED_FIELDS = [
  'linkedRoleTemplateId',
  'linkedRoleTemplateName',
  'templateDisplayTitle',
  'subtemplateId',
  'subtemplateDescription',
  'empNeeded',
  'slaNeeded',
  'slaBlueprintId',
  'blueprintName',
  'trainingTrack',
  'trainingTrack2',
  'trainingTrack3',
  'trainingTrack4',
  'trainingTrack5',
  'trainingTrack6',
  'sailpointRole',
];

function countRolesForCategory(rolesOrCountMap, categoryName) {
  const key = s(categoryName).toLowerCase();
  if (!key) return 0;
  if (rolesOrCountMap instanceof Map) return rolesOrCountMap.get(key) || 0;
  return (rolesOrCountMap || []).filter((r) => s(r?.jobCategory).toLowerCase() === key).length;
}

function buildRoleCountByCategory(roles) {
  const counts = new Map();
  for (const role of roles || []) {
    const key = s(role?.jobCategory).toLowerCase();
    if (!key) continue;
    counts.set(key, (counts.get(key) || 0) + 1);
  }
  return counts;
}

function buildCategoryDerivedFieldsCache(categories, blueprints, templateLinks) {
  const cache = new Map();
  for (const category of categories || []) {
    if (!isEligibleIntegrityJobCategory(category)) continue;
    const name = s(category.jobCategoryName);
    if (!name) continue;
    const dummyRole = { jobCategory: name };
    const synced = applyCategoryUpdatesToRole(dummyRole, category, blueprints, templateLinks);
    const fields = {};
    for (const field of ROLE_CATEGORY_DERIVED_FIELDS) {
      fields[field] = synced[field] ?? '';
    }
    cache.set(name.toLowerCase(), fields);
  }
  return cache;
}

function blueprintIdsMatch(a, b) {
  const left = s(a).toUpperCase();
  const right = s(b).toUpperCase();
  return !!left && left === right;
}

function categoryAsIntegrityRole(category) {
  return {
    jobCategory: category?.jobCategoryName,
    linkedRoleTemplateId: category?.linkableTemplateId,
    linkedRoleTemplateName: category?.linkableTemplateName,
    templateDisplayTitle: category?.linkableTemplateName,
    subtemplateId: category?.subtemplatesId,
    subtemplateDescription: category?.subtemplatesName,
    empNeeded: category?.needEMP,
  };
}

function roleTemplatesMatchCategory(role, category) {
  if (!category) return false;
  return (
    s(role?.linkedRoleTemplateId) === s(category.linkableTemplateId) &&
    s(role?.linkedRoleTemplateName) === s(category.linkableTemplateName) &&
    s(role?.subtemplateId) === s(category.subtemplatesId) &&
    s(role?.subtemplateDescription) === s(category.subtemplatesName)
  );
}

function buildCategoryByName(categories, { integrityEligibleOnly = false } = {}) {
  const catByName = new Map();
  for (const c of categories || []) {
    if (!c) continue;
    if (integrityEligibleOnly && !isEligibleIntegrityJobCategory(c)) continue;
    const name = s(c.jobCategoryName).toLowerCase();
    if (name) catByName.set(name, c);
  }
  return catByName;
}

function quoteVal(value) {
  const t = s(value);
  return t ? `"${t}"` : '(blank)';
}

function fieldLabel(fieldKey) {
  return INTEGRITY_FIELD_LABELS[fieldKey] || fieldKey;
}

function buildProposal({ id, code, role, summary, details, before, after, level = 'role' }) {
  const detailList = Array.isArray(details) ? details.filter(Boolean) : [];
  return {
    id,
    code,
    level,
    roleId: role.id,
    rbacCode: s(role.rbacCode),
    jobTitle: s(role.jobTitle),
    jobCategory: s(role.jobCategory),
    summary,
    details: detailList,
    description: [summary, ...detailList].join(' '),
    before,
    after,
  };
}

function buildCategoryProposal({
  id,
  code,
  category,
  summary,
  details,
  before,
  after,
  affectedRoleCount = 0,
}) {
  const detailList = Array.isArray(details) ? details.filter(Boolean) : [];
  return {
    id,
    code,
    level: 'category',
    categoryId: category.id,
    jobCategoryId: s(category.jobCategoryId),
    jobCategory: s(category.jobCategoryName),
    rbacCode: '',
    jobTitle: '',
    affectedRoleCount,
    summary,
    details: detailList,
    description: [summary, ...detailList].join(' '),
    before,
    after,
  };
}

/** Multiple template/subtemplate IDs: comma-separated (also | ; or newline). */
export function splitIntegrityMultiTemplateIds(value) {
  if (value == null || !String(value).trim()) return [];
  return String(value)
    .replace(/\r\n?/g, '\n')
    .split(/[\n,|;]+/)
    .map((t) => t.trim())
    .filter(Boolean);
}

/**
 * Parallel template name slots aligned to comma-separated template IDs.
 * When there is only one ID slot, commas stay inside the name
 * (e.g. "Cadence, Behavioral Health Front Desk Template").
 */
export function splitIntegrityMultiTemplateNames(value, templateIdSlotCount) {
  const single = s(value);
  if (!single) return [];
  const idSlots = Math.max(1, templateIdSlotCount || 0);
  if (idSlots <= 1) return splitTemplateNameTokens(single);
  if (!single.includes(',')) return splitTemplateNameTokens(single);
  return String(single)
    .replace(/\r\n?/g, '\n')
    .split(/[\n,|;]+/)
    .map((t) => t.trim())
    .filter(Boolean);
}

function pickFields(role, fields) {
  const out = {};
  for (const f of fields) out[f] = role ? role[f] : undefined;
  return out;
}

function fieldValueChanged(before, after) {
  return s(before).toLowerCase() !== s(after).toLowerCase();
}

function roleDerivedFieldsDiffer(a, b) {
  for (const field of ROLE_CATEGORY_DERIVED_FIELDS) {
    if (fieldValueChanged(a?.[field], b?.[field])) return true;
  }
  return false;
}

function buildTemplateLinkIndex(templateLinks) {
  const idToRows = new Map();
  const nameToRows = new Map();
  const linkableSubIdToRows = new Map();
  for (const raw of templateLinks || []) {
    const row = normalizeTemplateLinkRow(raw);
    const kind = canonicalTemplateLinkRecordType(row);
    const rowTemplateIds = splitIntegrityMultiTemplateIds(row.templateId);
    for (const id of rowTemplateIds) {
      const k = id.toLowerCase();
      if (!idToRows.has(k)) idToRows.set(k, []);
      idToRows.get(k).push(row);
    }
    for (const nm of splitIntegrityMultiTemplateNames(row.templateName, rowTemplateIds.length)) {
      const k = nm.toLowerCase();
      if (!nameToRows.has(k)) nameToRows.set(k, []);
      nameToRows.get(k).push(row);
    }
    if (kind === 'Linkable Template') {
      const rowSubIds = splitIntegrityMultiTemplateIds(row.subtemplateId);
      for (const sid of rowSubIds) {
        const k = sid.toLowerCase();
        if (!linkableSubIdToRows.has(k)) linkableSubIdToRows.set(k, []);
        linkableSubIdToRows.get(k).push(row);
      }
    }
  }
  return { idToRows, nameToRows, linkableSubIdToRows };
}

/**
 * Roles with a blueprint on file: set SER Needed to Yes when listed in the
 * Blueprints table, or replace the ID from the table by name when it is orphaned.
 */
export function detectRoleBlueprintFromTable(roles, blueprints = []) {
  const bpIndex = blueprints instanceof Map ? blueprints : buildBlueprintIndex(blueprints);
  const out = [];
  for (const role of roles || []) {
    if (!role) continue;
    if (!isActiveIntegrityRecord(role)) continue;
    const bpId = s(role.slaBlueprintId);
    const bpName = s(role.blueprintName);
    if (!bpId && !bpName) continue;

    if (bpId && blueprintExistsInTable(bpIndex, bpId)) {
      const tableName = blueprintNameForId(bpIndex, bpId, bpName);
      if (s(role.slaNeeded).toLowerCase() === 'yes' && s(role.blueprintName).toLowerCase() === tableName.toLowerCase()) {
        continue;
      }
      out.push(
        buildProposal({
          id: `role-ser-with-bp:${role.id}`,
          code: 'role-ser-when-blueprint',
          role,
          summary: 'This role has a blueprint listed in the Blueprints table, so SER Needed should be Yes.',
          details: [
            s(role.slaNeeded).toLowerCase() !== 'yes'
              ? `Set SER Needed to Yes (was ${quoteVal(role.slaNeeded) || '(blank)'}).`
              : `Keep blueprint ${quoteVal(bpId)} from the Blueprints reference table.`,
            tableName && s(role.blueprintName).toLowerCase() !== tableName.toLowerCase()
              ? `Set Blueprint Name to ${quoteVal(tableName)}.`
              : null,
          ].filter(Boolean),
          before: pickFields(role, ['slaNeeded', 'slaBlueprintId', 'blueprintName']),
          after: { slaNeeded: 'Yes', slaBlueprintId: bpId, blueprintName: tableName },
        })
      );
      continue;
    }

    const replacement = resolveBlueprintReplacement(bpIndex, bpId, bpName);
    if (!replacement) continue;
    const replaceSummary = bpId
      ? `Replace blueprint ${quoteVal(bpId)} with ${quoteVal(replacement.blueprintId)} from the Blueprints table.`
      : `Set SER Blueprint ID to ${quoteVal(replacement.blueprintId)} from the Blueprints table (matched by blueprint name).`;
    out.push(
      buildProposal({
        id: `role-bp-replace:${role.id}`,
        code: 'role-blueprint-replace',
        role,
        summary: replaceSummary,
        details: [
          bpId
            ? `Change SER Blueprint ID from ${quoteVal(bpId)} to ${quoteVal(replacement.blueprintId)}.`
            : `Set SER Blueprint ID to ${quoteVal(replacement.blueprintId)}.`,
          replacement.blueprintName
            ? `Set Blueprint Name to ${quoteVal(replacement.blueprintName)}.`
            : null,
          `Set SER Needed to Yes.`,
        ].filter(Boolean),
        before: pickFields(role, ['slaNeeded', 'slaBlueprintId', 'blueprintName']),
        after: {
          slaNeeded: 'Yes',
          slaBlueprintId: replacement.blueprintId,
          blueprintName: replacement.blueprintName,
        },
      })
    );
  }
  return out;
}

/**
 * @deprecated Use detectRoleBlueprintFromTable — only clears blueprints not in the Blueprints table.
 */
export function detectBlueprintWithoutSer(roles, blueprints = []) {
  return detectRoleBlueprintFromTable(roles, blueprints);
}

/**
 * Job categories with a blueprint ID listed in the Blueprints table but Need SER? is not Yes.
 */
export function detectCategorySerWhenBlueprint(categories, rolesOrCountMap = [], blueprints = []) {
  const bpIndex = blueprints instanceof Map ? blueprints : buildBlueprintIndex(blueprints);
  const out = [];
  for (const category of categories || []) {
    if (!isEligibleIntegrityJobCategory(category)) continue;
    if (!categoryHasBlueprint(category, bpIndex)) continue;
    const current = s(category.needSER);
    if (current.toLowerCase() === 'yes') continue;
    out.push(
      buildCategoryProposal({
        id: `cat-ser-with-bp:${category.id}`,
        code: 'category-ser-when-blueprint',
        category,
        affectedRoleCount: countRolesForCategory(rolesOrCountMap, category.jobCategoryName),
        summary: 'This job category has a blueprint in the Blueprints table, so Need SER? should be Yes.',
        details: [
          current
            ? `Set Need SER? to Yes (was ${quoteVal(current)}).`
            : 'Set Need SER? to Yes because a blueprint is defined on this job category.',
        ],
        before: pickFields(category, ['needSER', 'blueprintId', 'blueprintName']),
        after: {
          needSER: 'Yes',
          blueprintId: s(category.blueprintId),
          blueprintName: blueprintNameForId(bpIndex, s(category.blueprintId), s(category.blueprintName)),
        },
      })
    );
  }
  return out;
}

/**
 * Job categories whose blueprint ID is not in the Blueprints table — replace via name match.
 */
export function detectCategoryOrphanBlueprintRefs(categories, blueprints = [], rolesOrCountMap = []) {
  const bpIndex = blueprints instanceof Map ? blueprints : buildBlueprintIndex(blueprints);
  const out = [];
  for (const category of categories || []) {
    if (!isEligibleIntegrityJobCategory(category)) continue;
    const bpId = s(category.blueprintId);
    if (bpId && blueprintExistsInTable(bpIndex, bpId)) continue;
    if (!categoryHasBlueprintReference(category)) continue;
    const replacement = resolveBlueprintReplacement(bpIndex, bpId, category.blueprintName);
    if (!replacement) continue;
    const replaceSummary = bpId
      ? `Replace blueprint ${quoteVal(bpId)} with ${quoteVal(replacement.blueprintId)} from the Blueprints table.`
      : `Set Blueprint ID to ${quoteVal(replacement.blueprintId)} from the Blueprints table (matched by blueprint name).`;
    out.push(
      buildCategoryProposal({
        id: `cat-bp-replace:${category.id}`,
        code: 'category-blueprint-replace',
        category,
        affectedRoleCount: countRolesForCategory(rolesOrCountMap, category.jobCategoryName),
        summary: replaceSummary,
        details: [
          bpId
            ? `Change Blueprint ID from ${quoteVal(bpId)} to ${quoteVal(replacement.blueprintId)}.`
            : `Set Blueprint ID to ${quoteVal(replacement.blueprintId)}.`,
          replacement.blueprintName
            ? `Set Blueprint Name to ${quoteVal(replacement.blueprintName)}.`
            : null,
          `Set Need SER? to Yes.`,
        ].filter(Boolean),
        before: pickFields(category, ['needSER', 'blueprintId', 'blueprintName']),
        after: {
          needSER: 'Yes',
          blueprintId: replacement.blueprintId,
          blueprintName: replacement.blueprintName,
        },
      })
    );
  }
  return out;
}

/**
 * @deprecated Replaced by detectCategorySerWhenBlueprint — blueprint implies SER Yes.
 */
export function detectCategoryBlueprintWithoutSer(categories, roles = [], blueprints = []) {
  return detectCategorySerWhenBlueprint(categories, roles, blueprints);
}

/**
 * Job categories classified as No Access whose needEMP is not No.
 */
export function detectCategoryNoAccessEmpMismatch(categories, roles = []) {
  const out = [];
  for (const category of categories || []) {
    if (!isEligibleIntegrityJobCategory(category)) continue;
    const integrityRole = categoryAsIntegrityRole(category);
    if (roleHasListedTemplate(integrityRole, categories)) continue;
    if (isShellRbacRole(integrityRole, categories)) continue;
    if (!isNoAccessRbacRole(integrityRole, categories)) continue;
    const current = s(category.needEMP);
    if (current.toLowerCase() === 'no') continue;
    out.push(
      buildCategoryProposal({
        id: `cat-no-access-emp:${category.id}`,
        code: 'category-no-access-emp-mismatch',
        category,
        affectedRoleCount: countRolesForCategory(roles, category.jobCategoryName),
        summary: 'This job category is classified as No Access.',
        details: [
          current
            ? `Set Need EMP? to No (was ${quoteVal(current)}). No Access categories should not grant EMP.`
            : 'Set Need EMP? to No. No Access categories should not leave EMP blank.',
        ],
        before: pickFields(category, ['needEMP']),
        after: { needEMP: 'No' },
      })
    );
  }
  return out;
}

/**
 * Job categories with needEMP set but no linkable/subtemplate on the category.
 * Skips No Access and SHELL categories.
 */
export function detectCategoryEmpWithoutTemplate(categories, roles = []) {
  const out = [];
  for (const category of categories || []) {
    if (!isEligibleIntegrityJobCategory(category)) continue;
    if (!s(category.needEMP)) continue;
    const integrityRole = categoryAsIntegrityRole(category);
    if (isNoAccessRbacRole(integrityRole, categories)) continue;
    if (isShellRbacRole(integrityRole, categories)) continue;
    const hasTemplate =
      splitIntegrityMultiTemplateIds(category.linkableTemplateId).length > 0 ||
      splitIntegrityMultiTemplateIds(category.subtemplatesId).length > 0;
    if (hasTemplate) continue;
    out.push(
      buildCategoryProposal({
        id: `cat-emp-no-template:${category.id}`,
        code: 'category-emp-without-template',
        category,
        affectedRoleCount: countRolesForCategory(roles, category.jobCategoryName),
        summary: `Need EMP? is ${quoteVal(category.needEMP)}, but no template is defined on the job category.`,
        details: ['Clear Need EMP? — there is no linkable template or subtemplate on this job category.'],
        before: pickFields(category, ['needEMP']),
        after: { needEMP: '' },
      })
    );
  }
  return out;
}

/**
 * Job categories with a blueprint ID that resolves in the Blueprints table but
 * blueprintName is missing or does not match the reference table.
 */
export function detectCategoryBlueprintNameFromTable(categories, blueprints, roles = []) {
  const out = [];
  for (const category of categories || []) {
    if (!isEligibleIntegrityJobCategory(category)) continue;
    if (s(category.needSER).toLowerCase() === 'no') continue;
    const bpId = s(category.blueprintId);
    if (!bpId) continue;
    const expectedName = blueprintNameForId(blueprints, bpId, '');
    if (!expectedName) continue;
    const current = s(category.blueprintName);
    if (current.toLowerCase() === expectedName.toLowerCase()) continue;
    out.push(
      buildCategoryProposal({
        id: `cat-bp-name:${category.id}`,
        code: 'category-blueprint-name-from-table',
        category,
        affectedRoleCount: countRolesForCategory(roles, category.jobCategoryName),
        summary: `Blueprint name on this job category does not match the Blueprints table for ID ${quoteVal(bpId)}.`,
        details: [
          current
            ? `Set Blueprint Name to ${quoteVal(expectedName)} (was ${quoteVal(current)}).`
            : `Set Blueprint Name to ${quoteVal(expectedName)} from the Blueprints reference table.`,
        ],
        before: pickFields(category, ['blueprintId', 'blueprintName']),
        after: { blueprintId: bpId, blueprintName: expectedName },
      })
    );
  }
  return out;
}

/**
 * Roles with a SER blueprint ID that resolves in the Blueprints table but
 * blueprintName is missing or wrong. Skips rows whose job category owns the
 * same blueprint ID (category fix + role-category drift handle those).
 */
export function detectRoleBlueprintNameFromTable(roles, blueprints, jobCategories = []) {
  const catByName = buildCategoryByName(jobCategories, { integrityEligibleOnly: true });
  const out = [];
  for (const role of roles || []) {
    if (!role) continue;
    if (!isActiveIntegrityRecord(role)) continue;
    if (isExcludedIntegrityJobCategory(role.jobCategory)) continue;
    if (s(role.slaNeeded).toLowerCase() === 'no') continue;
    const bpId = s(role.slaBlueprintId);
    if (!bpId) continue;
    const cat = catByName.get(s(role.jobCategory).toLowerCase());
    if (cat && blueprintIdsMatch(cat.blueprintId, bpId)) continue;
    const expectedName = blueprintNameForId(blueprints, bpId, '');
    if (!expectedName) continue;
    const current = s(role.blueprintName);
    if (current.toLowerCase() === expectedName.toLowerCase()) continue;
    out.push(
      buildProposal({
        id: `role-bp-name:${role.id}`,
        code: 'role-blueprint-name-from-table',
        role,
        summary: `Blueprint name on this role does not match the Blueprints table for ID ${quoteVal(bpId)}.`,
        details: [
          current
            ? `Set Blueprint Name to ${quoteVal(expectedName)} (was ${quoteVal(current)}).`
            : `Set Blueprint Name to ${quoteVal(expectedName)} from the Blueprints reference table.`,
        ],
        before: pickFields(role, ['slaBlueprintId', 'blueprintName']),
        after: { slaBlueprintId: bpId, blueprintName: expectedName },
      })
    );
  }
  return out;
}

/**
 * @deprecated Role-level EMP-without-template; integrity fixes evaluate at job category level.
 */
export function detectEmpWithoutTemplate(roles, jobCategories) {
  const out = [];
  const catByName = new Map();
  for (const c of jobCategories || []) {
    if (!c) continue;
    if (!isActiveIntegrityRecord(c)) continue;
    const name = s(c.jobCategoryName).toLowerCase();
    if (name) catByName.set(name, c);
  }
  for (const role of roles || []) {
    if (!role) continue;
    if (!isActiveIntegrityRecord(role)) continue;
    if (!s(role.empNeeded)) continue;
    if (isNoAccessRbacRole(role, jobCategories)) continue;
    if (isShellRbacRole(role, jobCategories)) continue;
    const hasRoleTemplate =
      splitIntegrityMultiTemplateIds(role.linkedRoleTemplateId).length > 0 ||
      splitIntegrityMultiTemplateIds(role.subtemplateId).length > 0;
    if (hasRoleTemplate) continue;
    const cat = catByName.get(s(role.jobCategory).toLowerCase());
    const catHasTemplate =
      splitIntegrityMultiTemplateIds(cat?.linkableTemplateId).length > 0 ||
      splitIntegrityMultiTemplateIds(cat?.subtemplatesId).length > 0;
    if (catHasTemplate) continue;
    out.push(
      buildProposal({
        id: `emp-no-template:${role.id}`,
        code: 'emp-without-template',
        role,
        summary: `EMP Needed is ${quoteVal(role.empNeeded)}, but no template is defined on the role or job category.`,
        details: [
          `Clear EMP Needed — there is no Linked Role Template, subtemplate, or job category template to support EMP.`,
        ],
        before: pickFields(role, ['empNeeded']),
        after: { empNeeded: '' },
      })
    );
  }
  return out;
}

/**
 * @deprecated Role-level No Access EMP; integrity fixes evaluate at job category level.
 */
export function detectNoAccessEmpMismatch(roles, jobCategories = []) {
  const out = [];
  for (const role of roles || []) {
    if (!role) continue;
    if (roleHasListedTemplate(role, jobCategories)) continue;
    if (isShellRbacRole(role, jobCategories)) continue;
    if (!isNoAccessRbacRole(role, jobCategories)) continue;
    const current = s(role.empNeeded);
    if (current.toLowerCase() === 'no') continue;
    out.push(
      buildProposal({
        id: `no-access-emp:${role.id}`,
        code: 'no-access-emp-mismatch',
        role,
        summary: 'This role is classified as No Access.',
        details: [
          current
            ? `Set EMP Needed to No (was ${quoteVal(current)}). No Access roles should not grant EMP.`
            : 'Set EMP Needed to No. No Access roles should not leave EMP blank.',
        ],
        before: pickFields(role, ['empNeeded']),
        after: { empNeeded: 'No' },
      })
    );
  }
  return out;
}

function removeOrphanTokensFromIdField(value, orphanLcSet) {
  if (!s(value)) return { kept: value, removed: [] };
  // Best-effort: preserve the original separator pattern by splitting on the
  // canonical token splitter, then re-joining with comma+space. Acceptable
  // because callers only show before/after and the spExport rebuilds the
  // pipe-separated form when it needs the canonical layout.
  const tokens = splitIntegrityMultiTemplateIds(value);
  const kept = tokens.filter((t) => !orphanLcSet.has(t.toLowerCase()));
  const removed = tokens.filter((t) => orphanLcSet.has(t.toLowerCase()));
  return { kept: kept.join(', '), removed };
}

function compactTemplateNameKey(value) {
  return s(value)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '');
}

/** Site / org tokens on template names that may be absent on legacy role text (e.g. "SiteB"). */
const OPTIONAL_TEMPLATE_SITE_PREFIXES = new Set(['siteb', 'sitea', 'sitec', 'affiliate']);

function templateNameMatchWords(value) {
  return s(value)
    .toLowerCase()
    .split(/[^a-z0-9]+/g)
    .filter((w) => w.length > 2 && w !== 'template' && w !== 'subtemplate');
}

function looksLikeTemplateIdToken(value) {
  const t = s(value);
  if (!t) return false;
  return /^T[A-Za-z0-9]{4,}$/i.test(t);
}

function buildTemplateNameCatalog(templateLinks) {
  const entries = [];
  const addSlots = (row, ids, names) => {
    const count = Math.max(ids.length, names.length, 1);
    for (let i = 0; i < count; i++) {
      const id = s(ids[i] ?? ids[0] ?? '');
      const name = s(names[i] ?? names[0] ?? '');
      if (!id && !name) continue;
      const displayTitles = splitTemplateDisplayTitleSlots(row?.templateDisplayTitle);
      const primaryName = name || s(displayTitles[0] ?? '');
      entries.push({
        id,
        name: primaryName,
        row,
        norm: compactTemplateNameKey(primaryName || name),
        words: templateNameMatchWords(primaryName || name),
      });
      for (const title of displayTitles) {
        if (!s(title) || s(title).toLowerCase() === s(primaryName).toLowerCase()) continue;
        entries.push({
          id,
          name: s(title),
          row,
          norm: compactTemplateNameKey(title),
          words: templateNameMatchWords(title),
        });
      }
    }
  };

  for (const raw of templateLinks || []) {
    const row = normalizeTemplateLinkRow(raw);
    const rowTemplateIds = splitIntegrityMultiTemplateIds(row.templateId);
    addSlots(
      row,
      rowTemplateIds,
      splitIntegrityMultiTemplateNames(row.templateName, rowTemplateIds.length)
    );
    if (canonicalTemplateLinkRecordType(row) === 'Linkable Template') {
      const rowSubIds = splitIntegrityMultiTemplateIds(row.subtemplateId);
      addSlots(
        row,
        rowSubIds,
        splitIntegrityMultiTemplateNames(row.subtemplateName, rowSubIds.length)
      );
    }
  }
  return entries;
}

function scoreOrphanNameMatch(orphanName, entry) {
  if (!entry?.norm) return 0;
  const orphanNorm = compactTemplateNameKey(orphanName);
  if (!orphanNorm) return 0;
  if (orphanNorm === entry.norm) return 1;
  const orphanWords = templateNameMatchWords(orphanName);
  const entryWords = entry.words.length ? entry.words : templateNameMatchWords(entry.name);
  if (entryWords.length < 2) return 0;

  const matched = entryWords.filter((w) => orphanWords.includes(w) || orphanNorm.includes(w));
  const unmatched = entryWords.filter((w) => !matched.includes(w));
  if (unmatched.length > 0 && unmatched.every((w) => OPTIONAL_TEMPLATE_SITE_PREFIXES.has(w)) && matched.length >= 2) {
    return matched.length / entryWords.length;
  }
  if (unmatched.length > 0) return 0;
  return matched.length / entryWords.length;
}

function resolveIdAndNameFromLinkRow(row, nameToken) {
  const rowIds = splitIntegrityMultiTemplateIds(row?.templateId);
  const rowNames = splitIntegrityMultiTemplateNames(row?.templateName, rowIds.length);
  const key = s(nameToken).toLowerCase();
  let idx = rowNames.findIndex((nm) => s(nm).toLowerCase() === key);
  if (idx < 0) idx = 0;
  return {
    id: s(rowIds[idx] ?? rowIds[0] ?? ''),
    name: s(rowNames[idx] ?? rowNames[0] ?? ''),
  };
}

/** Template Name for a given Template ID on a link row (slot-aligned). */
function resolveTemplateNameFromLinkRowById(row, idToken) {
  const rowIds = splitIntegrityMultiTemplateIds(row?.templateId);
  const rowNames = splitIntegrityMultiTemplateNames(row?.templateName, rowIds.length);
  const key = s(idToken).toLowerCase();
  if (!key) return '';
  let idx = rowIds.findIndex((id) => s(id).toLowerCase() === key);
  if (idx < 0) idx = 0;
  return s(rowNames[idx] ?? rowNames[0] ?? '');
}

function resolveTemplateFromOrphanName(nameToken, nameToRows, catalog) {
  const key = s(nameToken).toLowerCase();
  if (!key) return null;

  const exactRows = nameToRows.get(key) || [];
  if (exactRows.length) {
    const { id, name } = resolveIdAndNameFromLinkRow(exactRows[0], nameToken);
    if (id || name) return { id, name: name || nameToken };
  }

  const scored = (catalog || [])
    .map((entry) => ({ entry, score: scoreOrphanNameMatch(nameToken, entry) }))
    .filter((x) => x.score >= 0.75);
  if (!scored.length) return null;

  scored.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    const aLinkable = canonicalTemplateLinkRecordType(a.entry.row) === 'Linkable Template' ? 1 : 0;
    const bLinkable = canonicalTemplateLinkRecordType(b.entry.row) === 'Linkable Template' ? 1 : 0;
    if (bLinkable !== aLinkable) return bLinkable - aLinkable;
    return b.entry.name.length - a.entry.name.length;
  });

  if (scored.length > 1 && scored[0].score - scored[1].score < 0.15) {
    return null;
  }

  const pick = scored[0].entry;
  return { id: pick.id, name: pick.name || nameToken };
}

function buildRoleTemplateResolutionHints(role, jobCategories) {
  const hints = [];
  const add = (value) => {
    const t = s(value);
    if (!t) return;
    hints.push(t);
  };
  add(role.templateDisplayTitle);
  for (const t of splitTemplateDisplayTitleSlots(role.templateDisplayTitle)) add(t);
  const cat = (jobCategories || []).find(
    (c) =>
      isEligibleIntegrityJobCategory(c) &&
      s(c?.jobCategoryName).toLowerCase() === s(role?.jobCategory).toLowerCase()
  );
  if (cat) {
    const catTemplateIds = splitIntegrityMultiTemplateIds(cat.linkableTemplateId);
    for (const t of splitIntegrityMultiTemplateNames(cat.linkableTemplateName, catTemplateIds.length)) add(t);
    for (const t of catTemplateIds) add(t);
  }
  return hints;
}

function resolveTemplateFromHints(hints, nameToRows, catalog) {
  for (const hint of hints || []) {
    if (!hint || looksLikeTemplateIdToken(hint)) continue;
    const resolved = resolveTemplateFromOrphanName(hint, nameToRows, catalog);
    if (resolved?.id || resolved?.name) return resolved;
  }
  return null;
}

/**
 * Repair orphan template ID/name tokens using Template Links (exact name, then fuzzy name → id).
 */
function repairOrphanTemplateIdAndNameFields(
  role,
  orphanIds,
  orphanNames,
  idToRows,
  nameToRows,
  catalog,
  jobCategories
) {
  const resolutionHints = buildRoleTemplateResolutionHints(role, jobCategories);
  const idTokens = splitIntegrityMultiTemplateIds(role.linkedRoleTemplateId);
  const nameTokens = splitIntegrityMultiTemplateNames(role.linkedRoleTemplateName, idTokens.length);
  const slots = Math.max(nameTokens.length, idTokens.length, orphanNames.size > 0 ? 1 : 0, 1);

  const nextIds = [];
  const nextNames = [];
  const replaced = [];
  const removed = [];
  const unresolved = [];

  for (let i = 0; i < slots; i++) {
    let idToken = s(idTokens[i] ?? (idTokens.length === 1 ? idTokens[0] : ''));
    let nameToken = s(nameTokens[i] ?? (nameTokens.length === 1 ? nameTokens[0] : ''));

    const nameIsOrphan = nameToken && orphanNames.has(nameToken.toLowerCase());
    const idIsOrphan = idToken && orphanIds.has(idToken.toLowerCase());

    if (idToken && !idIsOrphan) {
      const rows = idToRows.get(idToken.toLowerCase()) || [];
      const canonicalName = rows.length ? resolveTemplateNameFromLinkRowById(rows[0], idToken) : '';
      if (
        canonicalName &&
        (!nameToken || s(nameToken).toLowerCase() !== s(canonicalName).toLowerCase())
      ) {
        nextIds.push(idToken);
        nextNames.push(canonicalName);
        if (nameToken && s(nameToken).toLowerCase() !== s(canonicalName).toLowerCase()) {
          replaced.push({
            kind: 'name-from-id',
            from: nameToken,
            toId: idToken,
            toName: canonicalName,
          });
        }
        continue;
      }
    }

    if (nameIsOrphan) {
      let resolved = resolveTemplateFromOrphanName(nameToken, nameToRows, catalog);
      if (!resolved?.id && !resolved?.name) {
        resolved = resolveTemplateFromHints(resolutionHints, nameToRows, catalog);
      }
      if (resolved?.id || resolved?.name) {
        if (resolved.id) nextIds.push(resolved.id);
        else if (idToken && !idIsOrphan) nextIds.push(idToken);
        nextNames.push(resolved.name || nameToken);
        replaced.push({
          kind: 'name',
          from: nameToken,
          toId: resolved.id,
          toName: resolved.name || nameToken,
        });
        continue;
      }
      nextNames.push(nameToken);
      unresolved.push({ kind: 'name', value: nameToken });
      if (!idIsOrphan) {
        if (idToken) nextIds.push(idToken);
        continue;
      }
    }

    if (idIsOrphan) {
      let resolved = resolveTemplateFromOrphanName(nameToken, nameToRows, catalog);
      if (!resolved?.id) {
        resolved = resolveTemplateFromHints(resolutionHints, nameToRows, catalog);
      }
      if (resolved?.id) {
        nextIds.push(resolved.id);
        if (resolved.name) nextNames.push(resolved.name);
        else if (nameToken) nextNames.push(nameToken);
        replaced.push({
          kind: 'id',
          from: idToken,
          toId: resolved.id,
          toName: resolved.name || nameToken,
        });
        continue;
      }
      nextIds.push(idToken);
      removed.push(idToken);
      if (nameToken && !nameIsOrphan) nextNames.push(nameToken);
    } else {
      if (idToken) nextIds.push(idToken);
      if (nameToken) nextNames.push(nameToken);
    }
  }

  return {
    linkedRoleTemplateId: nextIds.join(', '),
    linkedRoleTemplateName: nextNames.join(', '),
    replaced,
    removed,
    unresolved,
  };
}

/**
 * Roles referencing template ids / names / subtemplate ids that do not appear
 * anywhere in the Template Links table. Surface one proposal per role with the
 * combined cleanup across the three fields.
 */
export function detectOrphanTemplateRefs(roles, templateLinks, jobCategories = [], options = {}) {
  const { ignoreCategoryAlignment = false, templateLinkIndex, nameCatalog: nameCatalogIn } = options;
  const linkIndex = templateLinkIndex || buildTemplateLinkIndex(templateLinks);
  const { idToRows, nameToRows, linkableSubIdToRows } = linkIndex;
  const nameCatalog = nameCatalogIn || buildTemplateNameCatalog(templateLinks);
  const catByName = buildCategoryByName(jobCategories, { integrityEligibleOnly: true });
  const out = [];
  for (const role of roles || []) {
    if (!role) continue;
    if (!ignoreCategoryAlignment && !isActiveIntegrityRecord(role)) continue;

    if (!ignoreCategoryAlignment) {
      const cat = catByName.get(s(role.jobCategory).toLowerCase());
      if (cat && roleTemplatesMatchCategory(role, cat)) continue;
      if (cat) continue;
    }

    const orphanIds = new Set();
    const orphanNames = new Set();
    const orphanSubIds = new Set();

    const roleTemplateIds = splitIntegrityMultiTemplateIds(role.linkedRoleTemplateId);
    const roleTemplateNames = splitIntegrityMultiTemplateNames(
      role.linkedRoleTemplateName,
      roleTemplateIds.length
    );
    const templateSlots = Math.max(roleTemplateIds.length, roleTemplateNames.length, 1);
    for (let i = 0; i < templateSlots; i++) {
      const id = s(roleTemplateIds[i] ?? (roleTemplateIds.length === 1 ? roleTemplateIds[0] : ''));
      const nm = s(roleTemplateNames[i] ?? (roleTemplateNames.length === 1 ? roleTemplateNames[0] : ''));
      if (id && (idToRows.get(id.toLowerCase()) || []).length === 0) {
        orphanIds.add(id.toLowerCase());
      }
      if (!nm) continue;
      const idValid = id && (idToRows.get(id.toLowerCase()) || []).length > 0;
      if (idValid) continue;
      if ((nameToRows.get(nm.toLowerCase()) || []).length === 0) {
        orphanNames.add(nm.toLowerCase());
      }
    }
    for (const sid of splitIntegrityMultiTemplateIds(role.subtemplateId)) {
      const k = sid.toLowerCase();
      const hits =
        (idToRows.get(k) || []).length > 0 || (linkableSubIdToRows.get(k) || []).length > 0;
      if (!hits) orphanSubIds.add(k);
    }

    const templateRepair = repairOrphanTemplateIdAndNameFields(
      role,
      orphanIds,
      orphanNames,
      idToRows,
      nameToRows,
      nameCatalog,
      jobCategories,
    );
    const subIdResult = removeOrphanTokensFromIdField(role.subtemplateId, orphanSubIds);

    const before = {
      linkedRoleTemplateId: role.linkedRoleTemplateId || '',
      linkedRoleTemplateName: role.linkedRoleTemplateName || '',
      subtemplateId: role.subtemplateId || '',
    };
    const after = {
      linkedRoleTemplateId: templateRepair.linkedRoleTemplateId,
      linkedRoleTemplateName: templateRepair.linkedRoleTemplateName,
      subtemplateId: s(subIdResult.kept),
    };

    const details = [];
    for (const ch of templateRepair.replaced) {
      if (ch.kind === 'name-from-id') {
        details.push(
          `Template name ${quoteVal(ch.from)} does not match Templates/Subtemplates for ID ${quoteVal(ch.toId)} — use ${quoteVal(ch.toName)} from that table.`
        );
      } else if (ch.kind === 'name') {
        details.push(
          `Template name ${quoteVal(ch.from)} is not in Templates/Subtemplates — use ${quoteVal(ch.toId)} and ${quoteVal(ch.toName)} from that table.`
        );
      } else if (ch.kind === 'id') {
        details.push(
          `Template ID ${quoteVal(ch.from)} is not in Templates/Subtemplates — use ${quoteVal(ch.toId)}${ch.toName ? ` (${quoteVal(ch.toName)})` : ''} from the paired template name.`
        );
      }
    }
    for (const id of templateRepair.removed) {
      details.push(
        `Template ID ${quoteVal(id)} is not in Templates/Subtemplates and could not be matched automatically — left unchanged for you to fix manually.`
      );
    }
    for (const u of templateRepair.unresolved) {
      if (u.kind === 'name') {
        details.push(
          `Template name ${quoteVal(u.value)} is not in Templates/Subtemplates and has no unique match in that table — left unchanged for you to fix manually.`
        );
      }
    }
    for (const sid of subIdResult.removed) {
      details.push(
        `Subtemplate ID ${quoteVal(sid)} is not in Templates/Subtemplates — remove it from the role.`
      );
    }

    const hasOrphans = orphanIds.size > 0 || orphanNames.size > 0 || orphanSubIds.size > 0;
    const needsReview =
      hasOrphans ||
      JSON.stringify(before) !== JSON.stringify(after) ||
      templateRepair.unresolved.length > 0 ||
      templateRepair.removed.length > 0 ||
      subIdResult.removed.length > 0;
    if (!needsReview) continue;

    out.push(
      buildProposal({
        id: `orphan:${role.id}`,
        code: 'orphan-template-ref',
        role,
        summary: 'Template or subtemplate on this role does not match the Templates/Subtemplates table.',
        details: details.length
          ? details
          : ['Review linked template fields and align them with Templates/Subtemplates.'],
        before,
        after,
      })
    );
  }
  return out;
}

/** Job category template/subtemplate fields vs Templates/Subtemplates table. */
export function detectCategoryOrphanTemplateRefs(
  categories,
  templateLinks,
  rolesOrCountMap = [],
  templateLinkIndex = null
) {
  const linkIndex = templateLinkIndex || buildTemplateLinkIndex(templateLinks);
  const nameCatalog = buildTemplateNameCatalog(templateLinks);
  const out = [];
  for (const category of categories || []) {
    if (!isEligibleIntegrityJobCategory(category)) continue;
    const pseudoRole = {
      id: category.id,
      jobCategory: category.jobCategoryName,
      linkedRoleTemplateId: category.linkableTemplateId,
      linkedRoleTemplateName: category.linkableTemplateName,
      subtemplateId: category.subtemplatesId,
    };
    const roleProposals = detectOrphanTemplateRefs([pseudoRole], templateLinks, [category], {
      ignoreCategoryAlignment: true,
      templateLinkIndex: linkIndex,
      nameCatalog,
    });
    for (const p of roleProposals) {
      out.push(
        buildCategoryProposal({
          id: `cat-orphan:${category.id}`,
          code: 'category-orphan-template-ref',
          category,
          affectedRoleCount: countRolesForCategory(rolesOrCountMap, category.jobCategoryName),
          summary: 'Template or subtemplate on this job category does not match Templates/Subtemplates.',
          details: p.details?.length
            ? p.details
            : ['Review linkable template fields on the job category.'],
          before: {
            linkableTemplateId: p.before?.linkedRoleTemplateId || '',
            linkableTemplateName: p.before?.linkedRoleTemplateName || '',
            subtemplatesId: p.before?.subtemplateId || '',
          },
          after: {
            linkableTemplateId: p.after?.linkedRoleTemplateId || '',
            linkableTemplateName: p.after?.linkedRoleTemplateName || '',
            subtemplatesId: p.after?.subtemplateId || '',
          },
        })
      );
    }
  }
  return out;
}

/**
 * Active roles whose category-derived fields differ from their job category.
 * Fix: sync role from the job category (same rules as Job Categories propagate).
 */
export function detectRoleDerivedFieldDriftFromCategory(
  roles,
  jobCategories,
  blueprints = [],
  templateLinks = [],
  categoryDerivedFields = null
) {
  const catByName = buildCategoryByName(jobCategories, { integrityEligibleOnly: true });
  const expectedByCategoryName =
    categoryDerivedFields ||
    buildCategoryDerivedFieldsCache(jobCategories, blueprints, templateLinks);
  const out = [];
  for (const role of roles || []) {
    if (!role) continue;
    if (!isActiveIntegrityRecord(role)) continue;
    if (isExcludedIntegrityJobCategory(role.jobCategory)) continue;
    const catKey = s(role.jobCategory).toLowerCase();
    const category = catByName.get(catKey);
    const expected = expectedByCategoryName.get(catKey);
    if (!expected || !category) continue;
    const before = {};
    const after = {};
    const details = [];
    for (const field of ROLE_CATEGORY_DERIVED_FIELDS) {
      if (s(role[field]).toLowerCase() === s(expected[field]).toLowerCase()) continue;
      if (
        (field === 'slaBlueprintId' || field === 'blueprintName') &&
        !s(expected[field]) &&
        (s(role[field]) || categoryHasBlueprintReference(category))
      ) {
        continue;
      }
      before[field] = role[field] ?? '';
      after[field] = expected[field] ?? '';
      details.push(
        `Sync ${fieldLabel(field)} to ${quoteVal(after[field] || '(blank)')} (from job category ${quoteVal(role.jobCategory)}).`
      );
    }
    if (!details.length) continue;
    out.push(
      buildProposal({
        id: `role-cat-drift:${role.id}`,
        code: 'role-category-drift',
        role,
        summary: `Role is out of sync with job category ${quoteVal(role.jobCategory)}.`,
        details,
        before,
        after,
      })
    );
  }
  return out;
}

/**
 * Active roles whose sailpointRole does not match their active job-category's
 * sailpointRole (when the category supplies one). Fix: set the role to the
 * category's value.
 */
export function detectSailpointDriftFromCategory(roles, jobCategories) {
  const out = [];
  const catByName = buildCategoryByName(jobCategories, { integrityEligibleOnly: true });
  for (const role of roles || []) {
    if (!role) continue;
    if (!isActiveIntegrityRecord(role)) continue;
    if (isExcludedIntegrityJobCategory(role.jobCategory)) continue;
    const cat = catByName.get(s(role.jobCategory).toLowerCase());
    if (!cat) continue;
    const catSp = s(cat.sailpointRole);
    if (!catSp) continue;
    const roleSp = s(role.sailpointRole);
    if (roleSp.toLowerCase() === catSp.toLowerCase()) continue;
    out.push(
      buildProposal({
        id: `sp-drift:${role.id}`,
        code: 'sailpoint-drift',
        role,
        summary: `SailPoint role on this row does not match job category ${quoteVal(cat.jobCategoryName)}.`,
        details: [
          roleSp
            ? `Change SailPoint role from ${quoteVal(roleSp)} to ${quoteVal(catSp)} (value from the job category).`
            : `Set SailPoint role to ${quoteVal(catSp)} (copied from the job category).`,
        ],
        before: pickFields(role, ['sailpointRole']),
        after: { sailpointRole: catSp },
      })
    );
  }
  return out;
}

/**
 * Aggregate all integrity proposals across detectors.
 * Category-level checks run first; role rows cover role-specific SER and drift
 * from the job category. Excludes placeholder job categories and inactive rows.
 */
export function findIntegrityFixes({ roles, jobCategories, templateLinks, blueprints = [] }) {
  const eligibleCategories = (jobCategories || []).filter(isEligibleIntegrityJobCategory);
  const eligibleRoles = (roles || []).filter(
    (role) =>
      role &&
      isActiveIntegrityRecord(role) &&
      !isExcludedIntegrityJobCategory(role?.jobCategory) &&
      roleIsOnEligibleIntegrityJobCategory(role, jobCategories)
  );
  const roleCountByCategory = buildRoleCountByCategory(eligibleRoles);
  const blueprintIndex = buildBlueprintIndex(blueprints);
  const templateLinkIndex = buildTemplateLinkIndex(templateLinks);
  const nameCatalog = buildTemplateNameCatalog(templateLinks);
  const categoryDerivedFields = buildCategoryDerivedFieldsCache(
    eligibleCategories,
    blueprints,
    templateLinks
  );
  return [
    ...detectCategoryOrphanBlueprintRefs(eligibleCategories, blueprintIndex, roleCountByCategory),
    ...detectCategorySerWhenBlueprint(eligibleCategories, roleCountByCategory, blueprintIndex),
    ...detectCategoryBlueprintNameFromTable(eligibleCategories, blueprintIndex, roleCountByCategory),
    ...detectCategoryNoAccessEmpMismatch(eligibleCategories, roleCountByCategory),
    ...detectCategoryEmpWithoutTemplate(eligibleCategories, roleCountByCategory),
    ...detectCategoryOrphanTemplateRefs(
      eligibleCategories,
      templateLinks,
      roleCountByCategory,
      templateLinkIndex
    ),
    ...detectRoleBlueprintFromTable(eligibleRoles, blueprintIndex),
    ...detectRoleBlueprintNameFromTable(eligibleRoles, blueprintIndex, eligibleCategories),
    ...detectOrphanTemplateRefs(eligibleRoles, templateLinks, eligibleCategories, {
      templateLinkIndex,
      nameCatalog,
    }),
    ...detectRoleDerivedFieldDriftFromCategory(
      eligibleRoles,
      eligibleCategories,
      blueprints,
      templateLinks,
      categoryDerivedFields
    ),
  ];
}

/**
 * Apply selected proposals. Category fixes update job categories and propagate
 * to all roles in those categories; role fixes patch individual role rows.
 */
export function applyIntegrityFixes({
  roles,
  jobCategories,
  proposals,
  selectedIds,
  blueprints = [],
  templateLinks = [],
}) {
  const selected = new Set(selectedIds || []);
  const oldByRoleId = new Map();
  const oldByCategoryId = new Map();
  const changedRoleIds = new Set();
  const changedCategoryIds = new Set();

  const patchesByRoleId = new Map();
  const patchesByCategoryId = new Map();
  for (const p of proposals || []) {
    if (!selected.has(p.id)) continue;
    if (p.level === 'category' && p.categoryId) {
      if (!patchesByCategoryId.has(p.categoryId)) patchesByCategoryId.set(p.categoryId, []);
      patchesByCategoryId.get(p.categoryId).push(p.after);
      continue;
    }
    if (!p.roleId) continue;
    if (!patchesByRoleId.has(p.roleId)) patchesByRoleId.set(p.roleId, []);
    patchesByRoleId.get(p.roleId).push(p.after);
  }

  if (patchesByRoleId.size === 0 && patchesByCategoryId.size === 0) {
    return {
      updatedRoles: roles || [],
      updatedJobCategories: jobCategories || [],
      oldByRoleId,
      oldByCategoryId,
      changedRoleIds,
      changedCategoryIds,
    };
  }

  let updatedJobCategories = (jobCategories || []).map((category) => {
    if (!category || !category.id) return category;
    const patches = patchesByCategoryId.get(category.id);
    if (!patches || patches.length === 0) return category;
    let next = { ...category };
    let mutated = false;
    for (const patch of patches) {
      for (const [k, v] of Object.entries(patch)) {
        if (fieldValueChanged(next[k], v)) {
          next[k] = v;
          mutated = true;
        }
      }
    }
    if (!mutated) return category;
    oldByCategoryId.set(category.id, category);
    changedCategoryIds.add(category.id);
    return next;
  });

  const categoryByName = buildCategoryByName(updatedJobCategories);

  let updatedRoles = (roles || []).map((role) => {
    if (!role || !role.id) return role;
    const patches = patchesByRoleId.get(role.id);
    let next = role;
    let mutated = false;
    if (patches && patches.length > 0) {
      next = { ...role };
      for (const patch of patches) {
        for (const [k, v] of Object.entries(patch)) {
          if (fieldValueChanged(next[k], v)) {
            next[k] = v;
            mutated = true;
          }
        }
      }
    }
    const cat = categoryByName.get(s(next.jobCategory).toLowerCase());
    if (cat && changedCategoryIds.has(cat.id)) {
      const synced = applyCategoryUpdatesToRole(next, cat, blueprints, templateLinks);
      if (roleDerivedFieldsDiffer(next, synced)) {
        next = synced;
        mutated = true;
      }
    }
    if (!mutated) return role;
    oldByRoleId.set(role.id, role);
    changedRoleIds.add(role.id);
    return next;
  });

  return {
    updatedRoles,
    updatedJobCategories,
    oldByRoleId,
    oldByCategoryId,
    changedRoleIds,
    changedCategoryIds,
  };
}

export const INTEGRITY_FIX_CODE_LABEL = {
  'category-ser-when-blueprint': 'Job category — blueprint in table, Need SER should be Yes',
  'category-blueprint-replace': 'Job category — replace blueprint from Blueprints table',
  'category-blueprint-name-from-table': 'Job category — blueprint name from Blueprints table',
  'category-no-access-emp-mismatch': 'Job category — No Access, Need EMP should be No',
  'category-emp-without-template': 'Job category — Need EMP but no template',
  'category-orphan-template-ref': 'Job category — template not in Templates/Subtemplates',
  'role-ser-when-blueprint': 'Role — blueprint in table, SER Needed should be Yes',
  'role-blueprint-replace': 'Role — replace blueprint from Blueprints table',
  'role-blueprint-name-from-table': 'Role — blueprint name from Blueprints table',
  'no-access-emp-mismatch': 'No Access role — EMP should be No',
  'emp-without-template': 'EMP set but no template exists',
  'orphan-template-ref': 'Role — template not in Templates/Subtemplates (no category)',
  'role-category-drift': 'Role out of sync with job category',
  'sailpoint-drift': 'SailPoint does not match job category',
};
