/**
 * Job codes are always 4 characters; leading zeros must be preserved.
 * Use when storing, comparing, or displaying job codes (and jobCodeId on roles).
 *
 * @param {*} value - Raw value (string, number, or null/undefined). Numbers from Excel (e.g. 123) become "0123".
 * @returns {string} Exactly 4 characters, padded with leading zeros; if longer than 4, last 4 chars.
 */
export function normalizeJobCode(value) {
  if (value == null) return '';
  let s = String(value).replace(/\s/g, '');
  if (s.length === 0) return '';
  if (s.length > 4) s = s.slice(-4);
  else if (s.length < 4) s = s.padStart(4, '0');
  return s;
}
