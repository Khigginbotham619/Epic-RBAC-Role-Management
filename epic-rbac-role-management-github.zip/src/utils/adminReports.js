import {
  splitTemplateIdTokens,
  splitTemplateNameTokens,
  normalizeTemplateLinkRow,
  canonicalTemplateLinkRecordType,
} from './templateLinkRoleMatch';
import { isJobCategoryExcludedFromOrgScope } from './jobCategoryScope';
import { normalizeJobCode } from './jobCodeUtils';
import { rankReplacementCategories } from './jobCategoryReassignment';
import { buildRbacCodeCountByJobCategoryName } from './jobCategoryRbacCounts';
import {
  splitIntegrityMultiTemplateIds,
  splitIntegrityMultiTemplateNames,
} from './integrityFixes';

/** Active job categories with organization scope other than “Not in Scope for Organization”. */
export function isJobCategoryIncludedInAdminReports(cat) {
  if (!cat) return false;
  if ((cat.status || 'Active') === 'Inactive') return false;
  if (isJobCategoryExcludedFromOrgScope(cat)) return false;
  return true;
}

/** Subset of categories used by admin data-quality reports (excludes inactive and out-of-org-scope). */
export function filterJobCategoriesForAdminReports(jobCategories) {
  return (jobCategories || []).filter(isJobCategoryIncludedInAdminReports);
}

function isLinkRowInactive(row) {
  const raw = row.currentStatus ?? row.CurrentStatus ?? '';
  if (raw === '' || raw == null) return false;
  return String(raw).trim().toLowerCase() !== 'active';
}

/**
 * Index template link rows by normalized template ID and name tokens (all record types).
 */
function buildTemplateLinkIndexes(templateLinks) {
  const normalized = (templateLinks || []).map(normalizeTemplateLinkRow);
  const idToRows = new Map();
  const nameToRows = new Map();
  /** Linkable rows only: subtemplate ID tokens → rows */
  const linkableSubIdToRows = new Map();

  for (const row of normalized) {
    const kind = canonicalTemplateLinkRecordType(row);
    for (const id of splitTemplateIdTokens(row.templateId)) {
      const k = id.toLowerCase();
      if (!idToRows.has(k)) idToRows.set(k, []);
      idToRows.get(k).push(row);
    }
    for (const nm of splitTemplateNameTokens(row.templateName)) {
      const k = nm.toLowerCase();
      if (!nameToRows.has(k)) nameToRows.set(k, []);
      nameToRows.get(k).push(row);
    }
    if (kind === 'Linkable Template') {
      for (const sid of splitTemplateIdTokens(row.subtemplateId)) {
        const k = sid.toLowerCase();
        if (!linkableSubIdToRows.has(k)) linkableSubIdToRows.set(k, []);
        linkableSubIdToRows.get(k).push(row);
      }
    }
  }
  return { normalized, idToRows, nameToRows, linkableSubIdToRows };
}

/**
 * RBAC roles whose linked template / subtemplate fields resolve to at least one Template Link row
 * with User Record Status other than Active.
 */
export function reportRolesWithInactiveTemplateLinks(roles, templateLinks) {
  const { idToRows, nameToRows, linkableSubIdToRows } = buildTemplateLinkIndexes(templateLinks);
  const out = [];

  for (const role of roles || []) {
    const hits = [];

    const addInactive = (field, token, rows) => {
      for (const row of rows) {
        if (isLinkRowInactive(row)) {
          hits.push({
            field,
            token,
            linkStatus: String(row.currentStatus || '').trim() || '—',
            recordType: canonicalTemplateLinkRecordType(row),
          });
        }
      }
    };

    for (const id of splitTemplateIdTokens(role.linkedRoleTemplateId)) {
      const rows = idToRows.get(id.toLowerCase()) || [];
      if (rows.length) addInactive('Linked Role Template ID', id, rows);
    }
    for (const nm of splitTemplateNameTokens(role.linkedRoleTemplateName)) {
      const rows = nameToRows.get(nm.toLowerCase()) || [];
      if (rows.length) addInactive('Linked Role Template Name', nm, rows);
    }
    for (const sid of splitTemplateIdTokens(role.subtemplateId)) {
      const key = sid.toLowerCase();
      const fromMain = idToRows.get(key) || [];
      const fromLinkableSub = linkableSubIdToRows.get(key) || [];
      const merged = [...new Map([...fromMain, ...fromLinkableSub].map((r) => [r.id, r])).values()];
      if (merged.length) addInactive('Subtemplate ID', sid, merged);
    }

    if (hits.length === 0) continue;

    const seen = new Set();
    const deduped = hits.filter((h) => {
      const k = `${h.field}|${h.token}|${h.linkStatus}|${h.recordType}`;
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
    out.push({ role, hits: deduped });
  }
  return out;
}

/**
 * Active in-scope job categories whose linked template/subtemplate fields resolve
 * to at least one Template Link row with User Record Status other than Active.
 */
export function reportJobCategoriesLinkedToInactiveTemplates(jobCategories, templateLinks) {
  const categories = filterJobCategoriesForAdminReports(jobCategories);
  const { idToRows, nameToRows, linkableSubIdToRows } = buildTemplateLinkIndexes(templateLinks);
  const out = [];

  for (const category of categories) {
    const hits = [];
    const addInactive = (field, token, rows) => {
      for (const row of rows) {
        if (isLinkRowInactive(row)) {
          hits.push({
            field,
            token,
            linkStatus: String(row.currentStatus || '').trim() || '—',
            recordType: canonicalTemplateLinkRecordType(row),
          });
        }
      }
    };

    for (const id of splitTemplateIdTokens(category.linkableTemplateId)) {
      const rows = idToRows.get(id.toLowerCase()) || [];
      if (rows.length) addInactive('Linkable Template ID', id, rows);
    }
    for (const nm of splitTemplateNameTokens(category.linkableTemplateName)) {
      const rows = nameToRows.get(nm.toLowerCase()) || [];
      if (rows.length) addInactive('Linkable Template Name', nm, rows);
    }
    for (const sid of splitTemplateIdTokens(category.subtemplatesId)) {
      const key = sid.toLowerCase();
      const fromMain = idToRows.get(key) || [];
      const fromLinkableSub = linkableSubIdToRows.get(key) || [];
      const merged = [...new Map([...fromMain, ...fromLinkableSub].map((r) => [r.id, r])).values()];
      if (merged.length) addInactive('Subtemplate ID', sid, merged);
    }

    if (hits.length === 0) continue;
    const seen = new Set();
    const deduped = hits.filter((h) => {
      const k = `${h.field}|${h.token}|${h.linkStatus}|${h.recordType}`;
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
    out.push({ category, hits: deduped });
  }
  return out;
}

/**
 * SailPoint catalog roles whose attached templates/subtemplates resolve to at least one
 * Templates/Subtemplates row with User Record Status other than Active.
 */
export function reportSailpointRolesAttachedToInactiveTemplates(sailpointCatalogRows, templateLinks) {
  const { idToRows, linkableSubIdToRows } = buildTemplateLinkIndexes(templateLinks);
  const out = [];

  for (const spRow of sailpointCatalogRows || []) {
    const hits = [];
    const roleName = String(spRow?.sailpointRole || '').trim();
    if (!roleName) continue;

    const addInactive = (field, token, rows) => {
      for (const row of rows) {
        if (isLinkRowInactive(row)) {
          hits.push({
            field,
            token,
            linkStatus: String(row.currentStatus || '').trim() || '—',
            recordType: canonicalTemplateLinkRecordType(row),
          });
        }
      }
    };

    for (const id of splitTemplateIdTokens(spRow.templates)) {
      const rows = idToRows.get(id.toLowerCase()) || [];
      if (rows.length) addInactive('Template ID', id, rows);
    }
    for (const sid of splitTemplateIdTokens(spRow.subtemplates)) {
      const key = sid.toLowerCase();
      const fromMain = idToRows.get(key) || [];
      const fromLinkableSub = linkableSubIdToRows.get(key) || [];
      const merged = [...new Map([...fromMain, ...fromLinkableSub].map((r) => [r.id, r])).values()];
      if (merged.length) addInactive('Subtemplate ID', sid, merged);
    }

    if (!hits.length) continue;
    const seen = new Set();
    const deduped = hits.filter((h) => {
      const k = `${h.field}|${h.token}|${h.linkStatus}|${h.recordType}`;
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
    out.push({ sailpointRoleRow: spRow, hits: deduped });
  }
  return out;
}

/**
 * RBAC roles with template ID/name / subtemplate ID set but no matching row in Template Links (any status).
 */
export function reportRolesWithOrphanTemplateRefs(roles, templateLinks) {
  const { idToRows, nameToRows, linkableSubIdToRows } = buildTemplateLinkIndexes(templateLinks);
  const out = [];

  for (const role of roles || []) {
    const orphans = [];
    const roleTemplateIds = splitIntegrityMultiTemplateIds(role.linkedRoleTemplateId);
    const roleTemplateNames = splitIntegrityMultiTemplateNames(
      role.linkedRoleTemplateName,
      roleTemplateIds.length
    );
    const templateSlots = Math.max(roleTemplateIds.length, roleTemplateNames.length, 1);

    for (let i = 0; i < templateSlots; i++) {
      const id = String(
        (roleTemplateIds[i] ?? (roleTemplateIds.length === 1 ? roleTemplateIds[0] : '')) || ''
      ).trim();
      const nm = String(
        (roleTemplateNames[i] ?? (roleTemplateNames.length === 1 ? roleTemplateNames[0] : '')) || ''
      ).trim();
      if (id) {
        const rows = idToRows.get(id.toLowerCase()) || [];
        if (!rows.length) orphans.push({ field: 'Linked Role Template ID', token: id });
      }
      if (nm) {
        const idValid = id && (idToRows.get(id.toLowerCase()) || []).length > 0;
        if (idValid) continue;
        const rows = nameToRows.get(nm.toLowerCase()) || [];
        if (!rows.length) orphans.push({ field: 'Linked Role Template Name', token: nm });
      }
    }
    for (const sid of splitTemplateIdTokens(role.subtemplateId)) {
      const key = sid.toLowerCase();
      const has =
        (idToRows.get(key) || []).length > 0 || (linkableSubIdToRows.get(key) || []).length > 0;
      if (!has) orphans.push({ field: 'Subtemplate ID', token: sid });
    }

    if (orphans.length) out.push({ role, orphans });
  }
  return out;
}

const SAILPOINT_ISSUE_LABELS = {
  not_in_catalog: 'Sailpoint role not in catalog',
  blank_sailpoint: 'Blank Sailpoint (active category)',
  flagged_review: 'Flagged for Sailpoint review',
};

/**
 * Job categories with Sailpoint gaps: not in catalog, blank while active, or marked for review.
 * Inactive and out-of-org-scope categories are excluded.
 */
export function reportJobCategorySailpointIssues(jobCategories, sailpointCatalogRows) {
  const cats = filterJobCategoriesForAdminReports(jobCategories);
  const catalog = new Set(
    (sailpointCatalogRows || [])
      .map((r) => String(r.sailpointRole || '').trim().toLowerCase())
      .filter(Boolean)
  );

  const results = [];
  for (const cat of cats) {
    const issues = [];
    const sp = String(cat.sailpointRole || '').trim();
    const spLc = sp.toLowerCase();
    const isActive = (cat.status || 'Active') !== 'Inactive';

    if (sp && !catalog.has(spLc)) {
      issues.push({ code: 'not_in_catalog', label: SAILPOINT_ISSUE_LABELS.not_in_catalog, detail: sp });
    }
    if (isActive && !sp) {
      issues.push({ code: 'blank_sailpoint', label: SAILPOINT_ISSUE_LABELS.blank_sailpoint, detail: '' });
    }
    if (String(cat.sailpointRoleReview || '').trim() === 'Review') {
      issues.push({ code: 'flagged_review', label: SAILPOINT_ISSUE_LABELS.flagged_review, detail: '' });
    }

    if (issues.length) results.push({ category: cat, issues });
  }
  return results;
}

/**
 * Job categories that share the same assigned Sailpoint role (normalized match).
 * One row per Sailpoint role used by two or more categories. Includes all categories
 * regardless of status or organization scope.
 */
export function reportDuplicateSailpointRolesOnJobCategories(
  jobCategories,
  sailpointCatalogRows = [],
  roles = []
) {
  const catalogByLc = new Map();
  for (const row of sailpointCatalogRows || []) {
    const key = String(row?.sailpointRole || '').trim().toLowerCase();
    if (!key || catalogByLc.has(key)) continue;
    catalogByLc.set(key, row);
  }
  const rbacCodeCountByCategoryName = buildRbacCodeCountByJobCategoryName(roles);

  const byNorm = new Map();
  for (const cat of jobCategories || []) {
    if (!cat) continue;
    const sp = String(cat.sailpointRole || '').trim();
    if (!sp) continue;
    const norm = normalizeMatchText(sp);
    if (!norm) continue;
    if (!byNorm.has(norm)) {
      byNorm.set(norm, { categories: [], spellings: new Set() });
    }
    const group = byNorm.get(norm);
    group.categories.push(cat);
    group.spellings.add(sp);
  }

  const out = [];
  for (const [norm, group] of byNorm.entries()) {
    if (group.categories.length < 2) continue;
    group.categories.sort((a, b) =>
      String(a.jobCategoryId || '').localeCompare(String(b.jobCategoryId || ''), undefined, {
        numeric: true,
      })
    );
    const spellings = [...group.spellings].sort((a, b) =>
      a.localeCompare(b, undefined, { sensitivity: 'base' })
    );
    const sailpointRole =
      spellings.length === 1 ? spellings[0] : spellings.join(' | ');
    const catalogRow = catalogByLc.get(spellings[0].toLowerCase()) || null;
    const rbacCodeCount = group.categories.reduce(
      (sum, c) => sum + (rbacCodeCountByCategoryName.get(String(c.jobCategoryName || '').trim()) || 0),
      0
    );
    out.push({
      sailpointRole,
      sailpointRoleNorm: norm,
      categoryCount: group.categories.length,
      categories: group.categories,
      jobCategoryIds: group.categories.map((c) => c.jobCategoryId || '').filter(Boolean).join('; '),
      jobCategoryNames: group.categories.map((c) => c.jobCategoryName || '').filter(Boolean).join('; '),
      categoryStatuses: group.categories.map((c) => c.status || 'Active').join('; '),
      organizationScopes: group.categories
        .map((c) => formatJobCategoryScopeLabel(c))
        .join('; '),
      requestable: catalogRow ? String(catalogRow.requestable || '').trim() : '',
      catalogStatus: catalogRow ? String(catalogRow.status || 'Active').trim() : '',
      rbacCodeCount,
    });
  }

  out.sort((a, b) => {
    if (b.categoryCount !== a.categoryCount) return b.categoryCount - a.categoryCount;
    return a.sailpointRole.localeCompare(b.sailpointRole, undefined, { sensitivity: 'base' });
  });
  return out;
}

/**
 * RBAC roles whose Job Category name matches a job category row with status Inactive (any role status).
 * Uses the full category list (does not apply in-scope / active filters).
 */
export function reportRolesWithInactiveJobCategory(roles, jobCategories) {
  const byName = new Map(
    (jobCategories || []).map((c) => [String(c.jobCategoryName || '').trim(), c])
  );
  const out = [];
  for (const role of roles || []) {
    const name = String(role.jobCategory || '').trim();
    if (!name) continue;
    const cat = byName.get(name);
    if (!cat) continue;
    if ((cat.status || 'Active') === 'Inactive') {
      out.push({ role, category: cat });
    }
  }
  return out;
}

function isReferenceStatusInactive(statusValue) {
  const raw = String(statusValue ?? '').trim().toLowerCase();
  if (!raw) return false;
  return raw !== 'active';
}

function issueKey(issue) {
  return `${issue.connectionType}|${issue.detail}|${issue.field || ''}|${issue.token || ''}`;
}

/**
 * RBAC roles connected to any inactive reference: job category, template link (on the role),
 * job code, SailPoint catalog role, or an active job category whose templates resolve to
 * non-active Template Links rows.
 */
export function reportRolesConnectedToInactive(
  roles,
  jobCategories,
  templateLinks,
  jobCodes,
  sailpointCatalogRows
) {
  const byRoleId = new Map();

  const addIssue = (role, issue) => {
    if (!role?.id) return;
    let entry = byRoleId.get(role.id);
    if (!entry) {
      entry = { role, issues: [] };
      byRoleId.set(role.id, entry);
    }
    const key = issueKey(issue);
    if (!entry.issues.some((i) => issueKey(i) === key)) entry.issues.push(issue);
  };

  for (const { role, category } of reportRolesWithInactiveJobCategory(roles, jobCategories)) {
    addIssue(role, {
      connectionType: 'Job category',
      detail: String(category.jobCategoryName || '').trim() || '—',
      status: String(category.status || 'Inactive').trim() || 'Inactive',
      field: 'jobCategory',
    });
  }

  for (const { role, hits } of reportRolesWithInactiveTemplateLinks(roles, templateLinks)) {
    for (const h of hits) {
      addIssue(role, {
        connectionType: 'Template link (on role)',
        detail: `${h.field}: ${h.token} (${h.recordType})`,
        status: h.linkStatus,
        field: h.field,
        token: h.token,
      });
    }
  }

  const inactiveCategoryTpl = reportJobCategoriesLinkedToInactiveTemplates(
    jobCategories,
    templateLinks
  );
  const inactiveTplByCatName = new Map(
    inactiveCategoryTpl.map((row) => [
      String(row.category.jobCategoryName || '').trim().toLowerCase(),
      row,
    ])
  );

  for (const role of roles || []) {
    const catNameLc = String(role.jobCategory || '').trim().toLowerCase();
    if (!catNameLc) continue;
    const catReport = inactiveTplByCatName.get(catNameLc);
    if (!catReport) continue;
    const catLabel = String(catReport.category.jobCategoryName || role.jobCategory || '').trim();
    for (const h of catReport.hits) {
      addIssue(role, {
        connectionType: 'Job category template',
        detail: `${catLabel}: ${h.field} ${h.token} (${h.recordType})`,
        status: h.linkStatus,
        field: h.field,
        token: h.token,
      });
    }
  }

  const inactiveJobCodeByCode = new Map();
  for (const jc of jobCodes || []) {
    const code = normalizeJobCode(jc?.jobCode);
    if (!code || !isReferenceStatusInactive(jc?.currentStatus)) continue;
    inactiveJobCodeByCode.set(code, jc);
  }
  for (const role of roles || []) {
    const code = normalizeJobCode(role?.jobCodeId);
    if (!code) continue;
    const jc = inactiveJobCodeByCode.get(code);
    if (!jc) continue;
    addIssue(role, {
      connectionType: 'Job code',
      detail: code,
      status: String(jc.currentStatus || 'Inactive').trim() || 'Inactive',
      field: 'jobCodeId',
    });
  }

  const inactiveSailpointByName = new Map();
  for (const sp of sailpointCatalogRows || []) {
    const name = String(sp?.sailpointRole || '').trim();
    if (!name || !isReferenceStatusInactive(sp?.status)) continue;
    inactiveSailpointByName.set(name.toLowerCase(), sp);
  }
  for (const role of roles || []) {
    const spName = String(role?.sailpointRole || '').trim();
    if (!spName) continue;
    const sp = inactiveSailpointByName.get(spName.toLowerCase());
    if (!sp) continue;
    addIssue(role, {
      connectionType: 'SailPoint role',
      detail: spName,
      status: String(sp.status || 'Inactive').trim() || 'Inactive',
      field: 'sailpointRole',
    });
  }

  return [...byRoleId.values()].sort((a, b) =>
    String(a.role.rbacCode || '').localeCompare(String(b.role.rbacCode || ''), undefined, {
      sensitivity: 'base',
    })
  );
}

/**
 * Token document-frequency over SailPoint catalog role names. Used to weight
 * specialty-token matches when suggesting an active replacement for a
 * non-requestable role.
 */
function buildSailpointNameDocFrequency(sailpointCatalogRows) {
  const df = new Map();
  let docs = 0;
  for (const r of sailpointCatalogRows || []) {
    const set = new Set(
      normalizeMatchText(r.sailpointRole)
        .split(/[^a-z0-9]+/g)
        .filter(Boolean)
    );
    if (!set.size) continue;
    docs += 1;
    for (const t of set) df.set(t, (df.get(t) || 0) + 1);
  }
  return { df, docs };
}

function sailpointNameTokenSet(value) {
  return new Set(
    normalizeMatchText(value)
      .split(/[^a-z0-9]+/g)
      .filter(Boolean)
  );
}

function sailpointDistinctiveTokens(value, dfCtx, maxFraction = 0.12) {
  const out = new Set();
  if (!dfCtx.docs) return out;
  const limit = Math.max(2, Math.floor(dfCtx.docs * maxFraction));
  for (const t of sailpointNameTokenSet(value)) {
    if (t.length < 2) continue;
    if (/^\d+$/.test(t)) continue;
    if ((dfCtx.df.get(t) || 0) <= limit) out.add(t);
  }
  return out;
}

function sailpointSpecialtyTokens(value, dfCtx, maxFraction = 0.04) {
  const out = new Set();
  if (!dfCtx.docs) return out;
  const limit = Math.max(2, Math.floor(dfCtx.docs * maxFraction));
  for (const t of sailpointNameTokenSet(value)) {
    if (t.length < 3) continue;
    if (/^\d+$/.test(t)) continue;
    if ((dfCtx.df.get(t) || 0) <= limit) out.add(t);
  }
  return out;
}

function sailpointTokenIdf(token, dfCtx) {
  return Math.log((dfCtx.docs + 1) / ((dfCtx.df.get(token) || 0) + 1));
}

function jaccardOfSets(a, b) {
  if (!a.size || !b.size) return 0;
  let inter = 0;
  for (const x of a) if (b.has(x)) inter += 1;
  return inter / (a.size + b.size - inter);
}

function templateTokenIntersect(aTokens, bTokens) {
  if (!aTokens.length || !bTokens.length) return 0;
  const aSet = new Set(aTokens.map((t) => t.toLowerCase()));
  let inter = 0;
  for (const t of bTokens) if (aSet.has(t.toLowerCase())) inter += 1;
  return inter;
}

/** Drop "no subtemplate" sentinel and tokenize template id strings. */
function splitTemplateIdsForMatch(value) {
  const s = String(value || '').trim();
  if (!s || s.toLowerCase() === 'no subtemplate') return [];
  return splitTemplateIdTokens(s).filter(
    (t) => t && t.toLowerCase() !== 'no subtemplate' && t.toLowerCase() !== 'no' && t.toLowerCase() !== 'subtemplate'
  );
}

/** True when token sets are equal (case-insensitive, order-independent). */
function templateIdSetsEqual(a, b) {
  if (a.length !== b.length) return false;
  const aSet = new Set(a.map((t) => t.toLowerCase()));
  for (const t of b) if (!aSet.has(t.toLowerCase())) return false;
  return true;
}

/**
 * True when the candidate's name tokens are a strict, non-trivial subset of
 * the source's - i.e., the candidate is a more-generic version of the source
 * role family (e.g. "Epic Mosaic Nurse Practitioner" relative to
 * "Epic Mosaic Nurse Practitioner - Anesthesia"). Used to allow such a
 * candidate as a fallback even when no specialty-token match exists.
 */
function isGenericNameSubset(sourceTokens, candTokens) {
  if (!candTokens || candTokens.size < 3) return false;
  if (!sourceTokens || candTokens.size >= sourceTokens.size) return false;
  for (const t of candTokens) {
    if (!sourceTokens.has(t)) return false;
  }
  return true;
}

/**
 * Strict template/subtemplate match required for a SailPoint candidate to be
 * considered a replacement for a non-requestable role. Both template-id sets
 * and subtemplate-id sets must match exactly (after stripping the
 * "No Subtemplate" sentinel); an empty set on one side must match an empty set
 * on the other.
 */
function sailpointReplacementTemplateMatch(jobTemplates, jobSubtemplates, candTemplates, candSubtemplates) {
  if (jobTemplates.length === 0) return false;
  if (!templateIdSetsEqual(jobTemplates, candTemplates)) return false;
  if (!templateIdSetsEqual(jobSubtemplates, candSubtemplates)) return false;
  return true;
}

const SAILPOINT_REPLACEMENT_MIN_SCORE = 1.0;

/**
 * Best active (requestable=TRUE, status=Active) SailPoint role to replace an
 * inactive (non-requestable) one. Candidates MUST share the exact same
 * template-id and subtemplate-id sets as the job category - this guarantees
 * the suggested role is requestable in the same template context that the job
 * category is configured for. Among template-matched candidates, scoring then
 * favors shared rare specialty tokens by IDF so that "Burn Medicine" doesn't
 * get mapped to an unrelated specialty just because both share "Medicine".
 *
 * Returns the suggested catalog row, or null if no candidate matches the
 * template/subtemplate signature and clears the specialty bar (signals that
 * manual mapping is needed).
 */
export function suggestActiveSailpointReplacement(
  inactiveRow,
  category,
  activeCatalogRows,
  dfCtx
) {
  const inactiveName = String(inactiveRow?.sailpointRole || '').trim();
  if (!inactiveName) return null;
  const inactiveLc = inactiveName.toLowerCase();

  const jobTemplates = splitTemplateIdsForMatch(category?.linkableTemplateId);
  const jobSubtemplates = splitTemplateIdsForMatch(category?.subtemplatesId);
  if (jobTemplates.length === 0) return null;

  const inactiveNameTokens = sailpointNameTokenSet(inactiveName);
  const jobCategoryNameTokens = sailpointNameTokenSet(category?.jobCategoryName);
  const inactiveDistinct = sailpointDistinctiveTokens(inactiveName, dfCtx).size
    ? sailpointDistinctiveTokens(inactiveName, dfCtx)
    : sailpointDistinctiveTokens(category?.jobCategoryName, dfCtx);
  const inactiveSpecialty = new Set([
    ...sailpointSpecialtyTokens(inactiveName, dfCtx),
    ...sailpointSpecialtyTokens(category?.jobCategoryName, dfCtx),
  ]);
  let specialtyIdfMax = 0;
  for (const t of inactiveSpecialty) {
    const idf = sailpointTokenIdf(t, dfCtx);
    if (idf > specialtyIdfMax) specialtyIdfMax = idf;
  }

  let best = null;
  let bestScore = -Infinity;

  for (const cand of activeCatalogRows) {
    const candName = String(cand.sailpointRole || '').trim();
    if (!candName || candName.toLowerCase() === inactiveLc) continue;

    const candTemplates = splitTemplateIdsForMatch(cand.templates);
    const candSubs = splitTemplateIdsForMatch(cand.subtemplates);
    if (!sailpointReplacementTemplateMatch(jobTemplates, jobSubtemplates, candTemplates, candSubs)) {
      continue;
    }

    const candNameTokens = sailpointNameTokenSet(candName);
    // A "generic" candidate (e.g. "Epic Mosaic Nurse Practitioner") whose name
    // tokens are a strict subset of the source's gets through without sharing
    // the source's specialty token, since it's intentionally a catch-all role.
    const isGeneric = isGenericNameSubset(inactiveNameTokens, candNameTokens);

    const candDistinct = sailpointDistinctiveTokens(candName, dfCtx);
    let sharedDistinct = 0;
    let sharedIdf = 0;
    for (const t of inactiveDistinct) {
      if (candDistinct.has(t)) {
        sharedDistinct += 1;
        sharedIdf += sailpointTokenIdf(t, dfCtx);
      }
    }
    if (!isGeneric) {
      if (inactiveDistinct.size > 0 && sharedDistinct === 0) continue;
      if (specialtyIdfMax > 0 && sharedIdf < specialtyIdfMax * 0.85) continue;
    }

    const nameOverlap = jaccardOfSets(inactiveNameTokens, candNameTokens);
    const catNameOverlap = jaccardOfSets(jobCategoryNameTokens, candNameTokens);

    const score = 2.0 * sharedIdf + 1.5 * nameOverlap + 0.75 * catNameOverlap;

    if (score > bestScore) {
      bestScore = score;
      best = cand;
    }
  }
  if (!best || bestScore < SAILPOINT_REPLACEMENT_MIN_SCORE) return null;
  return best;
}

function isRequestableActiveSailpointCatalogRow(row) {
  return (
    String(row?.requestable || '').trim().toUpperCase() === 'TRUE' &&
    String(row?.status || 'Active').trim().toLowerCase() !== 'inactive'
  );
}

/**
 * Best active job category to reassign RBAC roles to when the source category
 * uses a non-requestable SailPoint role. Candidates must map to a requestable
 * catalog role; scoring favors template/subtemplate/training-track overlap (same
 * as inactivate-and-reassign), with a boost when SailPoint matches
 * suggestedActiveSailpointRole.
 */
export function suggestReassignJobCategory(
  sourceCategory,
  jobCategories,
  sailpointCatalogRows,
  suggestedActiveSailpointRole = ''
) {
  if (!sourceCategory) return '';

  const catalogByLc = new Map();
  for (const row of sailpointCatalogRows || []) {
    const key = String(row?.sailpointRole || '').trim().toLowerCase();
    if (!key || catalogByLc.has(key)) continue;
    catalogByLc.set(key, row);
  }

  const suggestedLc = String(suggestedActiveSailpointRole || '').trim().toLowerCase();
  const sourceNameLc = String(sourceCategory.jobCategoryName || '').trim().toLowerCase();

  const candidates = (jobCategories || []).filter((c) => {
    if (!c) return false;
    const nameLc = String(c.jobCategoryName || '').trim().toLowerCase();
    if (!nameLc || nameLc === sourceNameLc) return false;
    if (String(c.status || 'Active').trim() === 'Inactive') return false;
    const spLc = String(c.sailpointRole || '').trim().toLowerCase();
    if (!spLc) return false;
    const spRow = catalogByLc.get(spLc);
    return spRow && isRequestableActiveSailpointCatalogRow(spRow);
  });

  const ranked = rankReplacementCategories(sourceCategory, candidates, {
    limit: 25,
    requirePrimarySignal: true,
  });

  if (ranked.length) {
    const boosted = ranked.map((r) => {
      let score = r.score;
      const spLc = String(r.category.sailpointRole || '').trim().toLowerCase();
      if (suggestedLc && spLc === suggestedLc) score += 5;
      return { ...r, score };
    });
    boosted.sort((a, b) => {
      if (b.score !== a.score) return b.score - a.score;
      return String(a.category.jobCategoryName || '').localeCompare(
        String(b.category.jobCategoryName || ''),
        undefined,
        { sensitivity: 'base' }
      );
    });
    return String(boosted[0].category.jobCategoryName || '').trim();
  }

  if (suggestedLc) {
    const sailpointMatch = candidates.find(
      (c) => String(c.sailpointRole || '').trim().toLowerCase() === suggestedLc
    );
    if (sailpointMatch) return String(sailpointMatch.jobCategoryName || '').trim();
  }

  return '';
}

/** Display label for organization job category scope. */
export function formatJobCategoryScopeLabel(categoryLike) {
  if (isJobCategoryExcludedFromOrgScope(categoryLike)) return 'Not in scope';
  const raw = String(categoryLike?.organizationJobCategoryScope || '').trim();
  if (!raw) return 'In scope';
  if (/not\s+in\s+scope/i.test(raw)) return 'Not in scope';
  if (/in\s+scope/i.test(raw)) return 'In scope';
  return raw;
}

/**
 * Job categories whose assigned Sailpoint role exists in the catalog but is
 * marked `requestable=FALSE`. For each row, also compute whether the
 * category's template/subtemplate IDs match the catalog row's, and suggest
 * the closest active (`requestable=TRUE`, `status=Active`) replacement.
 *
 * Includes active/inactive and in-scope/out-of-scope categories.
 */
export function reportJobCategoriesLinkedToNonRequestableSailpoint(
  jobCategories,
  sailpointCatalogRows,
  roles = []
) {
  const categories = (jobCategories || []).filter((cat) => cat != null);
  const rbacCodeCountByCategoryName = buildRbacCodeCountByJobCategoryName(roles);
  const catalog = sailpointCatalogRows || [];
  const catalogByLc = new Map();
  for (const row of catalog) {
    const key = String(row?.sailpointRole || '').trim().toLowerCase();
    if (!key) continue;
    if (!catalogByLc.has(key)) catalogByLc.set(key, row);
  }
  const activeCatalogRows = catalog.filter(
    (r) =>
      String(r?.requestable || '').trim().toUpperCase() === 'TRUE' &&
      String(r?.status || 'Active').trim().toLowerCase() !== 'inactive'
  );
  const dfCtx = buildSailpointNameDocFrequency(catalog);

  const out = [];
  for (const cat of categories) {
    const name = String(cat.sailpointRole || '').trim();
    if (!name) continue;
    const row = catalogByLc.get(name.toLowerCase());
    if (!row) continue;
    if (String(row.requestable || '').trim().toUpperCase() !== 'FALSE') continue;

    const jobTemplates = splitTemplateIdsForMatch(cat.linkableTemplateId);
    const jobSubtemplates = splitTemplateIdsForMatch(cat.subtemplatesId);
    const spTemplates = splitTemplateIdsForMatch(row.templates);
    const spSubtemplates = splitTemplateIdsForMatch(row.subtemplates);

    const tInter = templateTokenIntersect(jobTemplates, spTemplates);
    const sInter = templateTokenIntersect(jobSubtemplates, spSubtemplates);
    const templateMatch =
      jobTemplates.length > 0 &&
      tInter === jobTemplates.length &&
      tInter === spTemplates.length &&
      (jobSubtemplates.length === 0 ||
        (sInter === jobSubtemplates.length && sInter === spSubtemplates.length));

    const suggestion = suggestActiveSailpointReplacement(
      row,
      cat,
      activeCatalogRows,
      dfCtx
    );
    const suggestedActiveSailpointRole = suggestion?.sailpointRole || '';
    const suggestedReassignJobCategory = suggestReassignJobCategory(
      cat,
      categories,
      catalog,
      suggestedActiveSailpointRole
    );

    const categoryName = String(cat.jobCategoryName || '').trim();
    out.push({
      category: cat,
      sailpointRoleRow: row,
      sailpointRole: row.sailpointRole,
      requestable: row.requestable || 'FALSE',
      categoryStatus: String(cat.status || 'Active').trim() || 'Active',
      organizationScope: formatJobCategoryScopeLabel(cat),
      rbacCodeCount: rbacCodeCountByCategoryName.get(categoryName) || 0,
      jobCategoryTemplateIds: String(cat.linkableTemplateId || '').trim(),
      jobCategorySubtemplateIds: String(cat.subtemplatesId || '').trim(),
      sailpointTemplate: String(row.templates || '').trim(),
      sailpointSubtemplate: String(row.subtemplates || '').trim(),
      templateMatch,
      suggestedActiveSailpointRole,
      suggestedReassignJobCategory,
    });
  }
  out.sort((a, b) =>
    String(a.category.jobCategoryId || '').localeCompare(
      String(b.category.jobCategoryId || ''),
      undefined,
      { numeric: true }
    )
  );
  return out;
}

/**
 * Active in-scope job categories: SER needed but no blueprint ID.
 */
export function reportJobCategoriesMissingBlueprintWhenSer(jobCategories) {
  return filterJobCategoriesForAdminReports(jobCategories).filter((c) => {
    const ser = String(c.needSER || '').trim().toLowerCase();
    if (ser === 'no') return false;
    return !String(c.blueprintId || '').trim();
  });
}

/**
 * Active in-scope job categories not referenced by any RBAC role’s Job Category field (exact trimmed string match).
 */
export function reportJobCategoriesWithNoRoles(roles, jobCategories) {
  const cats = filterJobCategoriesForAdminReports(jobCategories);
  const referenced = new Set(
    (roles || [])
      .map((r) => String(r.jobCategory || '').trim())
      .filter(Boolean)
  );
  const out = [];
  for (const c of cats) {
    const name = String(c.jobCategoryName || '').trim();
    if (!name) continue;
    if (!referenced.has(name)) out.push(c);
  }
  out.sort((a, b) =>
    String(a.jobCategoryName || '').localeCompare(String(b.jobCategoryName || ''), undefined, { sensitivity: 'base' })
  );
  return out;
}

/**
 * Active roles: job category assigns a Sailpoint role but role row is blank or differs.
 * Only considers active in-scope job categories when resolving the category row.
 */
export function reportRolesSailpointDriftFromCategory(roles, jobCategories) {
  const byName = new Map(
    filterJobCategoriesForAdminReports(jobCategories).map((c) => [String(c.jobCategoryName || '').trim(), c])
  );
  const out = [];
  for (const role of roles || []) {
    if ((role.status || 'Active') === 'Inactive') continue;
    const name = String(role.jobCategory || '').trim();
    if (!name) continue;
    const cat = byName.get(name);
    if (!cat) continue;
    const catSp = String(cat.sailpointRole || '').trim();
    if (!catSp) continue;
    const roleSp = String(role.sailpointRole || '').trim();
    if (!roleSp || roleSp.toLowerCase() !== catSp.toLowerCase()) {
      out.push({ role, category: cat, categorySailpoint: catSp, roleSailpoint: roleSp || '—' });
    }
  }
  return out;
}

/** Minimum fuzzy score to treat a suggestion as worth showing (filters unrelated token overlap). */
export const SAILPOINT_CANDIDATE_MIN_DISPLAY_SCORE = 0.12;

/** Top candidate at or above this score is treated as a likely typo / slight variation for scenario text. */
export const SAILPOINT_CANDIDATE_CONFIDENT_SCORE = 0.55;

/** If #1 and #2 are within this gap and both ≥ min display, row is flagged ambiguous for reviewers. */
export const SAILPOINT_CANDIDATE_AMBIGUOUS_PAIR_GAP = 0.08;

function normalizeMatchText(value) {
  let s = String(value ?? '');
  try {
    s = s.normalize('NFKC');
  } catch (_) {
    /* ignore */
  }
  return s
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .replace(/[\u2010-\u2015\u2212\uFE58\uFE63\uFF0D]/g, '-')
    .replace(/[\u00A0\u2000-\u200A\u202F\u205F\u3000]/g, ' ')
    .replace(/[''`´]/g, "'")
    .replace(/\s*([,/;])\s*/g, '$1 ')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ');
}

function canonicalizeMatchText(value) {
  return normalizeMatchText(value).replace(/[^a-z0-9]+/g, '');
}

function tokenSet(value) {
  const parts = normalizeMatchText(value)
    .split(/[^a-z0-9]+/g)
    .map((t) => t.trim())
    .filter(Boolean);
  return new Set(parts);
}

function jaccardScore(aSet, bSet) {
  if (!aSet.size || !bSet.size) return 0;
  let inter = 0;
  for (const x of aSet) if (bSet.has(x)) inter += 1;
  const union = aSet.size + bSet.size - inter;
  return union > 0 ? inter / union : 0;
}

/**
 * Score one catalog name against a source string; includes reviewer-oriented reason codes.
 * @returns {{ sailpointRole: string, score: number, reasonCodes: string[], reasonLabels: string[], tokenScore: number, canonBonus: number, prefixBonus: number, belowDisplayThreshold: boolean } | null}
 */
export function scoreSailpointCandidateMatch(sourceValue, sailpointRoleName) {
  const name = String(sailpointRoleName || '').trim();
  const srcNorm = normalizeMatchText(sourceValue);
  const n = normalizeMatchText(name);
  if (!srcNorm || !n) return null;

  const srcCanon = canonicalizeMatchText(sourceValue);
  const c = canonicalizeMatchText(name);
  const srcTokens = tokenSet(sourceValue);
  const t = tokenSet(name);

  const reasonCodes = [];
  const reasonLabels = [];
  const pushReason = (code, label) => {
    if (!reasonCodes.includes(code)) {
      reasonCodes.push(code);
      reasonLabels.push(label);
    }
  };

  if (srcNorm === n) {
    pushReason('EXACT_NORM', 'Exact match after normalization (spacing, case, dash style)');
    return {
      sailpointRole: name,
      score: 1,
      reasonCodes,
      reasonLabels,
      tokenScore: 1,
      canonBonus: 0,
      prefixBonus: 0,
      belowDisplayThreshold: false,
    };
  }

  if (srcCanon && c && srcCanon === c) {
    pushReason('CANON_EQUIV', 'Same letters and digits as a catalog name; punctuation or spacing differs');
    return {
      sailpointRole: name,
      score: 0.99,
      reasonCodes,
      reasonLabels,
      tokenScore: jaccardScore(srcTokens, t),
      canonBonus: 0,
      prefixBonus: 0,
      belowDisplayThreshold: false,
    };
  }

  const tokenScore = jaccardScore(srcTokens, t);
  let canonBonus = 0;
  let prefixBonus = 0;

  if (srcCanon && c && (srcCanon.includes(c) || c.includes(srcCanon))) {
    canonBonus = 0.2;
    pushReason('CANON_SUBSTRING', 'One canonical string contains the other (possible truncation or suffix)');
  }
  if (n.startsWith(srcNorm) || srcNorm.startsWith(n)) {
    prefixBonus = 0.1;
    pushReason('PREFIX_ALIGN', 'Normalized strings share a prefix/suffix (one extends the other)');
  }
  if (tokenScore >= 0.45) {
    pushReason('TOKEN_HIGH', 'High token overlap (Jaccard)');
  } else if (tokenScore >= 0.22) {
    pushReason('TOKEN_MED', 'Moderate token overlap (Jaccard)');
  } else if (tokenScore > 0) {
    pushReason('TOKEN_LOW', 'Low token overlap (Jaccard)');
  }

  const score = Math.min(1, tokenScore + canonBonus + prefixBonus);
  const belowDisplayThreshold = score > 0 && score < SAILPOINT_CANDIDATE_MIN_DISPLAY_SCORE;
  if (belowDisplayThreshold) {
    pushReason('BELOW_DISPLAY_MIN', `Score under display minimum (${SAILPOINT_CANDIDATE_MIN_DISPLAY_SCORE})`);
  }
  if (score === 0) return null;

  return {
    sailpointRole: name,
    score,
    reasonCodes,
    reasonLabels,
    tokenScore,
    canonBonus,
    prefixBonus,
    belowDisplayThreshold,
  };
}

/**
 * Best SailPoint catalog names for a non-catalog RBAC value, sorted by score.
 * @param {number} max Max suggestions after filtering (default 3).
 * @param {{ minDisplayScore?: number, includeBelowMinAsFallback?: boolean }} [options]
 */
export function closestSailpointCandidates(sourceValue, sailpointNames, max = 3, options = {}) {
  const minDisplay = options.minDisplayScore ?? SAILPOINT_CANDIDATE_MIN_DISPLAY_SCORE;
  const includeFallback = options.includeBelowMinAsFallback !== false;

  const srcNorm = normalizeMatchText(sourceValue);
  if (!srcNorm) return [];

  const scored = [];
  for (const sp of sailpointNames) {
    const row = scoreSailpointCandidateMatch(sourceValue, sp);
    if (row) scored.push(row);
  }
  scored.sort((a, b) => b.score - a.score || a.sailpointRole.localeCompare(b.sailpointRole));

  const strong = scored.filter((r) => r.score >= minDisplay);
  if (strong.length >= max || !includeFallback) {
    return strong.slice(0, max);
  }
  if (strong.length > 0) {
    const need = max - strong.length;
    const weak = scored.filter((r) => r.score < minDisplay).slice(0, need);
    return [...strong, ...weak];
  }
  return scored.slice(0, max);
}

function buildSailpointReconciliationReviewReason(ctx, candidates) {
  const { duplicateMismatch, looksPlaceholder, scenario } = ctx;
  if (duplicateMismatch || looksPlaceholder) {
    return 'Duplicate RBAC value or placeholder text; fix data before fuzzy suggestions apply.';
  }
  if (!candidates.length) {
    return 'No catalog candidates above the display score threshold; pick manually or add a SailPoint role.';
  }
  const top = candidates[0];
  const ambiguousPair =
    candidates.length >= 2 &&
    top.score - candidates[1].score < SAILPOINT_CANDIDATE_AMBIGUOUS_PAIR_GAP &&
    candidates[1].score >= SAILPOINT_CANDIDATE_MIN_DISPLAY_SCORE;

  if (top.score < SAILPOINT_CANDIDATE_MIN_DISPLAY_SCORE) {
    return 'Only weak token overlap with catalog; suggestions are best-effort — verify carefully.';
  }
  if (scenario === 'slight_name_variation') {
    if (ambiguousPair) {
      return `Strong top match (score ≥ ${SAILPOINT_CANDIDATE_CONFIDENT_SCORE}), but second choice is very close — confirm the correct catalog row.`;
    }
    return `Strong match (score ≥ ${SAILPOINT_CANDIDATE_CONFIDENT_SCORE}); likely spelling or punctuation drift.`;
  }
  if (ambiguousPair || scenario === 'ambiguous_close_scores') {
    return 'Ambiguous: top two candidates are close in score; compare names before mapping.';
  }
  return 'Manual review required (ambiguous, placeholder, or no exact SailPoint row match).';
}

/**
 * Reconciliation report for Job Categories vs Sailpoint Roles.
 * Primary focus: RBAC job category Sailpoint values not present in Sailpoint catalog.
 * Secondary: Sailpoint catalog entries not referenced by any in-scope active job category.
 */
export function reportJobCategorySailpointReconciliation(jobCategories, sailpointCatalogRows) {
  const categories = filterJobCategoriesForAdminReports(jobCategories);
  const requestableByRole = new Map();
  const sailpointNames = [...new Set(
    (sailpointCatalogRows || [])
      .map((r) => {
        const name = String(r.sailpointRole || '').trim();
        if (name && !requestableByRole.has(name)) {
          requestableByRole.set(name, String(r.requestable || '').trim());
        }
        return name;
      })
      .filter(Boolean)
  )];
  const catalogByNorm = new Set(sailpointNames.map((n) => normalizeMatchText(n)));
  const catalogCanonSet = new Set(sailpointNames.map((n) => canonicalizeMatchText(n)));

  const mismatchCounts = new Map();
  const rbacRows = [];
  for (const c of categories) {
    const source = String(c.sailpointRole || '').trim();
    if (!source) continue;
    const norm = normalizeMatchText(source);
    const canon = canonicalizeMatchText(source);
    if (catalogByNorm.has(norm) || (canon && catalogCanonSet.has(canon))) continue;
    mismatchCounts.set(norm, (mismatchCounts.get(norm) || 0) + 1);
    rbacRows.push({ category: c, sourceRole: source, sourceRoleNorm: norm });
  }

  const rbacNotInSailpoint = rbacRows.map((row) => {
    const candidates = closestSailpointCandidates(row.sourceRole, sailpointNames, 3);
    const duplicateMismatch = (mismatchCounts.get(row.sourceRoleNorm) || 0) > 1;
    const looksPlaceholder = /^(na|n\/a|none|unknown|tbd|null|-+)$/i.test(row.sourceRole);
    let scenario = 'needs_manual_review';
    let recommendedAction = 'Map to a valid SailPoint role (or add to SailPoint catalog if intentional).';
    if (duplicateMismatch || looksPlaceholder) {
      scenario = 'duplicate_or_erroneous';
      recommendedAction = 'Inactivate duplicate/erroneous category row, or clear and remap to a valid SailPoint role.';
    } else if (candidates[0] && candidates[0].score >= SAILPOINT_CANDIDATE_CONFIDENT_SCORE) {
      scenario = 'slight_name_variation';
      recommendedAction = `Map to "${candidates[0].sailpointRole}".`;
    } else if (
      candidates.length >= 2 &&
      candidates[0].score - candidates[1].score < SAILPOINT_CANDIDATE_AMBIGUOUS_PAIR_GAP &&
      candidates[1].score >= SAILPOINT_CANDIDATE_MIN_DISPLAY_SCORE
    ) {
      scenario = 'ambiguous_close_scores';
      recommendedAction = `Compare top candidates (e.g. "${candidates[0].sailpointRole}" vs "${candidates[1].sailpointRole}") before updating the category.`;
    }
    const reviewReason = buildSailpointReconciliationReviewReason(
      { duplicateMismatch, looksPlaceholder, scenario },
      candidates
    );
    return {
      category: row.category,
      sourceRole: row.sourceRole,
      scenario,
      recommendedAction,
      reviewReason,
      candidates,
      duplicateCount: mismatchCounts.get(row.sourceRoleNorm) || 1,
    };
  });

  const rbacReferencedNorm = new Set(
    categories
      .map((c) => normalizeMatchText(c.sailpointRole || ''))
      .filter(Boolean)
  );
  const rbacReferencedCanon = new Set(
    categories
      .map((c) => canonicalizeMatchText(c.sailpointRole || ''))
      .filter(Boolean)
  );
  const sailpointNotInRbac = sailpointNames
    .filter((name) => {
      const n = normalizeMatchText(name);
      const c = canonicalizeMatchText(name);
      if (rbacReferencedNorm.has(n)) return false;
      if (c && rbacReferencedCanon.has(c)) return false;
      return true;
    })
    .map((name) => ({
      sailpointRole: name,
      requestable: requestableByRole.get(name) || '',
      recommendedAction: 'Decide whether to add this role to RBAC mapping, or ignore if not needed.',
    }));

  return {
    rbacNotInSailpoint,
    sailpointNotInRbac,
    summary: {
      totalInScopeCategories: categories.length,
      totalCatalogRoles: sailpointNames.length,
      rbacMismatchCount: rbacNotInSailpoint.length,
      sailpointUnusedCount: sailpointNotInRbac.length,
    },
  };
}

/** Compared for merge detection; description + job category name + assigned Job Category ID excluded; storage row id + last-edit excluded as metadata. */
const JOB_CATEGORY_MERGE_KEYS = [
  'organizationJobCategoryScope',
  'owningApplication',
  'impactedApplications',
  'owningWorkgroup',
  'otherInterestedWorkgroups',
  'needEMP',
  'needSER',
  'linkableTemplateId',
  'linkableTemplateName',
  'subtemplatesId',
  'subtemplatesName',
  'blueprintId',
  'blueprintName',
  'trainingTrack1',
  'trainingTrack2',
  'trainingTrack3',
  'trainingTrack4',
  'trainingTrack5',
  'trainingTrack6',
  'preLiveDayInTheLifeActivity',
  'postLiveDayInTheLifeActivity',
  'userSettingsLab',
  'sailpointRole',
  'sailpointRoleReview',
  'status',
];

/** At least one non-empty value here avoids reporting sparse “all blank” twins as merge candidates. */
const MERGE_SPECIFICITY_KEYS = [
  'blueprintId',
  'blueprintName',
  'linkableTemplateId',
  'linkableTemplateName',
  'subtemplatesId',
  'subtemplatesName',
  'trainingTrack1',
  'trainingTrack2',
  'trainingTrack3',
  'trainingTrack4',
  'trainingTrack5',
  'trainingTrack6',
];

function categoryHasMergeSpecificity(cat) {
  if (!cat) return false;
  return MERGE_SPECIFICITY_KEYS.some((k) => String(cat[k] ?? '').trim() !== '');
}

function normalizeMergeScalar(v) {
  return String(v ?? '')
    .trim()
    .replace(/\r\n/g, '\n')
    .replace(/\s+/g, ' ')
    .toLowerCase();
}

/**
 * Stable fingerprint of merge keys: substantive columns except description, job category name, and assigned Job Category
 * ID; storage UUID and last-edit stamp not included.
 */
export function jobCategoryMergeFingerprint(cat) {
  return JOB_CATEGORY_MERGE_KEYS.map((k) => `${k}=${normalizeMergeScalar(cat[k])}`).join('\x1e');
}

const MERGE_CLUSTER_REASON = 'identical_except_name_and_description';

const MERGE_REASON_LABELS = {
  [MERGE_CLUSTER_REASON]:
    'Compared columns match except job category name, description, and assigned Job Category ID (storage row id and last-edit excluded); cluster has blueprint, template/subtemplate, or training track data',
};

function numericJobCategoryId(c) {
  const m = String(c?.jobCategoryId || '').match(/\d+/);
  return m ? parseInt(m[0], 10) : Number.MAX_SAFE_INTEGER;
}

function pickExactNameByMajority(namesTrim) {
  const counts = new Map();
  for (const n of namesTrim) {
    counts.set(n, (counts.get(n) || 0) + 1);
  }
  let best = namesTrim[0] || '';
  let bestC = -1;
  for (const [n, c] of counts) {
    if (c > bestC || (c === bestC && n.length > best.length)) {
      bestC = c;
      best = n;
    }
  }
  return best;
}

/**
 * Suggested single job category name after merging a cluster: if names match ignoring case, use the most common exact
 * spelling (ties → longer string). Otherwise prefer an Active row, then lowest numeric job category id.
 */
export function suggestMergedJobCategoryNameForCluster(categories) {
  const list = (categories || []).filter(Boolean);
  if (!list.length) return '';

  const namesTrim = list.map((c) => String(c.jobCategoryName || '').trim()).filter(Boolean);
  const uniqueNorms = new Set(namesTrim.map((n) => n.toLowerCase()));

  if (uniqueNorms.size <= 1 && namesTrim.length) {
    return pickExactNameByMajority(namesTrim);
  }

  const sorted = [...list].sort((a, b) => {
    const aIn = (a.status || 'Active') === 'Inactive';
    const bIn = (b.status || 'Active') === 'Inactive';
    if (aIn !== bIn) return aIn ? 1 : -1;
    const na = numericJobCategoryId(a);
    const nb = numericJobCategoryId(b);
    if (na !== nb) return na - nb;
    return String(a.jobCategoryName || '').localeCompare(String(b.jobCategoryName || ''));
  });
  return String(sorted[0].jobCategoryName || '').trim() || '';
}

/**
 * Clusters of job categories that may be duplicates: same values on every compared column (job category name, description,
 * and assigned Job Category ID excluded; storage UUID and last-edit excluded). Only active, in-org-scope categories.
 * Values are normalized (trim, collapse whitespace, case-insensitive). Drops clusters with no blueprint, template/
 * subtemplate, or training track text (reduces empty-metadata false positives). Each cluster includes
 * suggestedJobCategoryName and alternateJobCategoryNames.
 */
export function reportJobCategoryMergeClusters(jobCategories) {
  const cats = filterJobCategoriesForAdminReports(jobCategories || []).filter((c) => c != null && c.id != null);
  if (cats.length < 2) return [];

  const byFp = new Map();
  for (const c of cats) {
    const fp = jobCategoryMergeFingerprint(c);
    if (!byFp.has(fp)) byFp.set(fp, []);
    byFp.get(fp).push(c);
  }

  const out = [];
  for (const list of byFp.values()) {
    if (list.length < 2) continue;
    if (!categoryHasMergeSpecificity(list[0])) continue;
    list.sort((a, b) =>
      String(a.jobCategoryId || '').localeCompare(String(b.jobCategoryId || ''), undefined, {
        numeric: true,
      })
    );
    const suggestedJobCategoryName = suggestMergedJobCategoryNameForCluster(list);
    const sugLc = suggestedJobCategoryName.toLowerCase();
    const alternateJobCategoryNames = [
      ...new Set(
        list
          .map((c) => String(c.jobCategoryName || '').trim())
          .filter((n) => n && n.toLowerCase() !== sugLc)
      ),
    ].join(' | ');
    out.push({
      reasons: [MERGE_CLUSTER_REASON],
      reasonLabels: [MERGE_REASON_LABELS[MERGE_CLUSTER_REASON]],
      categories: list,
      suggestedJobCategoryName,
      alternateJobCategoryNames,
    });
  }

  out.sort((a, b) => b.categories.length - a.categories.length);
  return out;
}

export function escapeCsvCell(val) {
  const s = String(val ?? '');
  if (/[",\r\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

export function downloadCsv(filename, headers, rows) {
  const lines = [headers.map(escapeCsvCell).join(',')];
  for (const row of rows) {
    lines.push(row.map(escapeCsvCell).join(','));
  }
  const blob = new Blob([`\ufeff${lines.join('\r\n')}`], { type: 'text/csv;charset=utf-8' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

function sanitizeSheetName(name) {
  // Excel sheet names: max 31 chars, no : \ / ? * [ ]
  const stripped = String(name || 'Sheet').replace(/[:\\/?*[\]]/g, ' ').trim();
  return (stripped || 'Sheet').slice(0, 31);
}

/**
 * Download a multi-sheet .xlsx workbook.
 * `sheets` is an array of `{ name, headers, rows }` where `rows` is an array
 * of cell arrays in the same order as `headers`.
 *
 * Uses the `xlsx` library (already a dependency for Excel import). Throws
 * a helpful error if the library is unavailable.
 */
export async function downloadXlsx(filename, sheets) {
  const list = Array.isArray(sheets) ? sheets.filter(Boolean) : [];
  if (!list.length) throw new Error('downloadXlsx: at least one sheet is required.');

  let XLSX;
  try {
    XLSX = await import('xlsx');
  } catch (err) {
    throw new Error('Excel export requires the "xlsx" package.');
  }

  const wb = XLSX.utils.book_new();
  const usedNames = new Set();
  for (const sheet of list) {
    let name = sanitizeSheetName(sheet.name);
    if (usedNames.has(name.toLowerCase())) {
      let suffix = 2;
      let candidate;
      do {
        const suffixStr = ` (${suffix})`;
        const base = String(sheet.name || 'Sheet').slice(0, 31 - suffixStr.length);
        candidate = sanitizeSheetName(`${base}${suffixStr}`);
        suffix += 1;
      } while (usedNames.has(candidate.toLowerCase()) && suffix < 100);
      name = candidate;
    }
    usedNames.add(name.toLowerCase());

    const headers = Array.isArray(sheet.headers) ? sheet.headers : [];
    const rows = Array.isArray(sheet.rows) ? sheet.rows : [];
    const aoa = [headers, ...rows.map((r) => (Array.isArray(r) ? r : []))];
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    if (headers.length) {
      ws['!cols'] = headers.map((h, i) => {
        let max = String(h ?? '').length;
        for (const row of rows) {
          const cell = row?.[i];
          if (cell == null) continue;
          const len = String(cell).length;
          if (len > max) max = len;
        }
        return { wch: Math.min(60, Math.max(10, max + 2)) };
      });
    }
    XLSX.utils.book_append_sheet(wb, ws, name);
  }

  const out = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
  const blob = new Blob([out], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}
