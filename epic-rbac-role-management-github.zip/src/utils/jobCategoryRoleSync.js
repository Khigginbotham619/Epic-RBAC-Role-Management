import {
  applyCategoryUpdatesToRole,
  buildCategoryByNameMap,
  categoryHasBlueprintReference,
  roleBelongsToCategory,
  roleMatchesJobCategory,
} from './fillBlanks';
import { INTEGRITY_FIELD_LABELS } from './integrityFixes';
import { parseLastEditTimestamp } from './lastEditStamp';
import { normalizeRoleId } from './roleIdUtils';

export { normalizeRoleId };

export const MS_24_HOURS = 24 * 60 * 60 * 1000;
/** Job categories edited within this window are eligible for role sync. */
export const SYNC_RECENT_EDIT_DAYS = 7;
export const MS_SYNC_RECENT_EDIT = SYNC_RECENT_EDIT_DAYS * 24 * 60 * 60 * 1000;

/** Sync only categories edited in the last week (review button default). */
export const SYNC_SCOPE_RECENT = 'recent';
/** Sync every job category against all assigned RBAC roles. */
export const SYNC_SCOPE_ALL = 'all';

const SYNC_FIELDS = [
  'jobCategory',
  'linkedRoleTemplateId',
  'linkedRoleTemplateName',
  'templateDisplayTitle',
  'subtemplateId',
  'subtemplateDescription',
  'empNeeded',
  'slaNeeded',
  'slaBlueprintId',
  'blueprintName',
  'trainingTrack',
  'trainingTrack2',
  'trainingTrack3',
  'trainingTrack4',
  'trainingTrack5',
  'trainingTrack6',
  'sailpointRole',
];

function s(v) {
  if (v == null) return '';
  return String(v).replace(/\u00a0/g, ' ').trim();
}

/** Readable label for a job category row (handles legacy keys and empty names). */
export function resolveJobCategoryDisplayName(category, roles = []) {
  if (!category) return '(Unnamed category)';

  const candidates = [
    category.jobCategoryName,
    category['Job Category Name'],
    category.job_category,
    category.description,
  ];
  for (const value of candidates) {
    const normalized = s(value);
    if (normalized) return normalized;
  }

  const matchingRoles = (roles || []).filter((role) => roleMatchesJobCategory(role, category));
  const fromRole = s(
    matchingRoles[0]?.jobCategory ??
    roles.find((role) => s(role?.jobCategory))?.jobCategory
  );
  if (fromRole) return fromRole;

  const id = s(category.jobCategoryId);
  if (id) return `Job Category ${id}`;

  return '(Unnamed category)';
}

/** Label for a sync review table row; never returns blank/whitespace-only text. */
export function formatCategorySyncRowLabel(row) {
  const direct = s(row?.displayName) || s(row?.categoryName);
  if (direct) return direct;
  return resolveJobCategoryDisplayName(row?.category, []);
}

/** Primary title + optional job category ID for sync review UI. */
export function formatCategorySyncRowDisplay(row) {
  const category = row?.category;
  const title = formatCategorySyncRowLabel(row);
  const categoryId = s(category?.jobCategoryId);
  const internalId = s(category?.id);
  const subtitleParts = [];
  if (categoryId) subtitleParts.push(`ID ${categoryId}`);
  if (internalId && internalId !== categoryId) subtitleParts.push(`Record ${internalId}`);
  return {
    title: title || '(Unnamed category)',
    subtitle: subtitleParts.join(' · '),
  };
}

function fieldLabel(field) {
  return INTEGRITY_FIELD_LABELS[field] || field;
}

function categoryEditAgeMs(cat) {
  const d = parseLastEditTimestamp(cat?.lastEditDateReasonInitials);
  if (!d) return null;
  return Date.now() - d.getTime();
}

/** True when lastEditDateReasonInitials is within the last 24 hours. */
export function isCategoryEditedInLast24Hours(cat) {
  const age = categoryEditAgeMs(cat);
  return age != null && age < MS_24_HOURS;
}

/** True when lastEditDateReasonInitials is within the sync lookback window (7 days). */
export function isCategoryEditedForSync(cat) {
  const age = categoryEditAgeMs(cat);
  return age != null && age < MS_SYNC_RECENT_EDIT;
}

function syncFieldDiffers(role, synced, field, category) {
  if (s(role?.[field]).toLowerCase() === s(synced?.[field]).toLowerCase()) return false;
  if (
    (field === 'slaBlueprintId' || field === 'blueprintName') &&
    !s(synced?.[field]) &&
    (s(role?.[field]) || categoryHasBlueprintReference(category))
  ) {
    return false;
  }
  return true;
}

export { buildCategoryByNameMap, roleBelongsToCategory };

function hasCategorySyncFieldChanges(role, synced, category) {
  for (const field of SYNC_FIELDS) {
    if (syncFieldDiffers(role, synced, field, category)) return true;
  }
  return false;
}

/**
 * Apply category-derived field updates onto roles. Only mutates roles whose values
 * actually differ (avoids re-stamping Last Edit when nothing changed).
 */
export function applyJobCategoryChangesToRoles(
  roles,
  changedCategories,
  {
    jobCategories = [],
    blueprints = [],
    templateLinks = [],
    previousNamesByCategoryId = {},
  } = {}
) {
  const categoryByName = buildCategoryByNameMap(jobCategories);
  const affectedIds = new Set();
  let updatedRoles = [...(roles || [])];

  for (const cat of changedCategories || []) {
    const previousCategoryName = previousNamesByCategoryId[cat.id];
    updatedRoles = updatedRoles.map((role) => {
      if (!roleBelongsToCategory(role, cat, categoryByName, { previousCategoryName })) return role;
      const synced = applyCategoryUpdatesToRole(role, cat, blueprints, templateLinks, {
        previousCategoryName,
        categoryByName,
      });
      if (!hasCategorySyncFieldChanges(role, synced, cat)) return role;
      affectedIds.add(normalizeRoleId(role.id));
      return synced;
    });
  }

  return { updatedRoles, affectedIds };
}

function buildRoleSyncEntry(role, category, blueprints, templateLinks, categoryByName) {
  if (!role?.id || !category) return null;
  if (!roleBelongsToCategory(role, category, categoryByName)) return null;

  const synced = applyCategoryUpdatesToRole(role, category, blueprints, templateLinks, {
    categoryByName,
  });
  const changes = [];
  for (const field of SYNC_FIELDS) {
    if (!syncFieldDiffers(role, synced, field, category)) continue;
    changes.push({
      field,
      label: fieldLabel(field),
      from: role[field] ?? '',
      to: synced[field] ?? '',
    });
  }
  if (changes.length === 0) return null;

  return {
    roleId: role.id,
    rbacCode: s(role.rbacCode) || role.id,
    categoryId: category.id,
    categoryName: resolveJobCategoryDisplayName(category, [role]),
    synced,
    changes,
  };
}

function categoryEligibleForSyncScope(category, scope) {
  if (scope === SYNC_SCOPE_ALL) {
    return !!s(category?.jobCategoryName ?? category?.description);
  }
  return isCategoryEditedForSync(category);
}

/**
 * Build a review plan for syncing RBAC roles from job categories.
 * @param {'recent'|'all'} scope - recent: edited in last 7 days; all: entire category table
 */
export function buildJobCategoryRoleSyncPlan({
  jobCategories = [],
  roles = [],
  blueprints = [],
  templateLinks = [],
  scope = SYNC_SCOPE_RECENT,
} = {}) {
  const syncScope = scope === SYNC_SCOPE_ALL ? SYNC_SCOPE_ALL : SYNC_SCOPE_RECENT;
  const categoriesToScan = (jobCategories || []).filter((cat) =>
    categoryEligibleForSyncScope(cat, syncScope)
  );
  const categorySummaries = [];
  const roleUpdates = [];
  const categoriesToSync = [];
  const seenCategoryIds = new Set();
  const categoryByName = buildCategoryByNameMap(jobCategories);

  for (const category of categoriesToScan) {
    const matchingRoles = (roles || []).filter((role) =>
      roleBelongsToCategory(role, category, categoryByName)
    );

    const entries = [];
    for (const role of matchingRoles) {
      const entry = buildRoleSyncEntry(role, category, blueprints, templateLinks, categoryByName);
      if (entry) entries.push(entry);
    }

    const displayName = resolveJobCategoryDisplayName(category, matchingRoles);
    categorySummaries.push({
      category,
      categoryName: displayName,
      displayName,
      lastEdit: s(category.lastEditDateReasonInitials),
      assignedRoleCount: matchingRoles.length,
      driftRoleCount: entries.length,
      roleCodes: entries.map((e) => e.rbacCode).sort(),
      roleEntries: entries,
    });

    if (entries.length > 0) {
      roleUpdates.push(...entries);
      if (!seenCategoryIds.has(category.id)) {
        seenCategoryIds.add(category.id);
        categoriesToSync.push(category);
      }
    }
  }

  const driftCategoryCount = categorySummaries.filter((row) => row.driftRoleCount > 0).length;

  return {
    scope: syncScope,
    recentCategoryCount: categorySummaries.length,
    categoriesScanned: categoriesToScan.length,
    driftCategoryCount,
    categorySummaries,
    roleUpdates,
    categoriesToSync,
    roleUpdateCount: roleUpdates.length,
  };
}

export function buildRoleSyncSelectionKey(roleId, field) {
  return `${String(roleId)}:${field}`;
}

/**
 * Re-map review UI selection keys onto a freshly built plan (same rbacCode + field).
 * Keeps user choices valid when the dialog plan is stale vs confirm-time data.
 */
export function remapRoleSyncSelectionToFreshPlan(originalPlan, freshPlan, selectedKeys) {
  if (!selectedKeys?.size) return new Set();
  const freshKeys = new Set();
  for (const update of freshPlan?.roleUpdates || []) {
    for (const change of update.changes || []) {
      freshKeys.add(buildRoleSyncSelectionKey(update.roleId, change.field));
    }
  }
  const remapped = new Set();
  for (const key of selectedKeys) {
    if (freshKeys.has(key)) {
      remapped.add(key);
      continue;
    }
    const [roleId, field] = String(key).split(':');
    const original = (originalPlan?.roleUpdates || []).find(
      (u) => normalizeRoleId(u.roleId) === normalizeRoleId(roleId)
    );
    if (!original || !(original.changes || []).some((c) => c.field === field)) continue;
    const fresh = (freshPlan?.roleUpdates || []).find(
      (u) =>
        s(u.rbacCode) === s(original.rbacCode) &&
        (u.changes || []).some((c) => c.field === field)
    );
    if (fresh) remapped.add(buildRoleSyncSelectionKey(fresh.roleId, field));
  }
  return remapped;
}

/** All pending field-change keys from a sync plan (selected by default in review UI). */
export function buildDefaultRoleSyncSelection(plan) {
  const keys = new Set();
  for (const update of plan?.roleUpdates || []) {
    for (const change of update.changes || []) {
      keys.add(buildRoleSyncSelectionKey(update.roleId, change.field));
    }
  }
  return keys;
}

/** Unique role ids that have at least one selected field change. */
export function countSelectedRoleSyncUpdates(selectedKeys) {
  const roleIds = new Set();
  for (const key of selectedKeys || []) {
    const roleId = String(key).split(':')[0];
    if (roleId) roleIds.add(roleId);
  }
  return roleIds.size;
}

/**
 * Merge selected sync plan updates onto the full roles array (does not persist).
 * @param {Set<string>|undefined} selectedKeys - `${roleId}:${field}` keys; all pending changes when omitted.
 */
export function applyJobCategoryRoleSyncPlan(roles, plan, editStamp, selectedKeys) {
  const applyAll = !selectedKeys;
  const fieldsByRoleId = new Map();

  for (const update of plan?.roleUpdates || []) {
    const roleId = normalizeRoleId(update.roleId);
    if (!roleId) continue;
    const fields = (update.changes || [])
      .map((change) => change.field)
      .filter((field) => applyAll || selectedKeys.has(buildRoleSyncSelectionKey(roleId, field)));
    if (fields.length === 0) continue;
    const existing = fieldsByRoleId.get(roleId);
    if (existing) {
      const mergedFields = [...new Set([...existing.fields, ...fields])];
      fieldsByRoleId.set(roleId, { synced: update.synced, fields: mergedFields });
    } else {
      fieldsByRoleId.set(roleId, { synced: update.synced, fields });
    }
  }

  if (fieldsByRoleId.size === 0) return roles || [];

  return (roles || []).map((role) => {
    const patch = fieldsByRoleId.get(normalizeRoleId(role.id));
    if (!patch) return role;
    const merged = { ...role };
    for (const field of patch.fields) {
      merged[field] = patch.synced[field];
    }
    return { ...merged, lastEditChangeControlDateReason: editStamp };
  });
}

/** Count roles whose data actually changed after applying a sync plan. */
export function countAppliedRoleSyncPatches(beforeRoles, afterRoles, selectedKeys) {
  const beforeById = new Map((beforeRoles || []).map((r) => [normalizeRoleId(r.id), r]));
  let count = 0;
  for (const role of afterRoles || []) {
    const id = normalizeRoleId(role.id);
    const prev = beforeById.get(id);
    if (!prev) continue;
    if (JSON.stringify(prev) !== JSON.stringify(role)) count += 1;
  }
  if (!selectedKeys?.size) return count;
  return count;
}

/** Count roles assigned to any of the given categories. */
export function countRolesForCategories(roles, changedCategories, jobCategories = []) {
  const categoryByName = buildCategoryByNameMap(jobCategories);
  return (roles || []).filter((role) =>
    (changedCategories || []).some((cat) => roleBelongsToCategory(role, cat, categoryByName))
  ).length;
}
