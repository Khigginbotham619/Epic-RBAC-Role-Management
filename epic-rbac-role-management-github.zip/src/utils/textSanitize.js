/**
 * Sanitize table/cell text: remove unreadable characters (replacement, mojibake) and normalize whitespace.
 * Use when displaying or storing data from imports/user input.
 * @param {*} str - Value to sanitize (string, number, or null/undefined).
 * @returns {string} Trimmed string with extra spaces collapsed and unreadable chars removed.
 */
export function sanitizeCellText(str) {
  if (str == null) return '';
  let s = String(str);
  // Remove Unicode replacement characters (U+FFFC object, U+FFFD replacement)
  s = s.replace(/[\uFFFC\uFFFD]/g, '');
  // Remove common mojibake: ï¿½ (UTF-8 U+FFFD bytes mis-decoded as Latin-1: EF,BF,BD → ï,¿,½)
  s = s.replace(/\u00EF\u00BF\u00BD/g, '');
  s = s.replace(/ï¿½/g, '');
  // Remove other control / non-printable characters (keep space \x20, normal printables)
  s = s.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
  // Collapse any whitespace (spaces, tabs, newlines) to single space and trim
  s = s.replace(/\s+/g, ' ').trim();
  return s;
}

/**
 * Sanitize all string values in an object (shallow). Useful for normalizing imported row data.
 * @param {Object} obj - Object with string values.
 * @returns {Object} New object with same keys and sanitized string values.
 */
export function sanitizeRow(obj) {
  if (obj == null || typeof obj !== 'object') return obj;
  const out = {};
  for (const key of Object.keys(obj)) {
    const v = obj[key];
    if (typeof v === 'string') {
      out[key] = sanitizeCellText(v);
    } else if (v != null && typeof v === 'object' && !Array.isArray(v)) {
      out[key] = sanitizeRow(v);
    } else {
      out[key] = v;
    }
  }
  return out;
}
