// Excel import utility using xlsx library
import * as XLSX from 'xlsx';
import { sanitizeCellText } from './textSanitize';

// expectedHeaders: optional array of expected headers (for validation)
// requiredFields: optional array of field names that must have values for a row to be valid
export const importFromExcel = (file, onSuccess, onError, expectedHeaders = null, requiredFields = null) => {
  const reader = new FileReader();
  
  reader.onload = (e) => {
    try {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: 'array' });
      
      // Get the first worksheet
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      
      if (!worksheet) {
        onError('Excel file must have at least one worksheet');
        return;
      }

      // Convert worksheet to JSON
      const jsonData = XLSX.utils.sheet_to_json(worksheet, { 
        header: 1, 
        defval: '',
        raw: false 
      });
      
      if (jsonData.length < 2) {
        onError('Excel file must have at least a header row and one data row');
        return;
      }

      // One label per physical column — do not drop blank header cells (merged / sparse
      // headers shift indices and mis-map values to the wrong fields).
      const rawHeaderRow = Array.isArray(jsonData[0]) ? jsonData[0] : [];
      let colCount = rawHeaderRow.length;
      for (let r = 1; r < jsonData.length; r++) {
        const row = jsonData[r];
        if (row && row.length > colCount) colCount = row.length;
      }
      const headers = [];
      for (let c = 0; c < colCount; c++) {
        const cell = rawHeaderRow[c];
        const trimmed =
          cell != null && String(cell).trim() !== ''
            ? String(cell).replace(/^\uFEFF/, '').trim()
            : '';
        headers.push(trimmed || `__col_${c}`);
      }

      // If expected headers provided, validate and map
      let headerMapping = {};
      if (expectedHeaders) {
        const normalizedHeaders = headers.map((h) => (h.startsWith('__col_') ? h : h.toLowerCase()));
        const normalizedExpected = expectedHeaders.map((h) => h.toLowerCase());

        // Map Excel headers to expected field names
        headers.forEach((header, index) => {
          if (header.startsWith('__col_')) {
            headerMapping[index] = header;
            return;
          }
          const normalizedHeader = header.toLowerCase();
          const expectedIndex = normalizedExpected.indexOf(normalizedHeader);
          if (expectedIndex !== -1) {
            headerMapping[index] = expectedHeaders[expectedIndex];
          } else {
            // Use header as-is if not in expected list
            headerMapping[index] = header;
          }
        });

        // Check for missing expected headers
        const missingHeaders = normalizedExpected.filter(
          (expected) => !normalizedHeaders.includes(expected)
        );

        if (missingHeaders.length > 0) {
          console.warn('Some expected headers are missing:', missingHeaders);
        }
      } else {
        // Use headers as-is
        headers.forEach((header, index) => {
          headerMapping[index] = header;
        });
      }

      // Parse data rows
      const importedData = [];
      const errors = [];

      for (let i = 1; i < jsonData.length; i++) {
        try {
          const row = jsonData[i];

          // Skip empty rows
          if (!row || row.length === 0 || row.every((cell) => !cell || !String(cell).trim())) {
            continue;
          }

          const rowObject = {};
          headers.forEach((header, colIdx) => {
            const fieldName = headerMapping[colIdx] || header;
            const cellValue = row[colIdx];
            rowObject[fieldName] = sanitizeCellText(cellValue);
          });

          // Validate required fields if specified
          if (requiredFields) {
            const hasRequired = requiredFields.some(field => rowObject[field] && rowObject[field].trim());
            if (!hasRequired) {
              errors.push(`Row ${i + 1}: Missing required fields`);
              continue; // Skip this row
            }
          }

          importedData.push(rowObject);
        } catch (error) {
          errors.push(`Row ${i + 1}: ${error.message}`);
        }
      }

      if (importedData.length === 0) {
        onError('No valid data rows found in Excel file');
        return;
      }

      if (errors.length > 0) {
        console.warn('Some rows had errors:', errors);
      }

      onSuccess(importedData, errors);
    } catch (error) {
      onError(`Error parsing Excel file: ${error.message}`);
    }
  };

  reader.onerror = () => {
    onError('Error reading file');
  };

  reader.readAsArrayBuffer(file);
};
