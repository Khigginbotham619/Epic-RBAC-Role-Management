/**
 * Sailpoint role suggestions rank catalog rows using:
 * - Job category name, with a leading "Epic Mosaic" prefix ignored (see categoryNameForSailpointMatch).
 * - Linkable template and subtemplate IDs and names on the category.
 * - Template Links rows that match those IDs/names (extra tokens vs role description/entitlements).
 *
 * Matching refinements: short category/template name tokens use word-boundary checks in role text;
 * hits in the Sailpoint role title score higher than hits only in description/entitlements; when both
 * name and template signals contribute, a small synergy bonus is applied.
 *
 * Sailpoint Match (Find Sailpoint / job category form): suggestions require linkable template and/or
 * subtemplate fields on the category; each populated side must match the catalog role name/description/
 * entitlements directly (IDs or name tokens). Name-only matches are not returned. Only catalog rows with
 * requestable=TRUE are suggested. When the job category name indicates Nurse Practitioner (or NP)
 * or Physician Assistant (or PA), only catalog roles in that same clinician family are suggested.
 * If the job category name does not contain the token SiteB, catalog rows that mention SiteB are excluded;
 * if it does contain SiteB, SiteB Sailpoint roles stay eligible like any other row (still subject to template
 * matching and scoring).
 *
 * Pin an exact role: add an entry to src/data/sailpointCategoryPreferredRoles.json
 * (normalized key → full role name as in the catalog). Keys starting with "_" are ignored.
 * Save the file and refresh the app to reload.
 */
import preferredRolesJson from '../data/sailpointCategoryPreferredRoles.json';
import { isRequestableSailpointCatalogRow } from './sailpointRequestable';
import {
  normalizeTemplateLinkRow,
  canonicalTemplateLinkRecordType,
  splitTemplateIdTokens,
  splitTemplateNameTokens,
} from './templateLinkRoleMatch';

const CATEGORY_MATCH_STOPWORDS = new Set([
  'the', 'and', 'for', 'with', 'from', 'per', 'are', 'job', 'role', 'cat', 'category', 'a', 'an', 'of', 'to', 'in', 'on', 'at', 'or', 'as',
  'epic', 'mosaic',
]);

/** Normalized category name key → exact Sailpoint role name. Underscore-prefixed JSON keys are metadata only. */
const PREFERRED_SAILPOINT_ROLE_BY_CATEGORY = Object.fromEntries(
  Object.entries(preferredRolesJson).filter(([k]) => typeof k === 'string' && !k.startsWith('_'))
);

/** Remove product prefix so matching uses the role-relevant part of the category name. */
export function categoryNameForSailpointMatch(jobCategoryName) {
  let s = String(jobCategoryName || '').trim().toLowerCase().replace(/\s+/g, ' ');
  s = s.replace(/\bepic\s+mosaic\b/g, ' ').replace(/\s+/g, ' ').trim();
  return s;
}

function categoryKeysForPreferredSailpointRole(jobCategoryName) {
  const base = categoryNameForSailpointMatch(jobCategoryName);
  const keys = new Set();
  if (base) keys.add(base);
  const noSsc = base.replace(/\s*ssc\s+use\s+only\s*$/i, '').trim();
  if (noSsc && noSsc !== base) keys.add(noSsc);
  return [...keys];
}

export function preferredSailpointRoleNameForCategory(jobCategoryName) {
  for (const key of categoryKeysForPreferredSailpointRole(jobCategoryName)) {
    const name = PREFERRED_SAILPOINT_ROLE_BY_CATEGORY[key];
    if (name) return name;
  }
  return null;
}

function jobCategoryTemplateSignals(fields) {
  const f = fields || {};
  const linkIds = splitTemplateIdTokens(f.linkableTemplateId);
  const subIds = splitTemplateIdTokens(f.subtemplatesId);
  const linkNames = splitTemplateNameTokens(f.linkableTemplateName);
  const subNames = splitTemplateNameTokens(f.subtemplatesName);
  return {
    linkIdSet: new Set(linkIds.map((t) => t.toLowerCase()).filter(Boolean)),
    subIdSet: new Set(subIds.map((t) => t.toLowerCase()).filter(Boolean)),
    linkNameTokens: [...new Set(linkNames.map((n) => n.trim().toLowerCase()).filter(Boolean))],
    subNameTokens: [...new Set(subNames.map((n) => n.trim().toLowerCase()).filter(Boolean))],
  };
}

function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Whether tok appears in hay (both lowercased). Short alphabetic tokens use word boundaries so
 * "or" does not match inside "transport", while long tokens, numeric, and hyphenated IDs still use substring.
 */
function matchesTokenInHaystack(hayLc, tokLc) {
  if (!hayLc || !tokLc) return false;
  const useSubstring =
    tokLc.length >= 5 ||
    /^\d/.test(tokLc) ||
    tokLc.includes('-') ||
    tokLc.includes('_');
  if (useSubstring) return hayLc.includes(tokLc);
  try {
    const re = new RegExp(`(?:^|[^a-z0-9])${escapeRegex(tokLc)}(?:[^a-z0-9]|$)`);
    return re.test(hayLc);
  } catch {
    return hayLc.includes(tokLc);
  }
}

function setsIntersect(a, b) {
  if (!a.size || !b.size) return false;
  for (const x of a) {
    if (b.has(x)) return true;
  }
  return false;
}

function nameTokensOverlap(rowTokensLc, categoryTokensLc) {
  for (const t of categoryTokensLc) {
    if (!t || t.length < 2) continue;
    for (const r of rowTokensLc) {
      if (!r) continue;
      if (r === t) return true;
      if (t.length >= 4 && r.includes(t)) return true;
      if (r.length >= 4 && t.includes(r)) return true;
    }
  }
  return false;
}

const SITEB_WORD_RE = /\bFCH\b/i;

const NURSE_PRACTITIONER_PHRASE_RE = /\bnurse\s+practitioner\b/i;
const PHYSICIAN_ASSISTANT_PHRASE_RE = /\bphysician\s+assist(?:ant|itant)\b/i;
const NP_SHORT_PREFIX_RE = /^np\s*-/i;
const PA_SHORT_PREFIX_RE = /^pa\s*-/i;
const SAILPOINT_NP_SHORT_RE = /\b(?:epic\s+mosaic\s+)?np\s*-/i;
const SAILPOINT_PA_SHORT_RE = /\b(?:epic\s+mosaic\s+)?pa\s*-/i;

/** @typedef {'nurse-practitioner'|'physician-assistant'} SailpointClinicianType */

function textMentionsNursePractitionerCategory(text) {
  const raw = String(text || '').trim();
  if (!raw) return false;
  if (NURSE_PRACTITIONER_PHRASE_RE.test(raw)) return true;
  const cat = categoryNameForSailpointMatch(raw);
  if (NURSE_PRACTITIONER_PHRASE_RE.test(cat)) return true;
  return NP_SHORT_PREFIX_RE.test(raw) || NP_SHORT_PREFIX_RE.test(cat);
}

function textMentionsPhysicianAssistantCategory(text) {
  const raw = String(text || '').trim();
  if (!raw) return false;
  if (PHYSICIAN_ASSISTANT_PHRASE_RE.test(raw)) return true;
  const cat = categoryNameForSailpointMatch(raw);
  if (PHYSICIAN_ASSISTANT_PHRASE_RE.test(cat)) return true;
  return PA_SHORT_PREFIX_RE.test(raw) || PA_SHORT_PREFIX_RE.test(cat);
}

/**
 * Clinician family implied by a job category name, or null when no NP/PA signal is present.
 * Physician (without "Assistant") and other roles are not constrained.
 */
export function jobCategoryClinicianType(jobCategoryName) {
  const isPa = textMentionsPhysicianAssistantCategory(jobCategoryName);
  const isNp = textMentionsNursePractitionerCategory(jobCategoryName);
  if (isPa && !isNp) return 'physician-assistant';
  if (isNp && !isPa) return 'nurse-practitioner';
  return null;
}

/** Clinician family from a Sailpoint catalog role title, or null when not NP/PA. */
export function sailpointRowClinicianType(row) {
  const roleName = String(row?.sailpointRole || '').trim();
  if (!roleName) return null;
  if (PHYSICIAN_ASSISTANT_PHRASE_RE.test(roleName)) return 'physician-assistant';
  if (NURSE_PRACTITIONER_PHRASE_RE.test(roleName)) return 'nurse-practitioner';
  if (SAILPOINT_PA_SHORT_RE.test(roleName)) return 'physician-assistant';
  if (SAILPOINT_NP_SHORT_RE.test(roleName)) return 'nurse-practitioner';
  return null;
}

/** True when row is eligible for suggestions given the category's NP/PA constraint (if any). */
export function sailpointRowMatchesCategoryClinicianType(jobCategoryName, row) {
  const want = jobCategoryClinicianType(jobCategoryName);
  if (!want) return true;
  const got = sailpointRowClinicianType(row);
  return got === want;
}

/** True if the job category name includes SiteB as its own token (e.g. "… SiteB …"). */
export function jobCategoryMentionsFch(jobCategoryName) {
  return SITEB_WORD_RE.test(String(jobCategoryName || '').trim());
}

/** True if the Sailpoint catalog row's role name, description, or entitlements mentions SiteB as a token. */
export function sailpointRowMentionsFch(row) {
  if (!row) return false;
  const parts = [row.sailpointRole, row.description, row.entitlements].map((x) => String(x || ''));
  return parts.some((p) => SITEB_WORD_RE.test(p));
}

/** Parse each template link once; pass from useMemo([templateLinks]) when scoring many categories. */
export function preparseTemplateLinkRows(templateLinks) {
  if (!Array.isArray(templateLinks) || templateLinks.length === 0) return [];
  const out = [];
  for (const row of templateLinks) {
    try {
      const n = normalizeTemplateLinkRow(row);
      const kind = canonicalTemplateLinkRecordType(row);
      const rowLinkIds = new Set(splitTemplateIdTokens(n.templateId).map((t) => t.toLowerCase()));
      const rowSubIds = new Set(splitTemplateIdTokens(n.subtemplateId).map((t) => t.toLowerCase()));
      const rowTmplNames = splitTemplateNameTokens(n.templateName).map((s) => s.toLowerCase());
      const rowSubNames = splitTemplateNameTokens(n.subtemplateName).map((s) => s.toLowerCase());
      out.push({ n, kind, rowLinkIds, rowSubIds, rowTmplNames, rowSubNames });
    } catch (_) {
      /* skip malformed row */
    }
  }
  return out;
}

function templateLinkRowMatchesJobCategoryParsed(p, sig) {
  if (p.kind === 'Subtemplate') {
    if (setsIntersect(sig.subIdSet, p.rowLinkIds)) return true;
    if (nameTokensOverlap(p.rowTmplNames, sig.subNameTokens)) return true;
    return false;
  }
  if (setsIntersect(sig.linkIdSet, p.rowLinkIds)) return true;
  if (setsIntersect(sig.subIdSet, p.rowSubIds)) return true;
  if (nameTokensOverlap(p.rowTmplNames, sig.linkNameTokens)) return true;
  if (nameTokensOverlap(p.rowSubNames, sig.subNameTokens)) return true;
  return false;
}

function collectLinkDerivedSignalsFromParsed(parsedRows, sig) {
  const extraIds = new Set();
  const extraWords = new Set();
  let n = 0;
  const maxWords = 120;
  for (const p of parsedRows) {
    if (!templateLinkRowMatchesJobCategoryParsed(p, sig)) continue;
    const nr = p.n;
    const chunks = [nr.templateId, nr.templateName, nr.templateDisplayTitle, nr.subtemplateId, nr.subtemplateName];
    for (const v of chunks) {
      if (v == null || !String(v).trim()) continue;
      const s = String(v);
      splitTemplateIdTokens(s).forEach((t) => extraIds.add(t.toLowerCase()));
      for (const w of s.toLowerCase().split(/[^a-z0-9]+/)) {
        if (w.length >= 3 && extraWords.size < maxWords) extraWords.add(w);
      }
    }
    n += 1;
    if (n > 400) break;
  }
  return { extraIds, extraWords };
}

/** Match haystack against linkable-template IDs/names only (not subtemplate fields). */
function directLinkTemplateBoost(hay, sig) {
  let bonus = 0;
  for (const id of sig.linkIdSet) {
    if (id.length >= 2 && hay.includes(id)) bonus += 26;
  }
  for (const tok of sig.linkNameTokens) {
    if (tok.length < 3) continue;
    if (matchesTokenInHaystack(hay, tok)) bonus += 14;
  }
  return bonus;
}

/** Match haystack against subtemplate IDs/names only (not linkable template fields). */
function directSubtemplateBoost(hay, sig) {
  let bonus = 0;
  for (const id of sig.subIdSet) {
    if (id.length >= 2 && hay.includes(id)) bonus += 26;
  }
  for (const tok of sig.subNameTokens) {
    if (tok.length < 3) continue;
    if (matchesTokenInHaystack(hay, tok)) bonus += 14;
  }
  return bonus;
}

function templateAndSubtemplateBoost(hay, sig, linkDerived) {
  let bonus = directLinkTemplateBoost(hay, sig) + directSubtemplateBoost(hay, sig);
  for (const id of linkDerived.extraIds) {
    if (id.length >= 2 && hay.includes(id)) bonus += 12;
  }
  for (const w of linkDerived.extraWords) {
    if (w.length >= 4 && matchesTokenInHaystack(hay, w)) bonus += 3;
  }
  return bonus;
}

/**
 * Suggestions require template/subtemplate fields on the category. Each populated side (linkable template vs
 * subtemplate) must match the role haystack via direct ID/name signals (not link-derived words alone).
 */
function roleHaystackMeetsCategoryTemplateSignals(hay, sig, linkDerived, hasTemplateSignals) {
  if (!hasTemplateSignals) return false;
  const hasLinkSignals = sig.linkIdSet.size > 0 || sig.linkNameTokens.length > 0;
  const hasSubSignals = sig.subIdSet.size > 0 || sig.subNameTokens.length > 0;
  if (hasLinkSignals && directLinkTemplateBoost(hay, sig) <= 0) return false;
  if (hasSubSignals && directSubtemplateBoost(hay, sig) <= 0) return false;
  return templateAndSubtemplateBoost(hay, sig, linkDerived) > 0;
}

function finalizeSuggestions(scored, preferredRow) {
  scored.sort((a, b) => b.score - a.score);
  const seen = new Set();
  const out = [];
  for (const { row, key } of scored) {
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(row);
    if (out.length >= 18) break;
  }
  if (preferredRow) {
    const rest = out.filter((r) => r.id !== preferredRow.id);
    return [preferredRow, ...rest].slice(0, 18);
  }
  return out;
}

/**
 * Rank Sailpoint roles for a job category: name (Epic Mosaic prefix stripped), linkable template + subtemplate
 * IDs/names, matching Template Links (extra scoring vs description/entitlements), and optional JSON pins.
 *
 * @param {unknown[]|undefined} preparsedTemplateRows Optional result of preparseTemplateLinkRows(templateLinks) to avoid reparsing for every category.
 */
export function suggestSailpointRolesForJobCategory(
  jobCategoryName,
  rows,
  categoryTemplateFields = {},
  templateLinks = [],
  preparsedTemplateRows
) {
  if (!Array.isArray(rows) || rows.length === 0) return [];

  const cat = categoryNameForSailpointMatch(jobCategoryName);
  const sig = jobCategoryTemplateSignals(categoryTemplateFields);
  const hasCategoryText = !!cat;
  const hasTemplateSignals =
    sig.linkIdSet.size > 0 ||
    sig.subIdSet.size > 0 ||
    sig.linkNameTokens.length > 0 ||
    sig.subNameTokens.length > 0;

  const preferredName = preferredSailpointRoleNameForCategory(jobCategoryName);
  const preferredLc = preferredName ? preferredName.trim().toLowerCase() : '';
  const rowBySailpointLc = new Map();
  for (const r of rows) {
    const k = String(r.sailpointRole || '').trim().toLowerCase();
    if (k && !rowBySailpointLc.has(k)) rowBySailpointLc.set(k, r);
  }
  let preferredRow = preferredLc ? rowBySailpointLc.get(preferredLc) || null : null;
  if (preferredRow && !isRequestableSailpointCatalogRow(preferredRow)) {
    preferredRow = null;
  }

  if (!hasTemplateSignals) {
    return [];
  }

  const hasParsedLinks = Array.isArray(preparsedTemplateRows) && preparsedTemplateRows.length > 0;
  const hasRawLinks = Array.isArray(templateLinks) && templateLinks.length > 0;
  const linkDerived =
    hasTemplateSignals && (hasParsedLinks || hasRawLinks)
      ? collectLinkDerivedSignalsFromParsed(
          hasParsedLinks ? preparsedTemplateRows : preparseTemplateLinkRows(templateLinks),
          sig
        )
      : { extraIds: new Set(), extraWords: new Set() };

  if (preferredRow) {
    const roleName = String(preferredRow.sailpointRole || '').trim();
    const roleL = roleName.toLowerCase();
    const hayPref = `${roleL} ${String(preferredRow.description || '').toLowerCase()} ${String(
      preferredRow.entitlements || ''
    ).toLowerCase()}`;
    if (!roleHaystackMeetsCategoryTemplateSignals(hayPref, sig, linkDerived, true)) {
      preferredRow = null;
    } else if (!jobCategoryMentionsFch(jobCategoryName) && sailpointRowMentionsFch(preferredRow)) {
      preferredRow = null;
    } else if (!sailpointRowMatchesCategoryClinicianType(jobCategoryName, preferredRow)) {
      preferredRow = null;
    }
  }

  const tokens = hasCategoryText
    ? [
        ...new Set(
          cat
            .split(/[^a-z0-9]+/)
            .filter((t) => t.length >= 2 && !CATEGORY_MATCH_STOPWORDS.has(t))
        ),
      ]
    : [];

  const scored = [];
  for (const row of rows) {
    if (!isRequestableSailpointCatalogRow(row)) continue;
    const roleName = String(row.sailpointRole || '').trim();
    if (!roleName) continue;
    const roleL = roleName.toLowerCase();
    const hay = `${roleL} ${String(row.description || '').toLowerCase()} ${String(row.entitlements || '').toLowerCase()}`;
    if (!roleHaystackMeetsCategoryTemplateSignals(hay, sig, linkDerived, hasTemplateSignals)) {
      continue;
    }
    // Non-SiteB categories must not get SiteB-titled roles; SiteB categories may match SiteB or non-SiteB roles.
    if (!jobCategoryMentionsFch(jobCategoryName) && sailpointRowMentionsFch(row)) {
      continue;
    }
    if (!sailpointRowMatchesCategoryClinicianType(jobCategoryName, row)) {
      continue;
    }
    const tmplBoost = templateAndSubtemplateBoost(hay, sig, linkDerived);
    let nameScore = 0;
    if (hasCategoryText) {
      if (cat.length >= 3 && hay.includes(cat)) nameScore += 100;
      const titleWords = new Set(
        roleL
          .split(/[^a-z0-9]+/)
          .filter((w) => w.length >= 3 && !CATEGORY_MATCH_STOPWORDS.has(w))
      );
      for (const tok of tokens) {
        if (!matchesTokenInHaystack(hay, tok)) continue;
        const inRoleTitle = titleWords.has(tok) || matchesTokenInHaystack(roleL, tok);
        if (inRoleTitle) nameScore += tok.length >= 4 ? 18 : 10;
        else nameScore += tok.length >= 4 ? 8 : 4;
      }
    }
    let score = nameScore + tmplBoost;
    if (hasCategoryText && hasTemplateSignals && nameScore > 0 && tmplBoost > 0) {
      score += 16;
    }
    if (score === 0) continue;
    scored.push({ row, score, key: roleL });
  }

  return finalizeSuggestions(scored, preferredRow);
}

/**
 * Without template/subtemplate fields on the category, suggestions are always empty (see suggestSailpointRolesForJobCategory).
 */
export function suggestSailpointRolesFromCategoryName(jobCategoryName, rows) {
  return suggestSailpointRolesForJobCategory(jobCategoryName, rows, {}, []);
}
