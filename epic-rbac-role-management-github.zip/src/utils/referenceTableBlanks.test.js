import {
  isBlank,
  REFERENCE_TABLE_DEFS,
  findBlankRowsForTable,
  findReferenceTableBlanks,
  applyReferenceTableFills,
} from './referenceTableBlanks';

describe('isBlank', () => {
  it.each([['', true], [null, true], [undefined, true], ['   ', true], ['x', false], [0, false]])(
    'returns %s for %p',
    (v, expected) => {
      expect(isBlank(v)).toBe(expected);
    },
  );
});

describe('REFERENCE_TABLE_DEFS', () => {
  it('covers the five reference tables', () => {
    expect(REFERENCE_TABLE_DEFS.map((d) => d.key)).toEqual([
      'jobCodes',
      'departments',
      'blueprints',
      'sailpointRoles',
      'templateLinks',
    ]);
  });

  it('each def declares an id field and at least one required field', () => {
    for (const def of REFERENCE_TABLE_DEFS) {
      expect(def.idField).toBeTruthy();
      expect(Array.isArray(def.requiredFields)).toBe(true);
      expect(def.requiredFields.length).toBeGreaterThan(0);
      for (const rf of def.requiredFields) {
        expect(rf.field).toBeTruthy();
        expect(rf.label).toBeTruthy();
      }
    }
  });
});

const jobCodesDef = REFERENCE_TABLE_DEFS.find((d) => d.key === 'jobCodes');
const deptDef = REFERENCE_TABLE_DEFS.find((d) => d.key === 'departments');
const sailpointDef = REFERENCE_TABLE_DEFS.find((d) => d.key === 'sailpointRoles');
const linksDef = REFERENCE_TABLE_DEFS.find((d) => d.key === 'templateLinks');

describe('findBlankRowsForTable', () => {
  it('flags rows missing required fields and skips rows without the id field', () => {
    const rows = [
      { id: '1', jobCode: '1234', jobTitle: 'Nurse' },
      { id: '2', jobCode: '5678', jobTitle: '' },
      { id: '3', jobCode: '', jobTitle: 'Orphan' },
      { id: '4', jobCode: '9999' },
    ];
    const blanks = findBlankRowsForTable(rows, jobCodesDef);
    expect(blanks.map((b) => b.keyValue)).toEqual(['5678', '9999']);
    expect(blanks[0].blanks.map((b) => b.field)).toEqual(['jobTitle']);
  });

  it('returns multiple missing fields when more than one is blank', () => {
    const rows = [
      {
        id: '1',
        sailpointRole: 'Role A',
        templates: '',
        requestable: '',
        status: 'Active',
      },
    ];
    const blanks = findBlankRowsForTable(rows, sailpointDef);
    expect(blanks).toHaveLength(1);
    expect(blanks[0].blanks.map((b) => b.field).sort()).toEqual(['requestable', 'templates']);
  });

  it('skips rows with no blanks', () => {
    const rows = [{ id: '1', deptId: 'D1', deptDescription: 'Cardio' }];
    expect(findBlankRowsForTable(rows, deptDef)).toEqual([]);
  });

  it('sorts results by id', () => {
    const rows = [
      { id: '1', jobCode: 'B-002', jobTitle: '' },
      { id: '2', jobCode: 'A-001', jobTitle: '' },
      { id: '3', jobCode: 'C-003', jobTitle: '' },
    ];
    const blanks = findBlankRowsForTable(rows, jobCodesDef);
    expect(blanks.map((b) => b.keyValue)).toEqual(['A-001', 'B-002', 'C-003']);
  });

  it('handles undefined input arrays gracefully', () => {
    expect(findBlankRowsForTable(undefined, jobCodesDef)).toEqual([]);
    expect(findBlankRowsForTable(null, jobCodesDef)).toEqual([]);
  });
});

describe('findReferenceTableBlanks', () => {
  it('returns one entry per reference-table def, in order', () => {
    const out = findReferenceTableBlanks({});
    expect(out.map((o) => o.def.key)).toEqual([
      'jobCodes',
      'departments',
      'blueprints',
      'sailpointRoles',
      'templateLinks',
    ]);
    for (const entry of out) expect(entry.blanks).toEqual([]);
  });

  it('detects blanks across multiple tables in one call', () => {
    const out = findReferenceTableBlanks({
      jobCodes: [{ id: '1', jobCode: '1234', jobTitle: '' }],
      departments: [{ id: '2', deptId: 'D1', deptDescription: 'OK' }],
      sailpointRoles: [],
      blueprints: [{ id: '3', blueprintId: 'BP1', blueprintName: '' }],
      templateLinks: [
        { id: '4', templateId: 'T1', templateName: 'TN', templateDisplayTitle: '' },
      ],
    });
    const byKey = Object.fromEntries(out.map((e) => [e.def.key, e.blanks]));
    expect(byKey.jobCodes).toHaveLength(1);
    expect(byKey.departments).toHaveLength(0);
    expect(byKey.blueprints).toHaveLength(1);
    expect(byKey.sailpointRoles).toHaveLength(0);
    expect(byKey.templateLinks).toHaveLength(1);
    expect(byKey.templateLinks[0].blanks.map((b) => b.field)).toEqual(['templateDisplayTitle']);
  });
});

describe('templateLinks specific requirements', () => {
  it('requires templateName and templateDisplayTitle when templateId is present', () => {
    const rows = [
      {
        id: '1',
        templateId: 'T1',
        templateName: '',
        templateDisplayTitle: 'Some title',
      },
    ];
    const blanks = findBlankRowsForTable(rows, linksDef);
    expect(blanks[0].blanks.map((b) => b.field)).toEqual(['templateName']);
  });

  it('proposes templateDisplayTitle from subtemplateName when present', () => {
    const rows = [
      {
        id: '1',
        templateId: 'T1',
        templateName: 'Some Template',
        subtemplateName: 'My Sub Description',
        templateDisplayTitle: '',
      },
    ];
    const blanks = findBlankRowsForTable(rows, linksDef);
    expect(blanks[0].blanks).toHaveLength(1);
    expect(blanks[0].blanks[0].field).toBe('templateDisplayTitle');
    expect(blanks[0].blanks[0].proposedFill).toBe('My Sub Description');
    expect(blanks[0].blanks[0].proposeFillSource).toBe('subtemplateName, then templateName');
  });

  it('falls back to templateName when subtemplateName is blank', () => {
    const rows = [
      {
        id: '1',
        templateId: 'T1',
        templateName: 'Some Template',
        templateDisplayTitle: '',
      },
    ];
    const blanks = findBlankRowsForTable(rows, linksDef);
    expect(blanks[0].blanks[0].proposedFill).toBe('Some Template');
  });

  it('proposedFill is null when no description source is available', () => {
    const rows = [
      {
        id: '1',
        templateId: 'T1',
        templateName: '',
        subtemplateName: '',
        templateDisplayTitle: '',
      },
    ];
    const blanks = findBlankRowsForTable(rows, linksDef);
    const titleBlank = blanks[0].blanks.find((b) => b.field === 'templateDisplayTitle');
    expect(titleBlank.proposedFill).toBeNull();
  });

  it('fields with no proposeFill helper return null/empty source', () => {
    const rows = [
      { id: '1', jobCode: '1234', jobTitle: '' },
    ];
    const blanks = findBlankRowsForTable(rows, jobCodesDef);
    expect(blanks[0].blanks[0].proposedFill).toBeNull();
    expect(blanks[0].blanks[0].proposeFillSource).toBeNull();
  });
});

describe('applyReferenceTableFills', () => {
  const linksDefLocal = REFERENCE_TABLE_DEFS.find((d) => d.key === 'templateLinks');

  it('applies all proposable fills when no selection is given', () => {
    const rows = [
      { id: '1', templateId: 'T1', templateName: 'A', subtemplateName: 'Desc A', templateDisplayTitle: '' },
      { id: '2', templateId: 'T2', templateName: 'B', templateDisplayTitle: 'Has Title' },
    ];
    const blanks = findBlankRowsForTable(rows, linksDefLocal);
    const result = applyReferenceTableFills(rows, blanks);
    expect(result.appliedCount).toBe(1);
    expect(result.changedRowIds.has('1')).toBe(true);
    expect(result.updatedRows.find((r) => r.id === '1').templateDisplayTitle).toBe('Desc A');
    expect(result.updatedRows.find((r) => r.id === '2').templateDisplayTitle).toBe('Has Title');
  });

  it('respects a selection set keyed by "id|field"', () => {
    const rows = [
      { id: '1', templateId: 'T1', templateName: 'A', templateDisplayTitle: '' },
      { id: '2', templateId: 'T2', templateName: 'B', templateDisplayTitle: '' },
    ];
    const blanks = findBlankRowsForTable(rows, linksDefLocal);
    const result = applyReferenceTableFills(rows, blanks, new Set(['1|templateDisplayTitle']));
    expect(result.appliedCount).toBe(1);
    expect(result.changedRowIds.has('1')).toBe(true);
    expect(result.changedRowIds.has('2')).toBe(false);
    expect(result.updatedRows.find((r) => r.id === '2').templateDisplayTitle).toBe('');
  });

  it('skips blanks that have no proposedFill even when selected', () => {
    const rows = [
      { id: '1', templateId: 'T1', templateName: '', subtemplateName: '', templateDisplayTitle: '' },
    ];
    const blanks = findBlankRowsForTable(rows, linksDefLocal);
    const result = applyReferenceTableFills(rows, blanks, new Set(['1|templateDisplayTitle']));
    expect(result.appliedCount).toBe(0);
    expect(result.changedRowIds.size).toBe(0);
  });

  it('preserves the original array reference when nothing changes', () => {
    const rows = [{ id: '1', templateId: 'T1', templateName: 'A', templateDisplayTitle: 'Already there' }];
    const blanks = findBlankRowsForTable(rows, linksDefLocal);
    const result = applyReferenceTableFills(rows, blanks);
    expect(result.updatedRows).toBe(rows);
  });
});
