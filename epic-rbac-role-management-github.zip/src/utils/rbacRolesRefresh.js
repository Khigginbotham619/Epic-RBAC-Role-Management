/** Notify open screens that roles were persisted so they reload from the server. */
export const RBAC_ROLES_UPDATED_EVENT = 'rbac-roles-updated';

/**
 * @param {object[]|undefined} updatedRoles - When provided, listeners can apply this snapshot
 *   instead of refetching (avoids stale cache read-after-write races).
 */
export function notifyRolesUpdated(updatedRoles) {
  if (typeof window === 'undefined') return;
  window.dispatchEvent(
    new CustomEvent(RBAC_ROLES_UPDATED_EVENT, {
      detail: Array.isArray(updatedRoles) ? { updatedRoles } : undefined,
    })
  );
}
