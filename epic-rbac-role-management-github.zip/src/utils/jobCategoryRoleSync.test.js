import {
  isCategoryEditedInLast24Hours,
  isCategoryEditedForSync,
  resolveJobCategoryDisplayName,
  formatCategorySyncRowLabel,
  formatCategorySyncRowDisplay,
  buildJobCategoryRoleSyncPlan,
  applyJobCategoryRoleSyncPlan,
  countAppliedRoleSyncPatches,
  remapRoleSyncSelectionToFreshPlan,
  applyJobCategoryChangesToRoles,
  buildDefaultRoleSyncSelection,
  buildRoleSyncSelectionKey,
  countSelectedRoleSyncUpdates,
  MS_SYNC_RECENT_EDIT,
  SYNC_SCOPE_ALL,
} from './jobCategoryRoleSync';

function recentEditStamp() {
  return `${new Date().toLocaleString('en-US')} - testuser`;
}

function editStampDaysAgo(days) {
  const d = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  return `${d.toLocaleString('en-US')} - testuser`;
}

describe('isCategoryEditedInLast24Hours', () => {
  it('returns true for a category edited just now', () => {
    expect(isCategoryEditedInLast24Hours({ lastEditDateReasonInitials: recentEditStamp() })).toBe(true);
  });

  it('returns false when there is no edit stamp', () => {
    expect(isCategoryEditedInLast24Hours({})).toBe(false);
  });

  it('returns false for an edit older than 24 hours', () => {
    expect(isCategoryEditedInLast24Hours({ lastEditDateReasonInitials: editStampDaysAgo(2) })).toBe(false);
  });
});

describe('isCategoryEditedForSync', () => {
  it('returns true for a category edited within the last week', () => {
    expect(isCategoryEditedForSync({ lastEditDateReasonInitials: editStampDaysAgo(3) })).toBe(true);
  });

  it('returns false for an edit older than the sync window', () => {
    expect(isCategoryEditedForSync({ lastEditDateReasonInitials: editStampDaysAgo(8) })).toBe(false);
  });

  it('uses a seven-day sync window', () => {
    expect(MS_SYNC_RECENT_EDIT).toBe(7 * 24 * 60 * 60 * 1000);
  });
});

describe('resolveJobCategoryDisplayName', () => {
  it('normalizes non-breaking spaces in category names', () => {
    expect(resolveJobCategoryDisplayName({ jobCategoryName: '\u00a0Nurse\u00a0' })).toBe('Nurse');
  });

  it('falls back to job category id when name is missing', () => {
    expect(resolveJobCategoryDisplayName({ jobCategoryId: '42' })).toBe('Job Category 42');
  });

  it('falls back to assigned role job category', () => {
    const category = { jobCategoryName: '' };
    const roles = [{ jobCategory: 'Burn Medicine NP' }];
    expect(resolveJobCategoryDisplayName(category, roles)).toBe('Burn Medicine NP');
  });

  it('falls back to description when the name is missing', () => {
    expect(
      resolveJobCategoryDisplayName({
        jobCategoryName: '',
        description: 'SiteB Clinic Manager',
        jobCategoryId: '1064',
      })
    ).toBe('SiteB Clinic Manager');
  });
});

describe('formatCategorySyncRowLabel', () => {
  it('never returns blank when category id or description exists', () => {
    const label = formatCategorySyncRowLabel({
      displayName: '   ',
      category: { jobCategoryId: '1064', description: 'SiteB Clinic Manager' },
    });
    expect(label).toBe('SiteB Clinic Manager');
  });
});

describe('formatCategorySyncRowDisplay', () => {
  it('shows category name and job category id', () => {
    const display = formatCategorySyncRowDisplay({
      displayName: 'SiteB Clinic Manager',
      category: { jobCategoryId: '1064', id: 'abc123' },
    });
    expect(display.title).toBe('SiteB Clinic Manager');
    expect(display.subtitle).toContain('ID 1064');
  });
});

describe('buildJobCategoryRoleSyncPlan', () => {
  const blueprints = [{ blueprintId: 'BP1', blueprintName: 'Nurse BP' }];

  it('finds roles that drift from a recently edited category', () => {
    const jobCategories = [
      {
        id: 'c1',
        jobCategoryName: 'Nurse',
        needEMP: 'Yes',
        linkableTemplateId: 'T1',
        linkableTemplateName: 'NURSE TPL',
        lastEditDateReasonInitials: recentEditStamp(),
      },
    ];
    const roles = [
      { id: 'r1', rbacCode: 'RBAC001', jobCategory: 'Nurse', empNeeded: 'No' },
      { id: 'r2', rbacCode: 'RBAC002', jobCategory: 'Physician', empNeeded: 'Yes' },
    ];

    const plan = buildJobCategoryRoleSyncPlan({ jobCategories, roles, blueprints, templateLinks: [] });
    expect(plan.recentCategoryCount).toBe(1);
    expect(plan.roleUpdateCount).toBe(1);
    expect(plan.roleUpdates[0].rbacCode).toBe('RBAC001');
    expect(plan.roleUpdates[0].changes.some((c) => c.field === 'empNeeded')).toBe(true);
    expect(plan.categorySummaries[0].roleEntries[0].changes).toEqual(
      expect.arrayContaining([
        expect.objectContaining({ field: 'empNeeded', from: 'No', to: 'Yes' }),
      ])
    );
  });

  it('reports in-sync when role already matches the category', () => {
    const jobCategories = [
      {
        id: 'c1',
        jobCategoryName: 'Nurse',
        needEMP: 'Yes',
        lastEditDateReasonInitials: recentEditStamp(),
      },
    ];
    const roles = [{ id: 'r1', rbacCode: 'RBAC001', jobCategory: 'Nurse', empNeeded: 'Yes' }];

    const plan = buildJobCategoryRoleSyncPlan({ jobCategories, roles, blueprints, templateLinks: [] });
    expect(plan.recentCategoryCount).toBe(1);
    expect(plan.roleUpdateCount).toBe(0);
    expect(plan.categorySummaries[0].driftRoleCount).toBe(0);
  });

  it('shows a readable category name in summaries when the stored name has non-breaking spaces', () => {
    const jobCategories = [
      {
        id: 'c1',
        jobCategoryName: '\u00a0Nurse\u00a0',
        needEMP: 'Yes',
        lastEditDateReasonInitials: recentEditStamp(),
      },
    ];
    const roles = [{ id: 'r1', rbacCode: 'RBAC001', jobCategory: 'Nurse', empNeeded: 'No' }];

    const plan = buildJobCategoryRoleSyncPlan({ jobCategories, roles, blueprints, templateLinks: [] });
    expect(plan.categorySummaries[0].displayName).toBe('Nurse');
    expect(plan.roleUpdateCount).toBe(1);
  });

  it('includes categories edited within the last week', () => {
    const jobCategories = [
      {
        id: 'c1',
        jobCategoryName: 'Nurse',
        needEMP: 'Yes',
        lastEditDateReasonInitials: editStampDaysAgo(5),
      },
    ];
    const roles = [{ id: 'r1', rbacCode: 'RBAC001', jobCategory: 'Nurse', empNeeded: 'No' }];

    const plan = buildJobCategoryRoleSyncPlan({ jobCategories, roles, blueprints, templateLinks: [] });
    expect(plan.recentCategoryCount).toBe(1);
    expect(plan.roleUpdateCount).toBe(1);
  });

  it('ignores categories edited more than a week ago', () => {
    const jobCategories = [
      {
        id: 'c1',
        jobCategoryName: 'Nurse',
        needEMP: 'Yes',
        lastEditDateReasonInitials: editStampDaysAgo(8),
      },
    ];
    const roles = [{ id: 'r1', rbacCode: 'RBAC001', jobCategory: 'Nurse', empNeeded: 'No' }];

    const plan = buildJobCategoryRoleSyncPlan({ jobCategories, roles, blueprints, templateLinks: [] });
    expect(plan.recentCategoryCount).toBe(0);
    expect(plan.roleUpdateCount).toBe(0);
  });

  it('syncs all categories when scope is all, regardless of edit date', () => {
    const jobCategories = [
      {
        id: 'c1',
        jobCategoryName: 'Nurse',
        needEMP: 'Yes',
        lastEditDateReasonInitials: editStampDaysAgo(30),
      },
    ];
    const roles = [{ id: 'r1', rbacCode: 'RBAC001', jobCategory: 'Nurse', empNeeded: 'No' }];

    const plan = buildJobCategoryRoleSyncPlan({
      jobCategories,
      roles,
      blueprints,
      templateLinks: [],
      scope: SYNC_SCOPE_ALL,
    });
    expect(plan.scope).toBe(SYNC_SCOPE_ALL);
    expect(plan.categoriesScanned).toBe(1);
    expect(plan.roleUpdateCount).toBe(1);
    expect(plan.driftCategoryCount).toBe(1);
  });
});

describe('applyJobCategoryChangesToRoles', () => {
  it('does not flag roles that already match the category', () => {
    const jobCategories = [
      { id: 'c1', jobCategoryName: 'Nurse', needEMP: 'Yes', linkableTemplateId: 'T1' },
    ];
    const roles = [
      {
        id: 'r1',
        jobCategory: 'Nurse',
        empNeeded: 'Yes',
        linkedRoleTemplateId: 'T1',
        lastEditChangeControlDateReason: '06/08/2026, 8:00:00 AM - user — Bulk update: Job Category',
      },
    ];
    const { affectedIds, updatedRoles } = applyJobCategoryChangesToRoles(roles, jobCategories, {
      jobCategories,
    });
    expect(affectedIds.size).toBe(0);
    expect(updatedRoles[0].lastEditChangeControlDateReason).toContain('Bulk update');
  });

  it('flags roles when category-derived fields drift', () => {
    const jobCategories = [{ id: 'c1', jobCategoryName: 'Nurse', needEMP: 'Yes' }];
    const roles = [{ id: 'r1', jobCategory: 'Nurse', empNeeded: 'No' }];
    const { affectedIds } = applyJobCategoryChangesToRoles(roles, jobCategories, { jobCategories });
    expect(affectedIds.size).toBe(1);
  });

  it('updates roles when the job category name was renamed', () => {
    const jobCategories = [{ id: 'c1', jobCategoryName: 'New Nurse', needEMP: 'Yes' }];
    const roles = [{ id: 'r1', jobCategory: 'Old Nurse', empNeeded: 'No' }];
    const { affectedIds, updatedRoles } = applyJobCategoryChangesToRoles(
      roles,
      [{ id: 'c1', jobCategoryName: 'New Nurse', needEMP: 'Yes' }],
      { jobCategories, previousNamesByCategoryId: { c1: 'Old Nurse' } }
    );
    expect(affectedIds.size).toBe(1);
    expect(updatedRoles[0].jobCategory).toBe('New Nurse');
    expect(updatedRoles[0].empNeeded).toBe('Yes');
  });
});

describe('applyJobCategoryRoleSyncPlan', () => {
  const roles = [
    { id: 'r1', rbacCode: 'RBAC001', jobCategory: 'Nurse', empNeeded: 'No', slaNeeded: 'No' },
    { id: 'r2', rbacCode: 'RBAC002', jobCategory: 'Physician', empNeeded: 'Yes' },
  ];
  const plan = {
    roleUpdates: [
      {
        roleId: 'r1',
        synced: {
          id: 'r1',
          rbacCode: 'RBAC001',
          jobCategory: 'Nurse',
          empNeeded: 'Yes',
          slaNeeded: 'Yes',
        },
        changes: [
          { field: 'empNeeded', from: 'No', to: 'Yes' },
          { field: 'slaNeeded', from: 'No', to: 'Yes' },
        ],
      },
    ],
  };

  it('applies synced role rows and stamps last edit', () => {
    const updated = applyJobCategoryRoleSyncPlan(roles, plan, 'stamp');
    expect(updated[0].empNeeded).toBe('Yes');
    expect(updated[0].slaNeeded).toBe('Yes');
    expect(updated[0].lastEditChangeControlDateReason).toBe('stamp');
    expect(updated[1].empNeeded).toBe('Yes');
  });

  it('applies only selected field changes', () => {
    const selected = new Set([buildRoleSyncSelectionKey('r1', 'empNeeded')]);
    const updated = applyJobCategoryRoleSyncPlan(roles, plan, 'stamp', selected);
    expect(updated[0].empNeeded).toBe('Yes');
    expect(updated[0].slaNeeded).toBe('No');
    expect(updated[0].lastEditChangeControlDateReason).toBe('stamp');
  });

  it('leaves roles unchanged when nothing is selected', () => {
    const updated = applyJobCategoryRoleSyncPlan(roles, plan, 'stamp', new Set());
    expect(updated).toEqual(roles);
  });

  it('matches role ids when one side is numeric and the other is a string', () => {
    const rolesWithNumericId = [{ id: 42, rbacCode: 'RBAC001', jobCategory: 'Nurse', empNeeded: 'No' }];
    const numericPlan = {
      roleUpdates: [
        {
          roleId: '42',
          synced: { id: 42, rbacCode: 'RBAC001', jobCategory: 'Nurse', empNeeded: 'Yes' },
          changes: [{ field: 'empNeeded', from: 'No', to: 'Yes' }],
        },
      ],
    };
    const updated = applyJobCategoryRoleSyncPlan(rolesWithNumericId, numericPlan, 'stamp');
    expect(updated[0].empNeeded).toBe('Yes');
  });
});

describe('remapRoleSyncSelectionToFreshPlan', () => {
  it('remaps selection when fresh plan uses a different role id for the same rbac code', () => {
    const originalPlan = {
      roleUpdates: [
        {
          roleId: 'old-id',
          rbacCode: 'RBAC001',
          changes: [{ field: 'empNeeded', from: 'No', to: 'Yes' }],
        },
      ],
    };
    const freshPlan = {
      roleUpdates: [
        {
          roleId: 'new-id',
          rbacCode: 'RBAC001',
          changes: [{ field: 'empNeeded', from: 'No', to: 'Yes' }],
        },
      ],
    };
    const selected = new Set(['old-id:empNeeded']);
    const remapped = remapRoleSyncSelectionToFreshPlan(originalPlan, freshPlan, selected);
    expect(remapped.has('new-id:empNeeded')).toBe(true);
  });
});

describe('countAppliedRoleSyncPatches', () => {
  it('counts roles that actually changed', () => {
    const before = [{ id: 'r1', empNeeded: 'No' }, { id: 'r2', empNeeded: 'Yes' }];
    const after = [{ id: 'r1', empNeeded: 'Yes' }, { id: 'r2', empNeeded: 'Yes' }];
    expect(countAppliedRoleSyncPatches(before, after)).toBe(1);
  });
});

describe('role sync selection helpers', () => {
  it('builds default selection for all pending changes', () => {
    const plan = {
      roleUpdates: [
        {
          roleId: 'r1',
          changes: [{ field: 'empNeeded' }, { field: 'slaNeeded' }],
        },
      ],
    };
    const selected = buildDefaultRoleSyncSelection(plan);
    expect(selected.size).toBe(2);
    expect(selected.has(buildRoleSyncSelectionKey('r1', 'empNeeded'))).toBe(true);
  });

  it('counts unique roles in a selection', () => {
    const selected = new Set([
      buildRoleSyncSelectionKey('r1', 'empNeeded'),
      buildRoleSyncSelectionKey('r1', 'slaNeeded'),
      buildRoleSyncSelectionKey('r2', 'empNeeded'),
    ]);
    expect(countSelectedRoleSyncUpdates(selected)).toBe(2);
  });
});
