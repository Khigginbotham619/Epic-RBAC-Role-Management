import { normalizeJobCode } from './jobCodeUtils';
import { displayTitlesFromTemplateLinks, formatTemplateNameTitleCase, templateNamesFromTemplateLinks } from './templateLinkRoleMatch';
import { blueprintNameForId, blueprintExistsInTable, resolveBlueprintReplacement } from './referenceTableAppend';

const rbacTemplateDisplayTitlesFromLinks = displayTitlesFromTemplateLinks;

/**
 * Shared logic for filling blank RBAC role fields from reference tables.
 * Used by RolesList (Fill Blanks button) and FindBlanks tab.
 * Job codes are always 4 characters with leading zeros preserved.
 *
 * @param {object} role - RBAC role
 * @param {object} context - { roles, jobCategories, jobCodes, departments, blueprints, getLastEditValue }
 * @returns {{ updates: object }} - Object of field -> value that would be filled (only blanks)
 */
function str(value) {
  if (value == null) return '';
  return String(value).replace(/\u00a0/g, ' ').trim();
}

/** True when the job category has a blueprint resolvable from the Blueprints table. */
export function categoryHasBlueprint(category, blueprints = null) {
  const bpId = str(category?.blueprintId);
  const bpName = str(category?.blueprintName);
  if (!bpId && !bpName) return false;
  if (!blueprints || (Array.isArray(blueprints) && blueprints.length === 0)) {
    return !!(bpId || bpName);
  }
  if (bpId && blueprintExistsInTable(blueprints, bpId)) return true;
  return !!resolveBlueprintReplacement(blueprints, bpId, bpName);
}

/** Category still stores a blueprint id or name (even if not in the reference table). */
export function categoryHasBlueprintReference(category) {
  return !!(str(category?.blueprintId) || str(category?.blueprintName));
}

/**
 * Blueprint fields to sync from a job category onto a role.
 * Never clears blueprint while the category still has a blueprint id or name.
 */
export function blueprintFieldsFromCategory(category, blueprints = []) {
  const bpId = str(category?.blueprintId);
  const bpName = str(category?.blueprintName);
  if (!categoryHasBlueprintReference(category)) {
    return { slaBlueprintId: '', blueprintName: '', forceSerYes: false };
  }
  if (bpId && blueprintExistsInTable(blueprints, bpId)) {
    return {
      slaBlueprintId: bpId,
      blueprintName: blueprintNameForId(blueprints, bpId, bpName),
      forceSerYes: true,
    };
  }
  const replacement = resolveBlueprintReplacement(blueprints, bpId, bpName);
  if (replacement) {
    return {
      slaBlueprintId: replacement.blueprintId,
      blueprintName: replacement.blueprintName,
      forceSerYes: true,
    };
  }
  return { slaBlueprintId: bpId, blueprintName: bpName, forceSerYes: false };
}

/** True when role.jobCategory matches the category name (case-insensitive, trimmed). */
export function roleMatchesJobCategory(role, category, options = {}) {
  const categoryName = str(category?.jobCategoryName);
  if (!categoryName) return false;
  const roleCat = str(role?.jobCategory).toLowerCase();
  if (roleCat === categoryName.toLowerCase()) return true;
  const previousName = str(options.previousCategoryName);
  return !!previousName && roleCat === previousName.toLowerCase();
}

export function buildCategoryByNameMap(jobCategories) {
  const categoryByName = new Map();
  for (const cat of jobCategories || []) {
    const name = str(cat.jobCategoryName ?? cat['Job Category Name'] ?? cat.job_category);
    if (name) categoryByName.set(name.toLowerCase(), cat);
  }
  return categoryByName;
}

/** True when role.jobCategory matches the category (by name, rename, or name map). */
export function roleBelongsToCategory(role, category, categoryByName, options = {}) {
  if (roleMatchesJobCategory(role, category, options)) return true;
  const roleCat = str(role?.jobCategory).toLowerCase();
  if (!roleCat || !categoryByName) return false;
  const mapped = categoryByName.get(roleCat);
  return mapped?.id === category.id;
}

/** Need SER? is Yes whenever the job category has a valid blueprint. */
export function effectiveCategoryNeedSer(category, blueprints = null) {
  const raw = str(category?.needSER);
  if (categoryHasBlueprint(category, blueprints) && raw.toLowerCase() !== 'yes') return 'Yes';
  return raw;
}

function computeFillUpdates(role, context) {
  const { roles = [], jobCategories = [], jobCodes = [], departments = [], blueprints = [], templateLinks = [] } = context;
  const updates = {};

  // If RBAC code exists but deptCodeId or jobCodeId is missing, split RBAC code: last 4 chars = job code, rest = dept code
  const rbacTrimmed = str(role.rbacCode);
  if (rbacTrimmed.length >= 4 && (!str(role.deptCodeId) || !str(role.jobCodeId))) {
    const jobCodeId = normalizeJobCode(rbacTrimmed.slice(-4));
    const deptCodeId = rbacTrimmed.slice(0, -4).trim();
    if (!str(role.deptCodeId) && deptCodeId) updates.deptCodeId = deptCodeId;
    if (!str(role.jobCodeId) && jobCodeId) updates.jobCodeId = jobCodeId;
  }

  let effectiveDeptCodeId = updates.deptCodeId ?? role.deptCodeId;
  let effectiveJobCodeId = updates.jobCodeId ?? role.jobCodeId;

  // If job code is still blank, try to copy from another role: same full RBAC code, or same job code (last 4 chars of RBAC)
  if (!str(effectiveJobCodeId) && rbacTrimmed) {
    let otherWithJobCode = roles.find(
      (r) => r && r.id !== role.id && str(r.rbacCode) === rbacTrimmed && str(r.jobCodeId)
    );
    if (!otherWithJobCode && rbacTrimmed.length >= 4) {
      const jobCodeSuffix = normalizeJobCode(rbacTrimmed.slice(-4));
      otherWithJobCode = roles.find(
        (r) => r && r.id !== role.id && str(r.rbacCode).length >= 4 &&
          normalizeJobCode(str(r.rbacCode).slice(-4)) === jobCodeSuffix && str(r.jobCodeId)
      );
    }
    if (otherWithJobCode) {
      const fromCode = normalizeJobCode(otherWithJobCode.jobCodeId);
      if (fromCode) {
        if (!str(role.jobCodeId)) updates.jobCodeId = fromCode;
        if (!str(role.jobTitle) && str(otherWithJobCode.jobTitle)) updates.jobTitle = str(otherWithJobCode.jobTitle);
        effectiveJobCodeId = updates.jobCodeId ?? effectiveJobCodeId;
      }
    }
  }

  if (!str(role.department) && str(effectiveDeptCodeId)) {
    const deptCodeIdNorm = str(effectiveDeptCodeId);
    const dept = departments.find((d) => str(d.deptId) === deptCodeIdNorm);
    if (dept && str(dept.deptDescription)) {
      updates.department = str(dept.deptDescription);
    }
  }
  const roleJobCode = normalizeJobCode(effectiveJobCodeId);
  if (!str(role.jobTitle) && roleJobCode) {
    const jc = jobCodes.find((j) => normalizeJobCode(j.jobCode) === roleJobCode);
    if (jc && str(jc.jobTitle)) {
      updates.jobTitle = str(jc.jobTitle);
    }
    // If still no job title (e.g. job code not in Job Codes list), copy from another role with same job code (same last 4 of RBAC)
    if (!updates.jobTitle && rbacTrimmed.length >= 4) {
      const jobCodeSuffix = normalizeJobCode(rbacTrimmed.slice(-4));
      const otherWithTitle = roles.find(
        (r) => r && r.id !== role.id && str(r.jobTitle) &&
          (normalizeJobCode(r.jobCodeId) === jobCodeSuffix ||
            (str(r.rbacCode).length >= 4 && normalizeJobCode(str(r.rbacCode).slice(-4)) === jobCodeSuffix))
      );
      if (otherWithTitle) updates.jobTitle = str(otherWithTitle.jobTitle);
    }
  }
  if (!str(role.jobCategory)) {
    const fromSameJobCode = roleJobCode ? roles.find((r) => normalizeJobCode(r.jobCodeId) === roleJobCode && str(r.jobCategory)) : null;
    const candidate = fromSameJobCode ? str(fromSameJobCode.jobCategory) : '';
    if (candidate && jobCategories.some((c) => str(c.jobCategoryName) === candidate)) {
      updates.jobCategory = candidate;
    }
  }
  // Blueprints are not required when SER (slaNeeded) is No
  const slaNeededNorm = str(role.slaNeeded).toLowerCase();
  const slaIdNorm = str(role.slaBlueprintId);
  if (slaNeededNorm !== 'no' && !str(role.blueprintName) && slaIdNorm) {
    const name = blueprintNameForId(blueprints, slaIdNorm, '');
    if (name) {
      updates.blueprintName = name;
      updates.slaNeeded = 'Yes';
    }
  }
  const jobCategoryName = str(updates.jobCategory ?? role.jobCategory);
  if (jobCategoryName) {
    const category = jobCategories.find((c) => str(c.jobCategoryName) === jobCategoryName);
    if (category) {
      if (!str(role.linkedRoleTemplateId)) updates.linkedRoleTemplateId = str(category.linkableTemplateId);
      if (!str(role.linkedRoleTemplateName)) {
        const linkableId = str(category.linkableTemplateId);
        const fromLinks =
          linkableId && templateLinks.length > 0
            ? templateNamesFromTemplateLinks(templateLinks, linkableId)
            : '';
        const name = fromLinks || str(category.linkableTemplateName);
        updates.linkedRoleTemplateName = name ? formatTemplateNameTitleCase(name) : '';
      }
      if (!str(role.subtemplateId)) updates.subtemplateId = str(category.subtemplatesId);
      if (!str(role.subtemplateDescription)) updates.subtemplateDescription = str(category.subtemplatesName);
      // EMP is only needed when a template or subtemplate exists (on role or being filled)
      const hasTemplateOrSubtemplate = str(role.linkedRoleTemplateId) || str(role.linkedRoleTemplateName) || str(role.subtemplateId) || str(role.subtemplateDescription) || str(updates.linkedRoleTemplateId) || str(updates.linkedRoleTemplateName) || str(updates.subtemplateId) || str(updates.subtemplateDescription);
      if (hasTemplateOrSubtemplate && !str(role.empNeeded)) updates.empNeeded = str(category.needEMP);
      if (!str(role.slaNeeded)) updates.slaNeeded = effectiveCategoryNeedSer(category, blueprints);
      // Blueprints are not required when SER is No
      const effectiveSlaNeeded = str(
        updates.slaNeeded ?? role.slaNeeded ?? effectiveCategoryNeedSer(category, blueprints)
      ).toLowerCase();
      if (effectiveSlaNeeded !== 'no') {
        const catBpId = str(category.blueprintId);
        if (
          !str(role.slaBlueprintId) &&
          catBpId &&
          (!blueprints?.length || blueprintExistsInTable(blueprints, catBpId))
        ) {
          updates.slaBlueprintId = catBpId;
        }
        if (!str(role.blueprintName)) {
          const bpId = str(updates.slaBlueprintId ?? category.blueprintId);
          updates.blueprintName = blueprintNameForId(blueprints, bpId, category.blueprintName);
        }
        if (updates.slaBlueprintId || updates.blueprintName) updates.slaNeeded = 'Yes';
      }
      // Autofill training tracks from category (not prompted in Find Blanks tab)
      if (!str(role.trainingTrack)) updates.trainingTrack = str(category.trainingTrack1);
      if (!str(role.trainingTrack2)) updates.trainingTrack2 = str(category.trainingTrack2);
      if (!str(role.trainingTrack3)) updates.trainingTrack3 = str(category.trainingTrack3);
      if (!str(role.trainingTrack4)) updates.trainingTrack4 = str(category.trainingTrack4);
      if (!str(role.trainingTrack5)) updates.trainingTrack5 = str(category.trainingTrack5);
      if (!str(role.trainingTrack6)) updates.trainingTrack6 = str(category.trainingTrack6);
      if (!str(role.sailpointRole)) updates.sailpointRole = str(category.sailpointRole);
    }
  }
  if (!str(role.templateDisplayTitle) && templateLinks.length > 0) {
    const tid = str(updates.linkedRoleTemplateId ?? role.linkedRoleTemplateId);
    const categoryDesc = jobCategoryName
      ? str(jobCategories.find((c) => str(c.jobCategoryName) === jobCategoryName)?.linkableTemplateName)
      : '';
    if (categoryDesc) {
      updates.templateDisplayTitle = categoryDesc;
    } else if (tid) {
      const tname = str(updates.linkedRoleTemplateName ?? role.linkedRoleTemplateName);
      const d = rbacTemplateDisplayTitlesFromLinks(templateLinks, tid, tname);
      if (d) updates.templateDisplayTitle = d;
    }
  }
  return { updates };
}

/**
 * Preview which fields would be filled (same rules as Fill Blanks / Find Blanks), without mutating the role.
 *
 * @param {object} role - RBAC role-shaped object (must include `id` for peer-role lookups)
 * @param {object} context - { roles, jobCategories, jobCodes, departments, blueprints, templateLinks }
 * @returns {Record<string, string>} Suggested field values for currently blank fields only
 */
export function getFillUpdatesForRole(role, context) {
  const { updates } = computeFillUpdates(role, context);
  return updates;
}

/**
 * Returns the role with blanks filled from reference tables. If nothing to fill, returns the same role.
 *
 * @param {object} role - RBAC role
 * @param {object} context - { roles, jobCategories, jobCodes, departments, blueprints, getLastEditValue }
 * @returns {object} - Role with filled fields and lastEditChangeControlDateReason updated
 */
export function fillBlanksForRole(role, context) {
  const { updates } = computeFillUpdates(role, context);
  if (Object.keys(updates).length === 0) return role;
  const lastEdit = typeof context.getLastEditValue === 'function' ? context.getLastEditValue() : '';
  return { ...role, ...updates, lastEditChangeControlDateReason: lastEdit };
}

/**
 * Returns which blanks can be filled for a role (for display in Find Blanks tab).
 *
 * @param {object} role - RBAC role
 * @param {object} context - { roles, jobCategories, jobCodes, departments, blueprints }
 * @returns {{ filledRole: object, changes: object }} - filledRole = role + changes; changes = { fieldName: suggestedValue }
 */
export function getBlanksForRole(role, context) {
  const { updates } = computeFillUpdates(role, context);
  const lastEdit = typeof context.getLastEditValue === 'function' ? context.getLastEditValue() : '';
  const filledRole = Object.keys(updates).length === 0
    ? role
    : { ...role, ...updates, lastEditChangeControlDateReason: lastEdit };
  return { filledRole, changes: updates };
}

/**
 * Apply an updated job category to a role. Only updates the fixed set of category-derived
 * fields (template, subtemplate, blueprint, EMP/SER, training tracks). Ignores any fields
 * added to the category after roles were assigned (we do not add new role properties).
 * Used when a job category is updated so all roles in that category stay in sync.
 *
 * @param {object} role - RBAC role (must have role.jobCategory matching category.jobCategoryName)
 * @param {object} category - Updated job category
 * @param {object[]} blueprints - Blueprints list for blueprint name lookup
 * @returns {object} - Role with category-derived fields updated from the category
 */
export function applyCategoryUpdatesToRole(role, category, blueprints = [], templateLinks = [], options = {}) {
  const categoryByName = options.categoryByName;
  const belongs =
    roleMatchesJobCategory(role, category, options) ||
    (categoryByName && roleBelongsToCategory(role, category, categoryByName, options));
  if (!belongs) return role;

  const updates = {};
  const categoryName = str(category.jobCategoryName);
  const roleCategory = str(role.jobCategory);
  const previousName = str(options.previousCategoryName);
  if (
    previousName &&
    roleCategory.toLowerCase() === previousName.toLowerCase() &&
    roleCategory.toLowerCase() !== categoryName.toLowerCase()
  ) {
    updates.jobCategory = categoryName;
  }

  updates.linkedRoleTemplateId = str(category.linkableTemplateId);
  const linkableId = updates.linkedRoleTemplateId;
  const linkableName = str(category.linkableTemplateName);
  const templateNameFromLinks =
    linkableId && templateLinks.length > 0 ? templateNamesFromTemplateLinks(templateLinks, linkableId) : '';
  updates.linkedRoleTemplateName = templateNameFromLinks
    ? formatTemplateNameTitleCase(templateNameFromLinks)
    : linkableName
      ? formatTemplateNameTitleCase(linkableName)
      : '';
  updates.subtemplateId = str(category.subtemplatesId);
  updates.subtemplateDescription = str(category.subtemplatesName);
  updates.empNeeded = str(category.needEMP);
  updates.slaNeeded = effectiveCategoryNeedSer(category, blueprints);
  const bpFields = blueprintFieldsFromCategory(category, blueprints);
  updates.slaBlueprintId = bpFields.slaBlueprintId;
  updates.blueprintName = bpFields.blueprintName;
  if (bpFields.forceSerYes) updates.slaNeeded = 'Yes';

  updates.trainingTrack = str(category.trainingTrack1);
  updates.trainingTrack2 = str(category.trainingTrack2);
  updates.trainingTrack3 = str(category.trainingTrack3);
  updates.trainingTrack4 = str(category.trainingTrack4);
  updates.trainingTrack5 = str(category.trainingTrack5);
  updates.trainingTrack6 = str(category.trainingTrack6);
  const categorySailpointRole = str(category.sailpointRole);
  // Preserve existing role mapping when the category has no sailpoint role value.
  if (categorySailpointRole) {
    updates.sailpointRole = categorySailpointRole;
  }

  if (templateLinks && templateLinks.length > 0) {
    const categoryDescription = str(category.linkableTemplateName);
    if (categoryDescription) {
      updates.templateDisplayTitle = categoryDescription;
    } else {
      const computed = rbacTemplateDisplayTitlesFromLinks(
        templateLinks,
        updates.linkedRoleTemplateId,
        updates.linkedRoleTemplateName
      );
      if (computed) updates.templateDisplayTitle = computed;
    }
  }

  return { ...role, ...updates };
}
