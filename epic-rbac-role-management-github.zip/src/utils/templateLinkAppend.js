import {
  canonicalTemplateLinkRecordType,
  formatTemplateNameTitleCase,
  normalizeTemplateLinkRow,
  splitLinkableTemplateDescriptionSlotsForSync,
  splitTemplateDisplayTitleSlots,
  splitTemplateIdTokens,
  splitTemplateNameTokens,
  splitSubtemplateNameSlotsForSync,
  templateNamesFromTemplateLinks,
} from './templateLinkRoleMatch';

/**
 * Collect occupied template/subtemplate tokens from existing template_links rows
 * (same coverage idea as lookup when syncing from the reference table).
 */
export function collectTemplateLinkOccupancy(links) {
  const linkableIds = new Set();
  const linkableNames = new Set();
  const subIds = new Set();
  const subNames = new Set();

  const addSubtemplateNameTokensFromCell = (raw) => {
    if (raw == null || !String(raw).trim()) return;
    const s = String(raw).replace(/\r\n?/g, '\n').trim();
    let parts;
    if (s.includes(',')) {
      parts = s.split(',').map((t) => t.trim().toLowerCase()).filter(Boolean);
    } else {
      parts = splitTemplateNameTokens(s).map((t) => t.toLowerCase());
    }
    parts.forEach((p) => subNames.add(p));
  };

  for (const row of links || []) {
    const n = normalizeTemplateLinkRow(row);
    const kind = canonicalTemplateLinkRecordType(n);
    if (kind === 'Linkable Template') {
      splitTemplateIdTokens(n.templateId).forEach((t) => linkableIds.add(t.toLowerCase()));
      splitTemplateNameTokens(n.templateName).forEach((t) => linkableNames.add(t.toLowerCase()));
      splitTemplateIdTokens(n.subtemplateId).forEach((t) => subIds.add(t.toLowerCase()));
      addSubtemplateNameTokensFromCell(n.subtemplateName);
    } else if (kind === 'Subtemplate') {
      splitTemplateIdTokens(n.templateId).forEach((t) => subIds.add(t.toLowerCase()));
      splitTemplateNameTokens(n.templateName).forEach((t) => subNames.add(t.toLowerCase()));
    }
  }

  return { linkableIds, linkableNames, subIds, subNames };
}

function linkableSlotOccupied(occ, idToken, nameToken) {
  const id = (idToken || '').trim();
  const name = (nameToken || '').trim();
  if (id && occ.linkableIds.has(id.toLowerCase())) return true;
  if (name && occ.linkableNames.has(name.toLowerCase())) return true;
  return false;
}

function subtemplateSlotOccupied(occ, idToken, nameToken) {
  const id = (idToken || '').trim();
  const name = (nameToken || '').trim();
  if (id && occ.subIds.has(id.toLowerCase())) return true;
  if (name && occ.subNames.has(name.toLowerCase())) return true;
  return false;
}

/**
 * Build new template_links rows for values entered on the role form that are not yet in the reference table.
 * Does not mutate existing rows; caller should append via appendTemplateLinks.
 */
export function buildTemplateLinkRowsToAppendFromRole(links, roleFields) {
  const occ = collectTemplateLinkOccupancy(links);
  const out = [];

  const ids = splitTemplateIdTokens(roleFields.linkedRoleTemplateId);
  const names = splitTemplateNameTokens(roleFields.linkedRoleTemplateName);
  const titleSlots = splitTemplateDisplayTitleSlots(roleFields.templateDisplayTitle);
  const linkSlots = Math.max(ids.length, names.length, 1);
  for (let i = 0; i < linkSlots; i++) {
    const id = (ids[i] ?? '').trim();
    const name = (names[i] ?? '').trim();
    if (!id && !name) continue;
    if (linkableSlotOccupied(occ, id, name)) continue;
    if (id) occ.linkableIds.add(id.toLowerCase());
    if (name) occ.linkableNames.add(name.toLowerCase());
    out.push({
      userRecordType: 'Linkable Template',
      templateId: id,
      templateName: name ? formatTemplateNameTitleCase(name) : '',
      primaryTemplateOwner: '',
      templateDisplayTitle: (titleSlots[i] ?? titleSlots[0] ?? '').trim(),
      subtemplateId: '',
      subtemplateName: '',
      currentStatus: 'Active',
    });
  }

  const sIds = splitTemplateIdTokens(roleFields.subtemplateId);
  const sNames = splitSubtemplateNameSlotsForSync(roleFields.subtemplateDescription);
  const subSlots = Math.max(sIds.length, sNames.length, 1);
  for (let i = 0; i < subSlots; i++) {
    const id = (sIds[i] ?? '').trim();
    const name = (sNames[i] ?? '').trim();
    if (!id && !name) continue;
    if (subtemplateSlotOccupied(occ, id, name)) continue;
    if (id) occ.subIds.add(id.toLowerCase());
    if (name) occ.subNames.add(name.toLowerCase());
    out.push({
      userRecordType: 'Subtemplate',
      templateId: id,
      templateName: name ? formatTemplateNameTitleCase(name) : '',
      primaryTemplateOwner: '',
      templateDisplayTitle: '',
      subtemplateId: '',
      subtemplateName: '',
      currentStatus: 'Active',
    });
  }

  return out;
}

/**
 * Same as {@link buildTemplateLinkRowsToAppendFromRole} for job category edit fields.
 */
export function buildTemplateLinkRowsToAppendFromJobCategory(links, catFields) {
  const occ = collectTemplateLinkOccupancy(links);
  const out = [];

  const ids = splitTemplateIdTokens(catFields.linkableTemplateId);
  const descriptions = splitLinkableTemplateDescriptionSlotsForSync(catFields.linkableTemplateName);
  const namesFromLinks = templateNamesFromTemplateLinks(links, catFields.linkableTemplateId);
  const names = splitTemplateNameTokens(namesFromLinks);
  const linkSlots = Math.max(ids.length, descriptions.length, names.length, 1);
  for (let i = 0; i < linkSlots; i++) {
    const id = (ids[i] ?? '').trim();
    const description = (descriptions[i] ?? descriptions[0] ?? '').trim();
    const name = (names[i] ?? names[0] ?? '').trim();
    if (!id && !name && !description) continue;
    if (linkableSlotOccupied(occ, id, name)) continue;
    if (id) occ.linkableIds.add(id.toLowerCase());
    if (name) occ.linkableNames.add(name.toLowerCase());
    out.push({
      userRecordType: 'Linkable Template',
      templateId: id,
      templateName: name ? formatTemplateNameTitleCase(name) : '',
      primaryTemplateOwner: '',
      templateDisplayTitle: description,
      subtemplateId: '',
      subtemplateName: '',
      currentStatus: 'Active',
    });
  }

  const sIds = splitTemplateIdTokens(catFields.subtemplatesId);
  const sNames = splitSubtemplateNameSlotsForSync(catFields.subtemplatesName);
  const subSlots = Math.max(sIds.length, sNames.length, 1);
  for (let i = 0; i < subSlots; i++) {
    const id = (sIds[i] ?? '').trim();
    const name = (sNames[i] ?? '').trim();
    if (!id && !name) continue;
    if (subtemplateSlotOccupied(occ, id, name)) continue;
    if (id) occ.subIds.add(id.toLowerCase());
    if (name) occ.subNames.add(name.toLowerCase());
    out.push({
      userRecordType: 'Subtemplate',
      templateId: id,
      templateName: name ? formatTemplateNameTitleCase(name) : '',
      primaryTemplateOwner: '',
      templateDisplayTitle: '',
      subtemplateId: '',
      subtemplateName: '',
      currentStatus: 'Active',
    });
  }

  return out;
}
