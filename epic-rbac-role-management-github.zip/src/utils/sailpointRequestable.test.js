import {
  findSailpointCatalogRowByName,
  formatSailpointRoleRequestableDisplay,
  getNonRequestableSailpointRoleWarning,
  getSailpointRequestableFilterBucket,
  getSailpointRoleRequestableValue,
  isNonRequestableSailpointCatalogRow,
  isRequestableSailpointCatalogRow,
  matchesSailpointRequestableFilter,
} from './sailpointRequestable';

describe('sailpointRequestable', () => {
  const catalog = [
    { sailpointRole: 'Epic Mosaic Active Role', requestable: 'TRUE' },
    { sailpointRole: 'Epic Mosaic Legacy Role', requestable: 'FALSE' },
  ];

  it('detects requestable and non-requestable catalog rows', () => {
    const active = findSailpointCatalogRowByName(catalog, 'epic mosaic active role');
    const legacy = findSailpointCatalogRowByName(catalog, 'epic mosaic legacy role');
    expect(isRequestableSailpointCatalogRow(active)).toBe(true);
    expect(isRequestableSailpointCatalogRow(legacy)).toBe(false);
    expect(isRequestableSailpointCatalogRow(null)).toBe(false);
    expect(isNonRequestableSailpointCatalogRow(legacy)).toBe(true);
    expect(getNonRequestableSailpointRoleWarning('Epic Mosaic Legacy Role', catalog)).toMatch(
      /requestable=FALSE/
    );
  });

  it('returns null for requestable or unknown roles', () => {
    expect(getNonRequestableSailpointRoleWarning('Epic Mosaic Active Role', catalog)).toBeNull();
    expect(getNonRequestableSailpointRoleWarning('Not In Catalog', catalog)).toBeNull();
    expect(getNonRequestableSailpointRoleWarning('', catalog)).toBeNull();
  });

  it('reads requestable values for display', () => {
    expect(getSailpointRoleRequestableValue('Epic Mosaic Active Role', catalog)).toBe('TRUE');
    expect(formatSailpointRoleRequestableDisplay('Epic Mosaic Legacy Role', catalog)).toBe('FALSE');
    expect(formatSailpointRoleRequestableDisplay('Not In Catalog', catalog)).toBe('—');
    expect(formatSailpointRoleRequestableDisplay('', catalog)).toBe('—');
  });

  it('filters by requestable bucket', () => {
    expect(getSailpointRequestableFilterBucket('Epic Mosaic Active Role', catalog)).toBe('Requestable');
    expect(getSailpointRequestableFilterBucket('Epic Mosaic Legacy Role', catalog)).toBe('Non-requestable');
    expect(getSailpointRequestableFilterBucket('Missing', catalog)).toBe('Unknown');
    expect(matchesSailpointRequestableFilter('Epic Mosaic Active Role', catalog, 'Requestable')).toBe(true);
    expect(matchesSailpointRequestableFilter('Epic Mosaic Legacy Role', catalog, 'Requestable')).toBe(false);
    expect(matchesSailpointRequestableFilter('Epic Mosaic Legacy Role', catalog, 'Non-requestable')).toBe(true);
    expect(matchesSailpointRequestableFilter('Missing', catalog, 'Non-requestable')).toBe(false);
    expect(matchesSailpointRequestableFilter('Missing', catalog, 'All')).toBe(true);
  });
});
