/**
 * SailPoint catalog requestable flag helpers for data-entry warnings.
 */

function s(v) {
  return v == null ? '' : String(v).trim();
}

/** Find a catalog row by role name (case-insensitive). */
export function findSailpointCatalogRowByName(sailpointCatalogRows, roleName) {
  const key = s(roleName).toLowerCase();
  if (!key) return null;
  return (
    (sailpointCatalogRows || []).find(
      (row) => s(row?.sailpointRole).toLowerCase() === key
    ) || null
  );
}

/** True when the catalog row is explicitly requestable=FALSE. */
export function isNonRequestableSailpointCatalogRow(row) {
  if (!row) return false;
  return s(row.requestable).toUpperCase() === 'FALSE';
}

/** True when the catalog row is explicitly requestable=TRUE. */
export function isRequestableSailpointCatalogRow(row) {
  if (!row) return false;
  return s(row.requestable).toUpperCase() === 'TRUE';
}

/**
 * Warning message when roleName maps to a non-requestable catalog row, or null.
 */
/** Raw `requestable` value from the catalog row for a role name, or '' if unknown. */
export function getSailpointRoleRequestableValue(roleName, sailpointCatalogRows) {
  const row = findSailpointCatalogRowByName(sailpointCatalogRows, roleName);
  if (!row) return '';
  return s(row.requestable);
}

/** Normalized requestable flag from catalog: TRUE, FALSE, or '' (unknown / no role). */
export function getSailpointRequestableFilterBucket(roleName, sailpointCatalogRows) {
  const value = getSailpointRoleRequestableValue(roleName, sailpointCatalogRows).toUpperCase();
  if (value === 'TRUE') return 'Requestable';
  if (value === 'FALSE') return 'Non-requestable';
  return 'Unknown';
}

/**
 * @param {'All'|'Requestable'|'Non-requestable'} filter
 */
export function matchesSailpointRequestableFilter(roleName, sailpointCatalogRows, filter) {
  const f = String(filter || 'All').trim();
  if (!f || f === 'All') return true;
  const bucket = getSailpointRequestableFilterBucket(roleName, sailpointCatalogRows);
  if (f === 'Requestable') return bucket === 'Requestable';
  if (f === 'Non-requestable') return bucket === 'Non-requestable';
  return true;
}

/** Display value for tables/exports (TRUE/FALSE/—). */
export function formatSailpointRoleRequestableDisplay(roleName, sailpointCatalogRows) {
  if (!s(roleName)) return '—';
  const value = getSailpointRoleRequestableValue(roleName, sailpointCatalogRows);
  return value || '—';
}

export function getNonRequestableSailpointRoleWarning(roleName, sailpointCatalogRows) {
  const row = findSailpointCatalogRowByName(sailpointCatalogRows, roleName);
  if (!isNonRequestableSailpointCatalogRow(row)) return null;
  const roleLabel = s(row.sailpointRole) || s(roleName);
  return (
    `The SailPoint role "${roleLabel}" is marked requestable=FALSE in the SailPoint catalog. ` +
    'Users may not be able to request access through SailPoint for RBAC roles linked to this job category. ' +
    'Use a requestable role unless this is intentional.'
  );
}
