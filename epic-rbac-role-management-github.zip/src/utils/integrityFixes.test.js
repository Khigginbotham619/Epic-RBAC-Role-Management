import {
  detectRoleBlueprintFromTable,
  detectCategoryOrphanBlueprintRefs,
  detectCategoryBlueprintNameFromTable,
  detectCategorySerWhenBlueprint,
  detectRoleBlueprintNameFromTable,
  detectEmpWithoutTemplate,
  detectNoAccessEmpMismatch,
  detectOrphanTemplateRefs,
  detectSailpointDriftFromCategory,
  detectRoleDerivedFieldDriftFromCategory,
  findIntegrityFixes,
  applyIntegrityFixes,
  INTEGRITY_FIX_CODE_LABEL,
} from './integrityFixes';

describe('detectRoleBlueprintFromTable', () => {
  const blueprints = [{ blueprintId: 'BP1', blueprintName: 'Blueprint One' }];

  it('sets SER Needed to Yes when blueprint ID is in the Blueprints table', () => {
    const out = detectRoleBlueprintFromTable(
      [
        { id: 'r1', slaNeeded: 'No', slaBlueprintId: 'BP1', blueprintName: 'X' },
        { id: 'r2', slaNeeded: 'Yes', slaBlueprintId: 'BP1', blueprintName: 'Blueprint One' },
      ],
      blueprints,
    );
    expect(out.map((p) => p.roleId)).toEqual(['r1']);
    expect(out[0].code).toBe('role-ser-when-blueprint');
    expect(out[0].after).toEqual({
      slaNeeded: 'Yes',
      slaBlueprintId: 'BP1',
      blueprintName: 'Blueprint One',
    });
  });

  it('replaces blueprint when the stored ID is not in the Blueprints table but the name matches', () => {
    const out = detectRoleBlueprintFromTable(
      [{ id: 'r1', slaNeeded: 'No', slaBlueprintId: 'B999', blueprintName: 'Ambulatory Physician' }],
      [{ blueprintId: 'B10000', blueprintName: 'Ambulatory Physician' }],
    );
    expect(out).toHaveLength(1);
    expect(out[0].code).toBe('role-blueprint-replace');
    expect(out[0].after).toEqual({
      slaNeeded: 'Yes',
      slaBlueprintId: 'B10000',
      blueprintName: 'Ambulatory Physician',
    });
  });

  it('leaves blueprint unchanged when no replacement can be found', () => {
    const out = detectRoleBlueprintFromTable(
      [{ id: 'r1', slaNeeded: 'No', slaBlueprintId: 'B999', blueprintName: 'Unknown Blueprint' }],
      [{ blueprintId: 'B10000', blueprintName: 'Ambulatory Physician' }],
    );
    expect(out).toEqual([]);
  });

  it('assigns blueprint ID from the table when only blueprint name is on the role', () => {
    const out = detectRoleBlueprintFromTable(
      [{ id: 'r1', slaNeeded: 'No', slaBlueprintId: '', blueprintName: 'Ambulatory Physician' }],
      [{ blueprintId: 'B10000', blueprintName: 'Ambulatory Physician' }],
    );
    expect(out).toHaveLength(1);
    expect(out[0].code).toBe('role-blueprint-replace');
    expect(out[0].after.slaBlueprintId).toBe('B10000');
  });
});

describe('detectRoleDerivedFieldDriftFromCategory', () => {
  const blueprints = [{ blueprintId: 'B10000', blueprintName: 'Ambulatory Physician' }];

  it('does not propose clearing blueprint when the category still has a blueprint reference', () => {
    const jobCategories = [
      {
        id: 'cat1',
        jobCategoryName: 'Nurse',
        needSER: 'No',
        blueprintId: 'B999',
        blueprintName: 'Ambulatory Physician',
        status: 'Active',
      },
    ];
    const roles = [
      {
        id: 'r1',
        jobCategory: 'Nurse',
        status: 'Active',
        slaNeeded: 'Yes',
        slaBlueprintId: 'B999',
        blueprintName: 'Ambulatory Physician',
      },
    ];
    const out = detectRoleDerivedFieldDriftFromCategory(roles, jobCategories, blueprints);
    const wipingDrift = out.filter(
      (p) =>
        p.code === 'role-category-drift' &&
        (('slaBlueprintId' in (p.after || {}) && !String(p.after.slaBlueprintId || '').trim()) ||
          ('blueprintName' in (p.after || {}) && !String(p.after.blueprintName || '').trim())),
    );
    expect(wipingDrift).toEqual([]);
    const replace = findIntegrityFixes({ roles, jobCategories, templateLinks: [], blueprints }).find(
      (p) => p.code === 'category-blueprint-replace' || p.code === 'role-blueprint-replace',
    );
    expect(replace).toBeTruthy();
  });
});

describe('detectCategorySerWhenBlueprint', () => {
  const blueprints = [
    { blueprintId: 'B1', blueprintName: 'One' },
    { blueprintId: 'B2', blueprintName: 'Two' },
  ];

  it('flags job categories with a blueprint in the table when Need SER? is not Yes', () => {
    const out = detectCategorySerWhenBlueprint(
      [
        { id: 'c1', jobCategoryName: 'Nurse', needSER: 'No', blueprintId: 'B1' },
        { id: 'c2', jobCategoryName: 'Doc', needSER: '', blueprintName: 'Physician' },
        { id: 'c3', jobCategoryName: 'Tech', needSER: 'Yes', blueprintId: 'B2' },
        { id: 'c4', jobCategoryName: 'Admin', needSER: 'No', blueprintId: '' },
        { id: 'c5', jobCategoryName: 'Bad', needSER: 'No', blueprintId: 'B999' },
      ],
      [],
      blueprints,
    );
    expect(out.map((p) => p.categoryId).sort()).toEqual(['c1']);
    expect(out[0].after).toEqual({
      needSER: 'Yes',
      blueprintId: 'B1',
      blueprintName: 'One',
    });
  });

  it('skips inactive job categories', () => {
    const out = detectCategorySerWhenBlueprint(
      [{ id: 'c1', jobCategoryName: 'Nurse', status: 'Inactive', needSER: 'No', blueprintId: 'B1' }],
      [],
      [{ blueprintId: 'B1', blueprintName: 'One' }],
    );
    expect(out).toEqual([]);
  });
});

describe('detectCategoryOrphanBlueprintRefs', () => {
  it('replaces blueprint when the stored ID is not in the Blueprints table but the name matches', () => {
    const out = detectCategoryOrphanBlueprintRefs(
      [{ id: 'c1', jobCategoryName: 'Nurse', blueprintId: 'B999', blueprintName: 'Ambulatory Physician' }],
      [{ blueprintId: 'B10000', blueprintName: 'Ambulatory Physician' }],
    );
    expect(out).toHaveLength(1);
    expect(out[0].code).toBe('category-blueprint-replace');
    expect(out[0].after).toEqual({
      needSER: 'Yes',
      blueprintId: 'B10000',
      blueprintName: 'Ambulatory Physician',
    });
  });

  it('does not propose a fix when no replacement can be found', () => {
    const out = detectCategoryOrphanBlueprintRefs(
      [{ id: 'c1', jobCategoryName: 'Nurse', blueprintId: 'B999', blueprintName: 'Old' }],
      [{ blueprintId: 'B1', blueprintName: 'Valid' }],
    );
    expect(out).toEqual([]);
  });
});

describe('detectCategoryBlueprintNameFromTable', () => {
  const blueprints = [{ blueprintId: 'B10000', blueprintName: 'Ambulatory Physician' }];

  it('flags job categories whose blueprint name does not match the Blueprints table', () => {
    const out = detectCategoryBlueprintNameFromTable(
      [
        {
          id: 'cat1',
          jobCategoryName: 'Surgeon',
          needSER: 'Yes',
          blueprintId: 'B10000',
          blueprintName: 'Wrong Name',
        },
        {
          id: 'cat2',
          jobCategoryName: 'Nurse',
          needSER: 'Yes',
          blueprintId: 'b10000',
          blueprintName: '',
        },
      ],
      blueprints,
    );
    expect(out.map((p) => p.categoryId).sort()).toEqual(['cat1', 'cat2']);
    for (const p of out) {
      expect(p.after.blueprintName).toBe('Ambulatory Physician');
      expect(p.level).toBe('category');
    }
  });

  it('skips when SER is No or blueprint ID is not in the table', () => {
    const out = detectCategoryBlueprintNameFromTable(
      [
        { id: 'a', needSER: 'No', blueprintId: 'B10000', blueprintName: '' },
        { id: 'b', needSER: 'Yes', blueprintId: 'B99999', blueprintName: '' },
        { id: 'c', needSER: 'Yes', blueprintId: 'B10000', blueprintName: 'Ambulatory Physician' },
      ],
      blueprints,
    );
    expect(out).toEqual([]);
  });
});

describe('detectRoleBlueprintNameFromTable', () => {
  const blueprints = [{ blueprintId: 'B10000', blueprintName: 'Ambulatory Physician' }];

  it('fills blueprint name on roles when the ID is in the Blueprints table', () => {
    const out = detectRoleBlueprintNameFromTable(
      [{ id: 'r1', slaNeeded: 'Yes', slaBlueprintId: 'b10000', blueprintName: '' }],
      blueprints,
      [],
    );
    expect(out).toHaveLength(1);
    expect(out[0].after.blueprintName).toBe('Ambulatory Physician');
  });

  it('skips when the job category owns the same blueprint ID', () => {
    const out = detectRoleBlueprintNameFromTable(
      [{ id: 'r1', jobCategory: 'Surgeon', slaNeeded: 'Yes', slaBlueprintId: 'B10000', blueprintName: '' }],
      blueprints,
      [{ jobCategoryName: 'Surgeon', blueprintId: 'B10000', needSER: 'Yes' }],
    );
    expect(out).toEqual([]);
  });
});

describe('detectEmpWithoutTemplate', () => {
  it('flags roles with empNeeded set but no template anywhere (non-SHELL, non-No-Access)', () => {
    const out = detectEmpWithoutTemplate(
      [
        {
          id: 'r1',
          empNeeded: 'Yes',
          linkedRoleTemplateId: '',
          subtemplateId: '',
          jobCategory: 'Wait for request',
        },
        { id: 'r2', empNeeded: 'Yes', linkedRoleTemplateId: 'T1', jobCategory: 'X' },
        { id: 'r3', empNeeded: '', jobCategory: 'X' },
      ],
      [{ jobCategoryName: 'X', linkableTemplateId: '', subtemplatesId: '' }],
    );
    expect(out.map((p) => p.roleId)).toEqual([]);
  });

  it('does not flag when category has a linkable template', () => {
    const out = detectEmpWithoutTemplate(
      [{ id: 'r1', empNeeded: 'Yes', jobCategory: 'X' }],
      [{ jobCategoryName: 'X', linkableTemplateId: 'T2100301' }],
    );
    expect(out).toEqual([]);
  });

  it('does not flag when category has comma-separated linkable templates', () => {
    const out = detectEmpWithoutTemplate(
      [{ id: 'r1', empNeeded: 'Yes', jobCategory: 'X' }],
      [{ jobCategoryName: 'X', linkableTemplateId: 'T2100301, T2100302' }],
    );
    expect(out).toEqual([]);
  });

  it('skips No-Access rows (handled by detectNoAccessEmpMismatch)', () => {
    const out = detectEmpWithoutTemplate(
      [{ id: 'r1', empNeeded: 'Yes', linkedRoleTemplateName: 'No Access', jobCategory: 'X' }],
      [],
    );
    expect(out).toEqual([]);
  });

  it('does not clear EMP on SHELL rows', () => {
    const out = detectEmpWithoutTemplate(
      [{ id: 'r1', empNeeded: 'Yes', jobCategory: 'SHELL' }],
      [{ jobCategoryName: 'SHELL', linkableTemplateId: '' }],
    );
    expect(out).toEqual([]);
  });
});

describe('detectNoAccessEmpMismatch', () => {
  it('flags No-Access rows whose empNeeded is anything other than "No"', () => {
    const out = detectNoAccessEmpMismatch([
      { id: 'r1', empNeeded: 'Yes', linkedRoleTemplateName: 'No Access' },
      { id: 'r2', empNeeded: 'No', linkedRoleTemplateName: 'No Access' },
      { id: 'r3', empNeeded: '', templateDisplayTitle: 'No Access Role' },
      { id: 'r4', empNeeded: 'no', jobCategory: 'Wait for request' },
      { id: 'r5', empNeeded: 'Yes', linkedRoleTemplateName: 'Some real template' },
    ]);
    expect(out.map((p) => p.roleId).sort()).toEqual(['r1', 'r3']);
    for (const p of out) {
      expect(p.code).toBe('no-access-emp-mismatch');
      expect(p.after).toEqual({ empNeeded: 'No' });
    }
  });

  it('treats various No-Access marker strings as triggering', () => {
    const out = detectNoAccessEmpMismatch([
      { id: 'r1', empNeeded: 'Yes', subtemplateDescription: 'Manual build in lower environments and DC to prod' },
      { id: 'r2', empNeeded: 'Yes', jobCategory: 'Nurse Practitioner - Anesthesia' },
    ]);
    expect(out.map((p) => p.roleId).sort()).toEqual(['r1', 'r2']);
  });

  it('does not flag Sr Director - Revenue Cycle or SHELL rows when EMP is Yes', () => {
    const cats = [{ jobCategoryName: 'Sr Director - Revenue Cycle', linkableTemplateId: 'T100' }];
    const out = detectNoAccessEmpMismatch(
      [
        {
          id: 'r-rev',
          empNeeded: 'Yes',
          jobCategory: 'Sr Director - Revenue Cycle',
          linkedRoleTemplateId: 'T100',
        },
        { id: 'r-shell', empNeeded: 'Yes', jobCategory: 'SHELL' },
      ],
      cats,
    );
    expect(out).toEqual([]);
  });
});

describe('detectOrphanTemplateRefs', () => {
  const templateLinks = [
    { templateId: 'T1', templateName: 'Alpha', recordType: 'Linkable Template', subtemplateId: 'ST1' },
    { templateId: 'T2', templateName: 'Beta' },
  ];

  it('flags ids, names, and subtemplate ids missing from Template Links', () => {
    const out = detectOrphanTemplateRefs(
      [
        {
          id: 'r1',
          linkedRoleTemplateId: 'T1, T99',
          linkedRoleTemplateName: 'Alpha, Beta',
          subtemplateId: 'ST1, STZ',
        },
        {
          id: 'r2',
          linkedRoleTemplateId: 'T2',
          linkedRoleTemplateName: 'Beta',
          subtemplateId: '',
        },
      ],
      templateLinks,
    );
    expect(out).toHaveLength(1);
    expect(out[0].roleId).toBe('r1');
    expect(out[0].after.linkedRoleTemplateId).toBe('T1, T2');
    expect(out[0].after.linkedRoleTemplateName).toBe('Alpha, BETA');
    expect(out[0].after.subtemplateId).toBe('ST1');
  });

  it('resolves legacy template name to SiteB Wisdom Front Desk from Templates/Subtemplates', () => {
    const links = [
      {
        templateId: 'T1172303',
        templateName: 'SiteB Wisdom Front Desk',
        userRecordType: 'Linkable Template',
      },
    ];
    const out = detectOrphanTemplateRefs(
      [
        {
          id: 'r1',
          linkedRoleTemplateId: '',
          linkedRoleTemplateName: 'CADENCE WISDOM FRONT DESK TEMPLATE',
          subtemplateId: '',
        },
      ],
      links,
    );
    expect(out).toHaveLength(1);
    expect(out[0].after.linkedRoleTemplateId).toBe('T1172303');
    expect(out[0].after.linkedRoleTemplateName).toBe('SiteB WISDOM FRONT DESK');
  });

  it('maps T1172304 to Cadence, Behavioral Health Front Desk Template (comma preserved)', () => {
    const links = [
      {
        templateId: 'T1172304',
        templateName: 'Cadence, Behavioral Health Front Desk Template',
        userRecordType: 'Linkable Template',
      },
    ];
    const out = detectOrphanTemplateRefs(
      [
        {
          id: 'r1',
          linkedRoleTemplateId: '',
          linkedRoleTemplateName: 'CADENCE BEHAVIORAL HEALTH FRONT DESK TEMPLATE',
          subtemplateId: '',
        },
      ],
      links,
    );
    expect(out).toHaveLength(1);
    expect(out[0].after.linkedRoleTemplateId).toBe('T1172304');
    expect(out[0].after.linkedRoleTemplateName).toBe('CADENCE, BEHAVIORAL HEALTH FRONT DESK TEMPLATE');
  });

  it('treats space-separated template IDs as one token (only commas separate multiples)', () => {
    const out = detectOrphanTemplateRefs(
      [
        {
          id: 'r1',
          linkedRoleTemplateId: 'T1 T99',
          linkedRoleTemplateName: 'Unknown Template Name',
          subtemplateId: '',
        },
      ],
      templateLinks,
    );
    expect(out).toHaveLength(1);
    expect(out[0].after.linkedRoleTemplateId).toBe('T1 T99');
    expect(out[0].details.some((line) => line.includes('T1 T99'))).toBe(true);
  });

  it('indexes comma-separated template IDs and names from Template Links rows', () => {
    const links = [
      {
        templateId: 'T1, T2',
        templateName: 'Alpha, Beta',
        userRecordType: 'Linkable Template',
      },
    ];
    const out = detectOrphanTemplateRefs(
      [
        {
          id: 'r1',
          linkedRoleTemplateId: 'T1, T2',
          linkedRoleTemplateName: 'Alpha, Beta',
          subtemplateId: '',
        },
      ],
      links,
    );
    expect(out).toHaveLength(0);
  });

  it('does not split template names on commas when checking orphans', () => {
    const links = [
      {
        templateId: 'T1172304',
        templateName: 'Cadence, Behavioral Health Front Desk Template',
        userRecordType: 'Linkable Template',
      },
    ];
    const out = detectOrphanTemplateRefs(
      [
        {
          id: 'r1',
          linkedRoleTemplateId: 'T1172304',
          linkedRoleTemplateName: 'Cadence, Behavioral Health Front Desk Template',
          subtemplateId: '',
        },
      ],
      links,
    );
    expect(out).toEqual([]);
  });

  it('resolves orphan template id on TORG079 using template display title hint', () => {
    const links = [
      {
        templateId: 'T1172303',
        templateName: 'SiteB Wisdom Front Desk',
        templateDisplayTitle: 'SiteB Wisdom Front Desk',
        userRecordType: 'Linkable Template',
      },
    ];
    const out = detectOrphanTemplateRefs(
      [
        {
          id: 'r-torg',
          rbacCode: 'TORG079',
          linkedRoleTemplateId: 'TORG079',
          linkedRoleTemplateName: '',
          templateDisplayTitle: 'SiteB Wisdom Front Desk',
          subtemplateId: '',
        },
      ],
      links,
    );
    expect(out).toHaveLength(1);
    expect(out[0].after.linkedRoleTemplateId).toBe('T1172303');
    expect(out[0].after.linkedRoleTemplateName).toBe('SiteB WISDOM FRONT DESK');
  });

  it('keeps unresolved orphan template IDs instead of wiping them', () => {
    const out = detectOrphanTemplateRefs(
      [
        {
          id: 'r1',
          linkedRoleTemplateId: 'T99',
          linkedRoleTemplateName: 'Missing Name',
          subtemplateId: '',
        },
      ],
      templateLinks,
    );
    expect(out).toHaveLength(1);
    expect(out[0].after.linkedRoleTemplateId).toBe('T99');
  });

  it('returns no proposals when every reference matches a Template Link', () => {
    const out = detectOrphanTemplateRefs(
      [{ id: 'r1', linkedRoleTemplateId: 'T1', linkedRoleTemplateName: 'Alpha', subtemplateId: 'ST1' }],
      templateLinks,
    );
    expect(out).toEqual([]);
  });

  it('aligns template name from Template Links when template ID is valid but name is not in catalog', () => {
    const links = [
      {
        templateId: 'T2100301',
        templateName: 'IP/OP ADVANCED PRACTICE PROVIDER (NP/PA) TEMPLATE',
        userRecordType: 'Linkable Template',
      },
    ];
    const out = detectOrphanTemplateRefs(
      [
        {
          id: 'r-walt',
          rbacCode: 'WA-WALT-043140',
          jobCategory: 'Advanced Practice Clinician - Behavioral Health (Outpatient and Inpatient)',
          linkedRoleTemplateId: 'T2100301',
          linkedRoleTemplateName: 'WRONG LEGACY NAME',
          subtemplateId: '',
        },
      ],
      links,
    );
    expect(out).toHaveLength(1);
    expect(out[0].after.linkedRoleTemplateName).toBe('IP/OP ADVANCED PRACTICE PROVIDER (NP/PA) TEMPLATE');
    expect(out[0].details.some((line) => line.includes('WRONG LEGACY NAME'))).toBe(true);
  });
});

describe('detectSailpointDriftFromCategory', () => {
  const jobCategories = [
    { jobCategoryName: 'Cat-A', sailpointRole: 'sp-a', status: 'Active' },
    { jobCategoryName: 'Cat-B', sailpointRole: 'sp-b', status: 'Inactive' },
    { jobCategoryName: 'Cat-C', sailpointRole: '', status: 'Active' },
  ];

  it('flags active roles whose sailpointRole differs from active category', () => {
    const out = detectSailpointDriftFromCategory(
      [
        { id: 'r1', status: 'Active', jobCategory: 'Cat-A', sailpointRole: 'other' },
        { id: 'r2', status: 'Active', jobCategory: 'Cat-A', sailpointRole: 'SP-A' }, // ci match - no drift
        { id: 'r3', status: 'Inactive', jobCategory: 'Cat-A', sailpointRole: 'other' }, // inactive role - skip
        { id: 'r4', status: 'Active', jobCategory: 'Cat-B', sailpointRole: 'other' }, // inactive category - skip
        { id: 'r5', status: 'Active', jobCategory: 'Cat-C', sailpointRole: 'other' }, // category has blank sp - skip
        { id: 'r6', status: 'Active', jobCategory: 'Cat-A', sailpointRole: '' },
      ],
      jobCategories,
    );
    expect(out.map((p) => p.roleId).sort()).toEqual(['r1', 'r6']);
    for (const p of out) expect(p.after.sailpointRole).toBe('sp-a');
  });
});

describe('findIntegrityFixes', () => {
  it('excludes rows whose jobCategory is SHELL', () => {
    const roles = [
      { id: 'shell-1', jobCategory: 'SHELL', slaNeeded: 'No', slaBlueprintId: 'BP1' },
      { id: 'real-1', jobCategory: 'Nurse', slaNeeded: 'No', slaBlueprintId: 'BP1' },
    ];
    const out = findIntegrityFixes({
      roles,
      jobCategories: [],
      templateLinks: [],
      blueprints: [{ blueprintId: 'BP1', blueprintName: 'Test' }],
    });
    expect(out.map((p) => p.roleId)).toEqual(['real-1']);
    expect(out[0].code).toBe('role-ser-when-blueprint');
  });

  it('excludes placeholder wait-for-role and EMP SHELL ONLY job categories', () => {
    const roles = [
      { id: 'emp-shell', jobCategory: 'EMP SHELL ONLY', slaNeeded: 'No', slaBlueprintId: 'BP1' },
      {
        id: 'unknown-wait',
        jobCategory: 'unknown-wait for role request',
        empNeeded: 'Yes',
      },
      { id: 'wait-req', jobCategory: '  Wait for role req  ', empNeeded: 'Yes' },
      { id: 'nurse', jobCategory: 'Nurse', slaNeeded: 'No', slaBlueprintId: 'BP1' },
    ];
    const out = findIntegrityFixes({
      roles,
      jobCategories: [],
      templateLinks: [],
      blueprints: [{ blueprintId: 'BP1', blueprintName: 'Test' }],
    });
    expect(out.map((p) => p.roleId)).toEqual(['nurse']);
  });

  it('excludes inactive roles and job categories', () => {
    const out = findIntegrityFixes({
      roles: [
        { id: 'inactive-role', status: 'Inactive', slaNeeded: 'No', slaBlueprintId: 'BP1' },
        { id: 'active-role', status: 'Active', slaNeeded: 'No', slaBlueprintId: 'BP1', jobCategory: 'Active Cat' },
        {
          id: 'drift-role',
          status: 'Active',
          jobCategory: 'Inactive Cat',
          sailpointRole: 'wrong',
        },
        {
          id: 'drift-active-cat',
          status: 'Active',
          jobCategory: 'Active Cat',
          sailpointRole: 'wrong',
        },
      ],
      jobCategories: [
        {
          id: 'inactive-cat',
          jobCategoryName: 'Inactive Cat',
          status: 'Inactive',
          needSER: 'No',
          blueprintId: 'BP1',
          sailpointRole: 'sp-expected',
        },
        {
          id: 'active-cat',
          jobCategoryName: 'Active Cat',
          status: 'Active',
          sailpointRole: 'sp-expected',
        },
      ],
      templateLinks: [],
      blueprints: [{ blueprintId: 'BP1', blueprintName: 'Test' }],
    });
    expect(new Set(out.map((p) => p.roleId))).toEqual(new Set(['active-role', 'drift-active-cat']));
    expect(out.find((p) => p.roleId === 'drift-active-cat')?.code).toBe('role-category-drift');
    expect(out.some((p) => p.roleId === 'active-role' && p.code === 'role-ser-when-blueprint')).toBe(true);
    expect(out.some((p) => p.categoryId === 'inactive-cat')).toBe(false);
    expect(out.some((p) => p.roleId === 'drift-role')).toBe(false);
  });

  it('aggregates category-level and role-level proposals', () => {
    const out = findIntegrityFixes({
      roles: [
        { id: 'r1', slaNeeded: 'No', slaBlueprintId: 'BP1' },
      ],
      jobCategories: [
        {
          id: 'cat1',
          jobCategoryName: 'Nurse',
          needSER: 'No',
          blueprintId: 'BP1',
          status: 'Active',
        },
      ],
      templateLinks: [],
      blueprints: [{ blueprintId: 'BP1', blueprintName: 'Test BP' }],
    });
    const codes = out.map((p) => p.code).sort();
    expect(codes).toContain('role-ser-when-blueprint');
    expect(codes).toContain('category-ser-when-blueprint');
    expect(out.find((p) => p.code === 'category-ser-when-blueprint')?.level).toBe('category');
  });
});

describe('applyIntegrityFixes', () => {
  it('applies selected proposals and returns updated roles + old map', () => {
    const roles = [
      { id: 'r1', slaNeeded: 'No', slaBlueprintId: 'BP1', blueprintName: 'X' },
      { id: 'r2', sailpointRole: 'other', jobCategory: 'A', status: 'Active' },
      { id: 'r3', empNeeded: '' }, // untouched
    ];
    const proposals = [
      {
        id: 'a',
        roleId: 'r1',
        before: { slaBlueprintId: 'BP1' },
        after: { slaBlueprintId: '', blueprintName: '' },
      },
      {
        id: 'b',
        roleId: 'r2',
        before: { sailpointRole: 'other' },
        after: { sailpointRole: 'sp-a' },
      },
    ];
    const result = applyIntegrityFixes({ roles, proposals, selectedIds: ['a', 'b'] });
    const byId = Object.fromEntries(result.updatedRoles.map((r) => [r.id, r]));
    expect(byId.r1.slaBlueprintId).toBe('');
    expect(byId.r1.blueprintName).toBe('');
    expect(byId.r2.sailpointRole).toBe('sp-a');
    expect(byId.r3).toBe(roles[2]);
    expect(result.changedRoleIds.has('r1')).toBe(true);
    expect(result.changedRoleIds.has('r2')).toBe(true);
    expect(result.changedRoleIds.has('r3')).toBe(false);
    expect(result.oldByRoleId.get('r1').slaBlueprintId).toBe('BP1');
  });

  it('merges multiple proposals targeting the same role', () => {
    const roles = [{ id: 'r1', slaBlueprintId: 'BP1', sailpointRole: 'old' }];
    const proposals = [
      { id: 'a', roleId: 'r1', after: { slaBlueprintId: '' } },
      { id: 'b', roleId: 'r1', after: { sailpointRole: 'new' } },
    ];
    const result = applyIntegrityFixes({ roles, proposals, selectedIds: ['a', 'b'] });
    expect(result.updatedRoles[0].slaBlueprintId).toBe('');
    expect(result.updatedRoles[0].sailpointRole).toBe('new');
    expect(result.changedRoleIds.size).toBe(1);
  });

  it('returns the same roles array when nothing is selected', () => {
    const roles = [{ id: 'r1', slaBlueprintId: 'BP1' }];
    const result = applyIntegrityFixes({ roles, proposals: [], selectedIds: [] });
    expect(result.updatedRoles).toBe(roles);
    expect(result.changedRoleIds.size).toBe(0);
  });

  it('does not mark a role changed if the patch values match existing values', () => {
    const roles = [{ id: 'r1', slaBlueprintId: '' }];
    const proposals = [{ id: 'a', roleId: 'r1', after: { slaBlueprintId: '' } }];
    const result = applyIntegrityFixes({ roles, proposals, selectedIds: ['a'] });
    expect(result.changedRoleIds.size).toBe(0);
  });

  it('applies category fixes and propagates to roles in that category', () => {
    const jobCategories = [
      {
        id: 'cat1',
        jobCategoryName: 'Nurse',
        needEMP: 'Yes',
        sailpointRole: 'sp-nurse',
        status: 'Active',
      },
    ];
    const roles = [
      { id: 'r1', jobCategory: 'Nurse', empNeeded: 'Yes', sailpointRole: 'other' },
      { id: 'r2', jobCategory: 'Other', empNeeded: 'Yes' },
    ];
    const proposals = [
      {
        id: 'cat-fix',
        level: 'category',
        categoryId: 'cat1',
        after: { needEMP: '' },
      },
    ];
    const result = applyIntegrityFixes({
      roles,
      jobCategories,
      proposals,
      selectedIds: ['cat-fix'],
      blueprints: [],
      templateLinks: [],
    });
    const cat = result.updatedJobCategories.find((c) => c.id === 'cat1');
    expect(cat.needEMP).toBe('');
    expect(result.changedCategoryIds.has('cat1')).toBe(true);
    const r1 = result.updatedRoles.find((r) => r.id === 'r1');
    expect(r1.empNeeded).toBe('');
    expect(result.changedRoleIds.has('r1')).toBe(true);
    expect(result.updatedRoles.find((r) => r.id === 'r2')).toBe(roles[1]);
  });

  it('propagates category fixes to roles when job category name casing differs', () => {
    const jobCategories = [
      {
        id: 'cat1',
        jobCategoryName: 'Nurse Practitioner',
        needSER: 'No',
        blueprintId: 'B1',
        status: 'Active',
      },
    ];
    const roles = [
      { id: 'r1', jobCategory: 'nurse practitioner', slaNeeded: 'No', slaBlueprintId: 'B1' },
    ];
    const proposals = [
      {
        id: 'cat-ser',
        level: 'category',
        categoryId: 'cat1',
        after: { needSER: 'Yes' },
      },
    ];
    const result = applyIntegrityFixes({
      roles,
      jobCategories,
      proposals,
      selectedIds: ['cat-ser'],
      blueprints: [{ blueprintId: 'B1', blueprintName: 'Test BP' }],
      templateLinks: [],
    });
    expect(result.updatedJobCategories[0].needSER).toBe('Yes');
    expect(result.updatedRoles[0].slaNeeded).toBe('Yes');
    expect(result.changedRoleIds.has('r1')).toBe(true);
  });
});

describe('INTEGRITY_FIX_CODE_LABEL', () => {
  it('has a label for every detector code', () => {
    expect(INTEGRITY_FIX_CODE_LABEL['category-ser-when-blueprint']).toBeTruthy();
    expect(INTEGRITY_FIX_CODE_LABEL['role-blueprint-name-from-table']).toBeTruthy();
    expect(INTEGRITY_FIX_CODE_LABEL['category-no-access-emp-mismatch']).toBeTruthy();
    expect(INTEGRITY_FIX_CODE_LABEL['category-emp-without-template']).toBeTruthy();
    expect(INTEGRITY_FIX_CODE_LABEL['category-orphan-template-ref']).toBeTruthy();
    expect(INTEGRITY_FIX_CODE_LABEL['category-blueprint-replace']).toBeTruthy();
    expect(INTEGRITY_FIX_CODE_LABEL['role-ser-when-blueprint']).toBeTruthy();
    expect(INTEGRITY_FIX_CODE_LABEL['role-blueprint-replace']).toBeTruthy();
    expect(INTEGRITY_FIX_CODE_LABEL['role-category-drift']).toBeTruthy();
    expect(INTEGRITY_FIX_CODE_LABEL['orphan-template-ref']).toBeTruthy();
  });
});
