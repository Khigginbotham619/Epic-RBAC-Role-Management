// CSV import utility - simplified and reliable
import { sanitizeCellText } from './textSanitize';

export const importFromCSV = (file, onSuccess, onError) => {
  const reader = new FileReader();
  
  reader.onload = (e) => {
    try {
      let text = e.target.result;
      if (!text || typeof text !== 'string') {
        onError('CSV file is empty or invalid');
        return;
      }
      // Strip BOM (Excel and other tools often add this to UTF-8 files)
      text = text.replace(/^\uFEFF/, '');
      if (!text.trim()) {
        onError('CSV file is empty');
        return;
      }

      const rows = parseCSV(text);
      if (rows.length < 2) {
        onError('CSV file must have at least a header row and one data row');
        return;
      }

      const headers = rows[0].map(h => String(h || '').replace(/^\uFEFF/, '').trim());

      const data = [];
      for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        
        // Skip completely empty rows
        if (row.every(cell => !cell || cell.trim() === '')) {
          continue;
        }
        
        const rowObj = {};
        headers.forEach((header, index) => {
          const raw = row[index] !== undefined && row[index] !== null ? row[index] : '';
          rowObj[header] = sanitizeCellText(raw);
        });
        
        data.push(rowObj);
      }

      if (data.length === 0) {
        onError('No valid data rows found in CSV file');
        return;
      }

      onSuccess(data, []);
    } catch (error) {
      console.error('CSV Import Error:', error);
      onError(`Error parsing CSV: ${error.message}`);
    }
  };

  reader.onerror = () => {
    onError('Error reading file');
  };

  reader.readAsText(file, 'UTF-8');
};

// Simple CSV parser
function parseCSV(text) {
  const rows = [];
  let currentRow = [];
  let currentField = '';
  let inQuotes = false;
  
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const nextChar = text[i + 1];
    
    if (char === '"') {
      if (inQuotes && nextChar === '"') {
        // Escaped quote
        currentField += '"';
        i++; // Skip next quote
      } else {
        // Toggle quote state
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      // End of field
      currentRow.push(currentField);
      currentField = '';
    } else if ((char === '\n' || char === '\r') && !inQuotes) {
      // End of row
      if (char === '\r' && nextChar === '\n') {
        i++; // Skip \n after \r
      }
      currentRow.push(currentField);
      if (currentRow.length > 0 && currentRow.some(f => f.trim() !== '')) {
        rows.push([...currentRow]);
      }
      currentRow = [];
      currentField = '';
    } else {
      currentField += char;
    }
  }
  
  // Add last field and row if file doesn't end with newline
  if (currentField !== '' || currentRow.length > 0) {
    currentRow.push(currentField);
    if (currentRow.length > 0 && currentRow.some(f => f.trim() !== '')) {
      rows.push([...currentRow]);
    }
  }
  
  return rows;
}
