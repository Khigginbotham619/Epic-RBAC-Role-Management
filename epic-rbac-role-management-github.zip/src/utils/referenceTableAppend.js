import { TRAINING_TRACK_OTHER } from '../components/TrainingTrackDropdown';
import { BLUEPRINT_OTHER } from '../components/BlueprintDropdown';

/** Build a case-insensitive Map keyed by blueprintId for fast repeated lookups. */
export function buildBlueprintIndex(blueprints) {
  const index = new Map();
  for (const bp of blueprints || []) {
    const key = String(bp?.blueprintId ?? '').trim().toUpperCase();
    if (key) index.set(key, bp);
  }
  return index;
}

/** Case-insensitive lookup in the Blueprints reference table by business blueprintId. */
export function findBlueprintById(blueprintsOrIndex, blueprintId) {
  const key = String(blueprintId ?? '').trim();
  if (!key) return null;
  const upper = key.toUpperCase();
  if (blueprintsOrIndex instanceof Map) {
    return blueprintsOrIndex.get(upper) || null;
  }
  return (
    (blueprintsOrIndex || []).find(
      (b) => String(b.blueprintId ?? '').trim().toUpperCase() === upper
    ) || null
  );
}

/** Blueprint display name from the reference table, or fallback when the ID is not listed. */
export function blueprintNameForId(blueprints, blueprintId, fallback = '') {
  const bp = findBlueprintById(blueprints, blueprintId);
  const name = bp ? String(bp.blueprintName ?? '').trim() : '';
  return name || String(fallback ?? '').trim();
}

/** True when blueprintId exists in the Blueprints reference table. */
export function blueprintExistsInTable(blueprintsOrIndex, blueprintId) {
  return !!findBlueprintById(blueprintsOrIndex, blueprintId);
}

function blueprintListFrom(blueprintsOrIndex) {
  if (blueprintsOrIndex instanceof Map) return Array.from(blueprintsOrIndex.values());
  return Array.isArray(blueprintsOrIndex) ? blueprintsOrIndex : [];
}

function compactBlueprintNameKey(value) {
  return String(value ?? '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '');
}

function blueprintNameWords(value) {
  return String(value ?? '')
    .trim()
    .toLowerCase()
    .split(/[^a-z0-9]+/g)
    .filter(Boolean);
}

function scoreBlueprintNameMatch(candidate, entry) {
  if (!entry?.norm) return 0;
  const candidateNorm = compactBlueprintNameKey(candidate);
  if (!candidateNorm) return 0;
  if (candidateNorm === entry.norm) return 1;
  if (candidateNorm.includes(entry.norm) || entry.norm.includes(candidateNorm)) return 0.92;

  const candidateWords = blueprintNameWords(candidate);
  const entryWords = entry.words.length ? entry.words : blueprintNameWords(entry.name);
  if (!entryWords.length) return 0;
  const matched = entryWords.filter((w) => candidateWords.includes(w) || candidateNorm.includes(w));
  if (!matched.length) return 0;
  const unmatched = entryWords.filter((w) => !matched.includes(w));
  if (unmatched.length > 0) return 0;
  return matched.length / entryWords.length;
}

/**
 * When a stored blueprint ID is not in the Blueprints table, find a replacement row
 * by matching the stored blueprint name (exact or strong fuzzy match).
 */
export function resolveBlueprintReplacement(blueprintsOrIndex, blueprintId, blueprintName = '') {
  const bpId = String(blueprintId ?? '').trim();
  const name = String(blueprintName ?? '').trim();
  if (bpId && blueprintExistsInTable(blueprintsOrIndex, bpId)) return null;
  if (!bpId && !name) return null;
  const byExactName = new Map();
  const catalog = [];
  for (const bp of blueprintListFrom(blueprintsOrIndex)) {
    const id = String(bp?.blueprintId ?? '').trim();
    const bpName = String(bp?.blueprintName ?? '').trim();
    if (!id) continue;
    catalog.push({
      id,
      name: bpName,
      norm: compactBlueprintNameKey(bpName),
      words: blueprintNameWords(bpName),
    });
    if (bpName) byExactName.set(bpName.toLowerCase(), bp);
  }

  if (name) {
    const exact = byExactName.get(name.toLowerCase());
    if (exact) {
      return {
        blueprintId: String(exact.blueprintId).trim(),
        blueprintName: String(exact.blueprintName ?? '').trim(),
        matchKind: 'exact-name',
      };
    }
  }

  if (bpId) {
    const idNorm = compactBlueprintNameKey(bpId);
    for (const entry of catalog) {
      if (idNorm && (idNorm === entry.norm || idNorm === compactBlueprintNameKey(entry.id))) {
        return {
          blueprintId: entry.id,
          blueprintName: entry.name,
          matchKind: 'id-as-name',
        };
      }
    }
  }

  const candidate = name || bpId;
  let best = null;
  let bestScore = 0;
  let tieCount = 0;
  for (const entry of catalog) {
    const score = scoreBlueprintNameMatch(candidate, entry);
    if (score < 0.75) continue;
    if (score > bestScore) {
      bestScore = score;
      best = entry;
      tieCount = 0;
    } else if (score === bestScore) {
      tieCount += 1;
    }
  }
  if (!best || tieCount > 0) return null;
  return {
    blueprintId: best.id,
    blueprintName: best.name,
    matchKind: 'fuzzy-name',
  };
}

/**
 * If the form has a blueprint id that is not in the reference list, return one row to pass to appendBlueprints.
 */
export function buildBlueprintsToAppend(existingBlueprints, blueprintId, blueprintName) {
  const id = String(blueprintId ?? '').trim();
  if (!id || id === BLUEPRINT_OTHER) return [];
  const key = id.toUpperCase();
  const exists = (existingBlueprints || []).some(
    (b) => String(b.blueprintId ?? '').trim().toUpperCase() === key
  );
  if (exists) return [];
  return [
    {
      blueprintId: id,
      blueprintName: String(blueprintName ?? '').trim(),
    },
  ];
}

/**
 * New training track names from a set of form field values, not already in the reference list.
 * Deduplicates by case-insensitive name and drops the "Other" sentinel.
 */
export function buildTrainingTracksToAppend(existingTracks, candidateNames) {
  const existing = new Set(
    (existingTracks || [])
      .map((t) => (t.trackName || '').trim().toLowerCase())
      .filter(Boolean)
  );
  const seen = new Set();
  const out = [];
  for (const raw of candidateNames || []) {
    const name = typeof raw === 'string' ? raw.trim() : '';
    if (!name || name === TRAINING_TRACK_OTHER) continue;
    const lk = name.toLowerCase();
    if (existing.has(lk)) continue;
    if (seen.has(lk)) continue;
    existing.add(lk);
    seen.add(lk);
    out.push({ trackName: name });
  }
  return out;
}

/** Role form: Training Track fields 1–6. */
export function roleFormTrainingTrackFieldValues(roleData) {
  return [
    roleData.trainingTrack,
    roleData.trainingTrack2,
    roleData.trainingTrack3,
    roleData.trainingTrack4,
    roleData.trainingTrack5,
    roleData.trainingTrack6,
  ];
}

/** Job category form: Training Track fields 1–6. */
export function jobCategoryTrainingTrackFieldValues(catData) {
  return [
    catData.trainingTrack1,
    catData.trainingTrack2,
    catData.trainingTrack3,
    catData.trainingTrack4,
    catData.trainingTrack5,
    catData.trainingTrack6,
  ];
}
