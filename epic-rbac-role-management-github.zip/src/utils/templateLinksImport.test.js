import {
  mapCsvCellsToTemplateLinkRow,
  pickImportMultiSlot,
} from './templateLinksImport';

const DEFAULT_HEADERS = [
  'User Record Type',
  'Template ID',
  'Template Name',
  'Primary Template Owner',
  'Template Display Title',
  'Subtemplate ID',
  'Subtemplate Description',
  'User Record Status',
];

describe('mapCsvCellsToTemplateLinkRow', () => {
  it('preserves commas in template name when CSV row has extra cells', () => {
    const cells = [
      'Linkable Template',
      'STORG005',
      'SiteA Or Lx',
      ' Wt',
      ' Ne Reporting Subtemplate',
      'owner@example.com',
      'Display Title, With Comma',
      '',
      '',
      'Active',
    ];
    const row = mapCsvCellsToTemplateLinkRow(cells, DEFAULT_HEADERS);
    expect(row['Template Name']).toBe('SiteA Or Lx, Wt, Ne Reporting Subtemplate');
    expect(row['Template Display Title']).toBe('Display Title, With Comma');
    expect(row['User Record Status']).toBe('Active');
  });

  it('preserves commas in template display title spillover', () => {
    const cells = [
      'Linkable Template',
      'T1',
      'Simple Name',
      'owner',
      'Title Part A',
      ' Title Part B',
      '',
      '',
      'Active',
    ];
    const row = mapCsvCellsToTemplateLinkRow(cells, DEFAULT_HEADERS);
    expect(row['Template Name']).toBe('Simple Name');
    expect(row['Template Display Title']).toBe('Title Part A, Title Part B');
    expect(row['Primary Template Owner']).toBe('owner');
  });

  it('maps one cell per column when counts already match', () => {
    const cells = [
      'Subtemplate',
      'ST1',
      'Sub, Name Here',
      '',
      'Sub Display, Title',
      '',
      '',
      'Active',
    ];
    const row = mapCsvCellsToTemplateLinkRow(cells, DEFAULT_HEADERS);
    expect(row['Template Name']).toBe('Sub, Name Here');
    expect(row['Template Display Title']).toBe('Sub Display, Title');
  });
});

describe('pickImportMultiSlot', () => {
  it('repeats a single name/title across expanded template-id slots', () => {
    const names = ['SiteA Or Lx, Wt, Ne'];
    expect(pickImportMultiSlot(names, 0)).toBe('SiteA Or Lx, Wt, Ne');
    expect(pickImportMultiSlot(names, 2)).toBe('SiteA Or Lx, Wt, Ne');
  });
});
