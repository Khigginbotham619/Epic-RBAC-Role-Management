/**
 * Count RBAC roles (with a code) linked to each job category name (exact trimmed match).
 */

/** @returns {Map<string, number>} category name → count */
export function buildRbacCodeCountByJobCategoryName(roles) {
  const counts = new Map();
  for (const role of roles || []) {
    const categoryName = String(role?.jobCategory || '').trim();
    const rbacCode = String(role?.rbacCode || '').trim();
    if (!categoryName || !rbacCode) continue;
    counts.set(categoryName, (counts.get(categoryName) || 0) + 1);
  }
  return counts;
}

export function countRbacCodesForJobCategoryName(countsByName, jobCategoryName) {
  const name = String(jobCategoryName || '').trim();
  if (!name) return 0;
  return countsByName?.get(name) || 0;
}
