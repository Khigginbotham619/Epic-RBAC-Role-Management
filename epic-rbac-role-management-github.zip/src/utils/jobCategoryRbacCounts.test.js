import {
  buildRbacCodeCountByJobCategoryName,
  countRbacCodesForJobCategoryName,
} from './jobCategoryRbacCounts';

describe('jobCategoryRbacCounts', () => {
  test('counts roles with non-empty rbacCode per job category name', () => {
    const roles = [
      { jobCategory: ' Nurse ', rbacCode: 'A1' },
      { jobCategory: 'Nurse', rbacCode: 'A2' },
      { jobCategory: 'Nurse', rbacCode: '' },
      { jobCategory: 'Clerk', rbacCode: 'B1' },
      { jobCategory: 'Clerk', rbacCode: '  ' },
    ];
    const counts = buildRbacCodeCountByJobCategoryName(roles);
    expect(counts.get('Nurse')).toBe(2);
    expect(counts.get('Clerk')).toBe(1);
    expect(countRbacCodesForJobCategoryName(counts, 'Nurse')).toBe(2);
    expect(countRbacCodesForJobCategoryName(counts, 'Unknown')).toBe(0);
  });
});
