import {
  isActiveRole,
  isRoleAssignedToCategory,
  findActiveRolesAssignedToCategory,
  findRolesAssignedToCategory,
  buildRoleReassignmentPlan,
  suggestReplacementCategory,
  rankReplacementCategories,
  scoreReplacementCategory,
} from './jobCategoryReassignment';

const ROLE_FROM = (id, overrides = {}) => ({
  id,
  rbacCode: `RBAC${id}`,
  jobCategory: 'Burn Medicine NP',
  jobTitle: 'Nurse Practitioner',
  department: 'Burn Unit',
  status: 'Active',
  linkedRoleTemplateId: 'T_OLD',
  subtemplateId: 'S_OLD',
  empNeeded: 'No',
  slaNeeded: 'No',
  slaBlueprintId: '',
  blueprintName: '',
  trainingTrack: 'Old Track 1',
  sailpointRole: 'Old SP Role',
  ...overrides,
});

const TARGET_CATEGORY = {
  id: 'cat-target',
  jobCategoryId: 'JC-TARGET',
  jobCategoryName: 'Cardiology NP',
  linkableTemplateId: 'T_NEW',
  linkableTemplateName: 'cardiology np template',
  subtemplatesId: 'S_NEW',
  subtemplatesName: 'Cardiology Sub',
  needEMP: 'Yes',
  needSER: 'No',
  blueprintId: '',
  blueprintName: '',
  trainingTrack1: 'New Track 1',
  trainingTrack2: '',
  trainingTrack3: '',
  trainingTrack4: '',
  trainingTrack5: '',
  trainingTrack6: '',
  sailpointRole: 'New SP Role',
  status: 'Active',
};

describe('isActiveRole', () => {
  it('treats blank status as Active', () => {
    expect(isActiveRole({ status: '' })).toBe(true);
    expect(isActiveRole({})).toBe(true);
  });
  it('flags Inactive (with whitespace) as not active', () => {
    expect(isActiveRole({ status: 'Inactive' })).toBe(false);
    expect(isActiveRole({ status: '  Inactive  ' })).toBe(false);
  });
  it('treats null/undefined role as not active', () => {
    expect(isActiveRole(null)).toBe(false);
    expect(isActiveRole(undefined)).toBe(false);
  });
});

describe('isRoleAssignedToCategory', () => {
  it('matches case-insensitively and trims', () => {
    expect(isRoleAssignedToCategory({ jobCategory: '  burn medicine np ' }, 'Burn Medicine NP')).toBe(true);
  });
  it('returns false when names differ', () => {
    expect(isRoleAssignedToCategory({ jobCategory: 'Cardiology NP' }, 'Burn Medicine NP')).toBe(false);
  });
});

describe('findActiveRolesAssignedToCategory', () => {
  const roles = [
    ROLE_FROM('1'),
    ROLE_FROM('2', { status: 'Inactive' }),
    ROLE_FROM('3', { jobCategory: 'Cardiology NP' }),
    ROLE_FROM('4', { status: '' }),
  ];
  it('returns only active roles assigned to the named category', () => {
    const out = findActiveRolesAssignedToCategory(roles, 'Burn Medicine NP');
    expect(out.map((r) => r.id).sort()).toEqual(['1', '4']);
  });
  it('returns [] for blank/empty category name', () => {
    expect(findActiveRolesAssignedToCategory(roles, '')).toEqual([]);
    expect(findActiveRolesAssignedToCategory(roles, '   ')).toEqual([]);
  });
});

describe('findRolesAssignedToCategory', () => {
  it('includes inactive roles', () => {
    const roles = [
      ROLE_FROM('1'),
      ROLE_FROM('2', { status: 'Inactive' }),
      ROLE_FROM('3', { jobCategory: 'Cardiology NP' }),
    ];
    const out = findRolesAssignedToCategory(roles, 'Burn Medicine NP');
    expect(out.map((r) => r.id).sort()).toEqual(['1', '2']);
  });
});

describe('buildRoleReassignmentPlan', () => {
  it('reassigns active roles only by default and resyncs category-derived fields', () => {
    const roles = [
      ROLE_FROM('1'),
      ROLE_FROM('2', { status: 'Inactive' }),
      ROLE_FROM('3', { jobCategory: 'Other' }),
    ];
    const plan = buildRoleReassignmentPlan({
      roles,
      fromCategoryName: 'Burn Medicine NP',
      toCategory: TARGET_CATEGORY,
      editStamp: '2026-05-12 12:00:00 - tester',
    });
    expect(plan.affectedRoleIds.size).toBe(1);
    expect(plan.affectedRoleIds.has('1')).toBe(true);
    expect(plan.oldByRoleId.get('1').jobCategory).toBe('Burn Medicine NP');
    const updated1 = plan.updatedRoles.find((r) => r.id === '1');
    expect(updated1.jobCategory).toBe('Cardiology NP');
    expect(updated1.linkedRoleTemplateId).toBe('T_NEW');
    expect(updated1.subtemplateId).toBe('S_NEW');
    expect(updated1.empNeeded).toBe('Yes');
    expect(updated1.sailpointRole).toBe('New SP Role');
    expect(updated1.trainingTrack).toBe('New Track 1');
    expect(updated1.lastEditChangeControlDateReason).toBe('2026-05-12 12:00:00 - tester');
    const role2 = plan.updatedRoles.find((r) => r.id === '2');
    expect(role2.jobCategory).toBe('Burn Medicine NP');
    expect(role2.linkedRoleTemplateId).toBe('T_OLD');
    const role3 = plan.updatedRoles.find((r) => r.id === '3');
    expect(role3.jobCategory).toBe('Other');
  });

  it('reassigns inactive roles when includeInactive=true', () => {
    const roles = [
      ROLE_FROM('1'),
      ROLE_FROM('2', { status: 'Inactive' }),
    ];
    const plan = buildRoleReassignmentPlan({
      roles,
      fromCategoryName: 'Burn Medicine NP',
      toCategory: TARGET_CATEGORY,
      includeInactive: true,
    });
    expect(plan.affectedRoleIds.size).toBe(2);
    expect(plan.affectedRoleIds.has('2')).toBe(true);
    const updated2 = plan.updatedRoles.find((r) => r.id === '2');
    expect(updated2.jobCategory).toBe('Cardiology NP');
  });

  it('is a no-op when fromCategoryName equals toCategory (case-insensitive)', () => {
    const roles = [ROLE_FROM('1', { jobCategory: 'Cardiology NP' })];
    const plan = buildRoleReassignmentPlan({
      roles,
      fromCategoryName: 'cardiology np',
      toCategory: TARGET_CATEGORY,
    });
    expect(plan.affectedRoleIds.size).toBe(0);
    expect(plan.updatedRoles).toBe(roles);
  });

  it('is a no-op when target category has no name', () => {
    const roles = [ROLE_FROM('1')];
    const plan = buildRoleReassignmentPlan({
      roles,
      fromCategoryName: 'Burn Medicine NP',
      toCategory: { jobCategoryName: '' },
    });
    expect(plan.affectedRoleIds.size).toBe(0);
  });

  it('does not mutate the input roles array', () => {
    const original = ROLE_FROM('1');
    const roles = [original];
    buildRoleReassignmentPlan({
      roles,
      fromCategoryName: 'Burn Medicine NP',
      toCategory: TARGET_CATEGORY,
      editStamp: 'edit',
    });
    expect(original.jobCategory).toBe('Burn Medicine NP');
    expect(original.linkedRoleTemplateId).toBe('T_OLD');
  });
});

describe('scoreReplacementCategory', () => {
  const source = {
    jobCategoryName: 'Burn Medicine NP',
    linkableTemplateId: 'T2100301',
    subtemplatesId: 'ST100',
    owningWorkgroup: 'Nursing',
    owningApplication: 'Epic',
    trainingTrack1: 'NP - Inpatient Documentation',
    trainingTrack2: 'NP - Orders',
    trainingTrack3: 'Burn-specific Workflows',
  };

  it('scores template + subtemplate exact match the highest', () => {
    const cand = {
      jobCategoryName: 'Wound Care NP',
      linkableTemplateId: 'T2100301',
      subtemplatesId: 'ST100',
    };
    const out = scoreReplacementCategory(source, cand);
    expect(out.signals.templateMatch).toBe(true);
    expect(out.signals.subtemplateMatch).toBe(true);
    expect(out.score).toBeGreaterThanOrEqual(5.5);
    expect(out.reasons.some((r) => r.toLowerCase().includes('template t2100301'))).toBe(true);
  });

  it('counts shared training tracks and lists them in reasons', () => {
    const cand = {
      jobCategoryName: 'Wound Care NP',
      linkableTemplateId: 'T2100301',
      subtemplatesId: 'ST100',
      trainingTrack1: 'NP - Inpatient Documentation',
      trainingTrack2: 'NP - Orders',
    };
    const out = scoreReplacementCategory(source, cand);
    expect(out.signals.sharedTrainingTracks.sort()).toEqual([
      'NP - Inpatient Documentation',
      'NP - Orders',
    ]);
    expect(out.reasons.join(' ')).toMatch(/2 training tracks in common/);
  });

  it('partial template id overlap scores less than exact match', () => {
    const exact = scoreReplacementCategory(source, {
      jobCategoryName: 'Wound Care NP',
      linkableTemplateId: 'T2100301',
    });
    const partial = scoreReplacementCategory(source, {
      jobCategoryName: 'Wound Care NP',
      linkableTemplateId: 'T2100301 T9999',
    });
    expect(exact.signals.templateMatch).toBe(true);
    expect(partial.signals.templateMatch).toBe(false);
    expect(exact.score).toBeGreaterThan(partial.score);
  });

  it('case-insensitive matching on training track strings', () => {
    const cand = {
      jobCategoryName: 'X',
      linkableTemplateId: 'OTHER',
      trainingTrack1: 'np - INPATIENT documentation',
    };
    const out = scoreReplacementCategory(source, cand);
    expect(out.signals.sharedTrainingTracks).toEqual(['NP - Inpatient Documentation']);
  });

  it('blank-vs-blank subtemplate counts only when template matches', () => {
    const sourceNoSub = { ...source, subtemplatesId: '' };
    const onlyTpl = scoreReplacementCategory(sourceNoSub, {
      jobCategoryName: 'X',
      linkableTemplateId: 'T2100301',
    });
    expect(onlyTpl.signals.templateMatch).toBe(true);
    expect(onlyTpl.signals.subtemplateMatch).toBe(true);
    expect(onlyTpl.score).toBeGreaterThan(3);

    const noTpl = scoreReplacementCategory(sourceNoSub, {
      jobCategoryName: 'X',
      linkableTemplateId: 'OTHER',
    });
    expect(noTpl.signals.templateMatch).toBe(false);
    expect(noTpl.signals.subtemplateMatch).toBe(false);
    expect(noTpl.score).toBe(0);
  });
});

describe('rankReplacementCategories', () => {
  const source = {
    jobCategoryName: 'Burn Medicine NP',
    linkableTemplateId: 'T2100301',
    subtemplatesId: 'ST100',
    trainingTrack1: 'NP - Inpatient Documentation',
    trainingTrack2: 'NP - Orders',
  };

  it('orders candidates by score desc and excludes inactive + self', () => {
    const candidates = [
      {
        id: 'self',
        jobCategoryName: 'Burn Medicine NP',
        linkableTemplateId: 'T2100301',
        subtemplatesId: 'ST100',
        status: 'Active',
      },
      {
        id: 'tpl-only',
        jobCategoryName: 'Trauma NP',
        linkableTemplateId: 'T2100301',
        subtemplatesId: '',
        status: 'Active',
      },
      {
        id: 'tpl+sub',
        jobCategoryName: 'Wound Care NP',
        linkableTemplateId: 'T2100301',
        subtemplatesId: 'ST100',
        status: 'Active',
      },
      {
        id: 'tpl+sub+training',
        jobCategoryName: 'Surgical NP',
        linkableTemplateId: 'T2100301',
        subtemplatesId: 'ST100',
        trainingTrack1: 'NP - Inpatient Documentation',
        trainingTrack2: 'NP - Orders',
        status: 'Active',
      },
      {
        id: 'inactive-perfect',
        jobCategoryName: 'Other NP',
        linkableTemplateId: 'T2100301',
        subtemplatesId: 'ST100',
        status: 'Inactive',
      },
      {
        id: 'unrelated',
        jobCategoryName: 'Cardiology Tech',
        linkableTemplateId: 'OTHER',
        subtemplatesId: 'OTHER',
        status: 'Active',
      },
    ];
    const ranked = rankReplacementCategories(source, candidates);
    expect(ranked.map((r) => r.category.id)).toEqual(['tpl+sub+training', 'tpl+sub', 'tpl-only']);
    expect(ranked[0].signals.templateMatch).toBe(true);
    expect(ranked[0].signals.subtemplateMatch).toBe(true);
    expect(ranked[0].signals.sharedTrainingTracks.length).toBe(2);
  });

  it('respects the limit option', () => {
    const candidates = Array.from({ length: 10 }).map((_, i) => ({
      id: `c${i}`,
      jobCategoryName: `Cat ${i}`,
      linkableTemplateId: 'T2100301',
      status: 'Active',
    }));
    const ranked = rankReplacementCategories(source, candidates, { limit: 3 });
    expect(ranked.length).toBe(3);
  });

  it('returns [] when source is missing', () => {
    expect(rankReplacementCategories(null, [{ id: 'a', linkableTemplateId: 'T1', status: 'Active' }])).toEqual([]);
  });

  it('hides candidates that only share owning workgroup / application / EMP-SER (no template, subtemplate, or training)', () => {
    const candidates = [
      {
        id: 'no-signal',
        jobCategoryName: 'Cardiology NP',
        linkableTemplateId: 'OTHER',
        subtemplatesId: 'OTHER',
        owningWorkgroup: 'Nursing',
        owningApplication: 'Epic',
        status: 'Active',
      },
    ];
    const sourceWithOwnership = {
      jobCategoryName: 'Burn Medicine NP',
      linkableTemplateId: 'T2100301',
      subtemplatesId: 'ST100',
      owningWorkgroup: 'Nursing',
      owningApplication: 'Epic',
    };
    expect(rankReplacementCategories(sourceWithOwnership, candidates)).toEqual([]);
  });

  it('still includes ownership-only matches when requirePrimarySignal is false', () => {
    const candidates = [
      {
        id: 'no-signal',
        jobCategoryName: 'Cardiology NP',
        linkableTemplateId: 'OTHER',
        owningWorkgroup: 'Nursing',
        status: 'Active',
      },
    ];
    const sourceWithOwnership = {
      jobCategoryName: 'Burn Medicine NP',
      linkableTemplateId: 'T2100301',
      owningWorkgroup: 'Nursing',
    };
    const ranked = rankReplacementCategories(sourceWithOwnership, candidates, { requirePrimarySignal: false });
    expect(ranked.length).toBe(1);
    expect(ranked[0].category.id).toBe('no-signal');
  });
});

describe('suggestReplacementCategory (wraps rankReplacementCategories)', () => {
  const source = {
    jobCategoryName: 'Burn Medicine NP',
    linkableTemplateId: 'T2100301',
    subtemplatesId: 'ST100',
    owningWorkgroup: 'Nursing',
    owningApplication: 'Epic',
  };

  it('prefers a candidate that shares both template and subtemplate', () => {
    const candidates = [
      { id: 'a', jobCategoryName: 'Cardiology NP', linkableTemplateId: 'T_OTHER', subtemplatesId: '', status: 'Active' },
      { id: 'b', jobCategoryName: 'Burn Medicine PA', linkableTemplateId: 'T2100301', subtemplatesId: 'ST100', status: 'Active' },
      { id: 'c', jobCategoryName: 'Generic NP', linkableTemplateId: 'T2100301', subtemplatesId: '', status: 'Active' },
    ];
    const out = suggestReplacementCategory(source, candidates);
    expect(out && out.id).toBe('b');
  });

  it('excludes inactive candidates', () => {
    const candidates = [
      { id: 'a', jobCategoryName: 'Burn Medicine PA', linkableTemplateId: 'T2100301', subtemplatesId: 'ST100', status: 'Inactive' },
    ];
    expect(suggestReplacementCategory(source, candidates)).toBeNull();
  });

  it('returns null when no candidate shares any signal', () => {
    const candidates = [
      { id: 'a', jobCategoryName: 'Cardiology NP', linkableTemplateId: 'OTHER', subtemplatesId: 'OTHER', owningWorkgroup: 'Other', owningApplication: 'Other', status: 'Active' },
    ];
    expect(suggestReplacementCategory(source, candidates)).toBeNull();
  });

  it('excludes the source category itself', () => {
    const candidates = [
      { id: 'self', jobCategoryName: 'Burn Medicine NP', linkableTemplateId: 'T2100301', subtemplatesId: 'ST100', status: 'Active' },
      { id: 'b', jobCategoryName: 'Burn Medicine PA', linkableTemplateId: 'T2100301', subtemplatesId: 'ST100', status: 'Active' },
    ];
    const out = suggestReplacementCategory(source, candidates);
    expect(out && out.id).toBe('b');
  });
});
