import {
  syncJobCategoryLinkableFromTemplateLinks,
  templateNamesFromTemplateLinks,
  splitLinkableTemplateDescriptionSlotsForSync,
} from './templateLinkRoleMatch';

const links = [
  {
    userRecordType: 'Linkable Template',
    templateId: 'T100, T200',
    templateName: 'ALPHA TEMPLATE\nBETA TEMPLATE',
    templateDisplayTitle: 'Alpha Display\nBeta Display',
    subtemplateId: '',
    subtemplateName: '',
    currentStatus: 'Active',
  },
];

describe('splitLinkableTemplateDescriptionSlotsForSync', () => {
  it('splits comma-separated template descriptions', () => {
    expect(splitLinkableTemplateDescriptionSlotsForSync('Alpha Display, Beta Display')).toEqual([
      'Alpha Display',
      'Beta Display',
    ]);
  });
});

describe('syncJobCategoryLinkableFromTemplateLinks', () => {
  it('resolves Template Display Title by template ID with comma separation', () => {
    const out = syncJobCategoryLinkableFromTemplateLinks(links, 'T100, T200', '', 'id');
    expect(out.linkableTemplateId).toBe('T100, T200');
    expect(out.linkableTemplateName).toBe('ALPHA DISPLAY, BETA DISPLAY');
  });

  it('resolves template ID from Template Display Title', () => {
    const out = syncJobCategoryLinkableFromTemplateLinks(links, '', 'Beta Display', 'name');
    expect(out.linkableTemplateName).toBe('Beta Display');
    expect(out.linkableTemplateId).toBe('T200');
  });
});

describe('templateNamesFromTemplateLinks', () => {
  it('returns comma-separated template names for job category IDs', () => {
    expect(templateNamesFromTemplateLinks(links, 'T100, T200')).toBe('ALPHA TEMPLATE, BETA TEMPLATE');
  });
});
