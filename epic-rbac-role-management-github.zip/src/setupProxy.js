const { createProxyMiddleware } = require('http-proxy-middleware');

module.exports = function (app) {
  // Only proxy /api to the backend; HMR and other dev requests stay on the dev server
  app.use(
    '/api',
    createProxyMiddleware({
      target: 'http://localhost:3001',
      changeOrigin: true,
    })
  );
};
