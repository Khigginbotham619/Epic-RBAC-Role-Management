/**
 * MSSQL data layer for Epic RBAC Role Management (normalized columns).
 * Used when process.env.datastore === 'MSSQL'. Connection string in process.env.MSSQL_connectionstring.
 *
 * All tables use explicit columns instead of JSON blob storage.
 * Audit log oldData/newData remain JSON (historical role snapshots).
 * Bulk copy (request.bulk) is used for batch writes to avoid row-by-row timeouts.
 */
const sql = require('mssql');

let pool = null;
const tableColumnsCache = new Map();
let schemaEnsured = false;

function getConnectionConfig() {
  let connStr = process.env.MSSQL_connectionstring || process.env.MSSQL_connectionString || '';
  connStr = connStr.trim();
  if (connStr.startsWith('"') && connStr.endsWith('"')) {
    connStr = connStr.slice(1, -1).trim();
  }
  if (!connStr) {
    throw new Error('MSSQL_connectionstring is required when datastore=MSSQL');
  }
  connStr = connStr.replace(/(^|;)User=/gi, '$1User Id=');
  return connStr;
}

function parseConnectionString(connStr) {
  const config = { options: {} };
  const pairs = connStr.split(';').filter(s => s.trim());
  for (const pair of pairs) {
    const idx = pair.indexOf('=');
    if (idx === -1) continue;
    const key = pair.slice(0, idx).trim().toLowerCase();
    const value = pair.slice(idx + 1).trim();
    switch (key) {
      case 'server': {
        const parts = value.split(',');
        config.server = parts[0];
        if (parts[1]) config.port = parseInt(parts[1], 10);
        break;
      }
      case 'database': config.database = value; break;
      case 'user':
      case 'user id': config.user = value; break;
      case 'password': config.password = value; break;
      case 'trustservercertificate':
        config.options.trustServerCertificate = value.toLowerCase() === 'true';
        break;
      case 'encrypt':
        config.options.encrypt = value.toLowerCase() === 'true';
        break;
      case 'connect timeout':
        config.connectionTimeout = parseInt(value, 10) * 1000;
        break;
      case 'request timeout':
        config.requestTimeout = parseInt(value, 10) * 1000;
        break;
    }
  }
  return config;
}

async function getPool() {
  if (pool) return pool;
  const connStr = getConnectionConfig();
  const config = parseConnectionString(connStr);
  if (!config.requestTimeout) {
    config.requestTimeout = 120000;
  }
  pool = await sql.connect(config);
  await ensureSchemaUpgrades(pool);
  return pool;
}

async function ensureSchemaUpgrades(activePool) {
  if (schemaEnsured) return;
  // Ensure Sailpoint role persistence works even if migration script wasn't run.
  await activePool.request().query(`
IF OBJECT_ID(N'sailpoint_roles', N'U') IS NULL
BEGIN
  CREATE TABLE sailpoint_roles (
    id NVARCHAR(36) NOT NULL PRIMARY KEY,
    sailpointRole NVARCHAR(500) NOT NULL DEFAULT '',
    status NVARCHAR(50) NOT NULL DEFAULT 'Active',
    templates NVARCHAR(MAX) NOT NULL DEFAULT '',
    subtemplates NVARCHAR(MAX) NOT NULL DEFAULT '',
    requestable NVARCHAR(100) NOT NULL DEFAULT '',
    matchedAccessProfile NVARCHAR(MAX) NOT NULL DEFAULT '',
    entitlementType NVARCHAR(255) NOT NULL DEFAULT '',
    instructions NVARCHAR(MAX) NOT NULL DEFAULT '',
    description NVARCHAR(MAX) NOT NULL DEFAULT '',
    entitlements NVARCHAR(MAX) NOT NULL DEFAULT ''
  );
  CREATE INDEX IX_sailpoint_roles_sailpointRole ON sailpoint_roles(sailpointRole);
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'sailpoint_roles', N'U') IS NOT NULL
AND COL_LENGTH('sailpoint_roles', 'status') IS NULL
BEGIN
  ALTER TABLE sailpoint_roles ADD status NVARCHAR(50) NOT NULL DEFAULT 'Active';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'sailpoint_roles', N'U') IS NOT NULL
AND COL_LENGTH('sailpoint_roles', 'templates') IS NULL
BEGIN
  ALTER TABLE sailpoint_roles ADD templates NVARCHAR(MAX) NOT NULL DEFAULT '';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'sailpoint_roles', N'U') IS NOT NULL
AND COL_LENGTH('sailpoint_roles', 'subtemplates') IS NULL
BEGIN
  ALTER TABLE sailpoint_roles ADD subtemplates NVARCHAR(MAX) NOT NULL DEFAULT '';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'sailpoint_roles', N'U') IS NOT NULL
AND COL_LENGTH('sailpoint_roles', 'requestable') IS NULL
BEGIN
  ALTER TABLE sailpoint_roles ADD requestable NVARCHAR(100) NOT NULL DEFAULT '';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'sailpoint_roles', N'U') IS NOT NULL
AND COL_LENGTH('sailpoint_roles', 'matchedAccessProfile') IS NULL
BEGIN
  ALTER TABLE sailpoint_roles ADD matchedAccessProfile NVARCHAR(MAX) NOT NULL DEFAULT '';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'sailpoint_roles', N'U') IS NOT NULL
AND COL_LENGTH('sailpoint_roles', 'entitlementType') IS NULL
BEGIN
  ALTER TABLE sailpoint_roles ADD entitlementType NVARCHAR(255) NOT NULL DEFAULT '';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'sailpoint_roles', N'U') IS NOT NULL
AND COL_LENGTH('sailpoint_roles', 'instructions') IS NULL
BEGIN
  ALTER TABLE sailpoint_roles ADD instructions NVARCHAR(MAX) NOT NULL DEFAULT '';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'sailpoint_roles', N'U') IS NOT NULL
BEGIN
  UPDATE sailpoint_roles
  SET templates = description
  WHERE ISNULL(LTRIM(RTRIM(templates)), '') = '' AND ISNULL(LTRIM(RTRIM(description)), '') <> '';
  UPDATE sailpoint_roles
  SET instructions = entitlements
  WHERE ISNULL(LTRIM(RTRIM(instructions)), '') = '' AND ISNULL(LTRIM(RTRIM(entitlements)), '') <> '';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'roles', N'U') IS NOT NULL
AND COL_LENGTH('roles', 'sailpointRole') IS NULL
BEGIN
  ALTER TABLE roles ADD sailpointRole NVARCHAR(500) NOT NULL DEFAULT '';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'roles', N'U') IS NOT NULL
AND COL_LENGTH('roles', 'templateDisplayTitle') IS NULL
BEGIN
  ALTER TABLE roles ADD templateDisplayTitle NVARCHAR(MAX) NOT NULL DEFAULT '';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'roles', N'U') IS NOT NULL
AND COL_LENGTH('roles', 'publishToSailpoint') IS NULL
BEGIN
  ALTER TABLE roles ADD publishToSailpoint NVARCHAR(10) NOT NULL DEFAULT 'Yes';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'roles', N'U') IS NOT NULL
AND COL_LENGTH('roles', 'affiliate') IS NULL
BEGIN
  ALTER TABLE roles ADD affiliate NVARCHAR(10) NOT NULL DEFAULT '';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'roles', N'U') IS NOT NULL
BEGIN
  UPDATE roles
  SET publishToSailpoint = 'Yes'
  WHERE ISNULL(LTRIM(RTRIM(publishToSailpoint)), '') = '';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'job_categories', N'U') IS NOT NULL
AND COL_LENGTH('job_categories', 'sailpointRole') IS NULL
BEGIN
  ALTER TABLE job_categories ADD sailpointRole NVARCHAR(500) NOT NULL DEFAULT '';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'job_categories', N'U') IS NOT NULL
AND COL_LENGTH('job_categories', 'sailpointRoleReview') IS NULL
BEGIN
  ALTER TABLE job_categories ADD sailpointRoleReview NVARCHAR(50) NOT NULL DEFAULT '';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'template_links', N'U') IS NULL
BEGIN
  CREATE TABLE template_links (
    id NVARCHAR(36) NOT NULL PRIMARY KEY,
    userRecordType NVARCHAR(100) NOT NULL DEFAULT 'Linkable Template',
    templateId NVARCHAR(255) NOT NULL DEFAULT '',
    templateName NVARCHAR(500) NOT NULL DEFAULT '',
    primaryTemplateOwner NVARCHAR(MAX) NOT NULL DEFAULT '',
    templateDisplayTitle NVARCHAR(MAX) NOT NULL DEFAULT '',
    subtemplateId NVARCHAR(255) NOT NULL DEFAULT '',
    subtemplateName NVARCHAR(500) NOT NULL DEFAULT '',
    currentStatus NVARCHAR(50) NOT NULL DEFAULT 'Active'
  );
  CREATE INDEX IX_template_links_templateId ON template_links(templateId);
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'template_links', N'U') IS NOT NULL
AND COL_LENGTH('template_links', 'userRecordType') IS NULL
BEGIN
  ALTER TABLE template_links ADD userRecordType NVARCHAR(100) NOT NULL DEFAULT 'Linkable Template';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'template_links', N'U') IS NOT NULL
AND COL_LENGTH('template_links', 'primaryTemplateOwner') IS NULL
BEGIN
  ALTER TABLE template_links ADD primaryTemplateOwner NVARCHAR(MAX) NOT NULL DEFAULT '';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'template_links', N'U') IS NOT NULL
AND COL_LENGTH('template_links', 'templateDisplayTitle') IS NULL
BEGIN
  ALTER TABLE template_links ADD templateDisplayTitle NVARCHAR(MAX) NOT NULL DEFAULT '';
END
`);
  await activePool.request().query(`
IF OBJECT_ID(N'sp_export_table', N'U') IS NULL
BEGIN
  CREATE TABLE sp_export_table (
    id NVARCHAR(36) NOT NULL PRIMARY KEY,
    rbacCode NVARCHAR(255) NOT NULL DEFAULT '',
    template NVARCHAR(MAX) NOT NULL DEFAULT '',
    serNeeded NVARCHAR(50) NOT NULL DEFAULT '',
    serBlueprintId NVARCHAR(255) NOT NULL DEFAULT '',
    affiliate NVARCHAR(10) NOT NULL DEFAULT ''
  );
  CREATE INDEX IX_sp_export_table_rbacCode ON sp_export_table(rbacCode);
END
`);
  tableColumnsCache.clear();
  schemaEnsured = true;
}

// ----- Column definitions per table -----

const ROLE_COLS = [
  'rbacCode', 'deptCodeId', 'department', 'jobCodeId', 'jobTitle', 'jobCategory',
  'linkedRoleTemplateId', 'linkedRoleTemplateName', 'templateDisplayTitle', 'subtemplateId', 'subtemplateDescription',
  'empNeeded', 'slaNeeded', 'slaBlueprintId', 'blueprintName',
  'trainingTrack', 'trainingTrack2', 'trainingTrack3', 'trainingTrack4', 'trainingTrack5', 'trainingTrack6',
  'sailpointRole',
  'affiliate',
  'publishToSailpoint',
  'status', 'lastEditChangeControlDateReason'
];

const JOB_CAT_COLS = [
  'jobCategoryId', 'jobCategoryName', 'organizationJobCategoryScope', 'description',
  'owningApplication', 'impactedApplications', 'owningWorkgroup', 'otherInterestedWorkgroups',
  'needEMP', 'needSER',
  'linkableTemplateId', 'linkableTemplateName', 'subtemplatesId', 'subtemplatesName',
  'blueprintId', 'blueprintName',
  'trainingTrack1', 'trainingTrack2', 'trainingTrack3', 'trainingTrack4', 'trainingTrack5', 'trainingTrack6',
  'sailpointRole',
  'sailpointRoleReview',
  'preLiveDayInTheLifeActivity', 'postLiveDayInTheLifeActivity', 'userSettingsLab',
  'status', 'lastEditDateReasonInitials'
];

const JOB_CODE_COLS = ['jobCode', 'jobTitle', 'currentStatus'];
const DEPT_COLS = ['deptId', 'deptDescription'];
const TEMPLATE_LINK_COLS = [
  'userRecordType', 'templateId', 'templateName', 'primaryTemplateOwner', 'templateDisplayTitle',
  'subtemplateId', 'subtemplateName', 'currentStatus'
];
const SAILPOINT_ROLE_COLS = [
  'sailpointRole', 'status', 'templates', 'subtemplates', 'requestable', 'matchedAccessProfile', 'entitlementType',
  'instructions', 'description', 'entitlements'
];
const BLUEPRINT_COLS = ['blueprintId', 'blueprintName'];
const TRACK_COLS = ['trackName'];
const SP_EXPORT_COLS = ['rbacCode', 'template', 'serNeeded', 'serBlueprintId', 'affiliate'];

// ----- Generic helpers for normalized tables -----

function str(val) {
  return val != null ? String(val) : '';
}

/** Map logical app column names to actual SQL column names (case-insensitive). */
async function resolveTableColumns(table, logicalCols) {
  const existing = await getExistingTableColumns(table);
  if (!existing || existing.size === 0) {
    throw new Error(`Database table "${table}" does not exist or is not visible.`);
  }
  const lowerToActual = new Map([...existing].map((c) => [String(c).toLowerCase(), c]));
  const resolved = [];
  for (const logical of logicalCols) {
    const actual = lowerToActual.get(String(logical).toLowerCase());
    if (actual) resolved.push({ logical, actual });
  }
  return resolved;
}

function buildSelectCols(resolvedCols) {
  return ['id', ...resolvedCols.map((c) => c.actual)].join(', ');
}

function rowToObj(r, resolvedCols) {
  const obj = { id: r.id };
  for (const { logical, actual } of resolvedCols) {
    const raw = r[actual] ?? r[logical];
    obj[logical] = raw != null ? raw : '';
  }
  return obj;
}

function buildBulkTable(table, resolvedCols, rows) {
  const bulkTable = new sql.Table(table);
  bulkTable.create = false;
  bulkTable.columns.add('id', sql.NVarChar(36), { nullable: false });
  for (const { actual } of resolvedCols) {
    bulkTable.columns.add(actual, sql.NVarChar(sql.MAX), { nullable: false });
  }
  for (const row of rows) {
    const id = row.id || require('crypto').randomUUID();
    bulkTable.rows.add(id, ...resolvedCols.map(({ logical }) => str(row[logical])));
  }
  return bulkTable;
}

async function getExistingTableColumns(table) {
  if (tableColumnsCache.has(table)) return tableColumnsCache.get(table);
  const p = await getPool();
  const result = await p.request()
    .input('table', sql.NVarChar(255), table)
    .query(`
      SELECT COLUMN_NAME
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_NAME = @table
    `);
  const cols = new Set((result.recordset || []).map((r) => (r.COLUMN_NAME || '').toString()));
  tableColumnsCache.set(table, cols);
  return cols;
}

async function getNormTable(table, cols) {
  const resolvedCols = await resolveTableColumns(table, cols);
  if (resolvedCols.length === 0) {
    throw new Error(`Database table "${table}" is missing required columns.`);
  }
  const p = await getPool();
  const result = await p.request().query(`SELECT ${buildSelectCols(resolvedCols)} FROM ${table} ORDER BY id`);
  return (result.recordset || []).map((r) => rowToObj(r, resolvedCols));
}

async function saveNormTable(table, cols, rows) {
  const resolvedCols = await resolveTableColumns(table, cols);
  if (resolvedCols.length === 0) {
    throw new Error(`Database table "${table}" is missing required columns.`);
  }
  const p = await getPool();
  const tx = p.transaction();
  await tx.begin();
  try {
    await tx.request().query(`DELETE FROM ${table}`);
    if (rows.length > 0) {
      await tx.request().bulk(buildBulkTable(table, resolvedCols, rows));
    }
    await tx.commit();
  } catch (e) {
    await tx.rollback();
    throw e;
  }
}

async function insertRows(table, cols, rows) {
  if (rows.length === 0) return;
  const resolvedCols = await resolveTableColumns(table, cols);
  if (resolvedCols.length === 0) {
    throw new Error(`Database table "${table}" is missing required columns.`);
  }
  const p = await getPool();
  await p.request().bulk(buildBulkTable(table, resolvedCols, rows));
}

// ----- Users (fixed columns - unchanged) -----

async function getUsers() {
  const p = await getPool();
  const result = await p.request().query('SELECT id, username, passwordHash, createdAt FROM users ORDER BY username');
  return (result.recordset || []).map((r) => ({
    id: r.id,
    username: r.username,
    passwordHash: r.passwordHash || '',
    createdAt: r.createdAt ? new Date(r.createdAt).toISOString() : ''
  }));
}

async function saveUsers(users) {
  const p = await getPool();
  const tx = p.transaction();
  await tx.begin();
  try {
    await tx.request().query('DELETE FROM users');
    if (users.length > 0) {
      const bulkTable = new sql.Table('users');
      bulkTable.create = false;
      bulkTable.columns.add('id', sql.NVarChar(36), { nullable: false });
      bulkTable.columns.add('username', sql.NVarChar(255), { nullable: false });
      bulkTable.columns.add('passwordHash', sql.NVarChar(255), { nullable: false });
      bulkTable.columns.add('createdAt', sql.DateTime2, { nullable: false });
      for (const u of users) {
        bulkTable.rows.add(
          u.id,
          (u.username || '').trim(),
          u.passwordHash || '',
          u.createdAt ? new Date(u.createdAt) : new Date()
        );
      }
      await tx.request().bulk(bulkTable);
    }
    await tx.commit();
  } catch (e) {
    await tx.rollback();
    throw e;
  }
}

// ----- Roles (normalized columns) -----

async function getRoles() {
  return getNormTable('roles', ROLE_COLS);
}

async function saveRoles(roles) {
  return saveNormTable('roles', ROLE_COLS, roles);
}

// ----- Audit log (normalized; oldData/newData stay as JSON strings) -----

async function getAuditLogs() {
  const p = await getPool();
  const result = await p.request().query(
    'SELECT id, action, log_timestamp, audit_user, roleId, entityType, entityId, oldData, newData, import_count, created_at FROM audit_log ORDER BY id DESC'
  );
  return (result.recordset || []).map(r => {
    const obj = {
      id: r.id,
      action: r.action || '',
      timestamp: r.log_timestamp || '',
      user: r.audit_user || '',
      roleId: r.roleId || ''
    };
    if (r.entityType) obj.entityType = r.entityType;
    if (r.entityId) obj.entityId = r.entityId;
    if (r.oldData) {
      try { obj.oldData = JSON.parse(r.oldData); } catch (_) { obj.oldData = null; }
    }
    if (r.newData) {
      try { obj.newData = JSON.parse(r.newData); } catch (_) { obj.newData = null; }
    }
    if (r.import_count != null) obj.count = r.import_count;
    return obj;
  });
}

function buildAuditBulkTable(logs) {
  const bulkTable = new sql.Table('audit_log');
  bulkTable.create = false;
  bulkTable.columns.add('action', sql.NVarChar(50), { nullable: false });
  bulkTable.columns.add('log_timestamp', sql.NVarChar(50), { nullable: false });
  bulkTable.columns.add('audit_user', sql.NVarChar(255), { nullable: false });
  bulkTable.columns.add('roleId', sql.NVarChar(36), { nullable: false });
  bulkTable.columns.add('entityType', sql.NVarChar(50), { nullable: false });
  bulkTable.columns.add('entityId', sql.NVarChar(36), { nullable: false });
  bulkTable.columns.add('oldData', sql.NVarChar(sql.MAX), { nullable: true });
  bulkTable.columns.add('newData', sql.NVarChar(sql.MAX), { nullable: true });
  bulkTable.columns.add('import_count', sql.Int, { nullable: true });
  for (const entry of logs) {
    bulkTable.rows.add(
      str(entry.action),
      str(entry.timestamp),
      str(entry.user),
      str(entry.roleId),
      str(entry.entityType),
      str(entry.entityId),
      entry.oldData ? JSON.stringify(entry.oldData) : null,
      entry.newData ? JSON.stringify(entry.newData) : null,
      entry.count != null ? entry.count : null
    );
  }
  return bulkTable;
}

async function appendAuditLog(entry) {
  const p = await getPool();
  await p.request()
    .input('action', sql.NVarChar(50), str(entry.action))
    .input('log_timestamp', sql.NVarChar(50), str(entry.timestamp))
    .input('audit_user', sql.NVarChar(255), str(entry.user))
    .input('roleId', sql.NVarChar(36), str(entry.roleId))
    .input('entityType', sql.NVarChar(50), str(entry.entityType))
    .input('entityId', sql.NVarChar(36), str(entry.entityId))
    .input('oldData', sql.NVarChar(sql.MAX), entry.oldData ? JSON.stringify(entry.oldData) : null)
    .input('newData', sql.NVarChar(sql.MAX), entry.newData ? JSON.stringify(entry.newData) : null)
    .input('import_count', sql.Int, entry.count != null ? entry.count : null)
    .query('INSERT INTO audit_log (action, log_timestamp, audit_user, roleId, entityType, entityId, oldData, newData, import_count) VALUES (@action, @log_timestamp, @audit_user, @roleId, @entityType, @entityId, @oldData, @newData, @import_count)');
}

async function replaceAuditLogs(logs) {
  const p = await getPool();
  const tx = p.transaction();
  await tx.begin();
  try {
    await tx.request().query('DELETE FROM audit_log');
    if (logs.length > 0) {
      await tx.request().bulk(buildAuditBulkTable(logs));
    }
    await tx.commit();
  } catch (e) {
    await tx.rollback();
    throw e;
  }
}

// ----- Job Categories (normalized columns) -----

async function getJobCategories() {
  return getNormTable('job_categories', JOB_CAT_COLS);
}
async function saveJobCategories(rows) {
  return saveNormTable('job_categories', JOB_CAT_COLS, rows);
}

// ----- Job Codes (normalized columns) -----

async function getJobCodes() {
  return getNormTable('job_codes', JOB_CODE_COLS);
}
async function saveJobCodes(rows) {
  return saveNormTable('job_codes', JOB_CODE_COLS, rows);
}

// ----- Departments (normalized columns) -----

async function getDepartments() {
  return getNormTable('departments', DEPT_COLS);
}
async function saveDepartments(rows) {
  return saveNormTable('departments', DEPT_COLS, rows);
}

// ----- Template Links (normalized columns) -----

async function getTemplateLinks() {
  return getNormTable('template_links', TEMPLATE_LINK_COLS);
}
async function saveTemplateLinks(rows) {
  return saveNormTable('template_links', TEMPLATE_LINK_COLS, rows);
}

// ----- Sailpoint Roles (normalized columns) -----

async function getSailpointRoles() {
  return getNormTable('sailpoint_roles', SAILPOINT_ROLE_COLS);
}
async function saveSailpointRoles(rows) {
  return saveNormTable('sailpoint_roles', SAILPOINT_ROLE_COLS, rows);
}

// ----- Blueprints (normalized columns) -----

async function getBlueprints() {
  return getNormTable('blueprints', BLUEPRINT_COLS);
}
async function saveBlueprints(rows) {
  return saveNormTable('blueprints', BLUEPRINT_COLS, rows);
}

// ----- Training Tracks (normalized columns) -----

async function getTrainingTracks() {
  return getNormTable('training_tracks', TRACK_COLS);
}
async function saveTrainingTracks(rows) {
  return saveNormTable('training_tracks', TRACK_COLS, rows);
}

// ----- SP Export Table (normalized columns) -----

async function getSPExportTable() {
  return getNormTable('sp_export_table', SP_EXPORT_COLS);
}
async function saveSPExportTable(rows) {
  return saveNormTable('sp_export_table', SP_EXPORT_COLS, rows);
}

// ----- Append helpers -----

function normalize(value) {
  if (value == null) return '';
  let s = String(value).replace(/\s/g, '');
  if (s.length === 0) return '';
  if (s.length > 4) s = s.slice(-4);
  else if (s.length < 4) s = s.padStart(4, '0');
  return s;
}

async function appendJobCodes(toAdd) {
  const current = await getJobCodes();
  const existingCodes = new Set((current || []).map((j) => normalize((j.jobCode || '').toString())));
  const added = [];
  for (const item of toAdd) {
    const code = normalize((item.jobCode || '').toString());
    if (!code) continue;
    if (existingCodes.has(code)) continue;
    existingCodes.add(code);
    added.push({
      id: item.id || require('crypto').randomUUID(),
      jobCode: code,
      jobTitle: (item.jobTitle || '').trim() || '',
      currentStatus: item.currentStatus || 'Active'
    });
  }
  if (added.length === 0) return { added: 0 };
  await insertRows('job_codes', JOB_CODE_COLS, added);
  return { added: added.length };
}

async function appendDepartments(toAdd) {
  const current = await getDepartments();
  const existingIds = new Set((current || []).map((d) => (d.deptId || '').trim().toUpperCase()));
  const added = [];
  for (const item of toAdd) {
    const deptId = (item.deptId || '').trim();
    if (!deptId) continue;
    const key = deptId.toUpperCase();
    if (existingIds.has(key)) continue;
    existingIds.add(key);
    added.push({
      id: item.id || require('crypto').randomUUID(),
      deptId,
      deptDescription: (item.deptDescription || '').trim() || ''
    });
  }
  if (added.length === 0) return { added: 0 };
  await insertRows('departments', DEPT_COLS, added);
  return { added: added.length };
}

async function appendBlueprints(toAdd) {
  const current = await getBlueprints();
  const existingIds = new Set((current || []).map((b) => (b.blueprintId || '').trim().toUpperCase()));
  const added = [];
  for (const item of toAdd) {
    const blueprintId = (item.blueprintId || '').trim();
    if (!blueprintId) continue;
    const key = blueprintId.toUpperCase();
    if (existingIds.has(key)) continue;
    existingIds.add(key);
    added.push({
      id: item.id || require('crypto').randomUUID(),
      blueprintId,
      blueprintName: (item.blueprintName || '').trim() || ''
    });
  }
  if (added.length === 0) return { added: 0 };
  await insertRows('blueprints', BLUEPRINT_COLS, added);
  return { added: added.length };
}

async function appendTrainingTracks(toAdd) {
  const current = await getTrainingTracks();
  const existingNames = new Set(
    (current || []).map((t) => (t.trackName || '').trim().toLowerCase()).filter(Boolean)
  );
  const added = [];
  for (const item of toAdd || []) {
    const trackName = (item.trackName || '').trim();
    if (!trackName) continue;
    const key = trackName.toLowerCase();
    if (existingNames.has(key)) continue;
    existingNames.add(key);
    added.push({
      id: item.id || require('crypto').randomUUID(),
      trackName,
    });
  }
  if (added.length === 0) return { added: 0 };
  await insertRows('training_tracks', TRACK_COLS, added);
  return { added: added.length };
}

async function appendSailpointRoles(toAdd) {
  const current = await getSailpointRoles();
  const existingRoles = new Set((current || []).map((r) => (r.sailpointRole || '').trim().toUpperCase()));
  const added = [];
  for (const item of toAdd) {
    const sailpointRole = (item.sailpointRole || '').trim();
    if (!sailpointRole) continue;
    const key = sailpointRole.toUpperCase();
    if (existingRoles.has(key)) continue;
    existingRoles.add(key);
    added.push({
      id: item.id || require('crypto').randomUUID(),
      sailpointRole,
      status: (item.status || '').trim() || 'Active',
      templates: (item.templates || item.description || '').trim() || '',
      subtemplates: (item.subtemplates || '').trim() || '',
      requestable: (item.requestable || '').trim() || '',
      matchedAccessProfile: (item.matchedAccessProfile || '').trim() || '',
      entitlementType: (item.entitlementType || '').trim() || '',
      instructions: (item.instructions || item.entitlements || '').trim() || '',
      description: (item.description || '').trim() || '',
      entitlements: (item.entitlements || '').trim() || ''
    });
  }
  if (added.length === 0) return { added: 0 };
  await insertRows('sailpoint_roles', SAILPOINT_ROLE_COLS, added);
  return { added: added.length };
}

/**
 * Insert new template_links rows only (does not replace the table).
 * Rows must align with columns in TEMPLATE_LINK_COLS.
 */
async function appendTemplateLinks(toAdd) {
  const rows = [];
  for (const item of toAdd || []) {
    const ut = str(item.userRecordType || '').trim();
    const templateId = str(item.templateId);
    const templateName = str(item.templateName);
    if (!ut || (!templateId.trim() && !templateName.trim())) continue;
    rows.push({
      id: item.id || require('crypto').randomUUID(),
      userRecordType: ut || 'Linkable Template',
      templateId,
      templateName,
      primaryTemplateOwner: str(item.primaryTemplateOwner),
      templateDisplayTitle: str(item.templateDisplayTitle),
      subtemplateId: str(item.subtemplateId),
      subtemplateName: str(item.subtemplateName),
      currentStatus: str(item.currentStatus || 'Active').trim() || 'Active',
    });
  }
  if (rows.length === 0) return { added: 0 };
  await insertRows('template_links', TEMPLATE_LINK_COLS, rows);
  return { added: rows.length };
}

async function close() {
  if (pool) {
    await pool.close();
    pool = null;
  }
}

module.exports = {
  getPool,
  getUsers,
  saveUsers,
  getRoles,
  saveRoles,
  getAuditLogs,
  appendAuditLog,
  replaceAuditLogs,
  getJobCategories,
  saveJobCategories,
  getJobCodes,
  saveJobCodes,
  appendJobCodes,
  getDepartments,
  saveDepartments,
  getTemplateLinks,
  saveTemplateLinks,
  appendTemplateLinks,
  appendDepartments,
  getSailpointRoles,
  saveSailpointRoles,
  appendSailpointRoles,
  getBlueprints,
  saveBlueprints,
  appendBlueprints,
  appendTrainingTracks,
  getTrainingTracks,
  saveTrainingTracks,
  getSPExportTable,
  saveSPExportTable,
  close
};
